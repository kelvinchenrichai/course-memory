@echo off
rem CK_TRADING · 拾課 Course Memory
chcp 65001 >nul
cd /d "%~dp0app"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\Start-Learning.ps1"
