# P4D backup fixtures

全部自製：沒有真實帳號、遠端、課程或媒體內容。

- `courses.json`：測試課程庫。測試時會在暫存資料夾建立 `files` 列出的檔案（內容為假資料、大小如列）；`{root}` 會被替換成該暫存資料夾。內容包含：
  - 兩堂同名課程（id 不同）
  - P4A 管線課程，原始音訊分成兩段
  - Demo 課程
  - 影片指向 `config.json` 的可疑課程
  - 不得上傳的 `cookies.sqlite`、`.part` 與 `secrets` 檔
- `rclone/`：自製的 rclone 輸出樣本：
  - `listremotes --long`
  - `--use-json-log` 的 stats 行
  - 斷網、授權過期的錯誤行
  - `lsjson --hash` 結果

  這些樣本只用來測試解析與錯誤分類，不代表任何真實帳號。
