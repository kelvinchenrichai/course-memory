# Fixtures

全部為自行合成的資料，網址使用 `example.invalid`，不含任何平台頁面內容或真實課程文字。由 Claude 維護；測試需要新案例時向 Claude 提出。

## `domain/`

- `valid/<name>.json`：必須通過 `schemas/<name>.schema.json`。
- `invalid/<name>--<case>.json`：`{ schema, reason, document }`，`document` 必須被該 schema 拒絕。
- 跨文件規則（例：`rightsSnapshot.checkedAt` 晚於 RightsRecord `updatedAt`、TimeMap 數值一致性）schema 無法表達，由程式驗證。

## `timemap/`

| 檔案類型 | 結構 | 呼叫 |
|---|---|---|
| `spans` 型（t01、t03、t04、t05） | `{ spans, expect }` | `recToSrc`、`srcToRec`、`splitRange` |
| `cases` 型（t02） | `{ cases: [{ rate, spans, expect }] }` | 同上 |
| `samples` 型（t06、samples-*） | `{ samples, options, expect: { quality, spans } }` | `buildSpans(samples, options)` |
| `invalid-spans` | `{ cases: [{ spans, expectError }] }` | `normalizeSpans` 必須拋錯，訊息含 `expectError` |
| `samples-missing-endrec` | `expectError` | `buildSpans` 必須拋錯 |

`expect.recToSrc` = `[[rec, src|null], …]`；`expect.srcToRec` = `[[src, [rec…]], …]`；`expect.splitRange` = `[[[recA, recB], [pieces…]], …]`。數值比較容差 1e-6。

### 這些 fixture 釘死的語意

1. **rec 區間半開**：Span 涵蓋 `[recStart, recEnd)`；只有最後一個 Span 含 `recEnd`。邊界點屬於後一個 Span（例：t04 `rec 15 → src 10`、`rec 10 → null`）。
2. **`srcToRec`**：只看 `play` Span；換算出的 `rec` 也必須落在該 Span 的半開區間內（最後一個 Span 閉區間）；結果依 `rec` 遞增；不得重複（t06 `src 10 → [10]`、t03 `src 900 → [630]`）。
3. **`splitRange`**：每一段的 `src` 端點以**該段所屬 Span** 的公式計算，不得用全域查找；`ad`／`preroll` 段 `src = [null, null]`。
4. **`buildSpans`**：
   - `endRec` 必填。
   - `options.recOrigin`（OBS 錄影起點，通常 0）：從 `recOrigin` 到第一個 `play` 樣本之間，以及第一個 `play` 前的所有非播放樣本，都是 `preroll`。
   - 相鄰同類 Span 的 src 接點誤差 `≤ 0.5 s`：合併；`0.5 – 1.0 s`：切段並標 `degraded`（量測漂移）；`> 1.0 s`：視為使用者 seek，切段且**不**降級。
   - `rate` 不同一律切段。
5. **`normalizeSpans` 拒絕**：`play` 的 `rate ≤ 0`、重疊、`recEnd ≤ recStart`、`play` 的 `srcEnd` 與 `srcStart + (recEnd − recStart) × rate` 差 > 0.5 s、`paused`/`buffering` 的 `srcStart ≠ srcEnd`、未知 `kind`。

## `obs/`

obs-websocket v5 協定腳本，語法見 `obs/README.md`，契約見 `docs/P2_OBS_CONTRACT.md`。

## `domain/states/<schema>/`

同一 schema 在不同狀態下的合法範例（例：RecordingSession 的 starting／recording／stopping／completed／partial／failed）。每份都必須通過對應的 schema；之所以不放在 `valid/`，是因為 `valid/` 以檔名對應 schema。

## `agent/`

平台無關的 Agent Runner 情境（P3A），語法見 `agent/README.md`，由 `tests/agent-runner.test.mjs` 執行。

## `companion/`

Companion 協定測資：命令生命週期（對應、重複、逾時、舊 instance、分頁錯誤），以及夾帶 Cookie、Token、DOM 的惡意回報，用來證明 allowlist 會把它們濾掉。由 `tests/companion.test.mjs` 執行。

## `platform/`

自建的頁面描述（JSON DOM 樹，不是平台的原始 HTML），供 `tests/helpers/fake-dom.mjs` 建構假頁面使用。

- `generic-html5/`：單一、沒有、多個 `<video>`；倍速被鎖住；沒有字幕；SPA 換頁。
- `youtube/`：播放清單、單支影片、廣告、登入、CAPTCHA、付費提示、selector 改版、快捷鍵失效、控制項全部失效、沒有字幕、首頁。`youtube` 區塊用來設定假頁面的行為。

## `pipeline/`、`transcript/`（P4A）

- `pipeline/` 是本機轉錄管線的情境、PipelineJob 範例、ffmpeg 裝置清單文字與自製短音訊，語法見 `pipeline/README.md`。
- `transcript/*.transcript.json` 是管線產出的 TranscriptTrack revision 1（重看、倍速切換加暫停），必須通過 `schemas/transcript-track.schema.json`，cue 時間也必須單調。

## `domain/valid/`、`domain/invalid/`：P9 直播錄製（v1 schema）

六個新的版本化 schema：`live-source`、`live-plan`、`live-session`、`live-segment`、`signal-event`、`highlight-candidate`（`$id` 為 `https://schemas.course-memory.local/v1/<名稱>.schema.json`）。每個 schema 在 `valid/` 都有一份合法範例；`invalid/<schema>--<情境>.json` 的格式是 `{ schema, document }`，必須被拒絕。兩者都由 `tests/claude-fixtures.test.mjs` 自動驗證。

| 不合法範例 | 驗證的規則 |
|---|---|
| `live-source--token-in-url` | 直播頁網址不得帶 token、signature、auth 等參數 |
| `live-source--hidden-stream-url` | 不得是 `.m3u8`／`.mpd`／`.flv` 等串流檔網址 |
| `live-source--cookie-field` | 不得有 cookie、帳密等欄位（`additionalProperties: false`） |
| `live-plan--segment-too-short` | 分段長度為 2–60 分鐘 |
| `live-plan--no-timezone` | 必須有 IANA 時區 |
| `live-session--recording-without-obs-confirmation` | `recording` 狀態必須有 `actualStartAt`、`obs.state = recording`，且 `startedByUs = true` |
| `live-session--blocked-without-blocker` | `blocked` 狀態必須說明原因 |
| `live-segment--verified-while-recording` | 仍在錄的分段不可能已上傳或已驗證 |
| `live-segment--full-path-name` | `file.name` 只能是檔名，不能是完整路徑 |
| `signal-event--unknown-source` | 來源只能是 manual／audio／transcript／visual／chat／platform／system |
| `highlight-candidate--no-signals` | 候選片段至少要引用一個訊號 |
| `highlight-candidate--auto-published` | 只有 pending-review／approved／rejected，沒有「已發布」 |

`tests/p9-live.test.mjs` 另外會把服務實際寫入 `data/live/state.json` 的每一筆紀錄，都拿去對應的 schema 驗證。
