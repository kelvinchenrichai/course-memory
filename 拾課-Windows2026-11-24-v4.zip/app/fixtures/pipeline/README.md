# P4A pipeline fixtures

全部自製，沒有任何課程內容或平台資料。

| 路徑 | 內容 | 使用者 |
|---|---|---|
| `scenarios/*.json` | 端到端情境：來源（audio／video／import）、輸入檔（假長度、有無影音軌）、TimeMap、錄音中「聽得到」的話（`utterances`，rec 時間）與預期結果 | `tests/pipeline.test.mjs` |
| `jobs/*.json` | 合法的 PipelineJob（由情境產生，路徑改成假 Windows 路徑） | `tests/pipeline-schemas.test.mjs` |
| `invalid/*.json` | `{ schema, reason, document }`，必須被 schema 拒絕 | 同上 |
| `dshow/*.txt` | 自製的 `ffmpeg -list_devices true -f dshow -i dummy` 輸出（新版 `(audio)` 格式、舊版分區格式、沒有音訊裝置） | `tests/audio-capture.test.mjs` |
| `media/tone-2s.wav` | 2 秒 440 Hz 正弦波（每 0.5 s 靜音交替），mono 16 kHz PCM，由 `synthWav()` 產生 | ffmpeg smoke test（沒裝 ffmpeg 時跳過） |
| `python-stub/faster_whisper/` | 測試用的假 `faster_whisper` 模組：不下載、不載入模型，只回傳固定段落 | `scripts/transcribe.py` 的端到端測試（透過 `PYTHONPATH`） |

## scenarios 語法

```json
{
  "source": "video",
  "files": [{ "name": "lesson.mkv", "durationSec": 62, "audio": true, "video": true }],
  "timeMap": { "source": "recording", "spans": [ ... ] },
  "utterances": [{ "rec": [5, 9], "text": "Hello class", "words": [{ "w": " Hello", "rec": [5, 6] }] }],
  "expect": {
    "strategy": "direct",
    "atempo": [[0.5]],
    "segments": [{ "text": "Hello class", "rec": [5, 9], "src": [3, 7], "pass": 1 }],
    "excluded": { "preroll": 1 },
    "recCues": 2,
    "srcCues": 2,
    "srcOverlaps": 0
  }
}
```

`timeMap` 的寫法：

- 省略：匯入檔，視為 identity。
- `{ "source": "none" }`：沒有 TimeMap，src 為 null。

假的 Whisper（`tests/helpers/fake-process.mjs`）只「聽得到」實際送進它的音訊：

- 1× 整檔轉錄時，它也會聽到暫停或廣告期間的聲音，之後由對時邏輯剔除。
- 逐 Span 還原時，這段聲音根本不會被切進去。
