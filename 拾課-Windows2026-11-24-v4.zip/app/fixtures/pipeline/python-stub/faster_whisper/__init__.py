"""Test-only stand-in for faster-whisper (no model, no download). Used by tests/pipeline-providers.test.mjs
via PYTHONPATH to exercise scripts/transcribe.py end to end. Never on the production path."""
import os
from types import SimpleNamespace

__version__ = "0.0.0-fixture"


class WhisperModel:
    def __init__(self, model, device="auto", compute_type="int8"):
        if os.environ.get("CMS_STUB_FAIL") == "load":
            raise RuntimeError("stub load failure")
        self.model = model

    def transcribe(self, path, language=None, vad_filter=True, beam_size=5, word_timestamps=True):
        words = [SimpleNamespace(word=" Hello", start=0.5, end=0.9, probability=0.98), SimpleNamespace(word=" class", start=0.95, end=1.4, probability=0.91)]
        segments = [
            SimpleNamespace(id=1, start=0.5, end=1.4, text=" Hello class", avg_logprob=-0.21, no_speech_prob=0.02, compression_ratio=1.1, words=words if word_timestamps else None),
            SimpleNamespace(id=2, start=2.0, end=2.6, text=" 你好", avg_logprob=-1.4, no_speech_prob=0.7, compression_ratio=0.9, words=[] if word_timestamps else None),
        ]
        info = SimpleNamespace(language=language or "en", language_probability=0.97, duration=3.0)
        return iter(segments), info
