# OBS 協定 fixtures

全部為自建資料。路徑使用 `C:\Fixture\…`；`connect-auth.json` 與 `auth-failure.json` 中的密碼是**測試專用假值**（`fixtureOnly`），不是任何真實 OBS 密碼。每個檔案的 `basis.official` 與 `basis.design` 分別列出依據的官方事實與本專案的設計決定；來源版本記在 `source`。

## 檔案結構

```json
{ "id": "...", "description": "...", "source": "...",
  "basis": { "official": ["..."], "design": ["..."] },
  "options": { "url": "ws://127.0.0.1:4455", "password": null | { "fixtureOnly": "..." }, "timeouts": { ... } },
  "steps": [ ... ],
  "cases": [ { "name": "...", "steps": [ ... ], "finalState": "..." } ],
  "expectFinal": { "state": "ready|closed", "pendingRequests": 0, "activeTimers": 0, "recording": false, "logMustNotContain": ["..."] } }
```

有 `cases` 時逐案執行（每案都是新的 client），且每案都要符合 `expectFinal`，但 `state` 以該案的 `finalState` 為準。`options.password` 由測試轉成 `getPassword()`。

## 步驟語法（依序執行）

| 步驟 | 意義 |
|---|---|
| `{"call": {"method": "startRecord", "as": "s"}}` | 呼叫 client 方法，把回傳的 Promise 記為 `s`（不 await） |
| `{"server": <msg>}` | fake 伺服器送出文字訊框 `JSON.stringify(<msg>)`，並先替換其中的 `{"$ref": "name"}` |
| `{"serverRaw": "<text>"}` | 送出原樣文字訊框（用於非 JSON） |
| `{"serverBinary": "<base64>"}` | 送出二進位訊框 |
| `{"serverClose": {"code": 1006, "reason": ""}}` | 伺服器端關閉連線 |
| `{"client": <pattern>}` | 自上一個檢查點以來，client 必須**恰好**送出 1 則訊息，且符合 pattern |
| `{"expectNoClientMessage": true}` | 自上一個檢查點以來，client 沒有送出任何訊息 |
| `{"expectClientClose": {"code": 1000}}` | client 曾以此關閉碼主動關閉 |
| `{"advance": 5000}` | 假時鐘前進 N 毫秒，觸發到期的計時器 |
| `{"expectPending": "s"}` | `s` 仍未 settle |
| `{"expectResult": {"of": "s", "resolves": {...}}}` | `s` 已 resolve，且結果**包含**所列欄位（部分比對） |
| `{"expectResult": {"of": "s", "rejects": {"code": "...", ...}}}` | `s` 已 reject，且 ObsError 包含所列欄位 |
| `{"expectEmitted": {"event": "...", "value": {...}}}` | client 曾 emit 該事件，且值包含所列欄位 |
| `{"expectNotEmitted": {"event": "..."}}` | 前一個伺服器訊息沒有觸發該事件 |
| `{"expectLog": {"level": "warn", "event": "..."}}` | logger 曾以該 level 記錄該結構化事件 |
| `{"burst": {"method": "...", "count": 100, "expectUniqueRequestIds": true}}` | 連續呼叫 N 次；fake 伺服器對每個請求回成功；所有 requestId 必須互異 |

## Pattern

| 寫法 | 意義 |
|---|---|
| 一般值 | 必須相等 |
| `"$string"` | 非空字串 |
| `"$any"` | 任意值 |
| `"$absent"`（作為物件屬性值） | 該鍵**不得**存在 |
| `"$optional"`（作為物件屬性值） | 該鍵可有可無 |
| `{"$capture": "r1"}` | 必須是非空字串，並記為 `r1`，供之後的 `{"$ref": "r1"}` 使用 |

物件比對採**精確鍵集**：client 訊息不得出現 pattern 沒列出的鍵（`$optional` 除外）。

## 一致性

這組 fixture 已由 Claude 用一份獨立的參考實作逐案跑過，全部通過；把期望值故意改壞的版本則會被抓出。Codex 的 `fake-obs` 測試應直接載入這些檔案，不要另外複製期望值。
