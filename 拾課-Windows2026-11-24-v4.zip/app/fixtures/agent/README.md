# Agent Runner fixtures

自建情境，由 `tests/agent-runner.test.mjs` 逐一執行。所有外部相依（player、capture、store、network、disk、clock）都是 `tests/helpers/agent-fakes.mjs` 裡的假物件：不開瀏覽器、不連 OBS、不連網站、不等待真實時間。

## 結構

```json
{ "id": "...", "description": "...", "captureMode": "audio|video",
  "env": { "lessons": { "A1": { "durationSec": 4 } }, "rights": [ ... ], "options": { ... } },
  "draft": { "items": [ ... ], "captureMode": "...", "rate": 2, "captions": { ... }, "cloudBackup": { ... } },
  "steps": [ ... ] }
```

有 `cases` 時逐案執行，每一案都從乾淨的假環境開始；案例層的 `options` 會覆寫 `env.options`。假播放器的原影片時間只在播放中前進，前進速度為「經過時間 × 倍速」；4 秒的章節在 2× 下約 2 秒播完。

## 步驟

| 步驟 | 意義 |
|---|---|
| `{"do": "createDraft"\|"requestConfirmation"\|"confirm"\|"start"\|"resume"\|"cancel"}` | 呼叫 Runner。`expectError` 表示必須以該代碼失敗。`confirm` 可帶 `acknowledgements`，或 `planHash: "tampered"` |
| `{"advance": ms}` | 假時鐘以每 500 ms 為一步前進 |
| `{"advanceUntil": {"completedLessons": n, "maxMs": ms}}` | 前進直到已完成 n 章 |
| `{"runUntilSettled": {"maxMs": ms}}` | 前進直到 `start()`／`resume()` 回傳 |
| `{"set": {...}}` | `network`（會觸發 change 事件）、`networkSilently`（只改狀態，等下一次輪詢偵測）、`player`、`disk`、`rights` |
| `{"onLessonCompleted": {"count": n, "set": {...}}}` | 第 n 章完成並通知 UI 的當下套用設定，用來模擬「下一章開始前」的變化 |
| `{"fail": {"player.setRate": 2}}` | 讓該動作失敗 N 次；`{"capture.start": {"times": 1, "code": "..."}}` 則以指定錯誤碼失敗 |
| `{"emit": {"capture": "disconnected"\|"stoppedExternally"\|"paused"}}` | capture adapter 發出事件 |
| `{"mark": "name"}` | 標記呼叫紀錄的位置，供之後的 `since` 使用 |
| `{"seedCompletedLesson": "A1"}` | 預先放入一個已完成的 session |
| `expectJob`／`expectSessions` | 部分比對；`"$lesson:A1"` 會被換成該章的 `lessonId` |
| `expectOrder` | `strict: true` 時，只抽出停止流程相關的呼叫（player.pause/play、capture.start/stop、store.saveSession/saveCheckpoint、終態 saveJob、終態 notify），必須**完全等於** `sequence` |
| `expectNoCalls`／`expectCount`／`expectNavigation` | 對呼叫紀錄做檢查 |
| `expectTimeMap`／`expectTimeMapKinds`／`expectCheckpointSourceTime` | 檢查 TimeMap 與檢查點 |
| `expectSchemaValid` | AgentJob 與所有 RecordingSession 必須通過 `schemas/` |
| `expectNoSecrets` | store 收到的所有寫入都不得含列出的字串，也不得含 password／cookie／token／authorization 鍵 |
| `expectTransitionError`／`expectTransitionOk` | 直接驗證狀態轉換表 |

每個情境結束時，假時鐘上不得殘留計時器。
