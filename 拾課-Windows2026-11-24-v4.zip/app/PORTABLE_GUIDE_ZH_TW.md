# 拾課可攜版快速開始

完整繁中說明請讀同層的 `可攜版使用說明.md`；AI／Codex／Claude 操作規範請讀 `docs/AI_AGENT_OPERATION_ZH_TW.md`。

1. 解壓縮到 `C:\CourseMemory`。
2. 右鍵執行 `Setup.ps1`；它會準備必要工具，並下載及驗證約 488 MB 的 whisper.cpp 備援模型。
3. 依 `OBS-設定指南.md` 設定 OBS WebSocket、顯示器擷取與桌面音訊。
4. Chrome 的 `chrome://extensions` 開啟開發人員模式，載入 `extension` 資料夾。
5. 執行 `Start-Learning.ps1`，在 `http://127.0.0.1:4317` 完成環境檢查。Codex／有完整 Windows 與 Chrome 操作能力的 Agent 可在使用者允許後協助安裝 Companion；Claude 或無此能力的 Agent 只負責提示，使用者完成瀏覽器操作。Agent 最後負責產生配對碼與驗證。
6. 只錄製已取得授權的內容。無人值守使用 OBS 專用 Chrome 視窗擷取與 Runner；播放器全螢幕只限有人在場的單支人工錄影。

本 ZIP 刻意不含 `config.json`、帳密／金鑰、Google Drive 登入、影片、逐字稿、個人資料、Python／Node 套件及大型模型。新電腦必須自行重新設定。

## 翻譯與重點整理

- 基礎模式是預設值，不需要 AI；逐字稿、字幕、搜尋與規則式重點整理仍可使用。
- 本機 AI 使用 Ollama。使用者需自行安裝 Ollama 並下載模型，逐字稿不離開電腦。
- 外部 AI 使用使用者自己的 OpenAI／Gemini 金鑰；必須在設定頁明確允許傳送逐字稿。
- 翻譯與 AI 重點整理是獨立開關。任何 AI 故障都不能阻止錄影、轉錄與基礎整理。
