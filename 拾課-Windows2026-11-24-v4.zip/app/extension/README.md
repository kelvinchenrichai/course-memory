# Course Memory Companion（MV3）

讓本機的 Course Memory Studio 控制**你正在看的那支影片**：播放、暫停、倍速、字幕，以及播放清單中的下一部。範圍只限你允許的網域、你選定的分頁。

## 不做的事

- 不讀取 Cookie、Token、密碼，也不讀取頁面的 localStorage／sessionStorage。
- 不下載影片，不讀取媒體網址或 DRM 資訊，不攔截網路請求。
- 不點擊「略過廣告」、按讚、留言、訂閱或「標記完成」。
- 不會在安裝時要求任何網站權限。

## 安裝（開發版）

1. Chrome／Edge 開啟 `chrome://extensions`，開啟「開發人員模式」。
2. 選「載入未封裝項目」，選擇本資料夾 `extension/`。

## 使用

1. 啟動 Course Memory Studio，在「課程佇列 → 瀏覽器 Companion」按「產生配對碼」。
2. 點擴充功能圖示，輸入 6 位數配對碼。
3. 開啟課程頁，按「允許此網域」，再按「使用此分頁」。
4. 在 Course Memory Studio 建立工作並確認後開始。

## 架構

| 檔案 | 角色 |
|---|---|
| `background.mjs` | service worker：處理配對、輪詢命令、導航已綁定的分頁、注入內容腳本 |
| `companion.mjs` | 與本機伺服器通訊的用戶端，不依賴 chrome API，可以在 Node 中測試 |
| `content.mjs` | 頁面內的分派器，只注入到已綁定、已授權的分頁 |
| `dispatch.mjs` | 把命令交給 adapter 執行，並套用 allowlist |
| `adapters/generic-html5.mjs` | 通用 `<video>` adapter |
| `adapters/youtube.mjs`＋`youtube-selectors.json` | YouTube adapter；所有 selector 都集中在 JSON 中 |
| `popup.html`／`popup.mjs` | 配對、連線狀態、目前網域偵測、授權網域、選擇分頁 |

通訊協定見 `docs/API.md` 的「Companion」一節。未決事項見 `docs/P3B_OPEN_QUESTIONS.md`。

## 0.4.0：匯入課程清單（P7A）

新增唯讀指令 `discover`。它只讀取選定分頁中看得到的課程清單（標題、順序、課程頁連結、時長），不會播放、點擊、捲動或切換頁面，也不讀取 cookie、儲存空間、輸入欄位或影片檔網址。沒有新增任何權限。更新後請在 `chrome://extensions` 重新載入擴充功能。

## 0.5.0：設定精靈與多平台（P8）

- 新增 Bilibili adapter，選擇器集中在 `adapters/bilibili-selectors.json`。
  - 只透過播放器原生的播放鍵、倍速選單、字幕選單與「下一個」按鈕操作。
  - 不會呼叫 `video.play()`，也不會寫入 `playbackRate`。
  - 課程以 BV 號加分P（p）辨識。
- 新增 `adapters/page-blockers.mjs`，YouTube 以外的平台共用：
  - 出現 CAPTCHA 或登入對話框時，一律停止。
  - 頁面只有「請先登入」「立即購買」這類文字時，只在找不到播放器的情況下才停止，避免已購買課程旁的推銷橫幅誤停。
  - 不會讀取任何輸入欄位。
- Skool、知識衛星與其他 HTML5 網站沿用 generic adapter，回報平台名稱：
  - 偵測到單一播放器時自動播放；
  - 瀏覽器擋下自動播放時回報 `PLAYBACK_BLOCKED`，請使用者自己按一次播放；
  - 嵌入式 iframe 播放器交給使用者操作。
- 沒有新增任何權限。請在 `chrome://extensions` 重新載入擴充功能，設定精靈會要求 0.5.0 以上。
