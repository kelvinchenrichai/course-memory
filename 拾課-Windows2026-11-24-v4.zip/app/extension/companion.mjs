import { sanitizeResult, sanitizeState } from './adapters/common.mjs';

const TOKEN_KEY = 'companionToken';
const TAB_ERRORS = new Set(['TAB_CLOSED', 'TAB_NOT_BOUND', 'PERMISSION_MISSING', 'CONTENT_NOT_READY']);
const COMMAND_ID = /^[0-9a-f]{32}$/;
const silent = { info() {}, warn() {}, error() {} };

/**
 * Extension-side Companion client (pure; chrome.* is injected by background.mjs).
 * - Talks only to http://127.0.0.1 / localhost.
 * - Keeps the pairing token in extension local storage and never logs it.
 * - Executes each commandId at most once, drops expired commands, never resends results on its own.
 */
export function createCompanionClient({ fetch, storage, clock, serverUrl = 'http://127.0.0.1:4317', executeCommand, getOnline = () => true, logger = silent, extensionVersion = '0.0.0', pollWaitMs = 20_000, heartbeatMs = 5_000, clientName = 'Course Memory Companion' } = {}) {
  const base = new URL(serverUrl);
  if (base.protocol !== 'http:' || !['127.0.0.1', 'localhost'].includes(base.hostname)) throw new Error('Companion server must be http://127.0.0.1 or http://localhost');
  const executed = new Set(); let token = null; let instanceId = null; let running = false; let connected = false; let lastError = null; let heartbeatTimer = null; let generation = 0;
  const log = (level, event, extra = {}) => logger[level]?.({ event, ...extra });
  const sleep = (ms) => new Promise((resolve) => clock.setTimeout(resolve, ms));
  const remember = (id) => { executed.add(id); if (executed.size > 1000) executed.delete(executed.values().next().value); };

  async function request(path, { method = 'GET', body, auth = true, timeoutMs = 15_000 } = {}) {
    const headers = { 'content-type': 'application/json' };
    if (auth) { if (!token) throw Object.assign(new Error('not paired'), { code: 'NOT_PAIRED' }); headers['x-companion-token'] = token; }
    const response = await fetch(new URL(path, base).toString(), { method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal: typeof AbortSignal?.timeout === 'function' ? AbortSignal.timeout(timeoutMs) : undefined });
    let data = null; try { data = await response.json(); } catch {}
    if (response.status === 401 && auth) { await forget('unauthorized'); }
    return { status: response.status, data };
  }

  async function forget(reason) { token = null; connected = false; running = false; generation += 1; await storage.remove(TOKEN_KEY); log('warn', 'companion_unpaired', { reason }); }

  async function load() { token = (await storage.get(TOKEN_KEY)) || null; return Boolean(token); }

  async function pair(code) {
    const { status, data } = await request('/api/companion/pair', { method: 'POST', body: { code: String(code || '').trim(), clientName }, auth: false });
    if (status !== 200 || typeof data?.token !== 'string') { lastError = data?.error || 'PAIRING_FAILED'; log('warn', 'pairing_failed', { status }); return { ok: false, error: lastError }; }
    token = data.token; instanceId = data.instanceId; await storage.set(TOKEN_KEY, token); lastError = null; log('info', 'paired');
    return { ok: true };
  }

  async function unpair() { try { if (token) await request('/api/companion/unpair', { method: 'POST', body: {} }); } catch {} await forget('user'); return { ok: true }; }

  async function heartbeat() {
    try {
      const { status, data } = await request('/api/companion/heartbeat', { method: 'POST', body: { online: Boolean(getOnline()), extensionVersion } });
      connected = status === 200; if (connected && data?.instanceId) adoptInstance(data.instanceId);
    } catch { connected = false; lastError = 'SERVER_UNREACHABLE'; }
  }

  function adoptInstance(next) {
    if (instanceId && next !== instanceId) log('info', 'server_restarted');
    instanceId = next;
  }

  async function postResult(command, payload) {
    try { await request(`/api/companion/commands/${command.commandId}/result`, { method: 'POST', body: { instanceId: command.instanceId, ...payload } }); }
    catch { log('warn', 'result_not_delivered', { type: command.type }); }
  }

  async function handle(command) {
    if (!command || !COMMAND_ID.test(command.commandId || '') || typeof command.type !== 'string') return;
    if (command.instanceId !== instanceId) { log('warn', 'stale_command_dropped'); return; }
    if (executed.has(command.commandId)) { log('warn', 'duplicate_command_ignored'); return; }
    remember(command.commandId);
    const ttl = Number(command.ttlMs) || 0;
    if (ttl <= 0) { await postResult(command, { error: 'EXPIRED' }); return; }
    let expired = false; let timer;
    const timeout = new Promise((resolve) => { timer = clock.setTimeout(() => { expired = true; resolve(null); }, ttl); });
    let outcome;
    try { outcome = await Promise.race([Promise.resolve().then(() => executeCommand(command)), timeout]); }
    catch (error) { clock.clearTimeout(timer); await postResult(command, { error: TAB_ERRORS.has(error?.code) ? error.code : 'EXECUTION_FAILED' }); return; }
    clock.clearTimeout(timer);
    if (expired) { await postResult(command, { error: 'EXPIRED' }); return; }
    await postResult(command, { result: command.type === 'getState' ? { ok: true, state: sanitizeState(outcome?.state) } : sanitizeResult(outcome) });
  }

  async function pollLoop(myGeneration) {
    let backoff = 1000;
    while (running && myGeneration === generation) {
      try {
        const { status, data } = await request(`/api/companion/commands?waitMs=${pollWaitMs}`, { timeoutMs: pollWaitMs + 10_000 });
        if (!running || myGeneration !== generation) break;
        if (status !== 200) { connected = false; await sleep(backoff); backoff = Math.min(backoff * 2, 10_000); continue; }
        connected = true; backoff = 1000; adoptInstance(data.instanceId);
        // A navigation command can spend many seconds waiting for the new page to finish loading.
        // Keep the long-poll loop alive while that command runs, otherwise the local hub's
        // liveness watchdog can mistake the busy extension for a disconnected one and stop a job
        // before recording starts.  Results are still matched by commandId and executed once.
        for (const command of Array.isArray(data.commands) ? data.commands : []) void handle(command);
      } catch { connected = false; lastError = 'SERVER_UNREACHABLE'; await sleep(backoff); backoff = Math.min(backoff * 2, 10_000); }
    }
  }

  function scheduleHeartbeat() { if (!running) return; heartbeatTimer = clock.setTimeout(async () => { await heartbeat(); scheduleHeartbeat(); }, heartbeatMs); }

  async function start() {
    if (running) return true; if (!token && !(await load())) return false;
    running = true; generation += 1; const mine = generation; pollLoop(mine); await heartbeat(); scheduleHeartbeat(); return true;
  }

  function stop() { running = false; generation += 1; if (heartbeatTimer != null) clock.clearTimeout(heartbeatTimer); heartbeatTimer = null; }

  return {
    pair, unpair, start, stop, load, heartbeat, handle,
    async reportTabs(tabs) { try { await request('/api/companion/tabs', { method: 'POST', body: { tabs } }); } catch {} },
    async reportState(tabId, state) { try { await request('/api/companion/state', { method: 'POST', body: { tabId, state: sanitizeState(state) } }); } catch {} },
    status: () => ({ paired: Boolean(token), connected, running, lastError, serverInstance: instanceId ? 'known' : 'unknown' })
  };
}
