import { sanitizeResult, sanitizeState } from './adapters/common.mjs';

const HANDLERS = {
  detect: (adapter) => adapter.detect(),
  getState: async (adapter) => ({ ok: true, state: await adapter.getState() }),
  verifyPage: (adapter, args) => adapter.verifyPage({ platformLessonId: args.platformLessonId, url: args.url }),
  setRate: (adapter, args) => adapter.setRate(Number(args.rate)),
  enableCaptions: (adapter, args) => adapter.enableCaptions({ languages: Array.isArray(args.languages) ? args.languages : [] }),
  play: (adapter) => adapter.play(),
  pause: (adapter) => adapter.pause(),
  nextLesson: (adapter) => adapter.nextLesson(),
  // P7A: read-only course-list discovery. Never touches the player (no play/pause/rate/navigation).
  discover: async (adapter, args, env) => (typeof env.discover === 'function' ? { ok: true, discovery: await env.discover() } : { ok: false, reason: 'UNSUPPORTED' })
};

/** Runs one Companion command against an in-page adapter and returns an allowlisted result. */
export async function dispatchCommand(adapter, type, args = {}, env = {}) {
  const handler = HANDLERS[type];
  if (!handler || !adapter) return { ok: false, reason: 'UNSUPPORTED' };
  try {
    const result = await handler(adapter, args || {}, env || {});
    return type === 'getState' ? { ok: true, state: sanitizeState(result.state) } : sanitizeResult(result);
  } catch { return { ok: false, reason: 'EXECUTION_FAILED' }; }
}
