// MV3 service worker. Glue between chrome.* APIs and the pure Companion client.
// Permissions: storage, scripting, activeTab, alarms; host access only to localhost plus origins the
// user grants one by one (optional_host_permissions). No cookies, webRequest, downloads, history or tabs.
import { createCompanionClient } from './companion.mjs';

const SERVER_URL = 'http://127.0.0.1:4317';
const clock = { now: () => Date.now(), setTimeout: (fn, ms) => setTimeout(fn, ms), clearTimeout: (id) => clearTimeout(id) };
const storage = {
  get: async (key) => (await chrome.storage.local.get(key))[key],
  set: (key, value) => chrome.storage.local.set({ [key]: value }),
  remove: (key) => chrome.storage.local.remove(key)
};
// Only event names reach the console; payloads (tokens, pages) are never logged.
const logger = { info: (e) => console.info('[companion]', e.event), warn: (e) => console.warn('[companion]', e.event), error: (e) => console.error('[companion]', e.event) };
const tabError = (code) => Object.assign(new Error(code), { code });

let boundTabId = null;

async function loadBinding() { boundTabId = (await chrome.storage.session.get('boundTabId')).boundTabId ?? null; }
async function setBinding(tabId) { boundTabId = tabId; await chrome.storage.session.set({ boundTabId: tabId }); await reportTabs(); }

async function originGranted(url) {
  try { const { origin, protocol } = new URL(url); if (!['http:', 'https:'].includes(protocol)) return false; return await chrome.permissions.contains({ origins: [`${origin}/*`] }); } catch { return false; }
}

async function ensureInjected(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) throw tabError('TAB_CLOSED');
  if (!(await originGranted(tab.url))) throw tabError('PERMISSION_MISSING');
  await chrome.scripting.executeScript({ target: { tabId }, files: ['content.mjs'] });
}

function waitForComplete(tabId, timeoutMs = 25_000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); reject(tabError('CONTENT_NOT_READY')); }, timeoutMs);
    function listener(id, info) { if (id === tabId && info.status === 'complete') { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(listener); resolve(); } }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function executeCommand(command) {
  if (boundTabId == null || command.tabId !== boundTabId) throw tabError('TAB_NOT_BOUND');
  if (command.type === 'navigate') {
    const url = command.args?.url;
    if (!url || !(await originGranted(url))) throw tabError('PERMISSION_MISSING');
    const current = await chrome.tabs.get(boundTabId).catch(() => null);
    // Do not reload the lesson that is already open. Besides preserving the user's current
    // position, this avoids a needless content-script disconnect during Runner startup.
    if (current?.url && new URL(current.url).href === new URL(url).href) {
      await ensureInjected(boundTabId);
      return { ok: true };
    }
    await chrome.tabs.update(boundTabId, { url });
    await waitForComplete(boundTabId);
    await ensureInjected(boundTabId);
    return { ok: true };
  }
  await ensureInjected(boundTabId);
  const response = await chrome.tabs.sendMessage(boundTabId, { kind: 'cm-command', type: command.type, args: command.args || {} }).catch(() => null);
  if (!response) throw tabError('CONTENT_NOT_READY');
  return response;
}

const client = createCompanionClient({ fetch: (...args) => fetch(...args), storage, clock, serverUrl: SERVER_URL, executeCommand, getOnline: () => navigator.onLine, logger, extensionVersion: chrome.runtime.getManifest().version });

async function reportTabs() {
  if (boundTabId == null) return client.reportTabs([]);
  const tab = await chrome.tabs.get(boundTabId).catch(() => null);
  if (!tab) { boundTabId = null; await chrome.storage.session.remove('boundTabId'); return client.reportTabs([]); }
  let origin = null; try { origin = new URL(tab.url).origin; } catch {}
  return client.reportTabs([{ tabId: tab.id, origin, bound: true, permissionGranted: await originGranted(tab.url) }]);
}

chrome.tabs.onRemoved.addListener((tabId) => { if (tabId === boundTabId) setBinding(null); });
// Re-inject into the bound tab whenever it finishes loading (refresh / SPA reload / extension reload),
// so the page keeps reporting state and the service worker stays awake to receive commands.
async function reinjectBound() { if (boundTabId == null) return; try { await ensureInjected(boundTabId); } catch {} }
chrome.tabs.onUpdated.addListener((tabId, info) => { if (tabId === boundTabId && info.status === 'complete') reinjectBound(); });
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (message?.kind === 'cm-state' && sender.tab?.id === boundTabId) { client.reportState(boundTabId, message.state); return false; }
  if (message?.kind !== 'popup') return false;
  (async () => {
    switch (message.action) {
      case 'status': return { ...client.status(), boundTabId };
      case 'pair': { const result = await client.pair(message.code); if (result.ok) await client.start(); return result; }
      case 'unpair': client.stop(); await setBinding(null); return client.unpair();
      case 'bind': {
        const tab = await chrome.tabs.get(message.tabId).catch(() => null);
        if (!tab || !(await originGranted(tab.url))) return { ok: false, error: 'PERMISSION_MISSING' };
        await setBinding(tab.id); await ensureInjected(tab.id); return { ok: true };
      }
      case 'unbind': await setBinding(null); return { ok: true };
      default: return { ok: false, error: 'UNKNOWN_ACTION' };
    }
  })().then(sendResponse, () => sendResponse({ ok: false, error: 'FAILED' }));
  return true;
});

// MV3 service workers can be suspended; an alarm restarts the loops. Jobs never auto-resume: the server
// marks them blocked when the Companion goes silent and only the user can continue.
chrome.alarms.create('companion-keepalive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => { if (alarm.name === 'companion-keepalive') client.start().then(reinjectBound).then(reportTabs); });
loadBinding().then(() => client.start()).then(reinjectBound).then(reportTabs);
