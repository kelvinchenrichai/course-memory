const $ = (id) => document.getElementById(id);
const send = (action, extra = {}) => chrome.runtime.sendMessage({ kind: 'popup', action, ...extra });
const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
let origin = null; try { const url = new URL(tab?.url || ''); if (['http:', 'https:'].includes(url.protocol)) origin = url.origin; } catch {}

async function render() {
  const status = await send('status');
  $('connection').textContent = !status.paired ? '尚未配對' : status.connected ? '已連線' : '已配對，等待本機程式';
  $('connection').className = status.paired && status.connected ? 'ok' : status.paired ? 'muted' : 'bad';
  $('pairRow').hidden = status.paired; $('pairHint').hidden = status.paired; $('unpair').hidden = !status.paired;
  $('site').textContent = origin || '此頁面不支援';
  const granted = origin ? await chrome.permissions.contains({ origins: [`${origin}/*`] }) : false;
  $('grant').hidden = !origin || granted;
  $('bind').hidden = !granted || status.boundTabId === tab.id; $('unbind').hidden = status.boundTabId !== tab.id;
  // activeTab lets the popup look once at the tab the user opened it on; only counts and ids leave the page.
  if (origin) {
    try {
      const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => ({ host: location.hostname, videos: document.querySelectorAll('video').length, v: new URL(location.href).searchParams.get('v'), title: document.title.slice(0, 120) }) });
      const platform = /(^|\.)youtube\.com$/.test(result.host) ? 'YouTube' : '一般 HTML5';
      const player = result.videos === 1 ? '找到 1 個播放器' : result.videos === 0 ? '沒有播放器' : `有 ${result.videos} 個播放器（不會自行猜測）`;
      $('detected').textContent = `${platform}｜${player}${result.v ? `｜影片 ${result.v}` : ''}`;
    } catch { $('detected').textContent = '無法讀取（需要允許此網域）'; }
  }
}

$('pair').addEventListener('click', async () => { const result = await send('pair', { code: $('code').value }); $('code').value = ''; if (!result.ok) $('pairHint').textContent = '配對失敗，請重新產生配對碼。'; render(); });
$('unpair').addEventListener('click', async () => { await send('unpair'); render(); });
$('grant').addEventListener('click', async () => { if (origin) await chrome.permissions.request({ origins: [`${origin}/*`] }); render(); });
$('bind').addEventListener('click', async () => { await send('bind', { tabId: tab.id }); render(); });
$('unbind').addEventListener('click', async () => { await send('unbind'); render(); });
render();
