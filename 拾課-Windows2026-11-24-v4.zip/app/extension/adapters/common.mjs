// Shared helpers for in-page adapters. Pure ESM: no chrome.* APIs, so Node tests can import them.

const CODE_LIKE = /^[A-Z][A-Z0-9_]{1,47}$/;
const BLOCKERS = new Set(['LOGIN_REQUIRED', 'CAPTCHA', 'PAYMENT_PROMPT', 'PLAYER_NOT_FOUND', 'AMBIGUOUS_PLAYER', 'DOM_CHANGED', 'UNEXPECTED_LESSON', 'MEDIA_ERROR', 'PLAYBACK_BLOCKED']);
const PLATFORMS = new Set(['youtube', 'bilibili', 'skool', 'satKnowledge', 'generic']);
const str = (value, max) => (typeof value === 'string' ? value.slice(0, max) : null);
const num = (value, min = -Infinity, max = Infinity) => (typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max ? value : null);
const bool = (value) => (typeof value === 'boolean' ? value : null);
const code = (value) => (typeof value === 'string' && CODE_LIKE.test(value) ? value : null);
const compact = (object) => Object.fromEntries(Object.entries(object).filter(([, value]) => value !== null && value !== undefined));

/**
 * Outgoing allowlist applied in the page before anything leaves the content script.
 * Never forwards cookies, tokens, headers, media URLs, DOM nodes or HTML.
 */
export function sanitizeState(raw) {
  if (!raw || typeof raw !== 'object') return {};
  const captions = raw.captions && typeof raw.captions === 'object' ? compact({ available: bool(raw.captions.available), on: bool(raw.captions.on), languages: Array.isArray(raw.captions.languages) ? raw.captions.languages.map((x) => str(x, 16)).filter(Boolean).slice(0, 5) : null }) : null;
  const capabilities = raw.capabilities && typeof raw.capabilities === 'object' ? compact(Object.fromEntries(['play', 'pause', 'setRate', 'captions', 'nextLesson', 'navigate', 'blockerDetection'].map((key) => [key, bool(raw.capabilities[key])]))) : null;
  return compact({
    adapterId: str(raw.adapterId, 40), platform: PLATFORMS.has(raw.platform) ? raw.platform : null, currentTime: num(raw.currentTime, 0), duration: num(raw.duration, 0), rate: num(raw.rate, 0.0625, 16),
    paused: bool(raw.paused), ended: bool(raw.ended), buffering: bool(raw.buffering), ad: bool(raw.ad), online: bool(raw.online),
    error: code(raw.error), blocker: BLOCKERS.has(raw.blocker) ? raw.blocker : null, loginRequired: bool(raw.loginRequired),
    lessonId: str(raw.lessonId, 200), title: str(raw.title, 200), isPlaylist: bool(raw.isPlaylist), captions, capabilities
  });
}

const DISCOVERY_PLATFORMS = new Set(['youtube', 'bilibili', 'skool', 'satKnowledge', 'generic']);
const DISCOVERY_BLOCKERS = new Set(['LOGIN_REQUIRED', 'CAPTCHA', 'PAYWALL', 'UNRECOGNIZED_PAGE']);
const clean = (value, max) => (typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max) : '');

/** P7A: allowlist for a discovered course list. Only titles, order, page links and durations leave the page. */
export function sanitizeDiscovery(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const items = Array.isArray(raw.items) ? raw.items.slice(0, 500).map((item, index) => ({
    key: clean(item?.key, 120), title: clean(item?.title, 200), order: Number.isInteger(item?.order) ? item.order : index + 1,
    url: typeof item?.url === 'string' && item.url.length <= 2000 && /^https?:\/\//.test(item.url) ? item.url : null,
    durationSec: num(item?.durationSec, 0, 86_400), locked: item?.locked === true, unavailable: item?.unavailable === true
  })) : [];
  return {
    platform: DISCOVERY_PLATFORMS.has(raw.platform) ? raw.platform : 'generic',
    pageUrl: typeof raw.pageUrl === 'string' && raw.pageUrl.length <= 2000 ? normalizeUrl(raw.pageUrl) : null,
    courseTitle: clean(raw.courseTitle, 200), items, blocker: DISCOVERY_BLOCKERS.has(raw.blocker) ? raw.blocker : null, partial: raw.partial === true
  };
}

export function sanitizeResult(raw) {
  if (!raw || typeof raw !== 'object') return { ok: false, reason: 'EMPTY_RESULT' };
  return compact({
    ok: raw.ok === true, reason: code(raw.reason), stop: BLOCKERS.has(raw.stop) ? raw.stop : null, blocker: BLOCKERS.has(raw.blocker) ? raw.blocker : null,
    lessonId: str(raw.lessonId, 200), loginRequired: bool(raw.loginRequired), available: bool(raw.available), trackLabel: str(raw.trackLabel, 80),
    rate: num(raw.rate, 0.0625, 16), adapterId: str(raw.adapterId, 40), platform: PLATFORMS.has(raw.platform) ? raw.platform : null, isPlaylist: bool(raw.isPlaylist), capabilities: raw.capabilities && typeof raw.capabilities === 'object' ? sanitizeState({ capabilities: raw.capabilities }).capabilities : null, state: raw.state ? sanitizeState(raw.state) : null, discovery: raw.discovery ? sanitizeDiscovery(raw.discovery) : null
  });
}

/** origin + path + query, without fragment; null when not http(s). */
export function normalizeUrl(value) {
  try { const url = new URL(String(value)); if (!['http:', 'https:'].includes(url.protocol)) return null; return `${url.origin}${url.pathname}${url.search}`; } catch { return null; }
}

/** Resolves true as soon as predicate() holds, false after timeoutMs. Checks immediately first. */
export function waitFor(predicate, { clock, timeoutMs = 1000, intervalMs = 100 } = {}) {
  const check = () => { try { return Boolean(predicate()); } catch { return false; } };
  if (check()) return Promise.resolve(true);
  return new Promise((resolve) => {
    const started = clock.now();
    const loop = () => { if (check()) return resolve(true); if (clock.now() - started >= timeoutMs) return resolve(false); clock.setTimeout(loop, intervalMs); };
    clock.setTimeout(loop, intervalMs);
  });
}

export const defaultClock = { now: () => Date.now(), setTimeout: (fn, ms) => setTimeout(fn, ms), clearTimeout: (id) => clearTimeout(id) };
export const fail = (reason, stop) => (stop ? { ok: false, reason, stop } : { ok: false, reason });
