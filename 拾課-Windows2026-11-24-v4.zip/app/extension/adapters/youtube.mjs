import { defaultClock, fail, sanitizeResult, sanitizeState, waitFor } from './common.mjs';

export const YOUTUBE_CAPABILITIES = Object.freeze({ play: true, pause: true, setRate: true, captions: true, nextLesson: true, navigate: true, blockerDetection: true });

/**
 * YouTube adapter. Acts only through YouTube's own UI: documented keyboard shortcuts first, the visible
 * player button as the single fallback. Never writes video.playbackRate, never clicks "Skip ad",
 * never likes/comments/subscribes, and never uses Shift+N outside a confirmed playlist.
 * Every selector comes from youtube-selectors.json; a missing selector fails safely with DOM_CHANGED.
 */
export function createYouTubeAdapter({ document, window, selectors, clock = defaultClock } = {}) {
  if (!selectors?.elements || !selectors?.shortcuts) throw new Error('youtube selectors are required');
  const S = selectors; const verifyMs = S.verifyTimeoutMs ?? 1000;
  const el = (name) => { const selector = S.elements[name]; return selector ? document.querySelector(selector) : null; };
  const url = () => new URL(window.location.href);
  const videoId = () => url().searchParams.get(S.videoIdParam) || null;
  const onWatchPage = () => url().pathname.startsWith(S.watchPathPrefix);
  const isPlaylist = () => Boolean(url().searchParams.get(S.playlistParam)) && Boolean(el('playlistPanel'));
  const hasClass = (node, key) => Boolean(node?.classList?.contains(S.playerClasses[key]));

  function blocker() {
    const here = url();
    for (const [codeName, rule] of Object.entries(S.blockers || {})) {
      if ((rule.hosts || []).includes(here.hostname)) return codeName;
      if ((rule.pathPrefixes || []).some((prefix) => here.pathname.startsWith(prefix))) return codeName;
      if ((rule.selectors || []).some((selector) => document.querySelector(selector))) return codeName;
    }
    return null;
  }

  /** Player + video must both resolve. On a watch page a miss means the page structure changed. */
  function detect() {
    const found = blocker(); if (found) return { ok: false, reason: found, blocker: found };
    const player = el('player'); const video = el('video');
    if (player && video) return { ok: true, player, video };
    return onWatchPage() ? { ok: false, reason: 'DOM_CHANGED', stop: 'DOM_CHANGED' } : { ok: false, reason: 'PLAYER_NOT_FOUND' };
  }

  function press(player, name) {
    const shortcut = S.shortcuts[name]; if (!shortcut) return false;
    const KeyboardEventCtor = window.KeyboardEvent;
    player.focus?.();
    for (const type of ['keydown', 'keyup']) player.dispatchEvent(new KeyboardEventCtor(type, { key: shortcut.key, code: shortcut.code, shiftKey: Boolean(shortcut.shiftKey), bubbles: true, cancelable: true }));
    return true;
  }

  function captionsInfo() {
    const button = el('subtitlesButton');
    if (!button) return { button: null, available: false, on: false };
    const unavailable = button.hidden === true || button.getAttribute('aria-disabled') === 'true' || button.style?.display === 'none';
    return { button, available: !unavailable, on: button.getAttribute('aria-pressed') === 'true' };
  }

  function getState() {
    const found = detect();
    const base = { adapterId: 'youtube', online: window.navigator?.onLine !== false, lessonId: videoId(), isPlaylist: isPlaylist(), title: el('title')?.textContent?.trim() ?? null, capabilities: YOUTUBE_CAPABILITIES };
    if (!found.ok) return sanitizeState({ ...base, blocker: found.blocker || found.reason, loginRequired: found.reason === 'LOGIN_REQUIRED' });
    const { player, video } = found; const captions = captionsInfo();
    return sanitizeState({
      ...base, currentTime: video.currentTime, duration: Number.isFinite(video.duration) ? video.duration : null, rate: video.playbackRate,
      paused: video.paused, ended: video.ended || hasClass(player, 'ended'), buffering: hasClass(player, 'buffering'),
      ad: hasClass(player, 'ad'), error: el('errorOverlay') ? 'PLAYER_ERROR' : video.error ? `MEDIA_ERR_${Number(video.error.code) || 0}` : null,
      captions: { available: captions.available, on: captions.on }
    });
  }

  /** One shortcut attempt, then one button attempt; two failed verifications → DOM_CHANGED. */
  async function toggleUntil(predicate, shortcut, buttonName) {
    const found = detect(); if (!found.ok) return fail(found.reason, found.stop || found.blocker);
    if (predicate(found)) return { ok: true };
    press(found.player, shortcut);
    if (await waitFor(() => predicate(found), { clock, timeoutMs: verifyMs })) return { ok: true };
    const button = el(buttonName);
    if (button) { button.click(); if (await waitFor(() => predicate(found), { clock, timeoutMs: verifyMs })) return { ok: true }; }
    return fail('VERIFY_FAILED', 'DOM_CHANGED');
  }

  const play = () => toggleUntil(({ video }) => !video.paused, 'playPause', 'playButton');
  const pause = () => toggleUntil(({ video }) => video.paused, 'playPause', 'playButton');

  async function setRate(rate) {
    const target = Number(rate);
    if (!(target > 0 && target <= 2) || Math.abs(target / S.rateStep - Math.round(target / S.rateStep)) > 1e-9) return fail('RATE_UNAVAILABLE');
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      const found = detect(); if (!found.ok) return fail(found.reason, found.stop || found.blocker);
      let ok = true;
      for (let presses = 0; presses < S.maxRatePresses && found.video.playbackRate !== target; presses += 1) {
        const before = found.video.playbackRate;
        press(found.player, target > before ? 'faster' : 'slower');
        // Re-read the real speed after every single press; YouTube owns the value.
        if (!(await waitFor(() => found.video.playbackRate !== before, { clock, timeoutMs: verifyMs }))) { ok = false; break; }
      }
      if (ok && found.video.playbackRate === target) return { ok: true, rate: target };
    }
    return fail('RATE_NOT_APPLIED', 'DOM_CHANGED');
  }

  async function enableCaptions() {
    const found = detect(); if (!found.ok) return fail(found.reason, found.stop || found.blocker);
    const info = captionsInfo();
    if (!info.button) return fail('SELECTOR_MISSING', 'DOM_CHANGED');
    if (!info.available) return { ok: true, available: false };
    const result = await toggleUntil(() => captionsInfo().on, 'captions', 'subtitlesButton');
    return result.ok ? { ok: true, available: true } : result;
  }

  async function verifyPage(expected = {}) {
    const found = detect();
    if (found.blocker) return sanitizeResult({ ok: true, blocker: found.blocker, loginRequired: found.blocker === 'LOGIN_REQUIRED' });
    if (!found.ok) return fail(found.reason, found.stop);
    const id = videoId();
    return sanitizeResult({ ok: true, lessonId: id ?? 'NO_VIDEO_ID', loginRequired: false });
  }

  async function nextLesson() {
    if (!isPlaylist()) return fail('NOT_A_PLAYLIST'); // never Shift+N here: it would jump to a recommendation
    const found = detect(); if (!found.ok) return fail(found.reason, found.stop || found.blocker);
    const before = videoId();
    press(found.player, 'nextInPlaylist');
    if (await waitFor(() => videoId() && videoId() !== before, { clock, timeoutMs: S.navigationTimeoutMs ?? 4000 })) return sanitizeResult({ ok: true, lessonId: videoId() });
    if (!isPlaylist()) return fail('NOT_A_PLAYLIST');
    const button = el('nextButton');
    if (button) { button.click(); if (await waitFor(() => videoId() && videoId() !== before, { clock, timeoutMs: S.navigationTimeoutMs ?? 4000 })) return sanitizeResult({ ok: true, lessonId: videoId() }); }
    return fail('NEXT_NOT_CONFIRMED', 'DOM_CHANGED');
  }

  return {
    id: 'youtube', capabilities: YOUTUBE_CAPABILITIES, selectorsVersion: S.version,
    detect: () => { const found = detect(); return found.ok ? { ok: true, adapterId: 'youtube', capabilities: YOUTUBE_CAPABILITIES, isPlaylist: isPlaylist() } : fail(found.reason, found.stop || found.blocker); },
    getState, play, pause, setRate, enableCaptions, verifyPage, nextLesson,
    navigate: async () => fail('NAVIGATE_VIA_BACKGROUND')
  };
}
