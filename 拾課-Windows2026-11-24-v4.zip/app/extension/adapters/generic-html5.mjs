import { defaultClock, fail, normalizeUrl, sanitizeResult, sanitizeState, waitFor } from './common.mjs';
import { detectPageBlocker, isHidden, platformOfHost } from './page-blockers.mjs';

export const GENERIC_CAPABILITIES = Object.freeze({ play: true, pause: true, setRate: true, captions: true, nextLesson: false, navigate: true, blockerDetection: true });

/**
 * Generic HTML5 <video> adapter. Uses only the standard HTMLMediaElement API on the single video the
 * user is watching. Never reads media URLs (src/currentSrc), DRM/EME state, cookies or storage.
 * More than one <video> → AMBIGUOUS_PLAYER (no guessing); none → PLAYER_NOT_FOUND.
 * The video is looked up again on every call, so SPA navigations are picked up automatically.
 * P8: also used for Skool, 知識衛星 and other sites. Login walls, CAPTCHAs and payment prompts stop the run;
 * the "next lesson" is never guessed here (the Runner opens the next planned URL, or the user does).
 */
export function createGenericHtml5Adapter({ document, window, clock = defaultClock } = {}) {
  let bound = null; // { url, platformLessonId } set by verifyPage

  const platform = () => platformOfHost(window.location.hostname);
  // Mux (used by Skool) and several course players keep the real <video> inside one or more open
  // shadow roots. Walk only DOM roots and return the video elements themselves; never read src,
  // currentSrc, page storage, cookies or the surrounding HTML.
  function findVideos() {
    const videos = []; const seenRoots = new Set(); const seenVideos = new Set();
    const visit = (root) => {
      if (!root?.querySelectorAll || seenRoots.has(root)) return; seenRoots.add(root);
      for (const video of root.querySelectorAll('video')) if (!seenVideos.has(video)) { seenVideos.add(video); videos.push(video); }
      for (const element of root.querySelectorAll('*')) if (element.shadowRoot) visit(element.shadowRoot);
    };
    visit(document);
    // Before the first click, <mux-player> may not have created its inner <video> yet. The custom
    // element implements the standard media-controller surface itself, so it is safe to use without
    // reading its media URL. Prefer a real video once one exists to avoid counting the same player twice.
    if (!videos.length) for (const player of document.querySelectorAll('mux-player')) {
      if (typeof player.play === 'function' && typeof player.pause === 'function' && !seenVideos.has(player)) { seenVideos.add(player); videos.push(player); }
    }
    return videos;
  }
  function findSkoolPosterCandidates() {
    if (platform() !== 'skool') return [];
    return [...document.querySelectorAll('img')].map((image) => {
      const rect = image.getBoundingClientRect?.() || {};
      const width = Number(rect.width) || Number(image.getAttribute?.('width')) || 0;
      const height = Number(rect.height) || Number(image.getAttribute?.('height')) || 0;
      return { image, width, height, area: width * height };
    }).filter(({ image, width, height, area }) => !isHidden(image) && area >= 40_000 && width / Math.max(height, 1) >= 1.2)
      .sort((a, b) => b.area - a.area);
  }
  function detect() {
    const videos = findVideos();
    // A signed-in Skool lesson shows marketing/subscription wording in the shared page shell before
    // its poster is activated.  That wording is not a paywall.  Keep strong DOM blockers enabled,
    // but defer text-only blocker detection until the lesson player actually exists.
    const posters = videos.length === 0 ? findSkoolPosterCandidates() : [];
    const hasUnambiguousPoster = Boolean(posters[0] && (!posters[1] || posters[1].area < posters[0].area * 0.8));
    const blocker = detectPageBlocker(document, {
      hasPlayer: videos.length === 1,
      includeText: !hasUnambiguousPoster
    });
    if (blocker) return { ok: false, reason: blocker, blocker };
    if (videos.length === 0) return { ok: false, reason: 'PLAYER_NOT_FOUND' };
    if (videos.length > 1) return { ok: false, reason: 'AMBIGUOUS_PLAYER', count: videos.length };
    return { ok: true, video: videos[0] };
  }

  // Skool renders a large lesson poster first and does not create <mux-player> until that poster is
  // activated.  Waiting for a video alone therefore makes unattended runs stop between every lesson.
  // Activate only one unmistakably large image on a Skool lesson page, then immediately pause and
  // rewind the player that appears.  This never reads media URLs and never bypasses a login/paywall.
  async function prepareSkoolPoster() {
    if (platform() !== 'skool' || findVideos().length) return { ok: true };
    const strongBlocker = detectPageBlocker(document, { hasPlayer: false, includeText: false });
    if (strongBlocker) return sanitizeResult({ ok: true, blocker: strongBlocker, loginRequired: strongBlocker === 'LOGIN_REQUIRED' });
    const images = findSkoolPosterCandidates();
    // More than one equally large candidate is ambiguous; never guess which item to open.
    if (!images.length || (images[1] && images[1].area >= images[0].area * 0.8)) return fail('PLAYER_NOT_FOUND');
    images[0].image.click?.();
    const ready = await waitFor(() => findVideos().length === 1, { clock, timeoutMs: 15_000, intervalMs: 100 });
    if (!ready) return fail('PLAYER_NOT_FOUND');
    const found = detect(); if (!found.ok) return fail(found.reason, found.blocker);
    try { found.video.pause(); found.video.currentTime = 0; } catch { return fail('PLAYER_NOT_FOUND'); }
    return { ok: true };
  }

  function applySkoolPresentation(video) {
    if (platform() !== 'skool' || !video) return;
    let target = video;
    // Keep Mux captions and controls by styling its outermost open-shadow host, not only the inner video.
    for (let i = 0; i < 4; i += 1) {
      const host = target.getRootNode?.()?.host;
      if (!host) break;
      target = host;
    }
    const style = target.style;
    if (!style) return;
    Object.assign(style, { position: 'fixed', inset: '0', width: '100vw', height: '100vh', zIndex: '2147483647', background: '#000', objectFit: 'contain' });
    document.documentElement?.style && (document.documentElement.style.overflow = 'hidden');
  }

  const captionTracks = (video) => [...(video.textTracks || [])].filter((track) => track.kind === 'captions' || track.kind === 'subtitles');

  function lessonId() {
    if (!bound) return null;
    return normalizeUrl(window.location.href) === bound.url ? bound.platformLessonId : 'URL_CHANGED';
  }

  function getState() {
    const found = detect();
    const base = { adapterId: 'generic-html5', platform: platform(), online: window.navigator?.onLine !== false, ad: false, isPlaylist: false, title: document.title, lessonId: lessonId(), capabilities: GENERIC_CAPABILITIES };
    if (!found.ok) return sanitizeState({ ...base, blocker: found.reason, loginRequired: found.reason === 'LOGIN_REQUIRED' });
    const v = found.video; const tracks = captionTracks(v);
    return sanitizeState({
      ...base, currentTime: v.currentTime, duration: Number.isFinite(v.duration) ? v.duration : null, rate: v.playbackRate,
      paused: v.paused, ended: v.ended, buffering: !v.paused && !v.ended && v.readyState < 3,
      error: v.error ? `MEDIA_ERR_${Number(v.error.code) || 0}` : null,
      captions: { available: tracks.length > 0, on: tracks.some((t) => t.mode === 'showing'), languages: tracks.map((t) => t.language).filter(Boolean) }
    });
  }

  async function play() {
    const found = detect(); if (!found.ok) return fail(found.reason);
    // A browser autoplay block is the user's call (one click on the page), not a broken page.
    try { await found.video.play(); } catch { return fail('PLAY_REJECTED', 'PLAYBACK_BLOCKED'); }
    return sanitizeResult({ ok: !found.video.paused, reason: found.video.paused ? 'PLAY_NOT_STARTED' : null });
  }

  async function pause() {
    const found = detect(); if (!found.ok) return fail(found.reason);
    found.video.pause();
    return sanitizeResult({ ok: found.video.paused });
  }

  async function setRate(rate) {
    const target = Number(rate); if (!(target > 0 && target <= 4)) return fail('INVALID_RATE');
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      const found = detect(); if (!found.ok) return fail(found.reason);
      found.video.playbackRate = target;
      if (await waitFor(() => found.video.playbackRate === target, { clock, timeoutMs: 500 })) return { ok: true, rate: target };
    }
    return fail('RATE_NOT_APPLIED', 'DOM_CHANGED');
  }

  async function enableCaptions({ languages = [] } = {}) {
    const found = detect(); if (!found.ok) return fail(found.reason);
    const tracks = captionTracks(found.video);
    if (!tracks.length) return { ok: true, available: false };
    const wanted = languages.map((l) => String(l).toLowerCase());
    const track = tracks.find((t) => wanted.some((l) => String(t.language || '').toLowerCase().startsWith(l))) || tracks[0];
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      track.mode = 'showing';
      if (await waitFor(() => track.mode === 'showing', { clock, timeoutMs: 500 })) return sanitizeResult({ ok: true, available: true, trackLabel: track.label || track.language || null });
    }
    return fail('CAPTIONS_NOT_APPLIED', 'DOM_CHANGED');
  }

  async function verifyPage(expected = {}) {
    const prepared = await prepareSkoolPoster();
    if (prepared.blocker) return prepared;
    if (!prepared.ok && findVideos().length === 0) return prepared;
    const found = detect();
    if (found.blocker) return sanitizeResult({ ok: true, blocker: found.blocker, loginRequired: found.blocker === 'LOGIN_REQUIRED' });
    if (!found.ok) return fail(found.reason);
    applySkoolPresentation(found.video);
    const here = normalizeUrl(window.location.href);
    const wantedUrl = expected.url ? normalizeUrl(expected.url) : here;
    if (!here || here !== wantedUrl) return { ok: true, lessonId: 'URL_CHANGED', loginRequired: false };
    bound = { url: here, platformLessonId: String(expected.platformLessonId ?? here).slice(0, 200) };
    return sanitizeResult({ ok: true, lessonId: bound.platformLessonId, loginRequired: false });
  }

  return {
    id: 'generic-html5', capabilities: GENERIC_CAPABILITIES,
    detect: () => { const found = detect(); return found.ok ? { ok: true, adapterId: 'generic-html5', platform: platform(), capabilities: GENERIC_CAPABILITIES } : fail(found.reason, found.blocker); },
    getState, play, pause, setRate, enableCaptions, verifyPage,
    // Navigation is performed by the extension background (chrome.tabs.update) on user-granted origins only.
    navigate: async () => fail('NAVIGATE_VIA_BACKGROUND'),
    nextLesson: async () => fail('UNSUPPORTED')
  };
}
