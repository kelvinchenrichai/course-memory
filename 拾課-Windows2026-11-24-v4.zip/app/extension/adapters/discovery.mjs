// P7A course-list discovery. Pure, read-only DOM readers that run inside the user-bound tab.
// Contract: discoverPage({ document, window }) → {
//   platform, pageUrl, courseTitle, partial, blocker,
//   items: [{ key, title, order, url, durationSec|null, locked, unavailable }]
// }
// Never calls play()/pause()/click()/scroll, never navigates, never fetches, never reads cookies, storage,
// media src or HTML. Only links the user can already see in this tab are reported.

const BV = /\/video\/(BV[0-9A-Za-z]{10})/;
const YT_ID = /^[A-Za-z0-9_-]{11}$/;
const LOCK_TEXT = /🔒|未解鎖|未解锁|鎖定|锁定|\blocked\b|會員專屬|会员专享|members only|購買後觀看|购买后观看|付費|付费/i;
const COURSE_CLASS = /(lesson|chapter|module|curriculum|syllabus|course|classroom|section|toc|outline|unit|episode|playlist|sidebar|catalog|章節|課程)/i;
const NOT_LESSON = /\/(login|logout|signin|sign-in|signup|sign-up|register|account|settings|profile|pricing|checkout|cart|about|help|terms|privacy|search|notifications|chat|members|calendar|leaderboard|community|invite|billing)(\/|$)/i;
const LOGIN_TEXT = /請先登入|登入以繼續|登入後才能|请先登录|登录后|sign in to continue|log in to continue|please (log|sign) in/i;
const PAYWALL_TEXT = /購買課程|立即購買|購買後即可|訂閱後即可|付費解鎖|立即购买|购买课程|付费内容|purchase to unlock|buy (this )?course|subscribe to (watch|unlock)|join (this )?group to|upgrade to (watch|access)/i;
const MAX_ITEMS = 500;

const up = (el) => el?.parentElement || null;
const tag = (el) => String(el?.tagName || '').toLowerCase();
const txt = (el) => String(el?.textContent || '').replace(/\s+/g, ' ').trim();
const cls = (el) => (typeof el?.className === 'string' ? el.className : '');
function hidden(el) {
  for (let node = el; node; node = up(node)) {
    if (node.hidden === true || node.getAttribute?.('aria-hidden') === 'true') return true;
    const style = node.style || {}; if (style.display === 'none' || style.visibility === 'hidden') return true;
  }
  return false;
}
const visible = (list) => [...list].filter((el) => !hidden(el));

export function parseDuration(value) {
  const s = String(value || '');
  const clock = s.match(/(?:^|[^\d:])(?:(\d{1,2}):)?(\d{1,2}):(\d{2})(?![\d:])/);
  if (clock) return (Number(clock[1] || 0) * 3600) + Number(clock[2]) * 60 + Number(clock[3]);
  const words = s.match(/(\d{1,3})\s*(?:分鐘|分钟|分(?=$|[\s\d秒）)])|min(?:ute)?s?\b)/i);
  return words ? Number(words[1]) * 60 : null;
}

function absolute(href, base) {
  if (!href || /^\s*(javascript|data|blob|mailto|tel):/i.test(href)) return null;
  try { const url = new URL(href, base); return ['http:', 'https:'].includes(url.protocol) ? url.toString() : null; } catch { return null; }
}

function locked(row) {
  if (LOCK_TEXT.test(txt(row))) return true;
  if (/(^|\s)(locked|is-locked)(\s|$)/i.test(cls(row)) || row.getAttribute?.('data-locked') === 'true' || row.getAttribute?.('aria-disabled') === 'true') return true;
  return Boolean(row.querySelector?.('.lock, .locked, .icon-lock, [data-locked=true]'));
}

export function detectDiscoveryPlatform(hostname) {
  const host = String(hostname || '').toLowerCase();
  const on = (domain) => host === domain || host.endsWith(`.${domain}`);
  if (on('youtube.com')) return 'youtube';
  if (on('bilibili.com')) return 'bilibili';
  if (on('skool.com')) return 'skool';
  if (on('sat.cool')) return 'satKnowledge';
  return 'generic';
}

function pageBlocker(document) {
  const frames = [...document.querySelectorAll('iframe')].map((frame) => String(frame.getAttribute('src') || '') + String(frame.getAttribute('title') || ''));
  if (document.querySelector('.g-recaptcha, .h-captcha, .cf-turnstile, .geetest_panel, .geetest_holder, #captcha, [data-sitekey]') || frames.some((s) => /recaptcha|hcaptcha|turnstile|captcha/i.test(s))) return 'CAPTCHA';
  return null;
}
function emptyReason(document) {
  const body = txt(document.querySelector('body') || document.documentElement);
  // Login walls are recognised by visible wording or a login form's own name; input fields are never inspected.
  const loginForm = visible(document.querySelectorAll('form')).some((form) => /(login|log-in|signin|sign-in|登入|登录)/i.test(`${form.getAttribute('action') || ''} ${form.id || ''} ${cls(form)}`));
  if (loginForm || LOGIN_TEXT.test(body)) return 'LOGIN_REQUIRED';
  if (PAYWALL_TEXT.test(body)) return 'PAYWALL';
  return 'UNRECOGNIZED_PAGE';
}

// ---- YouTube: playlist page or the playlist panel on a watch page -------------------------------
function youtube(document, location) {
  const url = new URL(location.href); const list = url.searchParams.get('list');
  const rows = visible(document.querySelectorAll('ytd-playlist-video-renderer, ytd-playlist-panel-video-renderer'));
  const items = [];
  rows.forEach((row, i) => {
    const anchor = row.querySelector('a#video-title, a#wc-endpoint, a#thumbnail, a');
    const href = anchor?.getAttribute('href');
    let id = null; try { id = href ? new URL(href, location.href).searchParams.get('v') : null; } catch {}
    id ||= row.getAttribute('data-video-id');
    if (!YT_ID.test(String(id))) return;
    const title = anchor?.getAttribute('title') || txt(row.querySelector('#video-title')) || txt(anchor);
    const order = Number.parseInt(txt(row.querySelector('#index')), 10);
    const duration = parseDuration(txt(row.querySelector('ytd-thumbnail-overlay-time-status-renderer')) || txt(row.querySelector('.badge-shape-wiz__text')) || row.getAttribute('data-duration'));
    const watch = new URL('https://www.youtube.com/watch'); watch.searchParams.set('v', id); if (list) watch.searchParams.set('list', list);
    items.push({ key: id, title, order: Number.isInteger(order) && order > 0 ? order : i + 1, url: watch.toString(), durationSec: duration, locked: /members only|會員專屬|会员专享/i.test(txt(row)), unavailable: /^\[(private|deleted|私人|已刪除|已删除|不公開)/i.test(title) });
  });
  if (!items.length && url.pathname === '/watch' && YT_ID.test(String(url.searchParams.get('v')))) {
    const id = url.searchParams.get('v');
    items.push({ key: id, title: txt(document.querySelector('h1.ytd-watch-metadata, h1')) || String(document.title || '').replace(/ - YouTube$/, ''), order: 1, url: `https://www.youtube.com/watch?v=${id}`, durationSec: null, locked: false, unavailable: false });
  }
  const header = document.querySelector('ytd-playlist-header-renderer, yt-page-header-renderer, ytd-playlist-panel-renderer');
  const declared = Number.parseInt((txt(header).match(/(\d[\d,]*)\s*(部影片|個影片|videos?)/i) || [])[1]?.replace(/,/g, ''), 10);
  const courseTitle = txt(document.querySelector('ytd-playlist-header-renderer h1, yt-page-header-renderer h1, ytd-playlist-panel-renderer .title, ytd-playlist-panel-renderer h3')) || String(document.title || '').replace(/ - YouTube$/, '');
  return { courseTitle, items, partial: Number.isInteger(declared) && declared > items.length };
}

// ---- Bilibili: 分P list / 合集 visible on a video page -------------------------------------------
function bilibili(document, location) {
  const pageBv = (location.pathname.match(BV) || [])[1] || null;
  const rows = visible(document.querySelectorAll('.video-pod__item, .list-box li, .video-episode-card, .video-section-list .section-item'));
  const items = [];
  rows.forEach((row, i) => {
    const anchor = row.querySelector('a') || (tag(row) === 'a' ? row : null);
    let href = absolute(anchor?.getAttribute('href'), location.href);
    const key = row.getAttribute('data-key') || anchor?.getAttribute('data-key');
    if (!href && key) {
      if (/^BV[0-9A-Za-z]{10}$/.test(key)) href = `https://www.bilibili.com/video/${key}/`;
      else if (/^\d{1,4}$/.test(key) && pageBv) href = `https://www.bilibili.com/video/${pageBv}/?p=${key}`;
    }
    if (!href || !BV.test(new URL(href).pathname)) return;
    const title = txt(row.querySelector('.title-txt, .part, .video-episode-card__info-title, .title')) || anchor?.getAttribute('title') || txt(anchor);
    const duration = parseDuration(txt(row.querySelector('.duration, .stat-item.duration, .video-episode-card__info-duration')) || txt(row));
    const p = new URL(href).searchParams.get('p');
    items.push({ key: `${(new URL(href).pathname.match(BV) || [])[1]}${p ? `:p${p}` : ''}`, title, order: i + 1, url: href, durationSec: duration, locked: locked(row), unavailable: false });
  });
  if (!items.length && pageBv) items.push({ key: pageBv, title: txt(document.querySelector('h1.video-title, h1')) || String(document.title || '').replace(/_哔哩哔哩.*$/, ''), order: 1, url: `https://www.bilibili.com/video/${pageBv}/`, durationSec: null, locked: false, unavailable: false });
  const courseTitle = txt(document.querySelector('.video-pod__header .title, .video-sections-head .title, .multi-page .head-left h3, h1.video-title, h1')) || String(document.title || '').replace(/_哔哩哔哩.*$/, '');
  return { courseTitle, items, partial: false };
}

// ---- Generic (Skool, 知識衛星, other logged-in course sites) --------------------------------------
// The outermost course-like ancestor (e.g. the whole sidebar, not one module) groups an outline's links.
function courseContainer(anchor) {
  let found = null;
  for (let node = up(anchor), depth = 0; node && depth < 12; node = up(node), depth += 1) {
    if (['body', 'html', 'main'].includes(tag(node))) break;
    const role = node.getAttribute?.('role');
    if (tag(node) === 'nav' || tag(node) === 'aside' || role === 'navigation' || role === 'tree' || COURSE_CLASS.test(cls(node)) || node.hasAttribute?.('data-course-outline')) found = node;
  }
  return found;
}
function generic(document, location, platform) {
  const page = new URL(location.href);
  const groups = new Map();
  for (const anchor of visible(document.querySelectorAll('a'))) {
    const href = absolute(anchor.getAttribute('href'), location.href); if (!href) continue;
    const url = new URL(href);
    if (url.hostname !== page.hostname || NOT_LESSON.test(url.pathname)) continue;
    if (platform === 'skool' && !/\/classroom\//.test(url.pathname)) continue;
    const container = courseContainer(anchor); if (!container) continue;
    if (!groups.has(container)) groups.set(container, []);
    groups.get(container).push(anchor);
  }
  // The course outline is the container with the most lesson-like links.
  const best = [...groups.values()].sort((a, b) => b.length - a.length)[0] || [];
  const seen = new Set(); const items = [];
  for (const anchor of best) {
    const url = new URL(absolute(anchor.getAttribute('href'), location.href)); url.hash = '';
    if (seen.has(url.toString())) continue; seen.add(url.toString());
    const raw = anchor.getAttribute('title') || anchor.getAttribute('aria-label') || txt(anchor);
    const title = raw.replace(/(?:^|\s)(?:\d{1,2}:)?\d{1,2}:\d{2}(?=\s|$)/g, ' ').replace(/🔒/g, '').replace(/\s+/g, ' ').trim();
    const row = up(anchor) && !COURSE_CLASS.test(cls(up(anchor))) ? up(anchor) : anchor;
    items.push({ key: url.toString(), title, order: items.length + 1, url: url.toString(), durationSec: parseDuration(txt(row)), locked: locked(anchor) || locked(row), unavailable: false });
    if (items.length >= MAX_ITEMS) break;
  }
  const courseTitle = txt(document.querySelector('[data-course-title], .course-title, .classroom-title, h1')) || String(document.title || '');
  return { courseTitle, items, partial: false };
}

export function discoverPage({ document, window }) {
  const location = window.location;
  const platform = detectDiscoveryPlatform(location.hostname);
  const base = { platform, pageUrl: `${new URL(location.href).origin}${location.pathname}${location.search}` };
  const captcha = pageBlocker(document);
  if (captcha) return { ...base, courseTitle: '', items: [], partial: false, blocker: captcha };
  const found = platform === 'youtube' ? youtube(document, location) : platform === 'bilibili' ? bilibili(document, location) : generic(document, location, platform);
  const items = found.items.slice(0, MAX_ITEMS);
  return { ...base, courseTitle: found.courseTitle, items, partial: found.partial || found.items.length > MAX_ITEMS, blocker: items.length ? null : emptyReason(document) };
}
