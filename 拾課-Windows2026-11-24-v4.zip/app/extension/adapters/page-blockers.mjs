// P8: page-level blockers shared by the in-page player adapters (pure, read-only DOM).
// Login walls, CAPTCHAs and payment prompts are recognised so the Agent stops safely and asks the user —
// it never fills a form, solves a challenge, closes a dialog or skips anything. Input fields are never read.

const CAPTCHA_SELECTOR = '.g-recaptcha, .h-captcha, .cf-turnstile, .geetest_panel, .geetest_holder, #captcha, [data-sitekey]';
const LOGIN_MARK = /(^|[\s_-])(login|log-in|signin|sign-in|auth-modal|登入|登录)([\s_-]|$)/i;
const PAYWALL_SELECTOR = '.paywall, .purchase-overlay, .locked-content, .pay-wall, [data-paywall]';
const LOGIN_TEXT = /請先登入|登入以繼續|登入後才能|请先登录|登录后才能|sign in to continue|log in to continue|please (log|sign) in to (watch|continue)/i;
const PAYMENT_TEXT = /購買課程|立即購買|購買後即可|訂閱後即可|付費解鎖|立即购买|购买后观看|付费内容|充电专属|purchase to unlock|buy (this )?course|subscribe to (watch|unlock)|upgrade to (watch|access)|join (this )?group to/i;

const up = (el) => el?.parentElement || null;
const cls = (el) => (typeof el?.className === 'string' ? el.className : '');
export function isHidden(el) {
  for (let node = el; node; node = up(node)) {
    if (node.hidden === true || node.getAttribute?.('aria-hidden') === 'true') return true;
    const style = node.style || {}; if (style.display === 'none' || style.visibility === 'hidden') return true;
  }
  return false;
}
const visible = (list) => [...list].filter((el) => !isHidden(el));
const text = (document) => String((document.querySelector('body') || document.documentElement)?.textContent || '').slice(0, 50_000);

export function captchaVisible(document) {
  if (visible(document.querySelectorAll(CAPTCHA_SELECTOR)).length) return true;
  return visible(document.querySelectorAll('iframe')).some((frame) => /recaptcha|hcaptcha|turnstile|captcha/i.test(`${frame.getAttribute('src') || ''} ${frame.getAttribute('title') || ''}`));
}

/** A visible login form or dialog, recognised by its own name (action / id / class), never by its fields. */
export function loginWallVisible(document) {
  return visible(document.querySelectorAll('form, [role=dialog], dialog')).some((node) => LOGIN_MARK.test(`${node.getAttribute('action') || ''} ${node.id || ''} ${cls(node)}`));
}

/**
 * CAPTCHA and login dialogs stop the Agent even when a video is visible. Wording-only cues (「請先登入」,
 * 「立即購買」) are trusted only when no usable player is on the page, so an upsell banner next to a
 * course the user already owns does not stop a lesson.
 */
export function detectPageBlocker(document, { hasPlayer = false, includeText = true } = {}) {
  if (captchaVisible(document)) return 'CAPTCHA';
  if (loginWallVisible(document)) return 'LOGIN_REQUIRED';
  if (visible(document.querySelectorAll(PAYWALL_SELECTOR)).length) return 'PAYMENT_PROMPT';
  if (hasPlayer || !includeText) return null;
  const body = text(document);
  if (LOGIN_TEXT.test(body)) return 'LOGIN_REQUIRED';
  if (PAYMENT_TEXT.test(body)) return 'PAYMENT_PROMPT';
  return null;
}

/** Platform the page belongs to (for display / capability notes only). */
export function platformOfHost(hostname) {
  const host = String(hostname || '').toLowerCase();
  const on = (domain) => host === domain || host.endsWith(`.${domain}`);
  if (on('youtube.com')) return 'youtube';
  if (on('bilibili.com')) return 'bilibili';
  if (on('skool.com')) return 'skool';
  if (on('sat.cool')) return 'satKnowledge';
  return 'generic';
}
