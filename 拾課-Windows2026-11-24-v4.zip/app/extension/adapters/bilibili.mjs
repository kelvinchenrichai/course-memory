import { defaultClock, fail, sanitizeResult, sanitizeState, waitFor } from './common.mjs';
import { captchaVisible, isHidden } from './page-blockers.mjs';

export const BILIBILI_CAPABILITIES = Object.freeze({ play: true, pause: true, setRate: true, captions: true, nextLesson: true, navigate: true, blockerDetection: true });
const BV = /\/video\/(BV[0-9A-Za-z]{10})/;

/**
 * P8 Bilibili adapter. Acts only through Bilibili's own player controls (play button, speed menu items,
 * subtitle menu, the native「下一個」button). Never writes video.playbackRate, never calls video.play(),
 * never reads media URLs, cookies or storage, never closes login / payment / CAPTCHA dialogs.
 * Every selector comes from bilibili-selectors.json; a missing control on a video page → DOM_CHANGED.
 * A lesson is identified by BV id + 分P (p, default 1), so tracking parameters never matter.
 */
export function createBilibiliAdapter({ document, window, selectors, clock = defaultClock } = {}) {
  if (!selectors?.elements) throw new Error('bilibili selectors are required');
  const S = selectors; const E = S.elements; const verifyMs = S.verifyTimeoutMs ?? 1000;
  const el = (name) => { const node = E[name] ? document.querySelector(E[name]) : null; return node && !isHidden(node) ? node : null; };
  const all = (name) => (E[name] ? [...document.querySelectorAll(E[name])].filter((node) => !isHidden(node)) : []);
  const keyOf = (href) => {
    try { const url = new URL(href, window.location.href); const bv = (url.pathname.match(BV) || [])[1]; return bv ? `${bv}:p${Number(url.searchParams.get('p')) || 1}` : null; } catch { return null; }
  };
  const here = () => keyOf(window.location.href);
  const onVideoPage = () => new RegExp(S.watchPathPattern).test(window.location.pathname);
  let bound = null; // { key, platformLessonId } after verifyPage

  function blocker() {
    if (captchaVisible(document)) return 'CAPTCHA';
    for (const [code, list] of Object.entries(S.blockers || {})) if (list.some((selector) => [...document.querySelectorAll(selector)].some((node) => !isHidden(node)))) return code;
    return null;
  }
  function detect() {
    const found = blocker(); if (found) return { ok: false, reason: found, blocker: found };
    const player = el('player'); const video = player ? document.querySelector(E.video) : null;
    if (player && video) return { ok: true, player, video };
    return onVideoPage() ? { ok: false, reason: 'DOM_CHANGED', stop: 'DOM_CHANGED' } : { ok: false, reason: 'PLAYER_NOT_FOUND' };
  }
  const lessonId = () => (!bound ? null : here() === bound.key ? bound.platformLessonId : 'URL_CHANGED');
  const isPlaylist = () => all('podItem').length > 1;
  function subtitles() {
    const button = el('subtitleButton'); const items = all('subtitleItem');
    return { button, items, available: Boolean(button && items.length), on: items.some((item) => item.classList.contains(E.subtitleActiveClass)) };
  }
  function getState() {
    const found = detect();
    const base = { adapterId: 'bilibili', platform: 'bilibili', online: window.navigator?.onLine !== false, lessonId: lessonId(), isPlaylist: isPlaylist(), title: el('title')?.textContent?.trim() ?? null, capabilities: BILIBILI_CAPABILITIES };
    if (!found.ok) return sanitizeState({ ...base, blocker: found.blocker || found.reason, loginRequired: found.reason === 'LOGIN_REQUIRED' });
    const { video } = found; const subs = subtitles();
    return sanitizeState({
      ...base, currentTime: video.currentTime, duration: Number.isFinite(video.duration) ? video.duration : null, rate: video.playbackRate,
      paused: video.paused, ended: video.ended, buffering: !video.paused && !video.ended && video.readyState < 3, ad: Boolean(el('adOverlay')),
      error: video.error ? `MEDIA_ERR_${Number(video.error.code) || 0}` : null, captions: { available: subs.available, on: subs.on }
    });
  }
  /** Native control click, verified; two failed verifications → DOM_CHANGED. */
  async function clickUntil(predicate, getButton) {
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      const found = detect(); if (!found.ok) return fail(found.reason, found.stop || found.blocker);
      if (predicate(found)) return { ok: true };
      const button = getButton(found); if (!button) return fail('SELECTOR_MISSING', 'DOM_CHANGED');
      button.click();
      if (await waitFor(() => predicate(found), { clock, timeoutMs: verifyMs })) return { ok: true };
    }
    return fail('VERIFY_FAILED', 'DOM_CHANGED');
  }
  const play = () => clickUntil(({ video }) => !video.paused, () => el('playButton'));
  const pause = () => clickUntil(({ video }) => video.paused, () => el('playButton'));
  async function setRate(rate) {
    const target = Number(rate);
    if (!(S.rates || []).includes(target)) return fail('RATE_UNAVAILABLE');
    const item = () => [...document.querySelectorAll(E.rateMenuItem)].find((node) => Number(node.getAttribute(S.rateAttribute)) === target);
    const result = await clickUntil(({ video }) => video.playbackRate === target, item);
    return result.ok ? { ok: true, rate: target } : (result.reason === 'VERIFY_FAILED' ? fail('RATE_NOT_APPLIED', 'DOM_CHANGED') : result);
  }
  async function enableCaptions({ languages = [] } = {}) {
    const found = detect(); if (!found.ok) return fail(found.reason, found.stop || found.blocker);
    const subs = subtitles();
    if (!subs.available) return { ok: true, available: false }; // many videos have no CC: not an error
    const wanted = languages.map((l) => String(l).toLowerCase());
    const pick = () => { const items = subtitles().items; return items.find((node) => wanted.some((l) => String(node.getAttribute(S.subtitleLanguageAttribute) || '').toLowerCase().replace(/^ai-/, '').startsWith(l))) || items[0]; };
    const target = pick();
    const result = await clickUntil(() => target.classList.contains(E.subtitleActiveClass), () => target);
    return result.ok ? sanitizeResult({ ok: true, available: true, trackLabel: target.textContent?.trim() || null }) : result;
  }
  async function verifyPage(expected = {}) {
    const found = detect();
    if (found.blocker) return sanitizeResult({ ok: true, blocker: found.blocker, loginRequired: found.blocker === 'LOGIN_REQUIRED' });
    if (!found.ok) return fail(found.reason, found.stop);
    const wanted = expected.url ? keyOf(expected.url) : here();
    if (!here() || here() !== wanted) return { ok: true, lessonId: 'URL_CHANGED', loginRequired: false };
    bound = { key: here(), platformLessonId: String(expected.platformLessonId ?? here()).slice(0, 200) };
    return sanitizeResult({ ok: true, lessonId: bound.platformLessonId, loginRequired: false });
  }
  /** Native「下一個」. Succeeds only when the page really moved to another 分P/合集 item. */
  async function nextLesson() {
    if (!isPlaylist()) return fail('NOT_A_PLAYLIST');
    const found = detect(); if (!found.ok) return fail(found.reason, found.stop || found.blocker);
    const before = here(); const button = el('nextButton');
    if (!button) return fail('SELECTOR_MISSING', 'DOM_CHANGED');
    button.click();
    if (await waitFor(() => here() && here() !== before, { clock, timeoutMs: S.navigationTimeoutMs ?? 5000 })) return sanitizeResult({ ok: true, lessonId: 'URL_CHANGED' });
    return fail('NEXT_NOT_CONFIRMED', 'DOM_CHANGED');
  }
  return {
    id: 'bilibili', capabilities: BILIBILI_CAPABILITIES, selectorsVersion: S.version,
    detect: () => { const found = detect(); return found.ok ? { ok: true, adapterId: 'bilibili', platform: 'bilibili', capabilities: BILIBILI_CAPABILITIES, isPlaylist: isPlaylist() } : fail(found.reason, found.stop || found.blocker); },
    getState, play, pause, setRate, enableCaptions, verifyPage, nextLesson,
    navigate: async () => fail('NAVIGATE_VIA_BACKGROUND')
  };
}
