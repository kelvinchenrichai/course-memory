// Content script, injected by background.mjs only into the user-bound tab on a user-granted origin.
// Written without static import/export so it runs as a classic content script; modules are loaded with
// dynamic import() from web_accessible_resources. Reads player state (and, on request, the visible
// course outline: titles, order, page links, durations): no cookies, storage,
// media URLs or page HTML ever leave this script (see adapters/common.mjs allowlist).
(async () => {
  if (globalThis.__courseMemoryCompanionLoaded || globalThis.__courseMemoryCompanionLoading) return;
  globalThis.__courseMemoryCompanionLoading = true;
  try {
  const asset = (path) => chrome.runtime.getURL(path);
  const { dispatchCommand } = await import(asset('dispatch.mjs'));
  const { sanitizeState } = await import(asset('adapters/common.mjs'));
  const isYouTube = /(^|\.)youtube\.com$/.test(location.hostname);

  async function createAdapter() {
    if (isYouTube) {
      const [{ createYouTubeAdapter }, selectors] = await Promise.all([import(asset('adapters/youtube.mjs')), fetch(asset('adapters/youtube-selectors.json')).then((r) => r.json())]);
      return createYouTubeAdapter({ document, window, selectors });
    }
    if (/(^|\.)bilibili\.com$/.test(location.hostname)) {
      const [{ createBilibiliAdapter }, selectors] = await Promise.all([import(asset('adapters/bilibili.mjs')), fetch(asset('adapters/bilibili-selectors.json')).then((r) => r.json())]);
      return createBilibiliAdapter({ document, window, selectors });
    }
    // Skool, 知識衛星 and other HTML5 sites: standard <video> API + page blocker detection.
    const { createGenericHtml5Adapter } = await import(asset('adapters/generic-html5.mjs'));
    return createGenericHtml5Adapter({ document, window });
  }
  const adapter = await createAdapter();

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || message?.kind !== 'cm-command') return false;
    // P7A: discovery reads only visible links/titles of this page; the module is loaded on first use.
    const discover = async () => (await import(asset('adapters/discovery.mjs'))).discoverPage({ document, window });
    dispatchCommand(adapter, message.type, message.args, { discover }).then(sendResponse);
    return true;
  });
  globalThis.__courseMemoryCompanionLoaded = true;

  // Adapters re-resolve the player on every call, so SPA navigations are re-detected automatically.
  // Push a compact state snapshot so the local app can show what is playing.
  setInterval(async () => {
    try { chrome.runtime.sendMessage({ kind: 'cm-state', state: sanitizeState(await adapter.getState()) }).catch(() => {}); } catch {}
  }, 1000);
  } catch (error) {
    // Loading failed: allow the next injection to retry instead of staying silently dead.
    console.warn('[companion] content_load_failed', String(error?.message || error).slice(0, 200));
  } finally { globalThis.__courseMemoryCompanionLoading = false; }
})();
