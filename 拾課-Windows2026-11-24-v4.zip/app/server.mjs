import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { makeId, searchCourses } from './lib/core.mjs';
import { ingestAuthorizedUrl } from './src/services/ingest.mjs';
import { exportClip, suggestClips } from './src/services/clips.mjs';
import { buildKnowledgePack, knowledgePackToCourseChapters, normalizeKnowledgeSegments } from './src/services/knowledge.mjs';
import { createKnowledgeGenerator } from './src/services/knowledge-ai.mjs';
import { createLocalAgentRuntime, routeLocalAgentApis } from './src/agent/runtime.mjs';
import { createConsole, routeConsoleApis } from './src/agent/console-api.mjs';
import { createTranslationProvider } from './src/translation/provider.mjs';
import { createTranslationStage } from './src/translation/stage.mjs';
import { createTranslationService, routeTranslationApis } from './src/translation/service.mjs';
import { createDiscoveryService, routeDiscoveryApis } from './src/discovery/service.mjs';
import { createSettingsStore } from './src/settings/settings.mjs';
import { createEnvironmentChecker, probeObsWebsocket } from './src/settings/environment.mjs';
import { createLearningSession } from './src/settings/learning-session.mjs';
import { createObsLauncher } from './src/settings/obs-launcher.mjs';
import { routeSettingsApis } from './src/settings/api.mjs';
import { createProcessRunner } from './src/pipeline/process-runner.mjs';
import { describeError } from './src/settings/processing.mjs';
import { handleCourseArchiveRequest } from './src/library/archive.mjs';
import { handleTranscriptLibraryRequest } from './src/library/transcripts.mjs';
import { receiveMediaImport } from './src/library/media-import.mjs';
import { createLibraryShell, handleLibraryShellRequest } from './src/library/shell.mjs';
import { checkLocalRequest } from './src/settings/api.mjs';
import { createRclone } from './src/backup/rclone.mjs';
import { createDriveFolderAdapter } from './src/backup/drive-folder.mjs';
import { createBackupService } from './src/backup/service.mjs';
import { TRANSCRIPT_EMPTY, buildPipelineCourse, publishErrorCode, shouldAttemptPublish, trackKeyOf } from './src/pipeline/publish.mjs';
import { createBackupSettings, routeBackupApis } from './src/backup/api.mjs';
import { readJson as readJsonFile, writeJsonAtomic } from './src/pipeline/files.mjs';
import { createLiveService } from './src/live/service.mjs';
import { routeLiveApis } from './src/live/api.mjs';
import { companionView } from './src/agent/console.mjs';
import { siteOf } from './src/discovery/urls.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const json = async (file, fallback) => { try { return JSON.parse(await fsp.readFile(file, 'utf8')); } catch { return fallback; } };
const save = (file, data) => fsp.writeFile(file, JSON.stringify(data, null, 2), 'utf8');
const defaults = JSON.parse(await fsp.readFile(path.join(root, 'config.example.json'), 'utf8'));
const config = { ...defaults, ...await json(path.join(root, 'config.json'), {}) };
config.port = Number(process.env.COURSE_MEMORY_PORT || config.port);
for (const key of ['recordingsFolder', 'libraryFolder', 'importsFolder', 'clipsFolder', 'pythonCommand', 'whisperCppCommand', 'whisperCppModel']) if (!path.isAbsolute(config[key])) config[key] = path.join(root, config[key]);
await Promise.all([fsp.mkdir(config.recordingsFolder, { recursive: true }), fsp.mkdir(config.libraryFolder, { recursive: true }), fsp.mkdir(config.importsFolder, { recursive: true }), fsp.mkdir(config.clipsFolder, { recursive: true }), fsp.mkdir(path.join(root, 'data'), { recursive: true })]);
const libraryShell = createLibraryShell({ recordingsFolder: config.recordingsFolder });
const canRun = (command) => new Promise((resolve) => {
  const child = spawn('where.exe', [command], { windowsHide: true });
  child.on('error', () => resolve(false));
  child.on('close', (code) => resolve(code === 0));
});
const configuredCommandAvailable = (command) => path.isAbsolute(command) ? fs.existsSync(command) : canRun(command);
const environment = {
  ffmpeg: await configuredCommandAvailable(config.ffmpegCommand || 'ffmpeg'),
  python: fs.existsSync(config.pythonCommand),
  obs: fs.existsSync(path.join(process.env.ProgramFiles || 'C:\\Program Files', 'obs-studio', 'bin', '64bit', 'obs64.exe')) || await canRun('obs64'),
  ollama: await canRun('ollama'),
  rclone: await canRun('rclone')
};
environment.ai = (config.aiProvider || 'ollama') === 'ollama' ? environment.ollama
  : config.aiProvider === 'openai' ? Boolean(config.openaiApiKey)
    : config.aiProvider === 'gemini' ? Boolean(config.geminiApiKey) : false;
let knowledgeGenerator = createKnowledgeGenerator(config);
const indexFile = path.join(config.libraryFolder, 'index.json');
const sessionFile = path.join(root, 'data', 'session.json');
const jobsFile = path.join(root, 'data', 'jobs.json');
const queueFile = path.join(root, 'data', 'learning-queue.json');
const clipsIndexFile = path.join(config.clipsFolder, 'index.json');
let courses = await json(indexFile, []);
if (!courses.length) {
  const demo = await json(path.join(root, 'demo', 'course.json'), null);
  if (demo) { courses = [demo]; await save(indexFile, courses); }
}
let processing = new Set();
let jobs = await json(jobsFile, []);
let clips = await json(clipsIndexFile, []);
let learningQueue = await json(queueFile, []);
const stable = new Map();
// Agent Runner + browser Companion (P3B). Interrupted jobs become blocked at startup; nothing auto-resumes.
const resolveAgentSessionOptions = async (session) => {
  if (!/^job_[0-9a-f]{12}$/.test(String(session?.agentJobId))) return null;
  try { const prefs = JSON.parse(await fsp.readFile(path.join(root, 'data', 'agent-console', `${session.agentJobId}.json`), 'utf8')); return ['auto', 'en', 'zh-Hant', 'zh-Hans'].includes(prefs.transcriptLanguage) ? { language: prefs.transcriptLanguage } : null; } catch { return null; }
};
const agentRuntime = await createLocalAgentRuntime({ root, config, sessionOptionsResolver: resolveAgentSessionOptions });

// P4C: settings page, environment status, processing centre and the mode-aware learning session.
const settingsStore = createSettingsStore({ configFile: path.join(root, 'config.json'), liveConfig: config, onChange: (changed) => {
  if (changed.some((key) => /^(aiProvider|knowledgeMode|summaryDetail|externalTranscriptSharing|ollama|openai|gemini)/.test(key))) knowledgeGenerator = createKnowledgeGenerator(config);
  environment.ai = (config.aiProvider || 'ollama') === 'ollama' ? environment.ollama : config.aiProvider === 'openai' ? Boolean(config.openaiApiKey) : config.aiProvider === 'gemini' ? Boolean(config.geminiApiKey) : false;
} });
const environmentChecker = createEnvironmentChecker({
  run: createProcessRunner().run, config, root, transcriber: agentRuntime.transcriber,
  obsInstalled: () => environment.obs,
  probeObs: () => probeObsWebsocket({ url: config.obsUrl || 'ws://127.0.0.1:4455', password: config.obsPassword }),
  keyConfigured: (provider) => Boolean(provider === 'openai' ? config.openaiApiKey : config.geminiApiKey)
});
const obsLauncher = createObsLauncher({
  run: createProcessRunner().run,
  probe: () => probeObsWebsocket({ url: config.obsUrl || 'ws://127.0.0.1:4455', password: config.obsPassword })
});
const learningSession = createLearningSession({
  sessionFile, captureFactory: agentRuntime.captureFactory, listAgentJobs: agentRuntime.listAgentJobs,
  prepareCapture: async (mode) => { if (mode === 'video') { await obsLauncher.ensureReady(); environmentChecker.invalidate(); } },
  enqueueCapture: (mode, files, meta = {}) => { if (!agentRuntime.pipeline) throw Object.assign(new Error('pipeline unavailable'), { code: 'PIPELINE_UNAVAILABLE' }); return agentRuntime.pipeline.enqueue({ source: { kind: mode }, files, title: meta.title, timeMap: { source: 'none' } }); }
});
const pipelinePublishErrors = new Map();
const settingsContext = {
  port: config.port, settings: settingsStore, environment: environmentChecker, learning: learningSession, pipeline: agentRuntime.pipeline,
  listAgentJobs: agentRuntime.listAgentJobs, listSessions: agentRuntime.listSessions, courses: () => courses, legacyJobs: () => jobs,
  publishErrors: () => [...pipelinePublishErrors.entries()].map(([jobId, value]) => ({ jobId, ...value }))
};

let liveService = null; // P9, created after the backup service (hooks above read it lazily)
// P4D: private cloud backup (rclone) + local space protection. Only allow-listed course artifacts are
// uploaded; verified local originals are removed only when the cleanup policy allows it.
const backupProcess = createProcessRunner();
const driveFolderReady = typeof config.backup?.driveFolder === 'string' && path.isAbsolute(config.backup.driveFolder) && fs.existsSync(config.backup.driveFolder);
const rclone = driveFolderReady ? createDriveFolderAdapter({ root: config.backup.driveFolder }) : createRclone({ run: backupProcess.run, start: backupProcess.start });
const backupService = createBackupService({
  config, dataDir: path.join(root, 'data'), rclone,
  roots: [config.recordingsFolder, config.importsFolder, ...(config.audioCapture?.outputFolder ? [path.resolve(root, config.audioCapture.outputFolder)] : [])],
  workRoot: path.join(root, 'data', 'pipeline', 'work'), libraryFolder: config.libraryFolder,
  listCourses: async () => courses, listPipelineJobs: async () => (agentRuntime.pipeline ? agentRuntime.pipeline.list() : []),
  freeBytes: () => agentRuntime.storage.measure(),
  // P7B: incremental backup hooks (no paths leave these helpers).
  listPublishErrors: async () => [...pipelinePublishErrors.entries()].map(([jobId, value]) => ({ jobId, code: value.code })),
  // P9: closed live segments only (paths stay inside the backup service; keys are media/segment-NNN.ext).
  listLiveSessions: async () => (liveService ? liveService.backupSources() : []),
  // P9: a live file whose owner was only inferred (or a quarantined candidate) is never removed by cleanup.
  canRemove: async (file) => (liveService ? liveService.mayRemove(file) : true),
  listActiveRecordings: async () => {
    const sessions = (await agentRuntime.listSessions().catch(() => [])).filter((item) => ['starting', 'recording', 'stopping'].includes(item.status));
    if (!sessions.length) return learningSession.capturing ? [{ id: 'manual', title: '手動錄影中' }] : [];
    const jobs = await agentRuntime.listAgentJobs().catch(() => []);
    return sessions.map((item) => ({ id: item.id, title: jobs.find((job) => job.id === item.agentJobId)?.plan?.lessons?.find((lesson) => lesson.lessonId === item.lessonId)?.title || '錄影中' }));
  },
  isMediaWriting: async (file) => {
    if (liveService && await liveService.isWriting(file)) return true;
    const key = path.resolve(file).toLowerCase();
    const sessions = await agentRuntime.listSessions().catch(() => []);
    if (sessions.some((item) => !['completed', 'partial', 'failed'].includes(item.status) && [item.obsOutputPath, ...(item.obsOutputFiles || [])].filter(Boolean).some((out) => path.resolve(out).toLowerCase() === key))) return true;
    if (!learningSession.capturing) return false;
    const stat = await fsp.stat(file).catch(() => null);
    return !stat || Date.now() - stat.mtimeMs < 120_000; // a legacy manual capture may be writing a recent file
  },
  isMediaBusy: async (file) => {
    if (liveService && await liveService.isWriting(file)) return true;
    const key = path.resolve(file).toLowerCase();
    if ([...processing].some((item) => path.resolve(item).toLowerCase() === key) || learningSession.capturing) return true;
    const active = agentRuntime.pipeline ? (await agentRuntime.pipeline.list()).filter((job) => !['completed', 'failed', 'cancelled'].includes(job.status)) : [];
    return active.some((job) => job.asset?.files?.some((item) => path.resolve(item.path).toLowerCase() === key));
  }
});
agentRuntime.storage.setReclaimer(() => backupService.reclaimIfLow());
const backupContext = {
  port: config.port, backup: backupService, rclone,
  settings: createBackupSettings({ liveConfig: config, readRaw: async () => { const raw = await readJsonFile(path.join(root, 'config.json'), {}); return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}; }, writeRaw: (raw) => writeJsonAtomic(path.join(root, 'config.json'), raw) })
};
setInterval(() => { if (config.backup?.autoUpload === true && config.cloudDestination) backupService.run().catch(() => {}); }, 60_000).unref();
// P7B: back up a recording as soon as it enters the pipeline, and append each new result right away.
let backupSignature = '';
async function pokeBackupIfChanged() {
  const jobs = agentRuntime.pipeline ? await agentRuntime.pipeline.list() : [];
  const signature = JSON.stringify([jobs.map((job) => [job.id, job.status, (job.stages || []).filter((stage) => stage.status === 'completed').length]), courses.map((course) => [course.id, course.status, Boolean(course.knowledge)]), [...pipelinePublishErrors.keys()]]);
  if (signature === backupSignature) return;
  backupSignature = signature; await backupService.poke();
}
backupService.checkConnection().catch(() => {});

// P5: Agent 學習 console — a thin bridge over the existing Agent service (no new Runner behaviour).
const consoleContext = { port: config.port, dataDir: path.join(root, 'data'), service: agentRuntime.service, store: agentRuntime.agentStore, freeBytes: () => agentRuntime.storage?.measure?.(),
  // P8 setup wizard「測試連線」: read-only Companion commands only (enforced in console-api).
  companionCommand: (command) => agentRuntime.hub.sendCommand(command) };
consoleContext.console = createConsole(consoleContext);
// P7A 匯入課程清單: read-only discovery through the bound Companion tab; plans go through the P5 console.
const discoveryContext = { port: config.port, discovery: createDiscoveryService({
  sendCommand: (command) => agentRuntime.hub.sendCommand(command), companionStatus: () => agentRuntime.service.companionStatus(),
  console: consoleContext.console, listJobs: () => agentRuntime.agentStore.listJobs(), freeBytes: consoleContext.freeBytes,
  listLocalVideos: async () => {
    const known = new Set(courses.flatMap((course) => [course.video, course.sourceMedia?.path, course.sourceMedia?.name]).filter(Boolean).map((item) => path.basename(String(item)).toLowerCase()));
    const names = (await fsp.readdir(config.recordingsFolder).catch(() => [])).filter((name) => /\.(mp4|mkv|mov|webm)$/i.test(name));
    return Promise.all(names.map(async (name) => { const stat = await fsp.stat(path.join(config.recordingsFolder, name)).catch(() => null); return { name, sizeBytes: stat?.size || 0, modifiedAt: stat ? stat.mtime.toISOString() : null, inLibrary: known.has(name.toLowerCase()) }; }));
  },
  scanLocal: () => scan()
}) };
agentRuntime.setSessionOptionsResolver(resolveAgentSessionOptions);

// P9 直播工作台: unattended live capture through OBS (browser-visible screen only). Nothing resumes by itself
// after a restart; an interrupted recording is shown as「OBS 可能仍在錄影」until the user decides.
const unavailableObs = { state: 'closed', on: () => () => {}, connect: async () => { throw Object.assign(new Error('OBS 用戶端無法建立'), { code: 'OBS_UNAVAILABLE' }); } };
const liveObs = agentRuntime.obsClient || unavailableObs;
liveService = createLiveService({
  dataDir: path.join(root, 'data'), obs: liveObs,
  rights: { read: (id) => agentRuntime.agentStore.readRights(id), save: (record) => agentRuntime.agentStore.saveRights(record) },
  freeBytes: () => agentRuntime.storage.measure(),
  disk: { warnBytes: Math.max(1, Number(config.backup?.warnFreeGb) || 10) * 1024 ** 3, stopBytes: Math.max(1, Number(config.live?.stopFreeGb) || 3) * 1024 ** 3 },
  backup: { poke: () => backupService.poke(), items: (courseId) => backupService.items(courseId), cleanupSafe: () => backupService.reclaimIfLow(), retry: (courseId) => backupService.retry({ courseId }).catch(() => null) },
  // Live segments are only backed up by the automatic uploader; with it switched off the session must say so.
  cloudStatus: async () => (config.backup?.autoUpload === true ? backupService.connectionState() : { state: config.cloudDestination ? 'auto-upload-off' : 'not-set' }),
  recordDirectory: async () => (await liveObs.getRecordDirectory()) || null,
  listMediaFiles: async (dir) => {
    const names = (await fsp.readdir(dir).catch(() => [])).filter((name) => /\.(mkv|mp4|mov|flv|ts)$/i.test(name));
    return (await Promise.all(names.map(async (name) => { const file = path.join(dir, name); const stat = await fsp.stat(file).catch(() => null); return stat?.isFile() ? { path: file, mtimeMs: stat.mtimeMs } : null; }))).filter(Boolean);
  },
  allowedRoots: [config.recordingsFolder, config.importsFolder],
  audioOnlyConfirmed: () => config.obsAudioOnlyProfileConfirmed === true,
  // Read-only page check through the bound Companion tab (getState); only when it shows the planned site.
  pageBlocker: async (source) => {
    const view = companionView(agentRuntime.service.companionStatus());
    if (!view.paired || !view.connected || !view.tabSelected || !view.site) return 'NOT_MONITORED';
    let host; try { host = new URL(source.pageUrl).hostname; } catch { return 'NOT_MONITORED'; }
    if (siteOf(host) !== siteOf(view.site)) return 'NOT_MONITORED';
    const reply = await agentRuntime.hub.sendCommand({ type: 'getState', args: {} }).catch(() => null);
    return typeof reply?.state?.blocker === 'string' ? reply.state.blocker : null;
  }
});
const liveContext = { port: config.port, live: liveService };
await liveService.recover().then((ids) => { if (ids.length) console.warn(`直播工作台：${ids.length} 場直播在程式重新啟動時中斷，請到「直播工作台」確認 OBS 狀態。`); }).catch(() => {});
setInterval(() => liveService.tick().catch((error) => console.warn(`直播工作台排程檢查失敗：${error.code || error.message}`)), 5000).unref();
// P9: the legacy watcher must not take a live segment (or any OBS file from a live window whose paths are still being
// resolved — including right after a stop). Normal recordings outside live windows are untouched.
const liveOwnsFile = async (file) => { const stat = await fsp.stat(file).catch(() => null); if (await liveService.holdsFile(file, stat?.mtimeMs)) return true; return Boolean(stat && liveService.recordingSince() !== null && stat.mtimeMs >= liveService.recordingSince()); };

// P6: bilingual transcripts. Provider = the one chosen in 設定 (never switched automatically); `none` skips.
const translationStage = createTranslationStage({ dataDir: path.join(root, 'data'), provider: () => createTranslationProvider(config) });
const translationContext = { port: config.port };
translationContext.translations = createTranslationService({
  stage: translationStage, config, dataDir: path.join(root, 'data'), listCourses: async () => courses,
  listPipelineJobs: async () => (agentRuntime.pipeline ? agentRuntime.pipeline.list() : []), listSessions: () => agentRuntime.listSessions()
});
let translationPass = null;
setInterval(() => { if (!translationPass) translationPass = translationContext.translations.autoPass().catch(() => {}).finally(() => { translationPass = null; }); }, 10_000).unref();

const sameFile = (a, b) => a && b && path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase();
const publishingPipelineJobs = new Set();

/** Publish completed P4A transcripts into the user-facing library. The pipeline remains the source of
 * truth; this is an idempotent projection for the current UI and never copies or uploads the media. */
async function syncPipelineCourses() {
  if (!agentRuntime.pipeline) return;
  const pipelineJobs = await agentRuntime.pipeline.list();
  for (const job of pipelineJobs.filter((item) => item.status === 'completed' && item.result?.transcript)) {
    if (courses.some((course) => course.pipelineJobId === job.id) || publishingPipelineJobs.has(job.id)) continue;
    const media = job.asset?.files?.[0]?.path; if (!media || processing.has(media)) continue;
    // P7B: an empty transcript is a final answer for that transcript revision, not a retry loop.
    if (!shouldAttemptPublish(job, pipelinePublishErrors.get(job.id))) continue;
    publishingPipelineJobs.add(job.id);
    try {
      const transcriptFile = path.join(root, 'data', 'pipeline', 'work', job.result.assetDir, job.result.transcript);
      const track = await json(transcriptFile, null);
      const existing = courses.find((course) => sameFile(course.sourceMedia || course.video, media));
      const course = await buildPipelineCourse({ job, track, existing, workRoot: path.join(root, 'data', 'pipeline', 'work'), chapterMinutes: config.chapterMinutes, generate: knowledgeGenerator });
      if (!existing) courses.unshift(course);
      const dir = path.join(config.libraryFolder, course.id); await fsp.mkdir(dir, { recursive: true });
      await save(path.join(dir, 'course.json'), course); await save(indexFile, courses);
      pipelinePublishErrors.delete(job.id);
    } catch (error) {
      const code = publishErrorCode(error);
      pipelinePublishErrors.set(job.id, { code, at: new Date().toISOString(), trackKey: trackKeyOf(job) });
      if (code !== TRANSCRIPT_EMPTY) console.warn(`無法發布逐字稿工作 ${job.id}: ${code}`);
    } finally { publishingPipelineJobs.delete(job.id); }
  }
}

function queueJob(type, detail, action) {
  const job = { id: makeId(`${type}:${Date.now()}:${Math.random()}`), type, detail, status: 'queued', progress: 0, createdAt: new Date().toISOString(), error: '' };
  jobs.unshift(job); jobs = jobs.slice(0, 100); save(jobsFile, jobs);
  setImmediate(async () => {
    job.status = 'running'; job.startedAt = new Date().toISOString(); job.progress = 10; await save(jobsFile, jobs);
    try { job.result = await action(job); job.status = 'completed'; job.progress = 100; }
    catch (error) { job.status = 'failed'; job.error = error.message; }
    job.finishedAt = new Date().toISOString(); await save(jobsFile, jobs);
  });
  return job;
}

function run(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { windowsHide: true, cwd: root });
    let stderr = '';
    child.stderr.on('data', (d) => stderr += d);
    child.on('error', reject);
    child.on('close', (code) => code === 0 ? resolve() : reject(new Error(stderr.slice(-1200) || `${command} 結束代碼 ${code}`)));
  });
}

/** Legacy library path: the same engine (and 自動 fallback) as the P4A pipeline; reasons stay readable. */
async function transcribe(audio, out) {
  const provider = agentRuntime.transcriber;
  if (!provider) throw Object.assign(new Error('轉錄工具尚未設定'), { code: 'WHISPER_NOT_CONFIGURED' });
  const language = { auto: 'auto', en: 'en', zh: 'zh-Hant' }[config.whisperLanguage] || 'auto';
  const raw = await provider.transcribe({ audio, outDir: path.dirname(out), language, wordTimestamps: false });
  return { language: raw.language || 'auto', engine: raw.engine, segments: raw.segments.map((s) => ({ start: s.start, end: s.end, text: String(s.text || '').trim() })).filter((s) => s.text) };
}

async function processVideo(video) {
  const id = makeId(`${video}:${(await fsp.stat(video)).mtimeMs}`);
  if (courses.some((c) => c.id === id) || processing.has(video)) return;
  processing.add(video);
  const title = path.basename(video, path.extname(video));
  const rights = await json(`${video}.rights.json`, { basis: 'user-authorized-recording', sourceType: 'recording', acknowledgedAt: new Date().toISOString() });
  const course = { id, title, video, rights, createdAt: new Date().toISOString(), status: 'processing', language: '', segments: [], chapters: [], markers: [], error: '' };
  courses.unshift(course); await save(indexFile, courses);
  try {
    const dir = path.join(config.libraryFolder, id); await fsp.mkdir(dir, { recursive: true });
    const audio = path.join(dir, 'audio.wav'); const transcriptPath = path.join(dir, 'transcript.json');
    await run(config.ffmpegCommand || 'ffmpeg', ['-y', '-i', video, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', audio]);
    const transcript = await transcribe(audio, transcriptPath);
    const normalized = normalizeKnowledgeSegments(transcript.segments);
    course.language = transcript.language; course.transcriptEngine = transcript.engine ? { name: transcript.engine.name, model: transcript.engine.model, ...(transcript.engine.backend ? { backend: transcript.engine.backend } : {}), ...(transcript.engine.fallbackFrom ? { fallbackFrom: transcript.engine.fallbackFrom } : {}) } : null; course.segments = normalized.map((segment) => ({ id: segment.id, start: segment.rec[0], end: segment.rec[1], src: segment.src, text: segment.text }));
    const track = { id: `trk_${id}`, assetId: `ast_${id}`, revision: 1, language: transcript.language || 'auto', segments: normalized };
    course.knowledge = await buildKnowledgePack({ title, track, chapterMinutes: config.chapterMinutes, generate: knowledgeGenerator });
    course.chapters = knowledgePackToCourseChapters(course.knowledge, normalized);
    const session = await json(sessionFile, null);
    // Only a finished session hands its markers over; an active recording session must never be cleared.
    if (session?.markers?.length && session.stoppedAt) { course.markers = session.markers; await save(sessionFile, null); }
    course.status = 'ready'; await save(path.join(dir, 'course.json'), course);
  } catch (error) {
    // Readable reason + code only (describeError adds the advice); never a raw stack, path or「RuntimeError」.
    const code = /^[A-Z][A-Z0-9_]{2,60}$/.test(String(error?.code || '')) ? error.code : 'LEGACY_PROCESSING_FAILED';
    course.status = 'error'; course.errorCode = code; course.error = describeError(code, error?.message).message;
  }
  finally { processing.delete(video); await save(indexFile, courses); }
}

async function scan() {
  // Files already owned by the P4A pipeline must never be processed again by the legacy watcher.
  const pipelineFiles = new Set();
  if (agentRuntime.pipeline) {
    for (const job of await agentRuntime.pipeline.list()) for (const item of job.asset?.files || []) if (item.path) pipelineFiles.add(path.resolve(item.path).toLowerCase());
  }
  const names = await fsp.readdir(config.recordingsFolder).catch(() => []);
  for (const name of names.filter((n) => /\.(mp4|mkv|mov|webm)$/i.test(n))) {
    const file = path.join(config.recordingsFolder, name); const stat = await fsp.stat(file); const prior = stable.get(file);
    stable.set(file, stat.size);
    // P9: live segments are not legacy lessons (P9 only records + backs them up; processing comes later).
    if (prior === stat.size && !pipelineFiles.has(path.resolve(file).toLowerCase()) && !(await liveOwnsFile(file))) processVideo(file);
  }
}

async function body(req) { let text = ''; for await (const chunk of req) { text += chunk; if (text.length > 1e6) throw new Error('內容過大'); } return text ? JSON.parse(text) : {}; }
const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml' };
function send(res, status, value, type = 'application/json; charset=utf-8') { const data = type.startsWith('application/json') ? JSON.stringify(value) : value; res.writeHead(status, { 'content-type': type, 'cache-control': 'no-store' }); res.end(data); }

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (await routeLocalAgentApis(agentRuntime, req, res, url)) return;
    if (await routeConsoleApis(consoleContext, req, res, url)) return;
    if (await routeTranslationApis(translationContext, req, res, url)) return;
    if (await routeDiscoveryApis(discoveryContext, req, res, url)) return;
    if (await routeSettingsApis(settingsContext, req, res, url)) return;
    if (await routeBackupApis(backupContext, req, res, url)) return;
    if (await routeLiveApis(liveContext, req, res, url)) return;
    if (url.pathname === '/api/library/open-recordings') {
      const result = handleLibraryShellRequest({ port: config.port, shell: libraryShell }, { method: req.method, pathname: url.pathname, headers: req.headers });
      if (result) return send(res, result.status, result.body);
      return send(res, 405, { error: 'METHOD_NOT_ALLOWED' });
    }
    if (url.pathname === '/api/transcripts' || /^\/api\/transcripts\/[^/]+\/(rename|trash|restore|text)$/.test(url.pathname)) {
      const data = req.method === 'POST' ? await body(req).catch(() => null) : null;
      const result = await handleTranscriptLibraryRequest({ port: config.port, courses: () => courses, saveCourse: async (course) => {
        await save(indexFile, courses);
        const courseFile = path.join(config.libraryFolder, course.id, 'course.json');
        if (fs.existsSync(courseFile)) await save(courseFile, course);
      } }, { method: req.method, pathname: url.pathname, headers: req.headers, body: data });
      if (result) return send(res, result.status, result.body);
      return send(res, 405, { error: 'METHOD_NOT_ALLOWED' });
    }
    if (url.pathname === '/api/imports/file' && req.method === 'POST') {
      const rejected = checkLocalRequest({ method: req.method, pathname: url.pathname, headers: req.headers }, config.port);
      if (rejected) return send(res, 403, { error: rejected, message: '只接受本機介面的請求' });
      try {
        const imported = await receiveMediaImport({ request: req, importsFolder: config.importsFolder });
        const queued = await agentRuntime.enqueueImport(imported.name);
        return send(res, 202, { ok: true, name: imported.name, bytes: imported.bytes, jobId: queued?.job?.id || queued?.id || null });
      } catch (error) { return send(res, error.status || 400, { error: error.code || 'IMPORT_FAILED', message: error.message || '匯入失敗' }); }
    }
    if (/^\/api\/courses\/[^/]+\/(archive|unarchive)$/.test(url.pathname)) {
      const data = req.method === 'POST' ? await body(req).catch(() => null) : null;
      const result = await handleCourseArchiveRequest({ port: config.port, courses: () => courses, saveCourse: async (course) => {
        await save(indexFile, courses);
        const courseFile = path.join(config.libraryFolder, course.id, 'course.json');
        if (fs.existsSync(courseFile)) { const stored = await json(courseFile, null); if (stored) { if (course.archived) Object.assign(stored, { archived: true, archivedAt: course.archivedAt }); else { delete stored.archived; delete stored.archivedAt; } await save(courseFile, stored); } }
      } }, { method: req.method, pathname: url.pathname, headers: req.headers, body: data });
      if (result) return send(res, result.status, result.body);
      return send(res, 405, { error: 'METHOD_NOT_ALLOWED' });
    }
    if (url.pathname === '/api/status') return send(res, 200, { recordingsFolder: config.recordingsFolder, transcriber: config.transcriber, whisperModel: config.whisperModel, aiProvider: config.aiProvider || 'ollama', ollamaModel: config.ollamaModel, processing: processing.size, environment, features: { urlIngest: environment.python, clips: environment.ffmpeg, cloud: environment.rclone || Boolean(config.cloudDestination) } });
    if (url.pathname === '/api/courses') return send(res, 200, courses.map(({ video, ...c }) => c));
    if (url.pathname === '/api/search') return send(res, 200, searchCourses(courses.filter((course) => !course.trashed), url.searchParams.get('q')));
    if (url.pathname === '/api/jobs') return send(res, 200, jobs);
    if (url.pathname === '/api/queue' && req.method === 'GET') return send(res, 200, learningQueue);
    if (url.pathname === '/api/queue' && req.method === 'POST') { const data = await body(req); const parsed = new URL(data.url); if (!['http:', 'https:'].includes(parsed.protocol)) return send(res, 400, { error: '請輸入有效的課程網址' }); const item = { id: makeId(`${data.url}:${Date.now()}`), title: String(data.title || parsed.hostname).slice(0, 200), url: parsed.toString(), platform: String(data.platform || parsed.hostname).slice(0, 80), status: 'pending', chapter: String(data.chapter || '').slice(0, 200), createdAt: new Date().toISOString() }; learningQueue.push(item); await save(queueFile, learningQueue); return send(res, 201, item); }
    const queueCompleteMatch = url.pathname.match(/^\/api\/queue\/([^/]+)\/complete$/);
    if (queueCompleteMatch && req.method === 'POST') { const item = learningQueue.find((entry) => entry.id === queueCompleteMatch[1]); if (!item) return send(res, 404, { error: '找不到課程佇列項目' }); item.status = 'completed'; item.completedAt = new Date().toISOString(); await save(queueFile, learningQueue); return send(res, 200, item); }
    if (url.pathname === '/api/agent/state') return send(res, 200, { session: await learningSession.status(), nextCourse: learningQueue.find((item) => item.status === 'pending') || null, queue: learningQueue, jobs: jobs.filter((job) => ['queued', 'running'].includes(job.status)), courses: courses.map((course) => ({ id: course.id, title: course.title, status: course.status, chapters: course.chapters?.length || 0 })) });
    if (url.pathname === '/api/clips') return send(res, 200, clips.map(({ file, subtitle, ...clip }) => clip));
    if (url.pathname === '/api/clips/suggestions') { const course = courses.find((c) => c.id === url.searchParams.get('courseId')); if (!course) return send(res, 404, { error: '找不到課程' }); return send(res, 200, suggestClips(course)); }
    if (url.pathname === '/api/scan' && req.method === 'POST') { await scan(); return send(res, 200, { ok: true }); }
    if (url.pathname === '/api/ingest/url' && req.method === 'POST') { const data = await body(req); const job = queueJob('url-ingest', { url: String(data.url || '').slice(0, 2000) }, async () => { const result = await ingestAuthorizedUrl({ url: data.url, rights: data.rights, importsFolder: config.importsFolder, pythonCommand: config.pythonCommand }); await processVideo(result.video); return { importId: result.id }; }); return send(res, 202, job); }
    if (url.pathname === '/api/clips/export' && req.method === 'POST') { const data = await body(req); const course = courses.find((c) => c.id === data.courseId); if (!course || course.demo) return send(res, 400, { error: '請選擇已匯入的真實課程影片' }); const job = queueJob('clip-export', { courseId: course.id, title: data.title }, async () => { const clip = await exportClip({ course, start: data.start, end: data.end, title: data.title, format: data.format, clipsFolder: config.clipsFolder }); clips.unshift(clip); await save(clipsIndexFile, clips); return { clipId: clip.id }; }); return send(res, 202, job); }
    // Compatibility route for the old Creator Studio form. It deliberately ignores any caller-supplied
    // destination/mode and delegates to the allow-listed P4D service, so a browser cannot make the
    // legacy whole-folder uploader leak course.json paths or other files.
    if (url.pathname === '/api/cloud/backup' && req.method === 'POST') { const data = await body(req); const course = courses.find((c) => c.id === data.courseId); if (!course || course.demo) return send(res, 400, { error: '請選擇已匯入的真實課程影片' }); const job = queueJob('cloud-backup', { courseId: course.id }, () => backupService.run({ courseId: course.id })); return send(res, 202, job); }
    if (url.pathname === '/api/session' && req.method === 'GET') return send(res, 200, await learningSession.status());
    if (url.pathname === '/api/session/start' && req.method === 'POST' && ((await learningSession.status()).active || learningSession.capturing)) return send(res, 409, { error: '已經有進行中的學習，請先在首頁結束' });
    if (url.pathname === '/api/session/start' && req.method === 'POST') { const session = { startedAt: Date.now(), markers: [] }; await save(sessionFile, session); return send(res, 200, session); }
    if (url.pathname === '/api/session/stop' && req.method === 'POST' && learningSession.capturing) return send(res, 200, await learningSession.stop());
    if (url.pathname === '/api/session/stop' && req.method === 'POST') { const session = await json(sessionFile, null); if (session) { session.stoppedAt = Date.now(); await save(sessionFile, session); } return send(res, 200, session); }
    if (url.pathname === '/api/markers' && req.method === 'POST') { const data = await body(req); const session = await json(sessionFile, { startedAt: Date.now(), markers: [] }); const marker = { id: makeId(`${Date.now()}${Math.random()}`), at: Math.max(0, (Date.now() - session.startedAt) / 1000), note: String(data.note || '⭐ 重點').slice(0, 300), createdAt: new Date().toISOString() }; session.markers ||= []; session.markers.push(marker); await save(sessionFile, session); return send(res, 200, marker); }
    const courseMarkerMatch = url.pathname.match(/^\/api\/courses\/([^/]+)\/markers$/);
    if (courseMarkerMatch && req.method === 'POST') { const course = courses.find((c) => c.id === courseMarkerMatch[1]); if (!course) return send(res, 404, { error: '找不到課程' }); const data = await body(req); const marker = { id: makeId(`${Date.now()}${Math.random()}`), at: Math.max(0, Number(data.at) || 0), note: String(data.note || '⭐ 重點').slice(0, 300), createdAt: new Date().toISOString() }; course.markers ||= []; course.markers.push(marker); await save(indexFile, courses); if (!course.demo) { const courseFile = path.join(config.libraryFolder, course.id, 'course.json'); if (fs.existsSync(courseFile)) await save(courseFile, course); } return send(res, 200, marker); }
    const videoMatch = url.pathname.match(/^\/api\/courses\/([^/]+)\/video$/);
    if (videoMatch) { const course = courses.find((c) => c.id === videoMatch[1]); if (!course) return send(res, 404, { error: '找不到課程' }); const stat = await fsp.stat(course.video); const range = req.headers.range; const mediaType = ({ '.wav': 'audio/wav', '.flac': 'audio/flac', '.m4a': 'audio/mp4', '.webm': 'video/webm', '.mkv': 'video/x-matroska', '.mov': 'video/quicktime' })[path.extname(course.video).toLowerCase()] || 'video/mp4'; if (range) { const [a, b] = range.replace('bytes=', '').split('-'); const start = Number(a), end = b ? Number(b) : Math.min(start + 2 ** 20, stat.size - 1); res.writeHead(206, { 'content-type': mediaType, 'content-range': `bytes ${start}-${end}/${stat.size}`, 'accept-ranges': 'bytes', 'content-length': end - start + 1 }); fs.createReadStream(course.video, { start, end }).pipe(res); } else { res.writeHead(200, { 'content-type': mediaType, 'content-length': stat.size, 'accept-ranges': 'bytes' }); fs.createReadStream(course.video).pipe(res); } return; }
    const clipFileMatch = url.pathname.match(/^\/api\/clips\/([^/]+)\/file$/);
    if (clipFileMatch) { const clip = clips.find((c) => c.id === clipFileMatch[1]); if (!clip) return send(res, 404, { error: '找不到剪輯輸出' }); const stat = await fsp.stat(clip.file); res.writeHead(200, { 'content-type': 'video/mp4', 'content-length': stat.size, 'content-disposition': `attachment; filename="${clip.id}.mp4"` }); fs.createReadStream(clip.file).pipe(res); return; }
    const relative = url.pathname === '/' ? 'index.html' : url.pathname.slice(1); const file = path.resolve(root, 'web', relative); const webRoot = path.resolve(root, 'web');
    if (!file.startsWith(webRoot)) return send(res, 403, { error: '禁止存取' });
    const data = await fsp.readFile(file); return send(res, 200, data, mime[path.extname(file)] || 'application/octet-stream');
  } catch (error) { send(res, error.code === 'ENOENT' ? 404 : 500, { error: error.message }); }
});

setInterval(scan, 5000).unref();
setInterval(() => syncPipelineCourses().catch(() => {}).then(() => pokeBackupIfChanged()).catch(() => {}), 4000).unref();
await scan(); setImmediate(() => syncPipelineCourses().catch(() => {}));
server.listen(config.port, '127.0.0.1', () => console.log(`Course Knowledge 正在執行：http://127.0.0.1:${config.port}`));
