import crypto from 'node:crypto';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { isInside, writeFileAtomic } from '../pipeline/files.mjs';
import { makeId } from '../../lib/core.mjs';

/**
 * Decides exactly which files belong to one course's private backup. Allow-list only: media originals,
 * transcript, subtitles and the generated summary / knowledge pack. Nothing is found by scanning folders,
 * so config.json, keys, cookies, browser data, temp files or other courses can never ride along.
 *
 * Remote layout (one folder per stable course id, never matched by file name):
 *   <dest>/courses/<courseId>/media/original-001.mkv
 *                            /transcript/transcript.json
 *                            /subtitles/transcript.rec.srt | transcript.src.srt | *.vtt
 *                            /summary/course.json          (sanitised: no local paths)
 *                            /knowledge/knowledge-pack.json
 *                            /manifest.json                (written last)
 */

export const COURSE_ID = /^[A-Za-z0-9_-]{6,64}$/;
const FORBIDDEN_NAME = /^(config(\.[\w-]+)?\.json|secrets?[\w.-]*|\.env(\..*)?|.*\.(key|pem|pfx|p12|kdbx|tmp|temp|part|partial|crdownload|lock|log)|cookies?(\.\w+)?|login data|web data|local state|session\.json|desktop\.ini|thumbs\.db|~\$.*|\..*)$/i;
// Keep this list limited to unambiguously sensitive/temporary folders. Generic names such as
// "agent", "default" or "profiles" are valid lesson-folder names and must not be blocked merely by
// name; explicit artifact selection + allowed-root/realpath checks remain the primary boundary.
const FORBIDDEN_SEGMENT = /^(node_modules|\.git|\.venv|user data|appdata|tmp-tests|\.tmp-test)$/i;

/** True when a local path must never be uploaded (by name or by any folder on its way). */
export function isForbiddenPath(file, { platform = process.platform } = {}) {
  const lib = platform === 'win32' ? path.win32 : path;
  const resolved = lib.resolve(String(file));
  const parts = resolved.split(/[\\/]+/).filter(Boolean);
  const name = parts.at(-1) || '';
  if (FORBIDDEN_NAME.test(name)) return true;
  return parts.slice(0, -1).some((segment) => FORBIDDEN_SEGMENT.test(segment));
}

// A configured root that *is* (or sits inside) one of these folders is refused outright: a user must not be
// able to turn a browser profile, a repository or a credential store into a backup source by pointing a root
// at it. Ordinary parents such as AppData, Local or Temp are NOT on this list — on Windows every temp folder
// lives under %LOCALAPPDATA%\Temp, and a root there is legitimate.
const SENSITIVE_ROOT_SEGMENT = /^(user data|\.git|\.venv|node_modules|\.ssh|\.gnupg|\.aws|\.azure|\.kube|\.mozilla|cookies|local storage|session storage|credentials)$/i;
const libFor = (platform) => (platform === 'win32' ? path.win32 : path.posix);
const caseKey = (value, platform) => (platform === 'win32' ? value.toLowerCase() : value);

/**
 * Shared P4D / P7B / P9 path rule. A file may be backed up (or cleaned) only when:
 *   1. its realpath lies inside the realpath of one explicitly configured root (symlink / junction escapes fail);
 *   2. that root itself is not a sensitive folder (browser User Data, .git, .ssh, …);
 *   3. the part *below* that root contains no forbidden folder (node_modules, .git, User Data, AppData, …) and
 *      neither the requested nor the real file name is forbidden (config.json, .env, cookies, Login Data, *.part, …).
 * Folders *above* the root are never inspected, so a root under C:\Users\x\AppData\Local\Temp is fine.
 * Returns { ok: true, real, root } or { ok: false, code } with code
 *   MISSING | OUTSIDE_ROOT | ROOT_SENSITIVE | FORBIDDEN_FOLDER | FORBIDDEN_NAME.
 */
export async function resolveAllowedPath(file, roots, { platform = process.platform, realpath = fsp.realpath } = {}) {
  if (typeof file !== 'string' || !file) return { ok: false, code: 'OUTSIDE_ROOT' };
  const lib = libFor(platform);
  if (FORBIDDEN_NAME.test(lib.basename(file))) return { ok: false, code: 'FORBIDDEN_NAME' };
  let real; try { real = await realpath(file); } catch { return { ok: false, code: 'MISSING' }; }
  const realRoots = await Promise.all((roots || []).filter(Boolean).map(async (root) => { try { return await realpath(root); } catch { return null; } }));
  const owners = realRoots.filter((root) => root && isInside(root, real, { platform }) && caseKey(lib.resolve(root), platform) !== caseKey(lib.resolve(real), platform));
  if (!owners.length) return { ok: false, code: 'OUTSIDE_ROOT' };
  const root = owners.sort((a, b) => b.length - a.length)[0]; // the most specific root decides
  if (lib.resolve(root).split(/[\\/]+/).filter(Boolean).some((segment) => SENSITIVE_ROOT_SEGMENT.test(segment))) return { ok: false, code: 'ROOT_SENSITIVE' };
  const parts = lib.relative(lib.resolve(root), lib.resolve(real)).split(/[\\/]+/).filter(Boolean);
  if (parts.slice(0, -1).some((segment) => FORBIDDEN_SEGMENT.test(segment) || segment.startsWith('.'))) return { ok: false, code: 'FORBIDDEN_FOLDER' };
  if (FORBIDDEN_NAME.test(parts.at(-1) || '')) return { ok: false, code: 'FORBIDDEN_NAME' };
  return { ok: true, real, root };
}

const MEDIA_EXT = /^\.(mp4|mkv|mov|webm|flv|ts|m4a|flac|wav|mp3|ogg|opus|aac)$/i;
const ASSET_ID = /^[A-Za-z0-9_-]{3,80}$/;

/** P7B: the library course id a pipeline job will be published under (same formula as server.mjs). */
export const courseIdForJob = (job) => (ASSET_ID.test(String(job?.asset?.id)) ? makeId(`pipeline:${job.asset.id}`) : null);
/** A pipeline output may be backed up only after the stage that writes it finished (files are then closed). */
export const stageDone = (job, name) => job?.status === 'completed' || Boolean(job?.stages?.some((stage) => stage.name === name && stage.status === 'completed'));
/** Asset work folder, relative to the pipeline work root; only well-formed relative values are accepted. */
export function assetDirOf(job) {
  const dir = job?.result?.assetDir || (ASSET_ID.test(String(job?.asset?.id)) ? `assets/${job.asset.id}` : null);
  return typeof dir === 'string' && /^[A-Za-z0-9_\-/]+$/.test(dir) && !dir.split('/').includes('..') ? dir : null;
}

export async function md5File(file) {
  const hash = crypto.createHash('md5'); const handle = await fsp.open(file, 'r');
  try { for await (const chunk of handle.createReadStream()) hash.update(chunk); } finally { await handle.close().catch(() => {}); }
  return hash.digest('hex');
}

/** Removes local paths recursively before generated JSON leaves the machine. */
export function sanitizePrivateData(value) {
  return JSON.parse(JSON.stringify(value, (key, item) => {
    if (typeof item !== 'string') return item;
    return /^(?:[A-Za-z]:\\|\\\\|\/(?:home|Users|mnt|sessions)\/)/i.test(item) ? undefined : item;
  }));
}

/** Removes every local path / private field before a course summary leaves the machine. */
export function sanitizeCourse(course) {
  const { video, sourceMedia, rights, error, ...rest } = course;
  const clean = sanitizePrivateData(rest);
  return { ...clean, ...(rights?.basis ? { rights: { basis: rights.basis, privateOnly: true } } : {}), visibility: 'private' };
}

/**
 * Builds the artifact list for one library course.
 * ctx: { pipelineJobs, workRoot, libraryFolder, stagingDir, allowedRoots, platform }
 * Returns [{ key, kind, source, cleanable, blocked? }]. Generated files are (re)written into stagingDir only
 * when their content changed, so an unchanged course keeps the same size/mtime and is not re-uploaded.
 */
/**
 * P9 hard guard: two different backup keys must never come from the same source file. Every artifact that shares
 * its (real) source with another key is blocked as SOURCE_DUPLICATE — nothing of it is uploaded, and an entry with
 * a blocked duplicate never gets a completion manifest. Paths are compared case-insensitively on Windows.
 */
export function blockDuplicateSources(items, platform = process.platform) {
  const keyOf = (file) => (platform === 'win32' ? path.win32.resolve(file).toLowerCase() : path.posix.resolve(file));
  const groups = new Map();
  for (const item of items) if (item.source && !item.blocked) { const k = keyOf(item.source); groups.set(k, [...(groups.get(k) || []), item]); }
  for (const list of groups.values()) if (new Set(list.map((item) => item.key)).size > 1) for (const item of list) { item.blocked = 'SOURCE_DUPLICATE'; item.source = null; item.cleanable = false; }
  return items;
}

export async function collectArtifacts(course, ctx) {
  if (!COURSE_ID.test(String(course?.id))) throw Object.assign(new Error('invalid course id'), { code: 'INVALID_COURSE' });
  const items = [];
  // P9 fix: one shared rule (resolveAllowedPath) — realpath of file and roots, then only the part below the
  // owning root is checked, so a legitimate root under %LOCALAPPDATA%\Temp is no longer refused.
  const allowed = async (file) => {
    const result = await resolveAllowedPath(file, ctx.allowedRoots || [], { platform: ctx.platform, realpath: ctx.realpath });
    if (result.ok) return result.real;
    return result.code === 'MISSING' ? null : false;
  };
  const add = async (key, kind, file, cleanable = false) => {
    const real = await allowed(file);
    if (real === null) return; // missing (e.g. already cleaned or never produced): nothing to add
    items.push(real ? { key, kind, source: real, original: file, cleanable } : { key, kind, source: null, cleanable: false, blocked: 'FILE_NOT_ALLOWED' });
  };

  // P9 live sessions: only segments the live service reports as closed (OBS has moved on to the next file).
  // Keys are fixed by segment index, so a later pass never renames or duplicates an uploaded segment.
  if (Array.isArray(course.liveSegments)) {
    for (const segment of course.liveSegments) {
      if (!/^media\/segment-\d{3,4}(-r\d{1,2})?\.(mkv|mp4|mov|flv|ts|m4a|wav|flac)$/.test(String(segment?.key))) continue;
      // The live service already knows this segment must not be uploaded (e.g. two segments share one file).
      if (typeof segment.blocked === 'string' && /^[A-Z][A-Z0-9_]{2,60}$/.test(segment.blocked)) { items.push({ key: segment.key, kind: 'media', source: null, cleanable: false, blocked: segment.blocked }); continue; }
      await add(segment.key, 'media', segment.path, segment.cleanable !== false); // P9: inferred-owner files are never cleanable
      // A repaired segment carries the size + MD5 the user confirmed; the upload must match them exactly.
      const added = items.at(-1);
      if (added?.key === segment.key && added.source && /^[0-9a-f]{32}$/.test(String(segment.expect?.md5 || '')) && Number.isInteger(segment.expect?.bytes)) Object.assign(added, { expectMd5: segment.expect.md5, expectBytes: segment.expect.bytes });
    }
    blockDuplicateSources(items, ctx.platform);
    return items; // live media only; transcripts / signals / candidates / manifests of a session stay local
  }
  const job = course.pipelineJobId ? (ctx.pipelineJobs || []).find((item) => item.id === course.pipelineJobId) : null;
  const originals = job?.asset?.files?.map((file) => file.path) || (course.sourceMedia ? [course.sourceMedia] : course.video ? [course.video] : []);
  for (const [index, file] of originals.entries()) {
    const ext = path.extname(String(file)).toLowerCase();
    await add(`media/original-${String(index + 1).padStart(3, '0')}${MEDIA_EXT.test(ext) ? ext : '.bin'}`, 'media', file, true);
  }
  const stage = async (key, kind, value) => {
    const file = path.join(ctx.stagingDir, course.id, ...key.split('/'));
    const text = `${JSON.stringify(value, null, 2)}\n`;
    let current = null; try { current = await fsp.readFile(file, 'utf8'); } catch {}
    if (current !== text) await writeFileAtomic(file, text);
    items.push({ key, kind, source: file, cleanable: false, generated: true });
  };
  // Transcript JSON is uploaded as a path-scrubbed staged copy (defence in depth: never a local path).
  const stageTranscript = async (file) => {
    const real = await allowed(file);
    if (real === null) return;
    if (!real) { items.push({ key: 'transcript/transcript.json', kind: 'transcript', source: null, cleanable: false, blocked: 'FILE_NOT_ALLOWED' }); return; }
    let value; try { value = JSON.parse(await fsp.readFile(real, 'utf8')); } catch { return; } // half-written / unreadable: try again next pass
    await stage('transcript/transcript.json', 'transcript', sanitizePrivateData(value));
  };
  const assetDir = job ? assetDirOf(job) : null;
  if (job && assetDir) {
    const dir = path.join(ctx.workRoot, ...assetDir.split('/'));
    // P7B: only outputs of finished stages (they are written atomically and then closed).
    if (stageDone(job, 'track')) await stageTranscript(path.join(dir, 'transcript.json'));
    if (stageDone(job, 'subtitles')) for (const name of ['transcript.rec.srt', 'transcript.src.srt', 'transcript.rec.vtt', 'transcript.src.vtt']) await add(`subtitles/${name}`, 'subtitles', path.join(dir, name));
  } else if (ctx.libraryFolder && !course.provisional) await stageTranscript(path.join(ctx.libraryFolder, course.id, 'transcript.json'));

  if (course.provisional) return items; // recording not yet published as a course: no summary / knowledge yet
  await stage('summary/course.json', 'summary', sanitizeCourse(course));
  if (course.knowledge) await stage('knowledge/knowledge-pack.json', 'knowledge', sanitizePrivateData(course.knowledge));
  return items;
}

/** The manifest written last: keys, sizes, hashes — no local paths. */
export async function writeManifest(course, items, ctx, now) {
  const file = path.join(ctx.stagingDir, course.id, 'manifest.json');
  const value = { schema: 'cms.backup-manifest/1', courseId: course.id, title: String(course.title || '').slice(0, 200), visibility: 'private', items: items.filter((item) => item.status === 'verified' && item.key !== 'manifest.json').map(({ key, kind, bytes, md5 }) => ({ key, kind, bytes, md5: md5 || null })).sort((a, b) => a.key.localeCompare(b.key)) };
  const text = `${JSON.stringify(value, null, 2)}\n`;
  let current = null; try { current = await fsp.readFile(file, 'utf8'); } catch {}
  if (current !== text) await writeFileAtomic(file, text);
  void now;
  return file;
}
