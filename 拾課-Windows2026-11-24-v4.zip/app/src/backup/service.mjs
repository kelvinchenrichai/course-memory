import fsp from 'node:fs/promises';
import path from 'node:path';
import { readJson, writeJsonAtomic } from '../pipeline/files.mjs';
import { COURSE_ID, collectArtifacts, courseIdForJob, md5File, resolveAllowedPath, writeManifest } from './artifacts.mjs';
import { RcloneError, destinationLabel, parseRemoteSpec } from './rclone.mjs';

/**
 * Private cloud backup + local space protection (P4D).
 *
 * Item states: queued → uploading → verifying → verified | failed (attempts left → queued after back-off).
 * A file is "verified" only after the remote reports the same size (and the same MD5 when the backend
 * exposes one). Only verified, unchanged originals can ever be removed locally, and the remote is checked
 * again right before removal. Cleanup policy (config.backup.cleanupPolicy):
 *   never          只備份、不清理（default）
 *   auto-when-low  空間低於警戒值時，自動清理已驗證的備份（最舊的先）
 *   manual         只有使用者在 UI 按下確認時才清理
 * State lives in data/backup/state.json (local paths stay local; the API returns keys only).
 * Nothing here creates share links or changes remote permissions.
 *
 * P7B incremental backup: a recording is backed up as soon as its pipeline job exists (the watcher saw a
 * stable, closed file and the recording session had ended) — before transcription or knowledge. Pipeline
 * outputs are appended stage by stage, the published course (summary / knowledge pack) last, then the
 * manifest. Local originals can be cleaned only when the whole course backup is complete.
 */

export const PHASES = Object.freeze({
  'waiting-recording': '等待錄影結束', 'media-uploading': '媒體上傳中', 'media-backed-up': '媒體已備份',
  'artifacts-uploading': '成果追加中', complete: '完整備份', 'needs-attention': '需要處理'
});
const ATTENTION_TEXT = {
  KNOWLEDGE_TRANSCRIPT_EMPTY: '沒有辨識到語音，無法產生知識整理；媒體已備份，本機原始檔會保留。',
  KNOWLEDGE_PUBLISH_FAILED: '知識整理暫時失敗，會自動重試；完成前不會清理本機原始檔。',
  PIPELINE_FAILED: '轉錄流程失敗；媒體備份不受影響，請到處理中心重試。',
  MEDIA_CHANGED_AFTER_RECORDING: '錄影檔在錄製結束後被修改，為安全起見沒有上傳，請確認檔案。',
  FILE_NOT_ALLOWED: '有檔案位於不允許備份的位置，已略過。',
  SOURCE_DUPLICATE: '兩個備份項目指向同一個本機檔案，已停止上傳且不會產生完成清單；本機與雲端檔案都保留。',
  SOURCE_CHANGED: '修復時確認的檔案大小或 MD5 與現在的本機檔案不同，已停止上傳且不會產生完成清單；請重新確認。',
  SEGMENT_PATH_DUPLICATE: '直播的兩個分段指向同一個檔案，已停止備份；請到「直播工作台」修復。本機與雲端檔案都保留。',
  MANIFEST_STALE: '先前的完成清單已不再有效（有分段需要修復），修復並驗證後才會更新。'
};

export class BackupError extends Error {
  constructor(code, message, status = 409) { super(message); this.name = 'BackupError'; this.code = code; this.status = status; }
}

export const POLICIES = Object.freeze(['never', 'auto-when-low', 'manual']);
const NETWORK = new Set(['NETWORK_OFFLINE', 'NETWORK_TIMEOUT']);
const OVERRIDING_BLOCKS = new Set(['SOURCE_DUPLICATE', 'SEGMENT_PATH_DUPLICATE', 'SOURCE_CHANGED']);
const STOP_BATCH = new Set(['NETWORK_OFFLINE', 'NETWORK_TIMEOUT', 'AUTH_REQUIRED', 'REMOTE_NOT_CONFIGURED', 'RCLONE_UNAVAILABLE', 'REMOTE_QUOTA']);

export function createBackupService({ config, dataDir, rclone, listCourses, listPipelineJobs = async () => [], listPublishErrors = async () => [], listActiveRecordings = async () => [], listLiveSessions = async () => [], canRemove = async () => true, isMediaBusy = async () => false, isMediaWriting = async () => false, quietMs = 5000, wallNow = () => Date.now(), connectionTtlMs = 60_000, roots, workRoot, libraryFolder, freeBytes = async () => Infinity, clock = { now: () => Date.now() }, logger = { info() {}, warn() {} }, backoffMs = [30_000, 120_000, 600_000], platform = process.platform, realpath = fsp.realpath }) {
  const stateFile = path.join(dataDir, 'backup', 'state.json');
  const stagingDir = path.join(dataDir, 'backup', 'staging');
  const allowedRoots = [...roots, stagingDir, workRoot, libraryFolder].filter(Boolean).map((dir) => path.resolve(dir));
  const cleanableRoots = roots.map((dir) => path.resolve(dir)); // only original media folders can be cleaned
  let state = null; let running = null; let current = null; let remoteType = null; let connection = { state: 'unknown' }; let checkedAt = 0;
  const settings = () => ({ autoUpload: config.backup?.autoUpload === true, cleanupPolicy: POLICIES.includes(config.backup?.cleanupPolicy) ? config.backup.cleanupPolicy : 'never', warnFreeBytes: Math.max(1, Number(config.backup?.warnFreeGb) || 10) * 1024 ** 3, maxAttempts: Math.min(10, Math.max(1, Number(config.backup?.maxAttempts) || 3)) });
  const destination = () => parseRemoteSpec(config.cloudDestination);
  const iso = () => new Date(clock.now()).toISOString();

  async function load() {
    if (state) return state;
    const data = await readJson(stateFile, { version: 1, courses: {} });
    state = { version: 1, courses: data && typeof data.courses === 'object' ? data.courses : {} };
    // Restart recovery: anything that was in flight is queued again; verified items stay verified.
    for (const course of Object.values(state.courses)) for (const item of course.items || []) if (['uploading', 'verifying'].includes(item.status)) { item.status = 'queued'; item.resumedAfterRestart = true; }
    return state;
  }
  const save = () => writeJsonAtomic(stateFile, state);
  const remoteFor = (dest, courseId, key) => `${dest.remote}:${dest.folder}/courses/${courseId}/${key}`;

  /** Adds or refreshes a course's artifact list. Unchanged verified files are left alone (idempotent). */
  async function enqueueCourse(course, pipelineJobs, { publishError = null } = {}) {
    if (!course || course.demo || course.status !== 'ready' || !COURSE_ID.test(String(course.id))) return null;
    const artifacts = await collectArtifacts(course, { pipelineJobs, workRoot, libraryFolder, stagingDir, allowedRoots, platform, realpath });
    const entry = state.courses[course.id] || (state.courses[course.id] = { courseId: course.id, title: String(course.title || '').slice(0, 200), createdAt: iso(), items: [] });
    entry.title = String(course.title || '').slice(0, 200);
    const job = course.pipelineJobId ? pipelineJobs.find((item) => item.id === course.pipelineJobId) : null;
    entry.provisional = course.provisional === true;
    entry.pipelineJobId = course.pipelineJobId || null;
    entry.pipelineError = job?.status === 'failed' ? 'PIPELINE_FAILED' : null;
    entry.publishError = publishError;
    // What a complete backup of this course must contain (checked before any local cleanup).
    entry.live = Array.isArray(course.liveSegments) || undefined;
    entry.required = entry.provisional ? null : entry.live ? ['media', 'manifest'] : [...new Set([...artifacts.map((a) => a.kind), ...(job ? ['transcript', 'subtitles'] : []), 'summary', ...(course.knowledge ? ['knowledge'] : []), 'manifest'])];
    for (const artifact of artifacts) {
      let item = entry.items.find((existing) => existing.key === artifact.key);
      if (item && !artifact.blocked) item.cleanable = artifact.cleanable; // P9: ownership can change (inferred → confirmed)
      if (artifact.blocked) {
        if (!item) entry.items.push({ key: artifact.key, kind: artifact.kind, status: 'blocked', code: artifact.blocked, attempts: 0 });
        // P9: a duplicate source revokes an earlier "verified" — the remote copy is kept (evidence) but no longer counts.
        else if (OVERRIDING_BLOCKS.has(artifact.blocked) && !(item.status === 'blocked' && item.code === artifact.blocked)) Object.assign(item, { status: 'blocked', code: artifact.blocked, revokedAt: iso(), cleanable: false });
        continue;
      }
      let stat; try { stat = await fsp.stat(artifact.source); } catch { continue; }
      const fingerprint = { bytes: stat.size, mtimeMs: Math.trunc(stat.mtimeMs) };
      if (artifact.kind === 'media' && !item?.cleanedAt && !(item?.status === 'verified' && item.bytes === fingerprint.bytes && item.mtimeMs === fingerprint.mtimeMs)) {
        // Never upload a file that may still be written: the recorder must be done and the file quiet.
        const writing = await isMediaWriting(artifact.source) || wallNow() - stat.mtimeMs < quietMs;
        const expected = job?.asset?.files?.find((file) => file.path && path.resolve(file.path) === path.resolve(artifact.original || ''))?.bytes;
        const changed = Number.isFinite(expected) && expected !== stat.size;
        if (writing || changed) {
          if (!item) { item = { key: artifact.key, kind: artifact.kind }; entry.items.push(item); }
          Object.assign(item, { source: artifact.source, cleanable: artifact.cleanable, ...fingerprint, status: changed ? 'blocked' : 'waiting', code: changed ? 'MEDIA_CHANGED_AFTER_RECORDING' : 'MEDIA_STILL_WRITING', attempts: 0, md5: null, verifiedAt: null, notBefore: 0 });
          continue;
        }
        if (item && ['waiting', 'blocked'].includes(item.status) && ['MEDIA_STILL_WRITING', 'MEDIA_CHANGED_AFTER_RECORDING'].includes(item.code)) item.status = 'reset';
      }
      if (item && item.status === 'verified' && item.bytes === fingerprint.bytes && item.mtimeMs === fingerprint.mtimeMs && item.source === artifact.source) continue;
      if (item?.cleanedAt) continue; // local original already removed after a verified backup
      // Same file still waiting or failed: keep its attempts / back-off (idempotent re-scan).
      if (item && !['verified', 'blocked', 'reset'].includes(item.status) && item.bytes === fingerprint.bytes && item.mtimeMs === fingerprint.mtimeMs && item.source === artifact.source) continue;
      if (!item) { item = { key: artifact.key, kind: artifact.kind }; entry.items.push(item); }
      Object.assign(item, { source: artifact.source, cleanable: artifact.cleanable, ...fingerprint, status: 'queued', attempts: 0, code: null, md5: null, verifiedAt: null, notBefore: 0 });
      if (artifact.expectMd5) Object.assign(item, { expectMd5: artifact.expectMd5, expectBytes: artifact.expectBytes }); else { delete item.expectMd5; delete item.expectBytes; }
    }
    // P9: a live entry whose segment key changed (repair → new revision key) keeps the old remote copy, but the old
    // key no longer belongs to the session: it is superseded, never counted, never cleaned, never in a manifest.
    if (entry.live) {
      const keys = new Set(artifacts.map((artifact) => artifact.key));
      for (const item of entry.items) if (item.kind === 'media' && !keys.has(item.key) && item.status !== 'superseded' && !item.cleanedAt) Object.assign(item, { status: 'superseded', supersededAt: iso(), cleanable: false });
    }
    // P9: a completion manifest is only valid while no duplicate source is blocked in the entry.
    const manifest = entry.items.find((item) => item.key === 'manifest.json');
    if (manifest && entry.items.some((item) => OVERRIDING_BLOCKS.has(item.code) && item.status === 'blocked') && manifest.status !== 'blocked') Object.assign(manifest, { status: 'blocked', code: 'MANIFEST_STALE', revokedAt: iso() });
    entry.updatedAt = iso();
    return entry;
  }

  async function uploadItem(dest, entry, item) {
    item.status = 'uploading'; item.progress = 0; current = { courseId: entry.courseId, key: item.key, bytes: 0, total: item.bytes }; await save();
    const stat = await fsp.stat(item.source).catch(() => null);
    if (!stat || stat.size !== item.bytes || Math.trunc(stat.mtimeMs) !== item.mtimeMs) { item.status = 'queued'; item.code = 'LOCAL_CHANGED'; return 'requeue'; }
    const remotePath = remoteFor(dest, entry.courseId, item.key);
    if (item.kind === 'media' && await isMediaWriting(item.source)) { item.status = 'waiting'; item.code = 'MEDIA_STILL_WRITING'; return 'requeue'; }
    // P9 repair: the file the user confirmed (size + MD5 recorded at confirmation) is the only acceptable source.
    if (item.kind === 'media' && item.expectMd5) {
      item.md5 = item.md5 || await md5File(item.source);
      if (item.bytes !== item.expectBytes || item.md5 !== item.expectMd5) { Object.assign(item, { status: 'blocked', code: 'SOURCE_CHANGED', cleanable: false, progress: 0 }); return 'blocked'; }
    }
    // P9 live entries: an identical remote copy (same size and MD5) is verified in place instead of being re-copied,
    // so a repair re-check never rewrites a remote file. Remotes without hashes are always (re)uploaded.
    if (item.kind === 'media' && entry.live) {
      item.md5 = item.md5 || await md5File(item.source);
      const existing = await rclone.stat(remotePath).catch(() => null);
      if (existing?.exists && existing.size === item.bytes && existing.md5 && existing.md5 === item.md5) {
        Object.assign(item, { status: 'verified', verifiedAt: iso(), remoteHash: 'md5', code: null, progress: 1, reusedRemote: true });
        return 'ok';
      }
    }
    await rclone.upload({ local: item.source, remotePath, onProgress: ({ bytes }) => { current.bytes = Math.min(bytes, item.bytes); item.progress = item.bytes ? Math.min(1, bytes / item.bytes) : 1; } });
    // P7B: the local file must be byte-for-byte what we meant to upload, also after the copy finished.
    const after = await fsp.stat(item.source).catch(() => null);
    if (!after || after.size !== item.bytes || Math.trunc(after.mtimeMs) !== item.mtimeMs) { item.status = 'queued'; item.code = 'LOCAL_CHANGED'; item.md5 = null; return 'requeue'; }
    item.status = 'verifying'; await save();
    item.md5 = item.md5 || await md5File(item.source);
    const remote = await rclone.stat(remotePath);
    if (!remote.exists) throw new RcloneError('VERIFY_MISSING', '遠端找不到剛上傳的檔案');
    if (remote.size !== item.bytes) throw new RcloneError('VERIFY_SIZE_MISMATCH', '遠端檔案大小不一致');
    if (remote.md5 && remote.md5 !== item.md5) throw new RcloneError('VERIFY_HASH_MISMATCH', '遠端檔案內容不一致');
    Object.assign(item, { status: 'verified', verifiedAt: iso(), remoteHash: remote.md5 ? 'md5' : 'size-only', code: null, progress: 1 });
    return 'ok';
  }

  async function processQueue({ only = null } = {}) {
    const dest = destination(); if (!dest) throw new BackupError('DESTINATION_NOT_SET', '尚未設定雲端目的地');
    const { maxAttempts } = settings(); const now = clock.now();
    for (const entry of Object.values(state.courses)) {
      if (only && entry.courseId !== only) continue; // P9: a scoped run never touches other entries
      // Media first: the recording itself is the irreplaceable part.
      const pending = () => entry.items.filter((item) => item.status === 'queued' && item.key !== 'manifest.json' && (item.notBefore || 0) <= now).sort((a, b) => (a.kind === 'media' ? 0 : 1) - (b.kind === 'media' ? 0 : 1));
      for (const item of pending()) {
        try { const result = await uploadItem(dest, entry, item); if (result === 'ok') logger.info({ event: 'backup_verified', courseId: entry.courseId, key: item.key }); }
        catch (error) {
          const code = error instanceof RcloneError ? error.code : 'UPLOAD_FAILED';
          item.attempts = (item.attempts || 0) + 1; item.code = code; item.progress = 0;
          const exhausted = item.attempts >= maxAttempts;
          item.status = exhausted || code === 'RCLONE_UNAVAILABLE' ? 'failed' : 'queued';
          item.notBefore = item.status === 'queued' ? clock.now() + backoffMs[Math.min(item.attempts - 1, backoffMs.length - 1)] : 0;
          logger.warn({ event: 'backup_item_failed', courseId: entry.courseId, key: item.key, code, attempts: item.attempts });
          await save();
          if (STOP_BATCH.has(code)) { connection = { state: NETWORK.has(code) ? 'offline' : code === 'AUTH_REQUIRED' ? 'auth-required' : code === 'RCLONE_UNAVAILABLE' ? 'rclone-missing' : 'error', code }; return; }
        } finally { current = null; }
        await save();
      }
      // Manifest last, once every other non-blocked file of the course is verified.
      const others = entry.items.filter((item) => item.key !== 'manifest.json' && item.status !== 'blocked' && item.status !== 'superseded');
      const duplicate = entry.items.some((item) => item.status === 'blocked' && OVERRIDING_BLOCKS.has(item.code));
      if (!entry.provisional && !duplicate && others.length && others.every((item) => item.status === 'verified')) {
        const file = await writeManifest({ id: entry.courseId, title: entry.title }, entry.items, { stagingDir });
        const stat = await fsp.stat(file);
        let manifest = entry.items.find((item) => item.key === 'manifest.json');
        if (!manifest || manifest.bytes !== stat.size || manifest.mtimeMs !== Math.trunc(stat.mtimeMs) || manifest.status !== 'verified') {
          if (!manifest) { manifest = { key: 'manifest.json', kind: 'manifest' }; entry.items.push(manifest); }
          Object.assign(manifest, { source: file, cleanable: false, bytes: stat.size, mtimeMs: Math.trunc(stat.mtimeMs), status: 'queued', attempts: manifest.attempts || 0, md5: null });
          try { await uploadItem(dest, entry, manifest); } catch (error) { manifest.status = 'queued'; manifest.code = error.code || 'UPLOAD_FAILED'; manifest.attempts = (manifest.attempts || 0) + 1; if (manifest.attempts >= maxAttempts) manifest.status = 'failed'; } finally { current = null; }
          await save();
        }
      }
    }
    connection = { state: 'connected' };
  }

  /** Reclaims space by removing verified local originals. `reason`: 'manual' | 'auto'. */
  async function cleanup({ courseId = null, reason = 'manual', targetFreeBytes = Infinity } = {}) {
    await load();
    const { cleanupPolicy } = settings();
    if (cleanupPolicy === 'never') throw new BackupError('CLEANUP_DISABLED', '目前的策略是「只備份、不清理」');
    if (reason === 'auto' && cleanupPolicy !== 'auto-when-low') throw new BackupError('CLEANUP_DISABLED', '自動清理沒有開啟');
    const dest = destination(); if (!dest) throw new BackupError('DESTINATION_NOT_SET', '尚未設定雲端目的地');
    const candidates = await reclaimable({ courseId });
    const removed = []; const skipped = [];
    for (const { entry, item } of candidates) {
      if (reason === 'auto' && await freeBytes() >= targetFreeBytes) break;
      const check = await safeToRemove(dest, entry, item);
      if (!check.ok) { skipped.push({ courseId: entry.courseId, key: item.key, code: check.code }); continue; }
      try { await fsp.unlink(item.source); } catch (error) { skipped.push({ courseId: entry.courseId, key: item.key, code: error.code === 'ENOENT' ? 'ALREADY_REMOVED' : 'REMOVE_FAILED' }); continue; }
      item.cleanedAt = iso(); item.cleanReason = reason; removed.push({ courseId: entry.courseId, key: item.key, bytes: item.bytes });
      logger.info({ event: 'backup_local_cleaned', courseId: entry.courseId, key: item.key, reason });
      await save();
    }
    return { removed, skipped, freedBytes: removed.reduce((sum, item) => sum + item.bytes, 0) };
  }

  async function reclaimable({ courseId = null } = {}) {
    await load();
    const list = [];
    for (const entry of Object.values(state.courses)) {
      if (courseId && entry.courseId !== courseId) continue;
      if (!isComplete(entry)) continue; // P7B: only fully backed-up courses
      for (const item of entry.items) if (item.status === 'verified' && item.cleanable && !item.cleanedAt && item.kind === 'media') list.push({ entry, item });
    }
    return list.sort((a, b) => String(a.item.verifiedAt).localeCompare(String(b.item.verifiedAt)));
  }

  /** Every condition must hold, checked again immediately before deletion. */
  async function safeToRemove(dest, entry, item) {
    if (!item.source) return { ok: false, code: 'NOT_IN_MEDIA_FOLDER' };
    // Same rule as upload (P9 fix): realpath inside an original-media root, nothing sensitive below that root.
    const allowed = await resolveAllowedPath(item.source, cleanableRoots, { platform, realpath });
    if (!allowed.ok) return { ok: false, code: allowed.code === 'MISSING' ? 'ALREADY_REMOVED' : 'NOT_IN_MEDIA_FOLDER' };
    const stat = await fsp.lstat(item.source).catch(() => null);
    if (!stat?.isFile()) return { ok: false, code: 'NOT_A_FILE' };
    if (stat.size !== item.bytes || Math.trunc(stat.mtimeMs) !== item.mtimeMs) return { ok: false, code: 'LOCAL_CHANGED' };
    if (await isMediaBusy(item.source)) return { ok: false, code: 'IN_USE' };
    if (!item.cleanable || !(await canRemove(item.source))) return { ok: false, code: 'NOT_CLEANABLE' }; // P9: e.g. a live file whose owner was only inferred
    const courseItems = entry.items.filter((other) => other.kind !== 'media' && other.status !== 'blocked');
    if (courseItems.some((other) => other.status !== 'verified') || !isComplete(entry)) return { ok: false, code: 'COURSE_NOT_FULLY_BACKED_UP' };
    let remote; try { remote = await rclone.stat(remoteFor(dest, entry.courseId, item.key)); } catch (error) { return { ok: false, code: error.code || 'VERIFY_FAILED' }; }
    if (!remote.exists || remote.size !== item.bytes || (remote.md5 && item.md5 && remote.md5 !== item.md5)) { item.status = 'queued'; item.code = 'REMOTE_CHANGED'; item.attempts = 0; await save(); return { ok: false, code: 'REMOTE_VERIFY_FAILED' }; }
    return { ok: true };
  }

  /** Library course → its entry. */
  const enqueueLibrary = (course, pipelineJobs, publishErrors) => enqueueCourse(course, pipelineJobs, { publishError: course.pipelineJobId ? publishErrors.get(course.pipelineJobId) || null : null });
  /** P7B: a recording that entered the pipeline but is not (yet) a published course. */
  function provisionalFor(job, published, publishedIds) {
    if (published.has(job.id) || job.status === 'cancelled' || !job.asset?.files?.length) return null;
    const id = courseIdForJob(job); if (!id || publishedIds.has(id)) return null;
    const name = path.basename(String(job.asset.files[0].path || ''), path.extname(String(job.asset.files[0].path || ''))) || '錄影';
    return { id, title: name, status: 'ready', provisional: true, pipelineJobId: job.id, sourceMedia: job.asset.files[0].path };
  }
  /** P9: live session → entry. Provisional until the session ended (no manifest, no cleanup while OBS may add segments). */
  const liveCourse = (live) => ({ id: live.id, title: String(live.title || '直播'), status: 'ready', provisional: live.final !== true, liveSegments: Array.isArray(live.segments) ? live.segments : [] });
  async function sources() {
    const pipelineJobs = await listPipelineJobs();
    const publishErrors = new Map((await listPublishErrors().catch(() => [])).map((item) => [item.jobId, item.code]));
    const courses = await listCourses();
    return { pipelineJobs, publishErrors, courses, published: new Set(courses.map((course) => course.pipelineJobId).filter(Boolean)), publishedIds: new Set(courses.map((course) => course.id)) };
  }

  async function scanCourses() {
    const src = await sources();
    for (const course of src.courses) await enqueueLibrary(course, src.pipelineJobs, src.publishErrors);
    for (const job of src.pipelineJobs) { const course = provisionalFor(job, src.published, src.publishedIds); if (course) await enqueueCourse(course, src.pipelineJobs, { publishError: src.publishErrors.get(job.id) || null }); }
    for (const live of await listLiveSessions().catch(() => [])) {
      if (!COURSE_ID.test(String(live?.id)) || src.publishedIds.has(live.id)) continue;
      await enqueueCourse(liveCourse(live), src.pipelineJobs);
    }
    await save();
  }

  /**
   * P9 hardening: refresh exactly one entry — a library course, a pipeline recording or a live session — and
   * nothing else. Unknown ids are COURSE_NOT_FOUND. No other entry is rescanned, retried or changed.
   */
  async function refreshOne(courseId) {
    const src = await sources();
    const course = src.courses.find((item) => item.id === courseId);
    if (course) { await enqueueLibrary(course, src.pipelineJobs, src.publishErrors); await save(); return; }
    const job = src.pipelineJobs.find((item) => courseIdForJob(item) === courseId);
    const provisional = job ? provisionalFor(job, src.published, src.publishedIds) : null;
    if (provisional) { await enqueueCourse(provisional, src.pipelineJobs, { publishError: src.publishErrors.get(job.id) || null }); await save(); return; }
    const live = (await listLiveSessions().catch(() => [])).find((item) => item?.id === courseId);
    if (live && COURSE_ID.test(String(live.id))) { await enqueueCourse(liveCourse(live), src.pipelineJobs); await save(); return; }
    throw new BackupError('COURSE_NOT_FOUND', '找不到課程', 404);
  }

  /** Every required part is present and verified, nothing failed, and the course is published. */
  function isComplete(entry) {
    if (!entry || entry.provisional || !Array.isArray(entry.required)) return false;
    if (entry.items.some((item) => ['failed', 'blocked', 'waiting'].includes(item.status))) return false;
    return entry.required.every((kind) => { const items = entry.items.filter((item) => item.kind === kind && item.status !== 'superseded'); return items.length > 0 && items.every((item) => item.status === 'verified'); });
  }

  function phaseOf(entry) {
    const live = entry.items.filter((item) => !item.cleanedAt);
    const media = entry.items.filter((item) => item.kind === 'media' && item.status !== 'superseded');
    const attention = entry.items.find((item) => ['failed', 'blocked'].includes(item.status))?.code || entry.pipelineError || entry.publishError;
    if (attention) return { phase: 'needs-attention', code: attention, reason: ATTENTION_TEXT[attention] || '有檔案備份失敗，請按「重試」或檢查連線。' };
    if (media.some((item) => item.status === 'waiting')) return { phase: 'waiting-recording', code: 'MEDIA_STILL_WRITING', reason: '錄影檔仍在寫入或剛寫完，穩定後才會上傳。' };
    if (media.some((item) => item.status !== 'verified')) return { phase: 'media-uploading' };
    if (isComplete(entry)) return { phase: 'complete' };
    if (live.some((item) => item.kind !== 'media' && item.status !== 'verified')) return { phase: 'artifacts-uploading' };
    return { phase: 'media-backed-up', reason: entry.provisional ? '轉錄與知識整理完成後會自動追加備份。' : '等待其餘成果產生後追加備份。' };
  }

  const service = {
    /** One pass: refresh artifact lists, upload and verify queued files. Concurrent calls share the pass. */
    run({ courseId = null, quick = false } = {}) {
      // A scoped run waits for an in-flight pass and then handles only its own entry.
      if (courseId) return (running || Promise.resolve()).catch(() => null).then(() => service.runOne(courseId));
      if (running) return running;
      running = (async () => {
        await load();
        if (!destination()) throw new BackupError('DESTINATION_NOT_SET', '尚未設定雲端目的地');
        await scanCourses();
        // Do not burn retry attempts while the destination is plainly unreachable.
        const fresh = quick && clock.now() - checkedAt < connectionTtlMs && connection.state !== 'unknown';
        const reach = fresh ? connection : await service.checkConnection().catch(() => ({ state: 'error' }));
        if (reach.state === 'connected') await processQueue();
        if (settings().cleanupPolicy === 'auto-when-low') await service.reclaimIfLow().catch(() => {});
        return service.status();
      })().finally(() => { running = null; });
      return running;
    },
    /** One entry only: refresh, upload, verify. No batch scan, no other entry, no automatic cleanup. */
    runOne(courseId) {
      if (running) return running.catch(() => null).then(() => service.runOne(courseId));
      running = (async () => {
        await load();
        if (!destination()) throw new BackupError('DESTINATION_NOT_SET', '尚未設定雲端目的地');
        await refreshOne(courseId);
        const reach = await service.checkConnection().catch(() => ({ state: 'error' }));
        if (reach.state === 'connected') await processQueue({ only: courseId });
        return service.status();
      })().finally(() => { running = null; });
      return running;
    },
    /** P7B trigger after a recording / stage finished: cheap, single-flight, honours autoUpload. */
    poke() {
      if (running) return running;
      if (!settings().autoUpload || !destination()) return Promise.resolve(null);
      return service.run({ quick: true }).catch(() => null);
    },
    async retry({ courseId = null } = {}) {
      await load();
      for (const entry of Object.values(state.courses)) if (!courseId || entry.courseId === courseId) for (const item of entry.items) if (item.status === 'failed' || (item.status === 'queued' && item.notBefore)) Object.assign(item, { status: 'queued', attempts: 0, notBefore: 0 });
      await save();
      return service.run({ courseId });
    },
    cleanup,
    /** P9: last known reachability of the destination (cheap; no network call). */
    connectionState() { return destination() ? { ...connection } : { state: 'not-set' }; },
    /** P9: per-item status of one entry (keys + states only, no paths) for the live workbench. */
    async items(courseId) {
      await load();
      const entry = state.courses[courseId];
      return entry ? entry.items.map((item) => ({ key: item.key, status: item.status, code: item.code || null, cleaned: Boolean(item.cleanedAt) })) : [];
    },
    /** Disk-guard hook: when free space is below the warning level and policy allows, reclaim verified originals. */
    async reclaimIfLow() {
      const { cleanupPolicy, warnFreeBytes } = settings();
      if (cleanupPolicy !== 'auto-when-low' || await freeBytes() >= warnFreeBytes) return { removed: [], freedBytes: 0 };
      return cleanup({ reason: 'auto', targetFreeBytes: warnFreeBytes + 2 * 1024 ** 3 });
    },
    async checkConnection() {
      const dest = destination();
      checkedAt = clock.now();
      if (!dest) { connection = { state: 'not-set' }; return connection; }
      const version = await rclone.version().catch(() => null);
      if (!version) { connection = { state: 'rclone-missing' }; return connection; }
      try { remoteType = (await rclone.listRemotes()).find((item) => item.name === dest.remote)?.type || null; } catch { remoteType = null; }
      if (!remoteType) { connection = { state: 'not-configured' }; return connection; }
      connection = await rclone.probe(dest);
      return connection;
    },
    /** UI view: no local paths, no account, no full remote path. */
    async status() {
      await load();
      const dest = destination(); const { cleanupPolicy, autoUpload, warnFreeBytes } = settings();
      const counts = { queued: 0, uploading: 0, verified: 0, failed: 0, blocked: 0, waiting: 0 };
      const courses = Object.values(state.courses).map((entry) => {
        const items = entry.items.map((item) => ({ key: item.key, kind: item.kind, status: item.status === 'verifying' ? 'uploading' : item.status, bytes: item.bytes || 0, attempts: item.attempts || 0, code: item.code || null, progress: item.status === 'verified' ? 1 : item.progress || 0, cleaned: Boolean(item.cleanedAt), retryAt: item.status === 'queued' && item.notBefore > clock.now() ? new Date(item.notBefore).toISOString() : null }));
        for (const item of items) counts[item.status] = (counts[item.status] || 0) + 1;
        const total = items.reduce((sum, item) => sum + item.bytes, 0); const done = items.filter((item) => item.status === 'verified').reduce((sum, item) => sum + item.bytes, 0);
        const reclaimableBytes = isComplete(entry) ? entry.items.filter((item) => item.status === 'verified' && item.cleanable && !item.cleanedAt && item.kind === 'media').reduce((sum, item) => sum + item.bytes, 0) : 0;
        const overall = items.some((item) => item.status === 'failed' || item.status === 'blocked') ? 'failed' : items.some((item) => item.status === 'uploading') ? 'uploading' : items.some((item) => item.status === 'queued' || item.status === 'waiting') ? 'queued' : 'verified';
        const phase = phaseOf(entry);
        return { courseId: entry.courseId, title: entry.title, overall, ...phase, phaseLabel: PHASES[phase.phase], provisional: Boolean(entry.provisional), progress: total ? Math.round((done / total) * 1000) / 1000 : 1, totalBytes: total, verifiedBytes: done, reclaimableBytes, localMediaCleaned: entry.items.some((item) => item.cleanedAt), items };
      }).sort((a, b) => a.title.localeCompare(b.title, 'zh-Hant'));
      const free = await freeBytes().catch(() => null);
      // Recordings still in progress (no file handed over yet): shown as「等待錄影結束」, nothing uploaded.
      const recording = (await listActiveRecordings().catch(() => [])).slice(0, 20).map((item) => ({ id: String(item.id || '').slice(0, 40), title: String(item.title || '錄影中').slice(0, 200), phase: 'waiting-recording', phaseLabel: PHASES['waiting-recording'] }));
      return {
        recording,
        destination: { configured: Boolean(dest), label: destinationLabel(dest, remoteType), visibility: 'private' },
        connection: { ...connection }, policy: { cleanupPolicy, autoUpload, warnFreeBytes },
        disk: { freeBytes: Number.isFinite(free) ? free : null, low: Number.isFinite(free) ? free < warnFreeBytes : null },
        counts, reclaimableBytes: courses.reduce((sum, course) => sum + course.reclaimableBytes, 0),
        current: current ? { courseId: current.courseId, key: current.key, bytes: current.bytes, total: current.total } : null,
        running: Boolean(running), courses
      };
    }
  };
  return service;
}
