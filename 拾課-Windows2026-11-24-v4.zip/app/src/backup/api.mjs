import { checkLocalRequest } from '../settings/api.mjs';
import { POLICIES } from './service.mjs';
import { parseRemoteSpec } from './rclone.mjs';

/**
 * P4D local API — same guard as P4C (localhost Host, same-origin, JSON bodies).
 *   GET  /api/backup                         → status (labels, counts, progress; no paths, no account)
 *   POST /api/backup/check                   → re-check rclone / remote reachability
 *   GET  /api/backup/remotes                 → configured rclone remotes: { name, type } only
 *   POST /api/backup/run      { courseId? }  → start a backup pass (202)
 *   POST /api/backup/retry    { courseId? }  → reset failed items and run (202)
 *   POST /api/backup/cleanup  { courseId?, confirm: true } → remove verified local originals (policy permitting)
 *   PUT  /api/backup/settings { destination?, cleanupPolicy?, autoUpload?, warnFreeGb? }
 * Private backup only: there is no route that shares, publishes or changes remote permissions.
 */

const ROUTES = /^\/api\/backup(?:\/(check|remotes|run|retry|cleanup|settings))?$/;
const json = (status, body) => ({ status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }, body });
const STATUS = { DESTINATION_NOT_SET: 409, CLEANUP_DISABLED: 409, COURSE_NOT_FOUND: 404, INVALID_VALUE: 400, CONFIRM_REQUIRED: 400, UNKNOWN_SETTING: 400, RCLONE_UNAVAILABLE: 503, REMOTE_NOT_CONFIGURED: 409 };
const COURSE = /^[A-Za-z0-9_-]{6,64}$/;

export const isBackupRoute = (pathname) => ROUTES.test(pathname);

function courseIdOf(body) {
  if (body.courseId == null) return null;
  if (typeof body.courseId !== 'string' || !COURSE.test(body.courseId)) throw Object.assign(new Error('課程代碼不正確'), { code: 'INVALID_VALUE' });
  return body.courseId;
}

/** ctx: { backup, rclone, settings: { update(values) }, port } */
export async function handleBackupRequest(ctx, request) {
  const { method, pathname } = request;
  const match = pathname.match(ROUTES); if (!match) return null;
  const rejected = checkLocalRequest(request, ctx.port);
  if (rejected) return json(rejected === 'JSON_REQUIRED' ? 415 : 403, { error: rejected });
  const body = request.body && typeof request.body === 'object' && !Array.isArray(request.body) ? request.body : {};
  const action = match[1] || null;
  try {
    if (!action && method === 'GET') return json(200, await ctx.backup.status());
    if (action === 'check' && method === 'POST') { await ctx.backup.checkConnection(); return json(200, await ctx.backup.status()); }
    if (action === 'remotes' && method === 'GET') return json(200, { remotes: (await ctx.rclone.listRemotes()).map(({ name, type }) => ({ name, type })) });
    if (action === 'run' && method === 'POST') { const courseId = courseIdOf(body); ctx.backup.run({ courseId }).catch(() => {}); return json(202, { started: true }); }
    if (action === 'retry' && method === 'POST') { const courseId = courseIdOf(body); ctx.backup.retry({ courseId }).catch(() => {}); return json(202, { started: true }); }
    if (action === 'cleanup' && method === 'POST') {
      if (body.confirm !== true) return json(400, { error: 'CONFIRM_REQUIRED', message: '清理本機檔案前需要確認' });
      const result = await ctx.backup.cleanup({ courseId: courseIdOf(body), reason: 'manual' });
      return json(200, { removedCount: result.removed.length, freedBytes: result.freedBytes, skipped: result.skipped.map(({ key, code }) => ({ key, code })) });
    }
    if (action === 'settings' && method === 'PUT') {
      const allowed = ['destination', 'cleanupPolicy', 'autoUpload', 'warnFreeGb'];
      const extra = Object.keys(body).find((key) => !allowed.includes(key));
      if (extra) return json(400, { error: 'UNKNOWN_SETTING' });
      const changes = {};
      if ('destination' in body) {
        const parsed = parseRemoteSpec(body.destination);
        if (!parsed) return json(400, { error: 'INVALID_VALUE', field: 'destination', message: '目的地格式應為「遠端名稱:資料夾」' });
        const remotes = await ctx.rclone.listRemotes().catch(() => []);
        const remote = remotes.find((item) => item.name === parsed.remote);
        if (!remote) return json(409, { error: 'REMOTE_NOT_CONFIGURED', message: '找不到這個 rclone 遠端，請先用 rclone config 設定' });
        if (['local', 'alias', 'union', 'combine'].includes(remote.type)) return json(400, { error: 'INVALID_VALUE', field: 'destination', message: '只能選擇雲端遠端' });
        changes.cloudDestination = parsed.spec;
      }
      if ('cleanupPolicy' in body) { if (!POLICIES.includes(body.cleanupPolicy)) return json(400, { error: 'INVALID_VALUE', field: 'cleanupPolicy' }); changes.cleanupPolicy = body.cleanupPolicy; }
      if ('autoUpload' in body) { if (typeof body.autoUpload !== 'boolean') return json(400, { error: 'INVALID_VALUE', field: 'autoUpload' }); changes.autoUpload = body.autoUpload; }
      if ('warnFreeGb' in body) { if (!Number.isInteger(body.warnFreeGb) || body.warnFreeGb < 1 || body.warnFreeGb > 2000) return json(400, { error: 'INVALID_VALUE', field: 'warnFreeGb' }); changes.warnFreeGb = body.warnFreeGb; }
      await ctx.settings.update(changes);
      await ctx.backup.checkConnection().catch(() => {});
      return json(200, await ctx.backup.status());
    }
    return json(405, { error: 'METHOD_NOT_ALLOWED' });
  } catch (error) {
    const code = typeof error?.code === 'string' && /^[A-Z][A-Z0-9_]{2,60}$/.test(error.code) ? error.code : 'BACKUP_ERROR';
    return json(error?.status || STATUS[code] || 500, { error: code, message: typeof error?.message === 'string' && /[一-鿿]/.test(error.message) ? error.message.slice(0, 200) : '處理失敗' });
  }
}

/** Persists backup settings into the git-ignored config.json (allow-listed keys only). */
export function createBackupSettings({ readRaw, writeRaw, liveConfig }) {
  return {
    async update(changes) {
      const raw = await readRaw();
      for (const [key, value] of Object.entries(changes)) {
        if (key === 'cloudDestination') { raw.cloudDestination = value; liveConfig.cloudDestination = value; raw.cloudMode = 'rclone'; liveConfig.cloudMode = 'rclone'; continue; }
        raw.backup = { ...(raw.backup || {}), [key]: value }; liveConfig.backup = { ...(liveConfig.backup || {}), [key]: value };
      }
      await writeRaw(raw);
    }
  };
}

async function readBody(req, limit = 16 * 1024) {
  let size = 0; const chunks = [];
  for await (const chunk of req) { size += chunk.length; if (size > limit) throw Object.assign(new Error('too large'), { status: 413 }); chunks.push(chunk); }
  if (!size) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw Object.assign(new Error('bad json'), { status: 400 }); }
}

export async function routeBackupApis(ctx, req, res, url) {
  if (!isBackupRoute(url.pathname)) return false;
  let result;
  try {
    const rejected = checkLocalRequest({ method: req.method, headers: req.headers }, ctx.port);
    const body = !rejected && ['POST', 'PUT'].includes(req.method) ? await readBody(req) : undefined;
    result = await handleBackupRequest(ctx, { method: req.method, pathname: url.pathname, headers: req.headers, body });
  } catch (error) { result = json(error.status === 413 ? 413 : 400, { error: error.status === 413 ? 'TOO_LARGE' : 'BAD_JSON' }); }
  res.writeHead(result.status, result.headers); res.end(JSON.stringify(result.body));
  return true;
}
