import fsp from 'node:fs/promises';

/**
 * Disk adapter for the Agent Runner (P4D). The Runner already refuses to start a lesson when
 * disk.freeBytes() is below options.minFreeBytes[mode] and then performs its normal safe stop
 * (pause → stop capture → partial session → checkpoint → blocked DISK_LOW → notify). This adapter only:
 *   1. raises those thresholds to the user's warning level (config.backup.warnFreeGb), and
 *   2. gives an optional reclaimer (verified-backup cleanup, policy permitting) one chance to free space
 *      before the measurement is reported.
 * The Runner state machine itself is not changed.
 */
export function createStorageGuard({ folder, warnFreeBytes = () => 10 * 1024 ** 3, statfs = (dir) => fsp.statfs(dir), logger = { warn() {} } }) {
  let reclaimer = null;
  const measure = async () => { const stats = await statfs(folder); return Number(stats.bavail) * Number(stats.bsize); };
  const warn = () => Number(typeof warnFreeBytes === 'function' ? warnFreeBytes() : warnFreeBytes) || 0;
  return {
    async freeBytes() {
      let free = await measure();
      if (free < warn() && reclaimer) {
        try { await reclaimer(); } catch (error) { logger.warn({ event: 'disk_reclaim_failed', code: error?.code || 'ERROR' }); }
        free = await measure();
      }
      return free;
    },
    measure,
    /** Thresholds for the Runner: never lower than its own defaults. */
    minFreeBytes(defaults = { audio: 512 * 1024 ** 2, video: 5 * 1024 ** 3 }) {
      const level = warn();
      return { audio: Math.max(defaults.audio, level), video: Math.max(defaults.video, level) };
    },
    setReclaimer(fn) { reclaimer = typeof fn === 'function' ? fn : null; },
    async status() { const free = await measure().catch(() => null); return { freeBytes: free, warnFreeBytes: warn(), low: free == null ? null : free < warn() }; }
  };
}
