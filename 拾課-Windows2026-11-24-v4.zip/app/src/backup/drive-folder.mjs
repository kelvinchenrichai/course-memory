import fsp from 'node:fs/promises';
import path from 'node:path';
import { isInside } from '../pipeline/files.mjs';
import { md5File } from './artifacts.mjs';
import { RcloneError } from './rclone.mjs';

/** Google Drive for desktop adapter. Browser callers never see or choose the local G: path. */
export const DRIVE_FOLDER_REMOTE = 'google-drive-desktop';

export function createDriveFolderAdapter({ root, remoteName = DRIVE_FOLDER_REMOTE, fs = fsp } = {}) {
  if (!path.isAbsolute(String(root || ''))) throw new Error('drive folder root must be absolute');
  const base = path.resolve(root);
  const resolveRemote = (value) => {
    const prefix = `${remoteName}:`;
    if (typeof value !== 'string' || !value.startsWith(prefix)) throw new RcloneError('REMOTE_NOT_CONFIGURED', '找不到 Google Drive 電腦版目的地');
    const relative = value.slice(prefix.length); const parts = relative.split('/');
    if (!relative || parts.some((part) => !part || part === '.' || part === '..' || /[\\:\u0000-\u001f]/.test(part))) throw new RcloneError('REMOTE_NOT_CONFIGURED', 'Google Drive 目的地不正確');
    const target = path.resolve(base, ...parts);
    if (!isInside(base, target)) throw new RcloneError('REMOTE_NOT_CONFIGURED', 'Google Drive 目的地超出允許範圍');
    return target;
  };
  return {
    async version() { try { await fs.access(base); return 'desktop'; } catch { return null; } },
    async listRemotes() { return [{ name: remoteName, type: 'drive' }]; },
    async probe(parsed) {
      if (parsed?.remote !== remoteName) return { state: 'not-configured', code: 'REMOTE_NOT_CONFIGURED' };
      try { await fs.access(base); return { state: 'connected' }; } catch { return { state: 'offline', code: 'NETWORK_OFFLINE' }; }
    },
    async upload({ local, remotePath, onProgress }) {
      const target = resolveRemote(remotePath); await fs.mkdir(path.dirname(target), { recursive: true });
      const temporary = `${target}.${process.pid}.part`;
      try {
        await fs.copyFile(local, temporary); const stat = await fs.stat(temporary); onProgress?.({ bytes: stat.size, total: stat.size }); await fs.rename(temporary, target);
      } catch (error) {
        await fs.unlink(temporary).catch(() => {});
        throw new RcloneError(error?.code === 'ENOSPC' ? 'REMOTE_QUOTA' : 'UPLOAD_FAILED', 'Google Drive 同步資料夾寫入失敗');
      }
    },
    async stat(remotePath) {
      const target = resolveRemote(remotePath); let stat;
      try { stat = await fs.stat(target); } catch (error) { if (error?.code === 'ENOENT') return { exists: false }; throw new RcloneError('NETWORK_OFFLINE', '無法讀取 Google Drive 同步資料夾'); }
      if (!stat.isFile()) return { exists: false };
      return { exists: true, size: stat.size, md5: await md5File(target) };
    }
  };
}
