/**
 * Thin rclone adapter for the private cloud backup (P4D). Every call is an argument array through the
 * shared process runner (no shell). rclone's own output is NEVER returned or logged: it can contain the
 * remote's account, local paths or tokens. Callers only see short error codes.
 *
 * Remote spec: "<remote>:<folder>" (e.g. "gdrive:CourseMemory"), the remote configured by the user with
 * `rclone config`. This code never logs in, never creates share links and never runs `rclone config`.
 */

export class RcloneError extends Error {
  constructor(code, message) { super(message); this.name = 'RcloneError'; this.code = code; }
}

export const REMOTE_SPEC = /^([A-Za-z0-9_][A-Za-z0-9_ .-]{0,40}):((?:[^\\:*?"<>|\u0000-\u001f]{1,120})(?:\/[^\\:*?"<>|\u0000-\u001f]{1,120})*)$/;

/** Validates "remote:folder". Rejects drive letters, `..`, backslashes and empty segments. */
export function parseRemoteSpec(value) {
  const text = typeof value === 'string' ? value.trim().replace(/\/+$/, '') : '';
  const match = text.match(REMOTE_SPEC);
  if (!match || match[1].length === 1) return null; // "C:..." is a drive letter, not a remote
  const segments = match[2].split('/');
  if (segments.some((segment) => !segment.trim() || segment === '.' || segment === '..')) return null;
  return { remote: match[1], folder: segments.join('/'), spec: `${match[1]}:${segments.join('/')}` };
}

const TYPE_LABEL = { drive: 'Google Drive', onedrive: 'OneDrive', dropbox: 'Dropbox', s3: 'S3', webdav: 'WebDAV', box: 'Box', b2: 'Backblaze B2' };

/** Safe label for the UI: provider type + last folder segment. No account, no full path. */
export function destinationLabel(parsed, type) {
  if (!parsed) return null;
  return `${TYPE_LABEL[type] || '雲端'} · ${parsed.folder.split('/').at(-1)}`;
}

export function classifyRcloneFailure(error) {
  if (error?.code === 'COMMAND_NOT_FOUND') return 'RCLONE_UNAVAILABLE';
  if (error?.code === 'PROCESS_ABORTED') return 'CANCELLED';
  if (error?.code === 'PROCESS_TIMEOUT') return 'NETWORK_TIMEOUT';
  const text = `${error?.stderr || ''}\n${error?.stdout || ''}`;
  if (/didn't find section in config file|config file not found|NOTICE: Config file .* not found/i.test(text)) return 'REMOTE_NOT_CONFIGURED';
  if (/invalid_grant|token expired|couldn't fetch token|oauth2|unauthorized|401/i.test(text)) return 'AUTH_REQUIRED';
  if (/storageQuotaExceeded|quota exceeded|insufficient storage/i.test(text)) return 'REMOTE_QUOTA';
  if (/userRateLimitExceeded|rateLimitExceeded|429|too many requests/i.test(text)) return 'REMOTE_RATE_LIMITED';
  if (/no such host|dial tcp|network is unreachable|i\/o timeout|connection refused|connection reset|temporary failure in name resolution|tls handshake timeout|context deadline exceeded/i.test(text)) return 'NETWORK_OFFLINE';
  if (/directory not found|object not found|not found/i.test(text)) return 'REMOTE_NOT_FOUND';
  return 'UPLOAD_FAILED';
}

/** Parses one stderr line of `--use-json-log --stats` (or the plain "Transferred:" line). */
export function parseProgress(line) {
  const text = String(line).trim(); if (!text) return null;
  if (text.startsWith('{')) {
    try { const data = JSON.parse(text); if (data?.stats && Number.isFinite(data.stats.bytes)) return { bytes: data.stats.bytes, total: Number.isFinite(data.stats.totalBytes) ? data.stats.totalBytes : null }; } catch {}
    return null;
  }
  const match = text.match(/Transferred:\s+([\d.]+)\s*(\w*?)i?B?\s*\/\s*([\d.]+)\s*(\w*?)i?B?,/);
  if (!match) return null;
  const unit = { '': 1, K: 1024, M: 1024 ** 2, G: 1024 ** 3, T: 1024 ** 4 };
  const toBytes = (value, suffix) => Math.round(Number(value) * (unit[(suffix || '').replace(/i?B$/, '').toUpperCase()] ?? 1));
  return { bytes: toBytes(match[1], match[2]), total: toBytes(match[3], match[4]) };
}

export function createRclone({ run, start, command = 'rclone', timeoutMs = 30_000 }) {
  if (typeof run !== 'function') throw new Error('rclone adapter needs a process runner');
  const base = ['--retries', '1', '--low-level-retries', '3', '--contimeout', '15s', '--timeout', '60s'];
  const call = async (args, options = {}) => {
    try { return await run(command, args, { timeoutMs, ...options }); }
    catch (error) { throw new RcloneError(classifyRcloneFailure(error), 'rclone 失敗'); }
  };

  return {
    async version() {
      try { const result = await run(command, ['version'], { timeoutMs: 10_000 }); return (result.stdout.match(/rclone v([\d.]+)/) || [])[1] || 'unknown'; }
      catch (error) { if (error?.code === 'COMMAND_NOT_FOUND') return null; throw new RcloneError(classifyRcloneFailure(error), 'rclone 無法執行'); }
    },
    /** Remote names and types only (`rclone listremotes --long`). Never `rclone config show`. */
    async listRemotes() {
      const result = await call(['listremotes', '--long']);
      return result.stdout.split(/\r?\n/).map((line) => line.match(/^([^:\s][^:]*):\s+(\S+)/)).filter(Boolean).map(([, name, type]) => ({ name, type }));
    },
    /** Reachability of the destination folder. A missing folder still counts as connected (created on upload). */
    async probe(parsed) {
      try { await call(['lsjson', `${parsed.remote}:${parsed.folder}`, '--max-depth', '1', '--dirs-only', ...base], { timeoutMs: 20_000 }); return { state: 'connected' }; }
      catch (error) { return error.code === 'REMOTE_NOT_FOUND' ? { state: 'connected' } : { state: { NETWORK_OFFLINE: 'offline', NETWORK_TIMEOUT: 'offline', AUTH_REQUIRED: 'auth-required', REMOTE_NOT_CONFIGURED: 'not-configured', RCLONE_UNAVAILABLE: 'rclone-missing' }[error.code] || 'error', code: error.code }; }
    },
    /** Uploads one file to an exact remote path. Reports progress; resolves when rclone exits 0. */
    upload({ local, remotePath, onProgress, signal }) {
      const args = ['copyto', local, remotePath, '--use-json-log', '--stats', '1s', '--stats-log-level', 'NOTICE', ...base];
      if (typeof start !== 'function') return call(args, { signal, timeoutMs: 0 }).then(() => undefined);
      return new Promise((resolve, reject) => {
        let buffered = ''; let stderr = '';
        const child = start(command, args, { onStderr: (chunk) => {
          stderr = (stderr + chunk).slice(-8000); buffered += chunk;
          const lines = buffered.split(/\r?\n/); buffered = lines.pop();
          for (const line of lines) { const progress = parseProgress(line); if (progress) onProgress?.(progress); }
        } });
        const onAbort = () => child.kill(); signal?.addEventListener?.('abort', onAbort, { once: true });
        child.wait().then((exit) => {
          signal?.removeEventListener?.('abort', onAbort);
          if (signal?.aborted) return reject(new RcloneError('CANCELLED', '已取消'));
          if (exit?.error === 'COMMAND_NOT_FOUND') return reject(new RcloneError('RCLONE_UNAVAILABLE', '找不到 rclone'));
          if (exit?.code === 0) return resolve();
          reject(new RcloneError(classifyRcloneFailure({ stderr }), 'rclone 上傳失敗'));
        });
      });
    },
    /** Remote size (and MD5 when the backend has it) of one exact file, or { exists:false }. */
    async stat(remotePath) {
      let result;
      try { result = await call(['lsjson', remotePath, '--hash', '--files-only', ...base], { timeoutMs: 30_000 }); }
      catch (error) { if (error.code === 'REMOTE_NOT_FOUND') return { exists: false }; throw error; }
      let list; try { list = JSON.parse(result.stdout); } catch { throw new RcloneError('VERIFY_UNREADABLE', '無法讀取遠端檔案資訊'); }
      const name = remotePath.split('/').at(-1);
      const entry = Array.isArray(list) ? list.find((item) => item?.Name === name && item.IsDir !== true) : null;
      if (!entry) return { exists: false };
      const md5 = entry.Hashes?.md5 || entry.Hashes?.MD5 || null;
      return { exists: true, size: Number(entry.Size), md5: typeof md5 === 'string' ? md5.toLowerCase() : null };
    }
  };
}
