const KINDS = new Set(['play', 'paused', 'buffering', 'ad', 'preroll']);

export function normalizeSpans(spans) {
  if (!Array.isArray(spans) || !spans.length) throw new Error('TimeMap requires at least one span');
  return spans.map((input, index) => {
    const span = { ...input, recStart: Number(input.recStart), recEnd: Number(input.recEnd), rate: Number(input.rate || 0) };
    if (!KINDS.has(span.kind)) throw new Error(`invalid TimeMap kind: ${span.kind}`);
    if (![span.recStart, span.recEnd, span.rate].every(Number.isFinite) || span.recStart < 0 || span.recEnd <= span.recStart || span.rate < 0 || span.rate > 4) throw new Error('invalid TimeMap span');
    if (index && span.recStart < Number(spans[index - 1].recEnd)) throw new Error('TimeMap spans overlap');
    if (['ad', 'preroll'].includes(span.kind)) {
      if (span.rate !== 0) throw new Error(`${span.kind} span rate must be 0`);
      span.srcStart = null; span.srcEnd = null;
    } else {
      span.srcStart = Number(input.srcStart); span.srcEnd = Number(input.srcEnd ?? input.srcStart);
      if (!Number.isFinite(span.srcStart) || !Number.isFinite(span.srcEnd)) throw new Error('mapped span requires source times');
      if (span.kind === 'play') {
        if (span.rate <= 0) throw new Error('play span rate must be greater than 0');
        const expected = span.srcStart + (span.recEnd - span.recStart) * span.rate;
        if (Math.abs(span.srcEnd - expected) > 0.5) throw new Error('play span srcEnd is inconsistent with rate');
      } else {
        if (span.rate !== 0 || span.srcStart !== span.srcEnd) throw new Error(`${span.kind} span source time must not move`);
      }
    }
    return span;
  });
}

const kindOf = (sample) => sample.ad ? 'ad' : sample.buffering ? 'buffering' : sample.paused ? 'paused' : 'play';

export function buildSpans(samples, { endRec, tolerance = 0.5, recOrigin } = {}) {
  if (!Array.isArray(samples) || samples.length < 2) throw new Error('at least two TimeMap samples are required');
  if (!Number.isFinite(Number(endRec))) throw new Error('endRec is required');
  const ordered = [...samples].sort((a, b) => a.rec - b.rec); const spans = []; let degraded = false;
  if (Number(endRec) <= Number(ordered.at(-1).rec)) throw new Error('endRec must be after the final sample');
  const firstPlayIndex = ordered.findIndex((sample) => kindOf(sample) === 'play');
  if (firstPlayIndex < 0) throw new Error('TimeMap samples contain no play state');
  const origin = Number(recOrigin ?? ordered[0].rec);
  if (origin < Number(ordered[firstPlayIndex].rec)) spans.push({ recStart: origin, recEnd: Number(ordered[firstPlayIndex].rec), srcStart: null, srcEnd: null, rate: 0, kind: 'preroll' });
  for (let index = firstPlayIndex; index < ordered.length; index += 1) {
    const sample = ordered[index]; const next = ordered[index + 1]; const recEnd = next?.rec ?? endRec;
    if (!Number.isFinite(sample.rec) || !Number.isFinite(recEnd) || recEnd <= sample.rec) continue;
    const kind = kindOf(sample); const rate = kind === 'play' ? Number(sample.rate || 1) : 0;
    const mapped = !['ad', 'preroll'].includes(kind); const srcStart = mapped ? Number(sample.src) : null;
    const srcEnd = mapped ? (kind === 'play' ? srcStart + (recEnd - sample.rec) * rate : srcStart) : null;
    const candidate = { recStart: sample.rec, recEnd, srcStart, srcEnd, rate, kind };
    const previous = spans.at(-1); const continuityError = previous?.srcEnd != null && candidate.srcStart != null ? Math.abs(previous.srcEnd - candidate.srcStart) : 0;
    if (previous?.kind === 'play' && candidate.kind === 'play' && continuityError > tolerance && continuityError <= 1) degraded = true;
    const continuous = previous && previous.kind === candidate.kind && previous.rate === candidate.rate && previous.recEnd === candidate.recStart && (candidate.srcStart == null || continuityError <= tolerance);
    if (continuous) { previous.recEnd = candidate.recEnd; previous.srcEnd = candidate.srcEnd; }
    else spans.push(candidate);
  }
  return { quality: degraded ? 'degraded' : 'ok', spans: normalizeSpans(spans) };
}

export function recToSrc(seconds, spans) {
  const value = Number(seconds); const map = normalizeSpans(spans); const span = map.find((item, index) => value >= item.recStart && (value < item.recEnd || (index === map.length - 1 && value === item.recEnd)));
  if (!span || ['ad', 'preroll'].includes(span.kind)) return null;
  if (span.kind !== 'play') return span.srcStart;
  return span.srcStart + (value - span.recStart) * span.rate;
}

export function srcToRec(seconds, spans) {
  const value = Number(seconds); const results = []; const map = normalizeSpans(spans);
  for (let index = 0; index < map.length; index += 1) {
    const span = map[index]; if (span.kind !== 'play') continue;
    const candidate = span.recStart + (value - span.srcStart) / span.rate;
    const inside = candidate >= span.recStart && (candidate < span.recEnd || (index === map.length - 1 && candidate === span.recEnd));
    if (inside && !results.some((item) => Math.abs(item - candidate) < 1e-9)) results.push(candidate);
  }
  return results.sort((a, b) => a - b);
}

export function splitRange(range, spans) {
  const [start, end] = range.map(Number); if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) throw new Error('invalid recording range');
  return normalizeSpans(spans).filter((span) => span.recEnd > start && span.recStart < end).map((span) => {
    const recStart = Math.max(start, span.recStart), recEnd = Math.min(end, span.recEnd);
    const mapWithin = (value) => span.kind === 'play' ? span.srcStart + (value - span.recStart) * span.rate : ['paused', 'buffering'].includes(span.kind) ? span.srcStart : null;
    return { kind: span.kind, rec: [recStart, recEnd], src: [mapWithin(recStart), mapWithin(recEnd)] };
  });
}
