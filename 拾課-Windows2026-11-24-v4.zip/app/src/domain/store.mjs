import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export class JsonStore {
  constructor(root) { this.root = path.resolve(root); }
  resolve(relative) {
    const target = path.resolve(this.root, relative);
    if (target !== this.root && !target.startsWith(`${this.root}${path.sep}`)) throw new Error('path escapes store root');
    return target;
  }
  async exists(relative) { try { await fsp.access(this.resolve(relative)); return true; } catch { return false; } }
  async read(relative, fallback) { try { return JSON.parse(await fsp.readFile(this.resolve(relative), 'utf8')); } catch (error) { if (error.code === 'ENOENT' && arguments.length > 1) return fallback; throw error; } }
  async write(relative, value) {
    const target = this.resolve(relative); await fsp.mkdir(path.dirname(target), { recursive: true });
    const temporary = `${target}.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`;
    await fsp.writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
    await fsp.rename(temporary, target);
    return target;
  }
}
