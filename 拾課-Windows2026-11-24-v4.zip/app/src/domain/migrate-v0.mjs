import path from 'node:path';
import fsp from 'node:fs/promises';
import { createId } from './ids.mjs';
import { JsonStore } from './store.mjs';

export const MIGRATION_VERSION = 2;
const normalizedLanguage = (value) => value === 'zh' ? 'zh-Hant' : ['zh-Hant', 'zh-Hans', 'en'].includes(value) ? value : 'auto';

export function migrateFlatCourse(course, { now = new Date().toISOString() } = {}) {
  if (!course?.id) throw new Error('legacy course id is required');
  const seed = `v0:${course.id}`;
  const ids = { course: createId('crs', `${seed}:course`), module: createId('mod', `${seed}:module:1`), lesson: createId('les', `${seed}:lesson:1`), asset: createId('ast', `${seed}:asset:1`), rights: createId('rts', `${seed}:rights`), track: createId('trk', `${seed}:track:1`), knowledge: createId('kp', `${seed}:knowledge:1`) };
  const segments = (course.segments || []).map((segment, index) => ({ id: `s${String(index + 1).padStart(4, '0')}`, rec: [segment.start, segment.end], src: [segment.start, segment.end], text: segment.text }));
  const rightsBasis = ['owned', 'licensed', 'cc', 'public-domain', 'platform-permitted', 'personal-study'].includes(course.rights?.basis) ? course.rights.basis : 'personal-study';
  const explicitlyAcknowledged = course.rights?.recordPermissionAcknowledged === true || course.rights?.acknowledged === true;
  const evidence = [...(Array.isArray(course.rights?.evidence) ? course.rights.evidence : []), ...(course.rights?.licenseUrl ? [{ type: 'url', value: course.rights.licenseUrl }] : [])];
  const rights = { id: ids.rights, schemaVersion: 1, basis: rightsBasis, allowDerivative: false, evidence, owner: course.rights?.owner || '', sourceUrl: course.rights?.sourceUrl || '', licenseUrl: course.rights?.licenseUrl || '', note: course.rights?.note || '', recordPermissionAcknowledged: explicitlyAcknowledged, privateTransformAllowed: false, needsReconfirmation: true, history: [], acknowledgedAt: course.rights?.acknowledgedAt || null, createdAt: now, updatedAt: now };
  const asset = { id: ids.asset, schemaVersion: 1, lessonId: ids.lesson, kind: course.demo ? 'demo' : 'recording', path: course.demo ? null : course.video, rightsId: ids.rights, createdAt: now, updatedAt: now };
  const track = { id: ids.track, schemaVersion: 1, assetId: ids.asset, revision: 1, parentRevision: null, origin: 'whisper', language: normalizedLanguage(course.language), segments, createdAt: now, updatedAt: now };
  const chapters = (course.chapters || []).map((chapter, index) => { const segmentIds = segments.filter((segment) => segment.rec[1] > chapter.start && segment.rec[0] < chapter.end).map((segment) => segment.id); return { id: chapter.id || `ch${index + 1}`, title: chapter.title, src: [chapter.start, chapter.end], segmentIds }; });
  const citeFor = (chapter) => chapters.find((item) => item.id === (chapter.id || `ch${(course.chapters || []).indexOf(chapter) + 1}`))?.segmentIds.slice(0, 3) || [];
  const knowledge = { id: ids.knowledge, schemaVersion: 1, lessonId: ids.lesson, trackId: ids.track, trackRevision: 1, language: 'zh-Hant', chapters, keyPoints: (course.chapters || []).flatMap((chapter) => (chapter.summary || []).map((text) => ({ text, cite: citeFor(chapter) }))), terms: (course.chapters || []).flatMap((chapter) => (chapter.terms || []).map((term) => ({ ...term, cite: citeFor(chapter) }))), actions: (course.chapters || []).flatMap((chapter) => (chapter.actions || []).map((text) => ({ text, cite: citeFor(chapter) }))), quiz: (course.chapters || []).flatMap((chapter) => (chapter.questions || []).map((q) => ({ q, type: 'short', answer: '', cite: citeFor(chapter) }))), createdAt: now, updatedAt: now };
  const markers = (course.markers || []).map((marker, index) => ({ id: createId('mk', `${seed}:${marker.id || index}`), assetId: ids.asset, purpose: 'study', at: { rec: marker.at, src: marker.at }, range: null, note: marker.note, source: 'legacy', createdAt: marker.createdAt || now, updatedAt: now }));
  const lesson = { id: ids.lesson, schemaVersion: 1, moduleId: ids.module, order: 1, title: course.title, platformLessonId: course.id, url: course.rights?.sourceUrl || '', status: course.status === 'ready' ? 'processed' : course.status || 'pending', primaryAssetId: ids.asset, createdAt: course.createdAt || now, updatedAt: now };
  const module = { id: ids.module, schemaVersion: 1, courseId: ids.course, title: '課程內容', order: 1, lessonIds: [ids.lesson], createdAt: now, updatedAt: now };
  const migratedCourse = { id: ids.course, schemaVersion: 1, title: course.title, platform: 'manual', sourceUrl: course.rights?.sourceUrl || '', defaultRightsId: ids.rights, language: normalizedLanguage(course.language), moduleIds: [ids.module], createdAt: course.createdAt || now, updatedAt: now };
  return { migrationVersion: MIGRATION_VERSION, sourceId: course.id, course: migratedCourse, modules: [module], lessons: [lesson], assets: [asset], rights: [rights], tracks: [track], knowledge: [knowledge], markers };
}

export async function migrateV0Library({ libraryFolder, indexFile = 'index.json', now } = {}) {
  const store = new JsonStore(libraryFolder); const legacy = await store.read(indexFile, []); const results = [];
  for (const oldCourse of legacy) {
    const migrated = migrateFlatCourse(oldCourse, { now }); const target = path.join(migrated.course.id, 'course.json');
    if (await store.exists(target)) { const current = await store.read(target); if (current.migrationVersion === MIGRATION_VERSION) { results.push({ oldId: oldCourse.id, newId: migrated.course.id, status: 'skipped' }); continue; } }
    const oldDir = oldCourse.id; const backup = path.join(oldDir, 'course.v0.json');
    if (!(await store.exists(backup))) { const original = path.join(oldDir, 'course.json'); if (await store.exists(original)) { await fsp.mkdir(path.dirname(store.resolve(backup)), { recursive: true }); await fsp.copyFile(store.resolve(original), store.resolve(backup)); } else await store.write(backup, oldCourse); }
    const existed = await store.exists(target); await store.write(target, migrated); results.push({ oldId: oldCourse.id, newId: migrated.course.id, status: existed ? 'upgraded' : 'migrated' });
  }
  return results;
}
