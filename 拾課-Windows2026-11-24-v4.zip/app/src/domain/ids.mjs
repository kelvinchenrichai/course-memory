import crypto from 'node:crypto';

export const ID_PREFIXES = new Set(['crs', 'mod', 'les', 'ast', 'rts', 'rec', 'trk', 'trn', 'kp', 'mk', 'clp', 'bak', 'job', 'lsrc', 'lpln', 'lses', 'lseg', 'sig', 'hlc']);

export function createId(prefix, seed) {
  if (!ID_PREFIXES.has(prefix)) throw new Error(`unsupported id prefix: ${prefix}`);
  const hex = seed == null ? crypto.randomBytes(6).toString('hex') : crypto.createHash('sha256').update(String(seed)).digest('hex').slice(0, 12);
  return `${prefix}_${hex}`;
}

function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map((key) => [key, stable(value[key])]));
  return value;
}

export function stableStringify(value) { return JSON.stringify(stable(value)); }

export function createStageKey({ stage, inputIds = [], inputRevisions = [], params = {}, pipelineVersion = '1' }) {
  const payload = stableStringify({ stage, inputIds, inputRevisions, params, pipelineVersion });
  return `sha256:${crypto.createHash('sha256').update(payload).digest('hex')}`;
}
