/**
 * Maps OBS recording time to the source player's timeline when playback speed changes.
 * Each segment starts at recordingStart and sourceStart with a fixed playback rate.
 * Pauses are represented with rate 0. Seeking should start a new recording session.
 */
export function normalizeTimeMap(segments) {
  if (!Array.isArray(segments) || !segments.length) throw new Error('time map requires at least one segment');
  const normalized = [];
  for (let index = 0; index < segments.length; index += 1) {
    const input = segments[index];
    const recordingStart = Number(input.recordingStart);
    const rate = Number(input.rate);
    if (!Number.isFinite(recordingStart) || recordingStart < 0) throw new Error('recordingStart must be a non-negative number');
    if (!Number.isFinite(rate) || rate < 0 || rate > 4) throw new Error('rate must be between 0 and 4');
    if (index === 0 && recordingStart !== 0) throw new Error('the first segment must start at recording time 0');
    const previous = normalized.at(-1);
    if (previous && recordingStart <= previous.recordingStart) throw new Error('segments must be ordered by recordingStart');
    const derivedSourceStart = previous ? previous.sourceStart + (recordingStart - previous.recordingStart) * previous.rate : 0;
    const sourceStart = input.sourceStart == null ? derivedSourceStart : Number(input.sourceStart);
    if (!Number.isFinite(sourceStart) || sourceStart < 0) throw new Error('sourceStart must be a non-negative number');
    normalized.push({ recordingStart, sourceStart, rate });
  }
  return normalized;
}

export function recordingToSource(seconds, segments) {
  const map = normalizeTimeMap(segments); const value = Number(seconds);
  if (!Number.isFinite(value) || value < 0) throw new Error('recording time must be a non-negative number');
  const segment = [...map].reverse().find((item) => item.recordingStart <= value) || map[0];
  return segment.sourceStart + (value - segment.recordingStart) * segment.rate;
}

export function sourceToRecording(seconds, segments) {
  const map = normalizeTimeMap(segments); const value = Number(seconds);
  if (!Number.isFinite(value) || value < 0) throw new Error('source time must be a non-negative number');
  for (let index = 0; index < map.length; index += 1) {
    const segment = map[index]; const next = map[index + 1];
    const sourceEnd = next ? next.sourceStart : Infinity;
    if (segment.rate === 0 && value === segment.sourceStart) return segment.recordingStart;
    if (segment.rate > 0 && value >= segment.sourceStart && value < sourceEnd) return segment.recordingStart + (value - segment.sourceStart) / segment.rate;
  }
  throw new Error('source time is outside the recorded timeline');
}
