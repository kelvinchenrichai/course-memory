// P9: wall-clock ⇄ UTC conversion for IANA time zones using only Intl (no dependency, testable).
// A plan is entered as local date-time + zone ("2026-11-13T23:30" in "Asia/Taipei"); it is stored with
// the computed UTC instants. Local times that do not exist (DST spring-forward gap) are rejected;
// ambiguous ones (fall-back overlap) resolve to the earlier instant.

const LOCAL = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/;
const formatters = new Map();
function formatter(timeZone) {
  if (!formatters.has(timeZone)) formatters.set(timeZone, new Intl.DateTimeFormat('en-US', { timeZone, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  return formatters.get(timeZone);
}

export function isValidTimeZone(timeZone) {
  if (typeof timeZone !== 'string' || !timeZone || timeZone.length > 64) return false;
  try { formatter(timeZone); return true; } catch { return false; }
}

/** Wall-clock fields of `ms` in `timeZone`. */
export function partsInZone(ms, timeZone) {
  const parts = Object.fromEntries(formatter(timeZone).formatToParts(new Date(ms)).filter((p) => p.type !== 'literal').map((p) => [p.type, Number(p.value)]));
  return { year: parts.year, month: parts.month, day: parts.day, hour: parts.hour % 24, minute: parts.minute, second: parts.second };
}

/** Offset (ms) of `timeZone` from UTC at instant `ms`. */
export function offsetAt(ms, timeZone) {
  const p = partsInZone(ms, timeZone);
  return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second) - Math.floor(ms / 1000) * 1000;
}

/** "YYYY-MM-DDTHH:mm" (local to `timeZone`) → UTC ms. Throws LOCAL_TIME_INVALID / LOCAL_TIME_NONEXISTENT. */
export function zonedToUtc(local, timeZone) {
  const m = LOCAL.exec(String(local || ''));
  if (!m || !isValidTimeZone(timeZone)) throw Object.assign(new Error('時間或時區格式不正確'), { code: 'LOCAL_TIME_INVALID' });
  const [y, mo, d, h, mi, s] = m.slice(1).map((v) => Number(v || 0));
  if (mo < 1 || mo > 12 || d < 1 || d > 31 || h > 23 || mi > 59 || s > 59) throw Object.assign(new Error('時間格式不正確'), { code: 'LOCAL_TIME_INVALID' });
  const asUtc = Date.UTC(y, mo - 1, d, h, mi, s);
  // Try both offsets around the instant; keep candidates whose wall clock matches exactly.
  const candidates = [...new Set([offsetAt(asUtc - 86_400_000, timeZone), offsetAt(asUtc, timeZone), offsetAt(asUtc + 86_400_000, timeZone)])]
    .map((offset) => asUtc - offset)
    .filter((ms) => { const p = partsInZone(ms, timeZone); return p.year === y && p.month === mo && p.day === d && p.hour === h && p.minute === mi; })
    .sort((a, b) => a - b);
  if (!candidates.length) throw Object.assign(new Error('這個時間因夏令時間調整而不存在，請改選其他時間'), { code: 'LOCAL_TIME_NONEXISTENT' });
  return candidates[0];
}

/** UTC ms → "YYYY-MM-DD HH:mm" in `timeZone` (display only). */
export function formatInZone(ms, timeZone) {
  const p = partsInZone(ms, timeZone); const two = (n) => String(n).padStart(2, '0');
  return `${p.year}-${two(p.month)}-${two(p.day)} ${two(p.hour)}:${two(p.minute)}`;
}
