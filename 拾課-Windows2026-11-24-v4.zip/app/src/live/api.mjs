import { checkLocalRequest } from '../settings/api.mjs';
import { LiveError } from './service.mjs';

/**
 * P9 直播工作台 local API — same guard as P4C (localhost Host, same-origin, JSON bodies).
 *   GET  /api/live                                   → overview: disk, cloud state, sources, plans, sessions (file names only)
 *   POST /api/live/sources                           → { name, pageUrl, contentType, purpose, defaultCaptureMode, rightsBasis?, evidence?, acknowledgements }
 *   POST /api/live/plans                             → { sourceId, title?, timeZone, startLocal, endLocal, prepareMinutes?, captureMode?, segmentMinutes?, backupAfterClose?, enable? }
 *   POST /api/live/plans/:id                         → edit (same fields) while not started
 *   POST /api/live/plans/:id/(enable|disable|cancel)
 *   POST /api/live/sessions/:id/(stop|cancel|resume|finish|marker|retry-backup|acknowledge|confirm-segment|repair-segment)
 *        repair-segment: { segmentId, candidateId, confirm: true } (candidateId from GET /api/live, never a path)
 *        finish: { confirm: true, stopObs?: boolean }; confirm-segment: { segmentId } (a segment of that session only, no paths)
 *   POST /api/live/settings { dedicatedRecordFolder: boolean }   (the folder is read from OBS, never sent by the browser)
 * There is no route that publishes, shares, uploads elsewhere or returns local paths, cookies or tokens.
 */

const ROUTES = /^\/api\/live(?:\/(sources|plans|sessions|settings)(?:\/((?:lpln|lses)_[0-9a-f]{12})(?:\/(enable|disable|cancel|stop|resume|finish|marker|retry-backup|acknowledge|confirm-segment|repair-segment))?)?)?$/;
const SEGMENT_ID = /^lseg_[0-9a-f]{12}$/;
const json = (status, body) => ({ status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }, body });
const pick = (body, keys) => Object.fromEntries(keys.filter((key) => key in body).map((key) => [key, body[key]]));
const PLAN_FIELDS = ['sourceId', 'title', 'timeZone', 'startLocal', 'endLocal', 'prepareMinutes', 'captureMode', 'segmentMinutes', 'backupAfterClose', 'enable'];
const SOURCE_FIELDS = ['name', 'pageUrl', 'contentType', 'purpose', 'defaultCaptureMode', 'rightsBasis', 'evidence', 'acknowledgements'];

export const isLiveRoute = (pathname) => ROUTES.test(pathname);

/** ctx: { live, port } */
export async function handleLiveRequest(ctx, request) {
  const { method, pathname } = request;
  const match = pathname.match(ROUTES); if (!match) return null;
  const rejected = checkLocalRequest(request, ctx.port);
  if (rejected) return json(rejected === 'JSON_REQUIRED' ? 415 : 403, { error: rejected });
  const body = request.body && typeof request.body === 'object' && !Array.isArray(request.body) ? request.body : {};
  const [, collection = null, id = null, action = null] = match;
  try {
    if (!collection && method === 'GET') return json(200, await ctx.live.overview());
    if (method !== 'POST') return json(405, { error: 'METHOD_NOT_ALLOWED' });
    if (collection === 'settings' && !id) {
      const extra = Object.keys(body).find((key) => key !== 'dedicatedRecordFolder');
      if (extra || typeof body.dedicatedRecordFolder !== 'boolean') return json(400, { error: 'INVALID_VALUE' });
      return json(200, await ctx.live.setDedicatedRecordFolder(body.dedicatedRecordFolder)); // the folder comes from OBS, never from the browser
    }
    if (collection === 'sources' && !id) { const source = await ctx.live.createSource(pick(body, SOURCE_FIELDS)); return json(201, { id: source.id, name: source.name, platform: source.platform, purpose: source.purpose }); }
    if (collection === 'plans' && !id) return json(201, await ctx.live.createPlan(pick(body, PLAN_FIELDS)));
    if (collection === 'plans' && id?.startsWith('lpln_') && !action) return json(200, await ctx.live.updatePlan(id, pick(body, PLAN_FIELDS.filter((key) => key !== 'enable'))));
    if (collection === 'plans' && id?.startsWith('lpln_') && ['enable', 'disable', 'cancel'].includes(action)) return json(200, await ctx.live.setPlanStatus(id, { enable: 'enabled', disable: 'disabled', cancel: 'cancelled' }[action]));
    if (collection === 'sessions' && id?.startsWith('lses_') && ['stop', 'cancel', 'resume', 'finish', 'marker', 'retry-backup', 'acknowledge', 'confirm-segment', 'repair-segment'].includes(action)) {
      if (['confirm-segment', 'repair-segment'].includes(action) && !SEGMENT_ID.test(String(body.segmentId))) return json(400, { error: 'INVALID_VALUE', message: '分段代碼不正確' });
      if (action === 'repair-segment' && !/^[0-9a-f]{12}$/.test(String(body.candidateId))) return json(400, { error: 'INVALID_VALUE', message: '候選檔案代碼不正確' });
      if (action === 'repair-segment' && body.confirm !== true) return json(400, { error: 'CONFIRM_REQUIRED', message: '修復前需要確認' });
      if (action === 'finish' && body.confirm !== true) return json(400, { error: 'CONFIRM_REQUIRED', message: '結束前需要確認' });
      return json(200, await ctx.live.act(id, action, action === 'finish' ? { stopObs: body.stopObs === true } : action === 'marker' ? { note: typeof body.note === 'string' ? body.note : '' } : action === 'confirm-segment' ? { segmentId: body.segmentId } : action === 'repair-segment' ? { segmentId: body.segmentId, candidateId: body.candidateId } : {}));
    }
    return json(404, { error: 'NOT_FOUND' });
  } catch (error) {
    const code = typeof error?.code === 'string' && /^[A-Z][A-Z0-9_]{2,60}$/.test(error.code) ? error.code : 'LIVE_ERROR';
    const status = error instanceof LiveError ? error.status : 500;
    return json(status, { error: code, message: typeof error?.message === 'string' && /[一-鿿]/.test(error.message) ? error.message.slice(0, 200) : '處理失敗' });
  }
}

async function readBody(req, limit = 16 * 1024) {
  let size = 0; const chunks = [];
  for await (const chunk of req) { size += chunk.length; if (size > limit) throw Object.assign(new Error('too large'), { status: 413 }); chunks.push(chunk); }
  if (!size) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw Object.assign(new Error('bad json'), { status: 400 }); }
}

export async function routeLiveApis(ctx, req, res, url) {
  if (url.pathname !== '/api/live' && !url.pathname.startsWith('/api/live/')) return false;
  if (!isLiveRoute(url.pathname)) { res.writeHead(404, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ error: 'NOT_FOUND' })); return true; }
  let result;
  try {
    const rejected = checkLocalRequest({ method: req.method, headers: req.headers }, ctx.port);
    const body = !rejected && req.method === 'POST' ? await readBody(req) : undefined;
    result = await handleLiveRequest(ctx, { method: req.method, pathname: url.pathname, headers: req.headers, body });
  } catch (error) { result = json(error.status === 413 ? 413 : 400, { error: error.status === 413 ? 'TOO_LARGE' : 'BAD_JSON' }); }
  res.writeHead(result.status, result.headers); res.end(JSON.stringify(result.body));
  return true;
}
