import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { createId } from '../domain/ids.mjs';
import { makeId } from '../../lib/core.mjs';
import { isInside, readJson, writeJsonAtomic } from '../pipeline/files.mjs';
import { validateRights, assertPrivateUse, assertPublicExportRecord, RIGHTS_BASES } from '../services/rights.mjs';
import { cleanPageUrl, DiscoveryError } from '../discovery/urls.mjs';
import { isValidTimeZone, zonedToUtc } from './time.mjs';

/**
 * P9 無人值守直播錄製核心 — platform-independent scheduler + OBS recorder.
 *
 * - Driven by tick() (the server calls it every few seconds; tests advance a fake clock). No real waiting.
 * - A session is「recording」only after OBS confirmed RecordStateChanged(STARTED) (obs.startRecord()).
 * - Segments: OBS SplitRecordFile (obs-websocket ≥ 5.5.0, file splitting enabled). Each RecordFileChanged
 *   closes the previous file. If splitting is unavailable the session is marked `segmentation-unavailable`
 *   and records one file — never pretending it was split.
 * - Only closed segments are handed to the existing P4D/P7B backup service (one entry per session).
 * - Never takes over or stops an OBS recording this program did not start; after a restart or an OBS
 *   disconnect the session is blocked with「OBS 可能仍在錄影」until the user decides.
 * - Never stores cookies, tokens, passwords or stream URLs; API views carry file names only.
 */

export const LIVE_STATUSES = Object.freeze(['scheduled', 'preparing', 'recording', 'stopping', 'processing', 'completed', 'blocked', 'failed', 'cancelled']);
export const SEGMENT_LIMITS = Object.freeze({ min: 2, max: 60, default: 10 });
export const PREPARE_LIMITS = Object.freeze({ min: 1, max: 60, default: 10 });
export const MAX_PLAN_HOURS = 12;
export const MIN_SPLIT_WEBSOCKET = '5.5.0';
const ACTIVE = new Set(['preparing', 'recording', 'stopping']);
const MEDIA_EXT = /\.(mkv|mp4|mov|flv|ts|m4v)$/i;
/** Blockers raised *after* recording ended: never offer resume / finish (that would re-record or skip backup). */
export const POST_RECORDING_BLOCKERS = Object.freeze(['BACKUP_FAILED', 'BACKUP_NOT_CONFIGURED', 'SEGMENT_PATH_AMBIGUOUS', 'SEGMENT_PATH_UNKNOWN', 'SEGMENT_OWNER_UNCONFIRMED', 'SEGMENT_PATH_DUPLICATE']);
/** Path problems that only the user can resolve (never re-evaluated away by a tick). */
const PATH_BLOCKERS = new Set(['SEGMENT_PATH_AMBIGUOUS', 'SEGMENT_PATH_UNKNOWN', 'SEGMENT_OWNER_UNCONFIRMED', 'SEGMENT_PATH_DUPLICATE']);
/**
 * Who says a segment file belongs to this recording:
 *   obs-confirmed  — OBS reported the path (RecordStateChanged / RecordFileChanged / StopRecord)
 *   user-confirmed — the user pressed「我確認這是本場直播檔案」for this session's segment
 *   inferred       — the only new media file in the record folder after StartRecord (never cleaned automatically;
 *                    uploaded only when the user declared the record folder OBS-only, otherwise waits for confirmation)
 */
export const FILE_SOURCES = Object.freeze(['obs-confirmed', 'user-confirmed', 'inferred']);
const POST = new Set(POST_RECORDING_BLOCKERS);
const PAGE_STOPS = new Set(['LOGIN_REQUIRED', 'CAPTCHA', 'DOM_CHANGED', 'PLAYER_NOT_FOUND', 'PAYMENT_PROMPT']);
const BYTES_PER_HOUR = { video: 2.7 * 1024 ** 3, audio: 0.12 * 1024 ** 3 };
const PLATFORM_OF = (host) => /(^|\.)youtube\.com$/.test(host) ? 'youtube' : /(^|\.)bilibili\.com$/.test(host) ? 'bilibili' : /(^|\.)twitch\.tv$/.test(host) ? 'twitch' : /(^|\.)discord\.com$/.test(host) ? 'discord' : 'generic';

export class LiveError extends Error {
  constructor(code, message, status = 400) { super(message); this.name = 'LiveError'; this.code = code; this.status = status; }
}
const fail = (code, message, status) => { throw new LiveError(code, message, status); };
const iso = (ms) => new Date(ms).toISOString();
const versionAtLeast = (value, min) => { const a = String(value || '').split('.').map(Number); const b = min.split('.').map(Number); for (let i = 0; i < 3; i += 1) if ((a[i] || 0) !== b[i]) return (a[i] || 0) > b[i]; return true; };
export const courseIdForLive = (sessionId) => makeId(`live:${sessionId}`);

export function createLiveService({
  dataDir, clock = { now: () => Date.now() }, obs, rights, freeBytes = async () => null,
  disk = { warnBytes: 20 * 1024 ** 3, stopBytes: 5 * 1024 ** 3 }, backup = null, cloudStatus = async () => ({ state: 'not-set' }),
  pageBlocker = async () => null, recordDirectory = async () => null, listMediaFiles = async () => [], allowedRoots = [],
  audioOnlyConfirmed = () => false, platform = process.platform, realpath = fsp.realpath, logger = console, intervals = { preflightMs: 30_000, diskMs: 30_000, pageMs: 15_000, splitConfirmMs: 15_000, cleanupMs: 300_000 }
} = {}) {
  if (!dataDir) throw new Error('dataDir is required');
  const file = path.join(dataDir, 'live', 'state.json');
  let state = null; let ticking = null;
  const runtime = new Map(); // per session (not persisted): timers / current file / pending split
  const now = () => clock.now();

  async function load() {
    if (state) return state;
    const raw = await readJson(file, null);
    state = raw && raw.version === 1 ? raw : { version: 1, sources: [], plans: [], sessions: [], segments: [], signals: [], candidates: [] };
    state.quarantine ??= []; // files we could not attribute: never uploaded, cleaned or re-processed
    state.settings ??= { dedicatedFolderKey: null }; // realpath key of the OBS record folder the user declared OBS-only
    return state;
  }
  const save = () => writeJsonAtomic(file, state);
  const touch = (record) => { record.updatedAt = iso(now()); return record; };
  const rt = (id) => { if (!runtime.has(id)) runtime.set(id, { currentPath: null, splitAt: null, lastPreflight: 0, lastDisk: 0, lastPage: 0, lastCleanup: 0 }); return runtime.get(id); };
  const segmentsOf = (sessionId) => state.segments.filter((item) => item.sessionId === sessionId).sort((a, b) => a.index - b.index);
  const openSegment = (sessionId) => segmentsOf(sessionId).find((item) => item.state === 'recording');
  const sourceOf = (id) => state.sources.find((item) => item.id === id);
  const planOf = (id) => state.plans.find((item) => item.id === id);
  const sessionOf = (id) => state.sessions.find((item) => item.id === id) || fail('SESSION_NOT_FOUND', '找不到這個直播紀錄', 404);
  const warn = (session, code) => { if (!session.warnings.includes(code)) session.warnings = [...session.warnings, code].slice(-20); };

  function block(session, code, { obsMayStillBeRecording = false } = {}) {
    session.status = 'blocked'; session.blocker = { code, at: iso(now()), obsMayStillBeRecording };
    session.obs.mayStillBeRecording = obsMayStillBeRecording;
    const open = openSegment(session.id);
    if (open) { open.state = 'interrupted'; open.endAt = iso(now()); touch(open); }
    touch(session); logger.warn?.({ event: 'live_blocked', sessionId: session.id, code });
  }

  // ---- sources / rights ---------------------------------------------------------------------------
  async function createSource(input = {}) {
    await load();
    const name = String(input.name || '').trim().slice(0, 120); if (!name) fail('INVALID_SOURCE', '請輸入直播名稱');
    let pageUrl; try { pageUrl = cleanPageUrl(String(input.pageUrl || '')); } catch (error) { fail(error instanceof DiscoveryError ? error.code : 'INVALID_URL', error.message); }
    const url = new URL(pageUrl); if (url.protocol !== 'https:') fail('INVALID_URL', '請使用 https 直播頁網址');
    if (/\.(m3u8|mpd|flv|ts|m4s)$/i.test(url.pathname)) fail('STREAM_URL_NOT_ALLOWED', '請貼上直播「頁面」網址，不要貼串流檔網址');
    if (!['esports', 'trading', 'generic'].includes(input.contentType)) fail('INVALID_SOURCE', '請選擇內容類型');
    if (!['private-study', 'creator-candidate'].includes(input.purpose)) fail('INVALID_SOURCE', '請選擇用途');
    const mode = input.defaultCaptureMode ?? 'video'; if (!['video', 'audio'].includes(mode)) fail('INVALID_SOURCE', '錄製方式不正確');
    const ack = input.acknowledgements || {};
    if (ack.recordPermission !== true || ack.privateProcessing !== true) fail('RIGHTS_REQUIRED', '請先確認你有權錄製這場直播，且只供私人處理', 403);
    const basis = input.rightsBasis ?? 'personal-study'; if (!RIGHTS_BASES.includes(basis)) fail('INVALID_SOURCE', '授權依據不正確');
    let record;
    try {
      record = validateRights({ basis, acknowledged: true, privateTransformAllowed: true, allowDerivative: input.purpose === 'creator-candidate' && ack.derivativePermission === true, evidence: input.evidence, sourceUrl: pageUrl, note: input.purpose === 'creator-candidate' ? '直播工作台：創作候選' : '直播工作台：私人學習' }, { now: iso(now()) });
    } catch (error) { fail('RIGHTS_INVALID', error.message, 403); }
    if (input.purpose === 'creator-candidate') { try { assertPublicExportRecord(record); } catch (error) { fail('DERIVATIVE_RIGHTS_REQUIRED', `創作候選需要公開二創授權：${error.message}`, 403); } }
    await rights.save(record);
    const source = { schemaVersion: 1, id: createId('lsrc'), createdAt: iso(now()), updatedAt: iso(now()), name, platform: PLATFORM_OF(url.hostname), pageUrl, contentType: input.contentType, rightsId: record.id, purpose: input.purpose, defaultCaptureMode: mode };
    state.sources.push(source); await save(); return source;
  }

  // ---- plans ---------------------------------------------------------------------------------------
  function windowOf(plan) { const start = Date.parse(plan.startAt); return { prepareAt: start - plan.prepareMinutes * 60_000, startAt: start, endAt: Date.parse(plan.endAt) }; }
  function assertNoOverlap(plan) {
    const mine = windowOf(plan);
    for (const other of state.plans) {
      if (other.id === plan.id || other.status !== 'enabled') continue;
      const w = windowOf(other);
      if (mine.prepareAt < w.endAt && w.prepareAt < mine.endAt) fail('PLAN_OVERLAP', `與「${other.title}」的時間重疊（含準備時間）。目前同一時間只能錄一場。`, 409);
    }
  }
  function normalizePlan(input, base = {}) {
    const merged = { ...base, ...input };
    const source = sourceOf(merged.sourceId) || fail('SOURCE_NOT_FOUND', '請先建立直播來源', 404);
    const title = String(merged.title || source.name).trim().slice(0, 120);
    if (!isValidTimeZone(merged.timeZone)) fail('INVALID_TIMEZONE', '時區不正確（例如 Asia/Taipei）');
    let startAt, endAt;
    try { startAt = zonedToUtc(merged.startLocal, merged.timeZone); endAt = zonedToUtc(merged.endLocal, merged.timeZone); } catch (error) { fail(error.code || 'LOCAL_TIME_INVALID', error.message); }
    if (endAt <= startAt) fail('INVALID_WINDOW', '結束時間必須晚於開始時間（跨午夜請把結束日期設為隔天）');
    if (endAt - startAt > MAX_PLAN_HOURS * 3_600_000) fail('INVALID_WINDOW', `單場最長 ${MAX_PLAN_HOURS} 小時`);
    if (!base.id && startAt <= now()) fail('INVALID_WINDOW', '開始時間已經過了');
    const segmentMinutes = Number(merged.segmentMinutes ?? SEGMENT_LIMITS.default);
    if (!Number.isInteger(segmentMinutes) || segmentMinutes < SEGMENT_LIMITS.min || segmentMinutes > SEGMENT_LIMITS.max) fail('INVALID_SEGMENT', `分段長度需為 ${SEGMENT_LIMITS.min}–${SEGMENT_LIMITS.max} 分鐘`);
    const prepareMinutes = Number(merged.prepareMinutes ?? PREPARE_LIMITS.default);
    if (!Number.isInteger(prepareMinutes) || prepareMinutes < PREPARE_LIMITS.min || prepareMinutes > PREPARE_LIMITS.max) fail('INVALID_PREPARE', `提前準備需為 ${PREPARE_LIMITS.min}–${PREPARE_LIMITS.max} 分鐘`);
    const captureMode = merged.captureMode ?? source.defaultCaptureMode; if (!['video', 'audio'].includes(captureMode)) fail('INVALID_PLAN', '錄製方式不正確');
    return { title, timeZone: merged.timeZone, startLocal: merged.startLocal, endLocal: merged.endLocal, startAt: iso(startAt), endAt: iso(endAt), prepareMinutes, captureMode, segmentMinutes, backupAfterClose: merged.backupAfterClose !== false, sourceId: source.id };
  }
  async function createPlan(input = {}) {
    await load();
    const plan = { schemaVersion: 1, id: createId('lpln'), createdAt: iso(now()), updatedAt: iso(now()), ...normalizePlan(input), status: input.enable === false ? 'disabled' : 'enabled', priority: 0, sessionId: null };
    if (plan.status === 'enabled') assertNoOverlap(plan);
    state.plans.push(plan); await save(); return plan;
  }
  async function updatePlan(id, patch = {}) {
    await load(); const plan = planOf(id) || fail('PLAN_NOT_FOUND', '找不到這個排程', 404);
    if (plan.sessionId || !['enabled', 'disabled', 'draft'].includes(plan.status)) fail('PLAN_LOCKED', '已開始或已結束的排程不能修改', 409);
    const next = { ...plan, ...normalizePlan(patch, plan) };
    if (next.status === 'enabled') assertNoOverlap(next);
    Object.assign(plan, next); touch(plan); await save(); return plan;
  }
  async function setPlanStatus(id, status) {
    await load(); const plan = planOf(id) || fail('PLAN_NOT_FOUND', '找不到這個排程', 404);
    if (!['enabled', 'disabled', 'cancelled'].includes(status)) fail('INVALID_ACTION', '不支援的操作');
    const session = plan.sessionId ? state.sessions.find((item) => item.id === plan.sessionId) : null;
    if (session && ['recording', 'stopping'].includes(session.status)) fail('SESSION_RECORDING', '正在錄影，請改用「立即安全停止」', 409);
    if (status === 'enabled') { if (Date.parse(plan.endAt) <= now()) fail('INVALID_WINDOW', '這個排程的時間已經過了'); assertNoOverlap({ ...plan, status: 'enabled' }); }
    if (status === 'cancelled' && session && ['scheduled', 'preparing'].includes(session.status)) { session.status = 'cancelled'; session.stopReason = 'CANCELLED_BY_USER'; touch(session); }
    plan.status = status; touch(plan); await save(); return plan;
  }

  // ---- preflight -----------------------------------------------------------------------------------
  async function preflight(session, plan, source) {
    const checks = []; const add = (id, ok, code = null, warning = false) => checks.push({ id, ok, ...(warning ? { warning: true } : {}), ...(code ? { code } : {}) });
    let obsOk = false;
    try { if (obs.state !== 'ready') await obs.connect(); obsOk = true; add('obs', true); } catch { add('obs', false, 'OBS_UNAVAILABLE'); }
    if (obsOk) {
      try {
        const version = await obs.getVersion(); session.obs.websocketVersion = String(version?.obsWebSocketVersion || '').slice(0, 20) || null;
        const canSplit = versionAtLeast(session.obs.websocketVersion, MIN_SPLIT_WEBSOCKET);
        add('websocket', true, canSplit ? null : 'SPLIT_UNSUPPORTED_VERSION', !canSplit);
        if (!canSplit) session.segmentation = 'segmentation-unavailable';
      } catch { add('websocket', false, 'OBS_PROTOCOL_ERROR'); }
      try { const status = await obs.getRecordStatus(); add('obs-idle', !status.active, status.active ? 'OBS_ALREADY_RECORDING' : null); } catch { add('obs-idle', false, 'OBS_UNAVAILABLE'); }
      if (plan.captureMode === 'video') {
        try {
          const scene = await obs.request('GetCurrentProgramScene'); const items = await obs.request('GetSceneItemList', { sceneName: scene.currentProgramSceneName || scene.sceneName });
          const enabled = (items.sceneItems || []).some((item) => item.sceneItemEnabled !== false);
          add('capture-source', enabled, enabled ? null : 'CAPTURE_SOURCE_MISSING');
        } catch { add('capture-source', false, 'CAPTURE_SOURCE_MISSING'); }
      } else add('capture-source', audioOnlyConfirmed() === true, audioOnlyConfirmed() === true ? null : 'AUDIO_PROFILE_UNCONFIRMED');
      try {
        const dir = await recordDirectory(); const inside = dir && allowedRoots.some((root) => { const rel = path.relative(path.resolve(root), path.resolve(dir)); return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel)); });
        add('record-folder', true, inside ? null : 'RECORD_FOLDER_NOT_BACKED_UP', !inside);
      } catch { add('record-folder', true, 'RECORD_FOLDER_UNKNOWN', true); }
    }
    const free = await Promise.resolve(freeBytes()).catch(() => null);
    const hours = (Date.parse(plan.endAt) - Math.max(now(), Date.parse(plan.startAt))) / 3_600_000;
    const needed = hours * BYTES_PER_HOUR[plan.captureMode];
    if (!Number.isFinite(free)) add('disk', true, 'DISK_UNKNOWN', true);
    else if (free < disk.stopBytes) add('disk', false, 'DISK_LOW');
    else add('disk', true, free - disk.stopBytes < needed ? 'DISK_MAY_RUN_OUT' : null, free - disk.stopBytes < needed);
    try {
      const record = await rights.read(source.rightsId);
      assertPrivateUse(record);
      if (source.purpose === 'creator-candidate') { try { assertPublicExportRecord(record); add('rights', true); } catch { add('rights', false, 'DERIVATIVE_RIGHTS_REQUIRED'); } }
      else add('rights', true);
    } catch { add('rights', false, 'RIGHTS_MISSING'); }
    const cloud = await cloudStatus().catch(() => ({ state: 'error' }));
    if (!plan.backupAfterClose) add('cloud', true, 'BACKUP_DISABLED', true);
    else add('cloud', true, cloud?.state === 'connected' ? null : 'CLOUD_UNAVAILABLE', cloud?.state !== 'connected'); // never blocks local recording
    const page = await pageBlocker(source).catch(() => null);
    add('page', !PAGE_STOPS.has(page), PAGE_STOPS.has(page) ? page : page === 'NOT_MONITORED' ? 'PAGE_NOT_MONITORED' : null, page === 'NOT_MONITORED');
    for (const item of checks) if (item.warning && item.code) warn(session, item.code);
    session.preflight = { checkedAt: iso(now()), ok: checks.every((item) => item.ok), checks };
    touch(session); return session.preflight;
  }

  // ---- recording -----------------------------------------------------------------------------------
  function newSegment(session, startMs, filePath) {
    const index = segmentsOf(session.id).length + 1;
    const seg = { schemaVersion: 1, id: createId('lseg'), createdAt: iso(now()), updatedAt: iso(now()), sessionId: session.id, index, state: 'recording', startAt: iso(startMs), endAt: null, file: filePath ? { name: path.basename(filePath), ref: filePath, bytes: null, source: 'obs-confirmed' } : null, upload: 'not-queued', verification: 'pending', processing: 'none' };
    state.segments.push(seg); session.checkpoint.segmentCount = index; rt(session.id).currentPath = filePath || null; return seg;
  }
  // ---- file identity (realpath; case-insensitive on Windows) ----------------------------------------------
  const lib = platform === 'win32' ? path.win32 : path.posix;
  const caseKey = (value) => (platform === 'win32' ? lib.resolve(value).toLowerCase() : lib.resolve(value));
  const realKey = async (value) => { try { return caseKey(await realpath(value)); } catch { return caseKey(value); } };
  async function knownKeys() {
    const refs = [...state.segments.map((seg) => seg.file?.ref), ...state.quarantine.map((item) => item.ref)].filter(Boolean);
    return new Set(await Promise.all(refs.map(realKey)));
  }
  /** Media files in OBS's record folder: [{ path, real, key, mtimeMs }] (realpath inside the real record folder only). */
  async function recordFolderFiles() {
    const dir = await recordDirectory().catch(() => null); if (!dir) return null;
    let realDir; try { realDir = await realpath(dir); } catch { return null; }
    const files = await listMediaFiles(dir).catch(() => null); if (!files) return null;
    const out = [];
    for (const item of files) {
      if (!MEDIA_EXT.test(String(item.path))) continue;
      let real; try { real = await realpath(item.path); } catch { continue; }
      if (!isInside(realDir, real, { platform }) || caseKey(realDir) === caseKey(real)) continue;
      out.push({ path: item.path, real, key: caseKey(real), mtimeMs: item.mtimeMs });
    }
    return out;
  }
  /** Taken right before StartRecord: only files that were NOT there may become this recording's first file. */
  async function snapshotRecordFolder(session) {
    const files = await recordFolderFiles();
    rt(session.id).snapshot = files ? new Set(files.map((item) => item.key)) : null;
  }
  /**
   * The first file's path, when OBS did not report it: exactly one new media file (absent from the snapshot,
   * inside the real record folder, written since the start, not known to any session). Several → ambiguous:
   * nothing is picked, uploaded or cleaned, and the user is asked. None yet → try again next tick.
   */
  async function adoptFirstPath(session) {
    const open = openSegment(session.id); const run = rt(session.id);
    if (!open || open.file || open.pathIssue === 'ambiguous' || open.index !== 1 || !run.snapshot) return;
    const files = await recordFolderFiles(); if (!files) return;
    const since = Date.parse(open.startAt) - 2_000; const known = await knownKeys();
    const fresh = files.filter((item) => !run.snapshot.has(item.key) && !known.has(item.key) && item.mtimeMs >= since);
    if (fresh.length === 1) { open.file = { name: lib.basename(fresh[0].real), ref: fresh[0].real, bytes: null, source: 'inferred' }; run.currentPath = fresh[0].real; if (!inDedicatedFolder(open)) warn(session, 'SEGMENT_OWNER_UNCONFIRMED'); touch(open); return; }
    if (fresh.length > 1) {
      open.pathIssue = 'ambiguous'; warn(session, 'SEGMENT_PATH_AMBIGUOUS'); touch(open);
      for (const item of fresh) state.quarantine.push({ sessionId: session.id, ref: item.real, at: iso(now()) });
      logger.warn?.({ event: 'live_segment_path_ambiguous', sessionId: session.id, candidates: fresh.length });
    }
  }
  /** Sets an OBS-reported path. A previously inferred file that turns out to be a different file is quarantined. */
  async function applyObsPath(seg, filePath) {
    if (!seg || !filePath) return;
    if (seg.file?.ref && seg.file.source === 'inferred' && await realKey(seg.file.ref) !== await realKey(filePath)) {
      state.quarantine.push({ sessionId: seg.sessionId, ref: seg.file.ref, at: iso(now()) });
      logger.warn?.({ event: 'live_inferred_file_replaced', sessionId: seg.sessionId });
    }
    // A candidate this session itself quarantined (ambiguous start) is released once OBS names it.
    const key = await realKey(filePath);
    const kept = []; for (const item of state.quarantine) if (!(item.sessionId === seg.sessionId && await realKey(item.ref) === key)) kept.push(item);
    state.quarantine = kept;
    seg.file = { name: lib.basename(filePath), ref: filePath, bytes: null, source: 'obs-confirmed' }; delete seg.pathIssue; touch(seg);
  }
  /** The user declared OBS's record folder as OBS-only, and this inferred file lies directly in it. */
  const inDedicatedFolder = (seg) => Boolean(state.settings.dedicatedFolderKey && seg?.file?.ref && caseKey(lib.dirname(seg.file.ref)) === state.settings.dedicatedFolderKey);
  /** May this closed segment go to the cloud? (cleanup is decided separately: only confirmed owners) */
  const uploadable = (seg) => seg.state === 'closed' && Boolean(seg.file) && seg.pathIssue !== 'duplicate' && (seg.file.source !== 'inferred' || inDedicatedFolder(seg));
  const needsOwner = (seg) => Boolean(seg.file) && seg.pathIssue !== 'duplicate' && seg.file.source === 'inferred' && !inDedicatedFolder(seg);
  /** Another segment (any session) or a quarantined candidate already owns this file. */
  async function ownedElsewhere(filePath, seg) {
    const target = await realKey(filePath);
    for (const other of state.segments) if (other !== seg && other.file?.ref && await realKey(other.file.ref) === target) return true;
    for (const item of state.quarantine) if (item.sessionId !== seg.sessionId && await realKey(item.ref) === target) return true;
    return false;
  }
  /**
   * Fallback when a segment has no trustworthy path: compare the record folder with the snapshot taken before
   * StartRecord. Exactly one new, unowned media file → `inferred` (normal ownership rules apply). None or several →
   * no guess: the segment is marked unknown / ambiguous and every candidate is quarantined (never uploaded or cleaned).
   */
  async function resolveFromFolder(session, seg) {
    const run = rt(session.id);
    const files = run.snapshot ? await recordFolderFiles() : null;
    if (!files) { seg.pathIssue ??= 'unknown'; return false; }
    const since = Date.parse(seg.startAt) - 2_000; const known = await knownKeys();
    const fresh = files.filter((item) => !run.snapshot.has(item.key) && !known.has(item.key) && item.mtimeMs >= since);
    if (fresh.length === 1) {
      seg.file = { name: lib.basename(fresh[0].real), ref: fresh[0].real, bytes: null, source: 'inferred' }; delete seg.pathIssue;
      if (!inDedicatedFolder(seg)) warn(session, 'SEGMENT_OWNER_UNCONFIRMED');
      return true;
    }
    seg.pathIssue = fresh.length ? 'ambiguous' : 'unknown';
    for (const item of fresh) state.quarantine.push({ sessionId: session.id, ref: item.real, at: iso(now()) });
    return false;
  }
  /**
   * P9 path rules at the end of a recording leg (StopRecord, OBS stopped externally, "finish + stop OBS"):
   *  - a segment that already has an OBS-confirmed path (STARTED / RecordFileChanged) keeps it; a different stop path
   *    is ignored (OBS 33 reports the FIRST file of a split recording on stop);
   *  - after a split (segment index > 1) the stop path is a candidate only and never assigned directly;
   *  - a single, never-split recording may take the stop path, unless OBS gave two different stop paths or the
   *    file already belongs to another segment.
   */
  async function applyStopPaths(session, seg, stopPaths) {
    const paths = [...new Set((stopPaths || []).filter((value) => typeof value === 'string' && value))];
    if (!paths.length) return;
    const split = seg.index > 1;
    if (seg.file && seg.file.source !== 'inferred') {
      const own = await realKey(seg.file.ref);
      for (const value of paths) if (await realKey(value) !== own) { warn(session, 'STOP_PATH_IGNORED'); logger.warn?.({ event: 'live_stop_path_ignored', sessionId: session.id, segment: seg.index }); break; }
      return;
    }
    if (split) { warn(session, 'STOP_PATH_IGNORED'); return; }
    const distinct = new Set(await Promise.all(paths.map(realKey)));
    if (distinct.size !== 1) { warn(session, 'STOP_PATH_MISMATCH'); return; }
    if (await ownedElsewhere(paths[0], seg)) { warn(session, 'STOP_PATH_IGNORED'); return; }
    await applyObsPath(seg, paths[0]);
  }
  async function closeSegment(session, endMs, { stopPaths = [] } = {}) {
    const seg = openSegment(session.id); if (!seg) return null;
    await applyStopPaths(session, seg, stopPaths);
    seg.state = 'closed'; seg.endAt = iso(endMs);
    if (!seg.file && seg.pathIssue !== 'ambiguous') await resolveFromFolder(session, seg);
    if (!seg.file) { seg.pathIssue ??= 'unknown'; warn(session, seg.pathIssue === 'ambiguous' ? 'SEGMENT_PATH_AMBIGUOUS' : 'SEGMENT_PATH_UNKNOWN'); }
    seg.upload = !seg.file || needsOwner(seg) ? 'not-queued' : planOf(session.planId)?.backupAfterClose === false ? 'disabled' : 'waiting'; touch(seg);
    return seg;
  }
  const stopPathsOf = (result) => [result?.eventPath ?? (result && !('eventPath' in result) ? result.outputPath : null), result?.responsePath ?? null];
  async function startRecording(session, plan) {
    const status = await obs.getRecordStatus().catch(() => null);
    if (status?.active) { block(session, 'OBS_ALREADY_RECORDING'); return; } // never take over someone else's recording
    session.status = 'preparing'; touch(session);
    await snapshotRecordFolder(session);
    let started;
    try { started = await obs.startRecord(); }
    catch (error) {
      const code = error?.code === 'OBS_START_UNCONFIRMED' ? 'OBS_START_UNCONFIRMED' : error?.code === 'OBS_ALREADY_RECORDING' ? 'OBS_ALREADY_RECORDING' : 'OBS_UNAVAILABLE';
      block(session, code, { obsMayStillBeRecording: code === 'OBS_START_UNCONFIRMED' }); return;
    }
    session.status = 'recording'; session.actualStartAt ??= iso(started.startedAtMs ?? now());
    session.obs = { ...session.obs, state: 'recording', startedByUs: true, mayStillBeRecording: true };
    session.blocker = null; if (session.segmentation === 'unknown') session.segmentation = 'split-record';
    const run = rt(session.id); run.legStartedAt = started.startedAtMs ?? now();
    newSegment(session, run.legStartedAt, run.startedPath || null); run.startedPath = null;
    await adoptFirstPath(session);
    touch(session); if (plan.backupAfterClose) backup?.poke?.();
  }
  async function stopRecording(session, reason, { thenBlock = null } = {}) {
    session.status = 'stopping'; touch(session); await save();
    let result;
    try { result = await obs.stopRecord(); }
    catch (error) { block(session, error?.code === 'OBS_STOP_UNCONFIRMED' ? 'OBS_STOP_UNCONFIRMED' : 'OBS_DISCONNECTED', { obsMayStillBeRecording: true }); return; }
    await closeSegment(session, now(), { stopPaths: stopPathsOf(result) });
    session.obs = { ...session.obs, state: 'stopped', startedByUs: false, mayStillBeRecording: false };
    session.actualStopAt = iso(now()); session.stopReason = reason;
    if (thenBlock) { session.status = 'blocked'; session.blocker = { code: thenBlock, at: iso(now()), obsMayStillBeRecording: false }; }
    else session.status = 'processing';
    touch(session); backup?.poke?.();
  }
  async function maybeSplit(session, plan) {
    const run = rt(session.id); const open = openSegment(session.id); if (!open) return;
    if (run.splitAt) { // waiting for RecordFileChanged
      if (now() - run.splitAt > intervals.splitConfirmMs) { run.splitAt = null; session.segmentation = 'segmentation-unavailable'; warn(session, 'SEGMENTATION_UNAVAILABLE'); touch(session); }
      return;
    }
    if (session.segmentation !== 'split-record' || now() - Date.parse(open.startAt) < plan.segmentMinutes * 60_000) return;
    run.splitAt = now();
    try { await obs.splitRecordFile(); }
    catch (error) {
      run.splitAt = null;
      if (error?.code === 'OBS_SPLIT_UNAVAILABLE') { session.segmentation = 'segmentation-unavailable'; warn(session, 'SEGMENTATION_UNAVAILABLE'); touch(session); }
    }
  }

  // OBS events (one subscription for the service's lifetime). Handlers are serialized with tick() so a
  // RecordFileChanged arriving mid-tick never interleaves with a state write; idle() lets tests wait.
  let chain = Promise.resolve();
  const serial = (fn) => { const next = chain.then(fn, fn); chain = next.catch((error) => logger.warn?.({ event: 'live_event_failed', code: error?.code || 'ERROR' })); return next; };
  const subscribe = (name, fn) => obs.on?.(name, (event) => { serial(async () => { await load(); await fn(event); }); });
  const live = () => state?.sessions.find((item) => item.status === 'recording' || item.status === 'stopping');
  subscribe('recordFileChanged', async (event) => {
    const session = live(); if (!session || session.status !== 'recording' || !event?.outputPath) return;
    const run = rt(session.id); run.splitAt = null;
    const previous = openSegment(session.id);
    void previous; // its path is the one we already know (or none): never guessed from the folder
    await closeSegment(session, event.atMs ?? now());
    newSegment(session, event.atMs ?? now(), event.outputPath);
    if (session.segmentation === 'unknown') session.segmentation = 'split-record';
    touch(session); await save(); backup?.poke?.();
  });
  subscribe('recordState', async (event) => {
    const session = live();
    if (event?.state === 'OBS_WEBSOCKET_OUTPUT_STARTED' && event.outputPath) { const s = state?.sessions.find((item) => item.status === 'preparing'); if (s) rt(s.id).startedPath = event.outputPath; else if (session) { const open = openSegment(session.id); if (open?.index === 1 && (!open.file || open.file.source === 'inferred')) await applyObsPath(open, event.outputPath); } }
    if (!session || session.status !== 'recording' || event?.state !== 'OBS_WEBSOCKET_OUTPUT_STOPPED') return;
    // Stopped in OBS by someone else: the file is finalized → keep it, stop safely, ask the user.
    await closeSegment(session, event.atMs ?? now(), { stopPaths: [event.outputPath] });
    session.obs = { ...session.obs, state: 'stopped', startedByUs: false, mayStillBeRecording: false };
    session.actualStopAt ??= iso(event.atMs ?? now());
    session.status = 'blocked'; session.blocker = { code: 'OBS_STOPPED_EXTERNALLY', at: iso(now()), obsMayStillBeRecording: false };
    touch(session); await save(); backup?.poke?.();
  });
  const onLost = async () => { const session = live(); if (!session) return; block(session, 'OBS_DISCONNECTED', { obsMayStillBeRecording: true }); session.obs.state = 'disconnected'; await save(); };
  subscribe('disconnected', onLost); subscribe('obsExiting', onLost);

  // ---- tick ----------------------------------------------------------------------------------------
  async function syncBackupStates(session) {
    const plan = planOf(session.planId);
    const items = backup?.items ? await backup.items(courseIdForLive(session.id)).catch(() => null) : null;
    for (const seg of segmentsOf(session.id)) {
      if (seg.state !== 'closed' || !seg.file) continue;
      if (!uploadable(seg)) { if (seg.upload !== 'not-queued') { seg.upload = 'not-queued'; seg.verification = 'pending'; touch(seg); } continue; }
      if (!plan?.backupAfterClose) { seg.upload = 'disabled'; continue; }
      const item = items?.find((entry) => entry.key === segmentKey(seg));
      const next = !item ? 'waiting' : item.status === 'verified' ? 'uploaded' : item.status === 'uploading' || item.status === 'verifying' ? 'uploading' : item.status === 'queued' ? 'queued' : item.status === 'waiting' ? 'waiting' : 'failed';
      const verification = item?.status === 'verified' ? 'verified' : ['failed', 'blocked'].includes(item?.status) ? 'failed' : 'pending';
      if (seg.upload !== next || seg.verification !== verification) { seg.upload = next; seg.verification = verification; touch(seg); }
    }
  }
  /**
   * Backup state of an ended session (derived, not stored):
   *   disabled | not-configured | waiting | uploading | verified | failed — plus `unresolved` closed segments
   *   whose file could not be identified (never uploaded).
   */
  function backupState(session) {
    const plan = planOf(session.planId); const segs = segmentsOf(session.id);
    const closed = segs.filter((seg) => seg.state === 'closed'); const withFile = closed.filter(uploadable);
    const counts = { total: withFile.length, verified: withFile.filter((seg) => seg.verification === 'verified').length, failed: withFile.filter((seg) => seg.upload === 'failed').length, unresolved: closed.filter((seg) => !seg.file).length, unconfirmed: closed.filter(needsOwner).length, duplicate: segs.filter((seg) => seg.pathIssue === 'duplicate').length, interrupted: segs.filter((seg) => seg.state === 'interrupted').length };
    if (counts.duplicate) return { state: 'needs-repair', ...counts };
    if (!plan?.backupAfterClose) return { state: 'disabled', ...counts };
    if (counts.failed) return { state: 'failed', ...counts };
    if (counts.verified === counts.total) return { state: 'verified', ...counts };
    return { state: withFile.some((seg) => seg.upload === 'uploading') ? 'uploading' : 'waiting', ...counts };
  }
  const postBlock = (session, code) => {
    if (session.status === 'blocked' && session.blocker?.code === code) return;
    session.status = 'blocked'; session.blocker = { code, at: iso(now()), obsMayStillBeRecording: false }; touch(session);
  };
  /**
   * After recording ended. Completed only when every closed segment is verified in the cloud (or backup is
   * switched off for this plan). Offline / retrying stays processing; a final failure or a missing cloud
   * destination is a blocker the user must see — local files are always kept.
   */
  /**
   * P9 hard guard: no two segments (of any session) may point at the same file. Every segment of `session` that
   * shares its realpath with another segment is marked `duplicate` (not uploaded, not verified, not cleanable) and
   * the session is blocked with SEGMENT_PATH_DUPLICATE until the user repairs it. Nothing is deleted or rewritten.
   */
  /**
   * Files the user may pick to repair one segment: media files in OBS's record folder (or the folder this session's
   * segments live in) written during that segment's time window, not owned by any other segment and not
   * quarantined for another session. Ids are opaque (hash of the realpath); paths never leave the server.
   */
  function fileFingerprint(file) {
    return new Promise((resolve, reject) => {
      const hash = crypto.createHash('md5'); let bytes = 0;
      fs.createReadStream(file).on('data', (chunk) => { bytes += chunk.length; hash.update(chunk); }).on('error', reject).on('end', () => resolve({ bytes, md5: hash.digest('hex') }));
    });
  }
  async function repairCandidates(session, seg) {
    const dirs = new Set();
    const obsDir = await recordDirectory().catch(() => null); if (obsDir) dirs.add(obsDir);
    for (const other of segmentsOf(session.id)) if (other.file?.ref) dirs.add(lib.dirname(other.file.ref));
    const from = Date.parse(seg.startAt) - 5_000; const to = Date.parse(seg.endAt || session.actualStopAt || iso(now())) + 120_000;
    const seen = new Set(); const out = [];
    for (const dir of dirs) {
      for (const item of await listMediaFiles(dir).catch(() => []) || []) {
        if (!MEDIA_EXT.test(String(item.path)) || !(item.mtimeMs >= from && item.mtimeMs <= to)) continue;
        let real; try { real = await realpath(item.path); } catch { continue; }
        const key = caseKey(real); if (seen.has(key)) continue; seen.add(key);
        if (state.segments.some((other) => other !== seg && other.file?.ref && caseKey(other.file.ref) === key)) continue;
        if (state.quarantine.some((q) => q.sessionId !== session.id && caseKey(q.ref) === key)) continue;
        const stat = await fsp.stat(real).catch(() => null); if (!stat?.isFile()) continue;
        out.push({ id: crypto.createHash('sha1').update(key).digest('hex').slice(0, 12), key, real, name: lib.basename(real), bytes: stat.size, mtimeMs: item.mtimeMs });
      }
    }
    return out.sort((a, b) => a.mtimeMs - b.mtimeMs);
  }
  async function repairOptions(session) {
    if (!(session.status === 'blocked' && ['SEGMENT_PATH_DUPLICATE', 'SEGMENT_PATH_AMBIGUOUS', 'SEGMENT_PATH_UNKNOWN'].includes(session.blocker?.code))) return {};
    const out = {};
    // Each candidate says exactly what confirming it does: the new backup name, and which earlier remote copy is
    // kept (marked superseded, never deleted).
    for (const seg of segmentsOf(session.id)) if (seg.state === 'closed' && ['duplicate', 'ambiguous', 'unknown'].includes(seg.pathIssue)) {
      const replaces = seg.file?.ref ? segmentKey(seg).slice('media/'.length) : null;
      out[seg.id] = (await repairCandidates(session, seg)).map(({ id, name, bytes, mtimeMs }) => ({ id, fileName: name, bytes, modifiedAt: iso(mtimeMs), newKey: segmentKey({ ...seg, revision: (seg.revision || 0) + 1, file: { ref: name } }).slice('media/'.length), replacesKey: replaces }));
    }
    return out;
  }
  async function duplicateSegmentIds(session) {
    const groups = new Map();
    for (const seg of state.segments) if (seg.file?.ref && seg.state !== 'recording') { const key = await realKey(seg.file.ref); groups.set(key, [...(groups.get(key) || []), seg]); }
    const ids = new Set();
    for (const list of groups.values()) if (list.length > 1) for (const seg of list) if (seg.sessionId === session.id) ids.add(seg.id);
    return ids;
  }
  async function markDuplicates(session) {
    const ids = await duplicateSegmentIds(session);
    for (const seg of segmentsOf(session.id)) {
      if (ids.has(seg.id)) { if (seg.pathIssue !== 'duplicate') { seg.pathIssue = 'duplicate'; seg.upload = 'not-queued'; seg.verification = 'pending'; touch(seg); } }
      else if (seg.pathIssue === 'duplicate') { delete seg.pathIssue; seg.upload = seg.file ? 'waiting' : 'not-queued'; touch(seg); }
    }
    if (ids.size) { warn(session, 'SEGMENT_PATH_DUPLICATE'); postBlock(session, 'SEGMENT_PATH_DUPLICATE'); if (session.status === 'blocked') logger.warn?.({ event: 'live_segment_path_duplicate', sessionId: session.id, segments: ids.size }); }
    return ids.size;
  }
  async function settleAfterRecording(session, plan) {
    if (await markDuplicates(session)) return; // never completed while two segments share a file
    const summary = backupState(session);
    const done = () => { session.status = 'completed'; session.blocker = null; plan.status = 'done'; touch(session); touch(plan); };
    if (summary.state === 'disabled') { warn(session, 'BACKUP_DISABLED'); if (summary.unresolved) warn(session, 'SEGMENT_PATH_UNKNOWN'); done(); return; }
    const cloud = await cloudStatus().catch(() => ({ state: 'error' }));
    if (summary.total && ['not-set', 'auto-upload-off'].includes(cloud?.state)) { postBlock(session, 'BACKUP_NOT_CONFIGURED'); return; }
    if (summary.state === 'failed') { postBlock(session, 'BACKUP_FAILED'); return; }
    if (summary.state !== 'verified') {
      if (['offline', 'error', 'auth-required'].includes(cloud?.state)) warn(session, 'CLOUD_OFFLINE');
      if (session.status !== 'processing') { session.status = 'processing'; session.blocker = null; touch(session); }
      return;
    }
    if (summary.unconfirmed) { postBlock(session, 'SEGMENT_OWNER_UNCONFIRMED'); return; }
    if (summary.unresolved) { postBlock(session, segmentsOf(session.id).some((seg) => seg.pathIssue === 'ambiguous') ? 'SEGMENT_PATH_AMBIGUOUS' : 'SEGMENT_PATH_UNKNOWN'); return; }
    if (summary.interrupted) warn(session, 'SEGMENTS_INTERRUPTED_LOCAL');
    done();
  }
  async function tickSession(session, plan, source) {
    const run = rt(session.id); const t = now(); const w = windowOf(plan);
    if (session.status === 'preparing') {
      if (t - run.lastPreflight >= intervals.preflightMs || t >= w.startAt && !session.preflight?.ok) { run.lastPreflight = t; await preflight(session, plan, source); }
      if (t < w.startAt) return;
      if (!session.preflight?.ok) { block(session, session.preflight.checks.find((item) => !item.ok)?.code || 'PREFLIGHT_FAILED'); return; }
      await startRecording(session, plan); return;
    }
    if (session.status === 'recording') {
      const open = segmentsOf(session.id); session.checkpoint.recordedSeconds = Math.max(0, (t - Date.parse(session.actualStartAt)) / 1000); session.checkpoint.lastEventAt = iso(t);
      if (t >= w.endAt) { await stopRecording(session, 'SCHEDULE_END'); return; }
      if (t - run.lastPage >= intervals.pageMs) {
        run.lastPage = t; const code = await pageBlocker(source).catch(() => null);
        if (PAGE_STOPS.has(code)) { await stopRecording(session, code, { thenBlock: code }); return; }
      }
      if (t - run.lastDisk >= intervals.diskMs) {
        run.lastDisk = t; let free = await Promise.resolve(freeBytes()).catch(() => null);
        if (Number.isFinite(free) && free < disk.warnBytes) {
          warn(session, 'DISK_LOW_WARNING');
          if (backup?.cleanupSafe && (t - run.lastCleanup >= intervals.cleanupMs || free < disk.stopBytes)) { run.lastCleanup = t; await backup.cleanupSafe().catch(() => null); free = await Promise.resolve(freeBytes()).catch(() => free); }
          if (free < disk.stopBytes) { await stopRecording(session, 'DISK_LOW', { thenBlock: 'DISK_LOW' }); return; }
        }
      }
      await adoptFirstPath(session);
      await syncBackupStates(session);
      await maybeSplit(session, plan); void open; touch(session); return;
    }
    if (session.status === 'processing' || (session.status === 'blocked' && POST.has(session.blocker?.code) && !PATH_BLOCKERS.has(session.blocker.code))) {
      await syncBackupStates(session); await settleAfterRecording(session, plan); return;
    }
    if (['blocked', 'completed'].includes(session.status)) await syncBackupStates(session);
  }
  async function tick() {
    if (ticking) return ticking;
    ticking = serial(async () => {
      await load(); const t = now();
      for (const plan of state.plans) {
        const source = sourceOf(plan.sourceId); if (!source) continue;
        let session = plan.sessionId ? state.sessions.find((item) => item.id === plan.sessionId) : null;
        const w = windowOf(plan);
        if (!session && plan.status === 'enabled') {
          if (t < w.prepareAt) continue;
          session = { schemaVersion: 1, id: createId('lses'), createdAt: iso(t), updatedAt: iso(t), planId: plan.id, sourceId: source.id, status: 'preparing', segmentation: 'unknown', obs: { state: 'unknown', startedByUs: false, mayStillBeRecording: false, websocketVersion: null }, checkpoint: { segmentCount: 0, recordedSeconds: 0, lastEventAt: null }, preflight: null, blocker: null, stopReason: null, warnings: [], actualStartAt: null, actualStopAt: null };
          if (t >= w.endAt) { session.status = 'failed'; session.stopReason = 'SCHEDULE_MISSED'; plan.status = 'done'; }
          else if (state.sessions.some((item) => ACTIVE.has(item.status) && item.planId !== plan.id)) block(session, 'ANOTHER_SESSION_ACTIVE');
          state.sessions.push(session); plan.sessionId = session.id; touch(plan);
        }
        if (session) await tickSession(session, plan, source);
      }
      await save();
    }).finally(() => { ticking = null; });
    return ticking;
  }

  /** After a restart: nothing resumes by itself; an interrupted recording is reported as possibly still running. */
  const recover = () => serial(recoverNow);
  async function recoverNow() {
    await load(); const ids = [];
    for (const session of state.sessions) {
      if (session.status === 'preparing') { block(session, 'SERVER_RESTARTED'); ids.push(session.id); }
      else if (session.status === 'recording' || session.status === 'stopping') { block(session, 'SERVER_RESTARTED', { obsMayStillBeRecording: true }); session.obs.state = 'unknown'; ids.push(session.id); }
    }
    await reconcile();
    await save(); return ids;
  }
  /**
   * Startup reconciliation of already-ended sessions (including `completed` ones written by older code): two
   * segments sharing one file → blocked SEGMENT_PATH_DUPLICATE, affected segments no longer verified. The old
   * manifest stops counting through the backup entry (see backup service). Nothing is deleted, rewritten or
   * re-uploaded here.
   */
  async function reconcile() {
    const found = [];
    for (const session of state.sessions) {
      if (!['processing', 'completed', 'blocked', 'failed'].includes(session.status) || session.obs?.mayStillBeRecording) continue;
      if (await markDuplicates(session)) { found.push(session.id); if (session.status === 'blocked') { const plan = planOf(session.planId); if (plan) touch(plan); } }
    }
    if (found.length) logger.warn?.({ event: 'live_reconcile_duplicates', sessions: found.length });
    return found;
  }

  // ---- user actions --------------------------------------------------------------------------------
  const act = (sessionId, action, body = {}) => serial(() => actNow(sessionId, action, body));
  async function actNow(sessionId, action, body = {}) {
    await load(); const session = sessionOf(sessionId); const plan = planOf(session.planId); const source = sourceOf(session.sourceId);
    if (POST.has(session.blocker?.code) && ['resume', 'finish', 'cancel'].includes(action)) fail('INVALID_ACTION', '錄影已結束；請依畫面指示處理備份或分段', 409);
    if (action === 'stop') {
      if (session.status !== 'recording') fail('NOT_RECORDING', '目前沒有在錄影', 409);
      await stopRecording(session, 'USER_STOPPED'); plan.status = 'done'; await save(); return view(session);
    }
    if (action === 'cancel') {
      if (!['preparing', 'scheduled'].includes(session.status) && !(session.status === 'blocked' && !session.blocker?.obsMayStillBeRecording && !segmentsOf(session.id).length)) fail('INVALID_ACTION', '這個狀態不能取消；錄影中請用「立即安全停止」', 409);
      session.status = 'cancelled'; session.stopReason = 'CANCELLED_BY_USER'; plan.status = 'cancelled'; touch(session); touch(plan); await save(); return view(session);
    }
    if (action === 'retry-backup') {
      if (!(session.status === 'blocked' && ['BACKUP_FAILED', 'BACKUP_NOT_CONFIGURED'].includes(session.blocker?.code))) fail('INVALID_ACTION', '目前沒有需要重試的備份', 409);
      try { await backup?.retry?.(courseIdForLive(session.id)); } catch { /* the next pass retries; state below is re-derived */ } session.status = 'processing'; session.blocker = null; touch(session);
      await save(); return view(session);
    }
    if (action === 'confirm-segment') {
      // Only a segment of THIS session whose file was inferred; the path comes from our own record, never the browser.
      const seg = segmentsOf(session.id).find((item) => item.id === body.segmentId);
      if (!seg || seg.file?.source !== 'inferred') fail('INVALID_ACTION', '這個分段不需要確認', 409);
      let real; try { real = await realpath(seg.file.ref); } catch { fail('SEGMENT_FILE_MISSING', '找不到這個分段的檔案，無法確認', 409); }
      if (caseKey(real) !== caseKey(seg.file.ref)) fail('SEGMENT_FILE_CHANGED', '檔案位置已變動，無法確認', 409);
      const key = caseKey(real);
      const elsewhere = state.segments.some((other) => other !== seg && other.file?.ref && caseKey(other.file.ref) === key) || state.quarantine.some((item) => caseKey(item.ref) === key);
      if (elsewhere) fail('SEGMENT_FILE_CLAIMED', '這個檔案已屬於其他紀錄，無法確認', 409);
      seg.file = { ...seg.file, source: 'user-confirmed' }; touch(seg);
      if (seg.state === 'closed' && seg.upload === 'not-queued' && plan.backupAfterClose) seg.upload = 'waiting';
      if (session.status === 'blocked' && session.blocker?.code === 'SEGMENT_OWNER_UNCONFIRMED' && !segmentsOf(session.id).some(needsOwner)) { session.status = 'processing'; session.blocker = null; touch(session); }
      await save(); backup?.poke?.(); return view(session);
    }
    if (action === 'repair-segment') {
      // One segment of THIS session that is a duplicate / unresolved; the file is one of the candidates the
      // service itself listed (identified by an opaque id, never a browser-supplied path).
      if (!(session.status === 'blocked' && ['SEGMENT_PATH_DUPLICATE', 'SEGMENT_PATH_AMBIGUOUS', 'SEGMENT_PATH_UNKNOWN'].includes(session.blocker?.code))) fail('INVALID_ACTION', '目前沒有需要修復的分段', 409);
      const seg = segmentsOf(session.id).find((item) => item.id === body.segmentId);
      if (!seg || !['duplicate', 'ambiguous', 'unknown'].includes(seg.pathIssue) || seg.state !== 'closed') fail('INVALID_ACTION', '這個分段不需要修復', 409);
      const candidate = (await repairCandidates(session, seg)).find((item) => item.id === body.candidateId);
      if (!candidate) fail('REPAIR_CANDIDATE_INVALID', '找不到這個候選檔案，或它已屬於其他分段', 409);
      const previous = seg.file?.ref || null;
      // The confirmed file's size and MD5 are recorded now; the backup must upload exactly these bytes.
      const confirmed = await fileFingerprint(candidate.real).catch(() => null);
      if (!confirmed) fail('REPAIR_CANDIDATE_INVALID', '候選檔案無法讀取', 409);
      const previousKey = seg.file?.ref ? segmentKey(seg).slice('media/'.length) : null;
      seg.revision = (seg.revision || 0) + 1; // new backup key: the earlier remote copy is kept as evidence, never overwritten
      seg.file = { name: lib.basename(candidate.real), ref: candidate.real, bytes: confirmed.bytes, md5: confirmed.md5, source: 'user-confirmed' };
      delete seg.pathIssue; seg.upload = plan.backupAfterClose ? 'waiting' : 'disabled'; seg.verification = 'pending';
      seg.repairs = [...(seg.repairs || []), { at: iso(now()), from: previous ? lib.basename(previous) : null, to: seg.file.name, bytes: confirmed.bytes, md5: confirmed.md5, newKey: segmentKey(seg).slice('media/'.length), ...(previousKey ? { supersedes: previousKey } : {}) }].slice(-5);
      state.quarantine = state.quarantine.filter((item) => caseKey(item.ref) !== candidate.key);
      touch(seg);
      if (!(await markDuplicates(session)) && !segmentsOf(session.id).some((item) => item.state === 'closed' && (!item.file || ['ambiguous', 'unknown'].includes(item.pathIssue)))) {
        session.status = 'processing'; session.blocker = null; warn(session, 'SEGMENT_REPAIRED'); touch(session);
      }
      await save(); backup?.poke?.(); return view(session);
    }
    if (action === 'acknowledge') {
      if (!(session.status === 'blocked' && ['SEGMENT_PATH_AMBIGUOUS', 'SEGMENT_PATH_UNKNOWN', 'SEGMENT_OWNER_UNCONFIRMED'].includes(session.blocker?.code))) fail('INVALID_ACTION', '目前沒有需要確認的分段', 409);
      // The user has checked the record folder themselves. Files stay where they are and are never uploaded.
      warn(session, session.blocker.code); session.status = 'completed'; session.blocker = null; plan.status = 'done'; touch(session); touch(plan);
      await save(); return view(session);
    }
    if (POST.has(session.blocker?.code) && ['resume', 'finish', 'cancel'].includes(action)) fail('INVALID_ACTION', '錄影已結束；請依畫面指示處理備份或分段', 409);
    if (action === 'resume') {
      if (session.status !== 'blocked') fail('INVALID_ACTION', '只有暫停中的直播可以恢復', 409);
      if (now() >= Date.parse(plan.endAt)) fail('WINDOW_ENDED', '排程時間已結束，請改用「結束這場」', 409);
      try { if (obs.state !== 'ready') await obs.connect(); } catch { fail('OBS_UNAVAILABLE', 'OBS 仍無法連線，請先開啟 OBS', 409); }
      const status = await obs.getRecordStatus().catch(() => null);
      if (status?.active) fail('OBS_STILL_RECORDING', 'OBS 仍在錄影。請先在 OBS 停止，或改用「結束這場」並確認停止 OBS。', 409);
      session.status = 'preparing'; session.blocker = null; session.obs.mayStillBeRecording = false; touch(session);
      await preflight(session, plan, source);
      if (!session.preflight.ok) { block(session, session.preflight.checks.find((item) => !item.ok)?.code || 'PREFLIGHT_FAILED'); await save(); return view(session); }
      if (now() >= Date.parse(plan.startAt)) await startRecording(session, plan);
      await save(); return view(session);
    }
    if (action === 'finish') {
      if (session.status !== 'blocked') fail('INVALID_ACTION', '只有暫停中的直播可以結束', 409);
      if (body.stopObs === true) {
        // Explicit user confirmation that the running OBS recording belongs to this session.
        try { if (obs.state !== 'ready') await obs.connect(); const status = await obs.getRecordStatus(); if (status.active) { const result = await obs.stopRecord(); const seg = segmentsOf(session.id).filter((item) => item.state === 'interrupted').at(-1); if (seg && result?.wasActive) { await applyStopPaths(session, seg, stopPathsOf(result)); if (seg.file) { seg.state = 'closed'; seg.upload = needsOwner(seg) ? 'not-queued' : plan.backupAfterClose ? 'waiting' : 'disabled'; touch(seg); } } } }
        catch { fail('OBS_UNAVAILABLE', '無法連線 OBS 停止錄影，請直接在 OBS 按「停止錄影」', 409); }
      }
      session.status = 'processing'; session.stopReason = session.blocker?.code ? `ENDED_AFTER_${session.blocker.code}`.slice(0, 60) : 'ENDED_BY_USER';
      session.obs.mayStillBeRecording = false; session.blocker = null; session.actualStopAt ??= iso(now()); plan.status = 'done';
      touch(session); touch(plan); await save(); backup?.poke?.(); return view(session);
    }
    if (action === 'marker') {
      if (!['recording', 'processing', 'completed', 'blocked'].includes(session.status) || !session.actualStartAt) fail('INVALID_ACTION', '開始錄影後才能加標記', 409);
      const rec = Math.max(0, (now() - Date.parse(session.actualStartAt)) / 1000);
      const note = String(body.note || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 200);
      state.signals.push({ schemaVersion: 1, id: createId('sig'), createdAt: iso(now()), updatedAt: iso(now()), sessionId: session.id, source: 'manual', type: 'marker', recStart: rec, recEnd: rec, score: 0.5, confidence: 1, metadata: note ? { note } : {} });
      await save(); return view(session);
    }
    fail('INVALID_ACTION', '不支援的操作');
  }

  // ---- views (no paths, no rights internals) ---------------------------------------------------------
  const segmentKey = (seg) => `media/segment-${String(seg.index).padStart(3, '0')}${seg.revision ? `-r${seg.revision}` : ''}${path.extname(seg.file?.ref || '.mkv').toLowerCase() || '.mkv'}`;
  function segmentView(seg) { return { id: seg.id, index: seg.index, state: seg.state, startAt: seg.startAt, endAt: seg.endAt, fileName: seg.file?.name || null, owner: seg.file?.source || null, needsOwnerConfirmation: needsOwner(seg), pathIssue: seg.pathIssue || null, revision: seg.revision || 0, backupKey: seg.file ? segmentKey(seg).slice('media/'.length) : null, confirmed: seg.file?.md5 ? { bytes: seg.file.bytes, md5: seg.file.md5 } : null, lastRepair: seg.repairs?.length ? { at: seg.repairs.at(-1).at, newKey: seg.repairs.at(-1).newKey || null, supersedes: seg.repairs.at(-1).supersedes || null } : null, upload: seg.upload, verification: seg.verification, processing: seg.processing }; }
  function view(session, repair = {}) {
    const plan = planOf(session.planId); const source = sourceOf(session.sourceId); const segs = segmentsOf(session.id);
    return {
      id: session.id, planId: session.planId, status: session.status, segmentation: session.segmentation, title: plan?.title || source?.name || '', sourceName: source?.name || '', platform: source?.platform || 'generic',
      obs: { state: session.obs.state, startedByUs: session.obs.startedByUs, mayStillBeRecording: session.obs.mayStillBeRecording, websocketVersion: session.obs.websocketVersion },
      actualStartAt: session.actualStartAt, actualStopAt: session.actualStopAt, recordedSeconds: Math.round(session.checkpoint.recordedSeconds),
      segments: segs.map((seg) => ({ ...segmentView(seg), repairCandidates: repair[seg.id] || [] })), counts: { segments: segs.length, closed: segs.filter((s) => s.state === 'closed').length, backedUp: segs.filter((s) => s.verification === 'verified').length, interrupted: segs.filter((s) => s.state === 'interrupted').length },
      preflight: session.preflight, blocker: session.blocker, stopReason: session.stopReason, warnings: session.warnings,
      signals: state.signals.filter((sig) => sig.sessionId === session.id).map((sig) => ({ id: sig.id, source: sig.source, type: sig.type, recStart: sig.recStart, note: sig.metadata?.note || null })),
      candidates: state.candidates.filter((item) => item.sessionId === session.id),
      backup: session.actualStartAt ? backupState(session) : null,
      actions: (() => { const post = POST.has(session.blocker?.code); return {
        stop: session.status === 'recording', cancel: !post && (session.status === 'preparing' || (session.status === 'blocked' && !session.blocker?.obsMayStillBeRecording && !segs.length)),
        resume: !post && session.status === 'blocked' && Date.parse(plan?.endAt) > now(), finish: !post && session.status === 'blocked',
        retryBackup: session.status === 'blocked' && ['BACKUP_FAILED', 'BACKUP_NOT_CONFIGURED'].includes(session.blocker?.code),
        acknowledge: session.status === 'blocked' && ['SEGMENT_PATH_AMBIGUOUS', 'SEGMENT_PATH_UNKNOWN', 'SEGMENT_OWNER_UNCONFIRMED'].includes(session.blocker?.code),
        repair: session.status === 'blocked' && ['SEGMENT_PATH_DUPLICATE', 'SEGMENT_PATH_AMBIGUOUS', 'SEGMENT_PATH_UNKNOWN'].includes(session.blocker?.code),
        marker: Boolean(session.actualStartAt) && session.status !== 'cancelled' }; })()
    };
  }
  async function overview() {
    await load(); const t = now();
    const free = await Promise.resolve(freeBytes()).catch(() => null); const cloud = await cloudStatus().catch(() => ({ state: 'error' }));
    return {
      now: iso(t), settings: { dedicatedRecordFolder: Boolean(state.settings.dedicatedFolderKey) }, disk: { freeBytes: Number.isFinite(free) ? free : null, warnBytes: disk.warnBytes, stopBytes: disk.stopBytes }, cloud: { state: cloud?.state || 'unknown' },
      sources: state.sources.map((s) => ({ id: s.id, name: s.name, platform: s.platform, pageUrl: s.pageUrl, contentType: s.contentType, purpose: s.purpose, defaultCaptureMode: s.defaultCaptureMode })),
      plans: state.plans.filter((p) => p.status !== 'cancelled' || Date.parse(p.endAt) > t - 7 * 86_400_000).sort((a, b) => a.startAt.localeCompare(b.startAt)).map((p) => ({ id: p.id, sourceId: p.sourceId, title: p.title, timeZone: p.timeZone, startLocal: p.startLocal, endLocal: p.endLocal, startAt: p.startAt, endAt: p.endAt, prepareMinutes: p.prepareMinutes, captureMode: p.captureMode, segmentMinutes: p.segmentMinutes, backupAfterClose: p.backupAfterClose, status: p.status, sessionId: p.sessionId })),
      sessions: await Promise.all(state.sessions.slice(-30).reverse().map(async (session) => view(session, await repairOptions(session))))
    };
  }

  /** For the existing backup service: one entry per session, closed segments only (paths stay server-side). */
  async function backupSources() {
    await load();
    const out = [];
    for (const session of state.sessions) {
      if (planOf(session.planId)?.backupAfterClose === false) continue;
      const dup = await duplicateSegmentIds(session); // computed here too: never rely on a tick having marked them
      const segs = segmentsOf(session.id);
      const listed = segs.filter((seg) => seg.state === 'closed' && seg.file && (dup.has(seg.id) || seg.pathIssue === 'duplicate' || uploadable(seg)));
      if (!listed.length) continue;
      out.push({
        id: courseIdForLive(session.id), title: planOf(session.planId)?.title || '直播', liveSessionId: session.id,
        // No completion manifest while any segment is a duplicate or the session may still change.
        final: !dup.size && !segs.some((seg) => seg.pathIssue === 'duplicate') && (['processing', 'completed'].includes(session.status) || (session.status === 'blocked' && !session.obs.mayStillBeRecording && !openSegment(session.id))),
        segments: listed.map((seg) => (dup.has(seg.id) || seg.pathIssue === 'duplicate') ? { key: segmentKey(seg), blocked: 'SEGMENT_PATH_DUPLICATE' }
          : { key: segmentKey(seg), path: seg.file.ref, cleanable: seg.file.source !== 'inferred', ...(seg.revision && seg.file.md5 ? { expect: { bytes: seg.file.bytes, md5: seg.file.md5 } } : {}) })
      });
    }
    return out;
  }
  /**
   * True while a media file must not be touched by backup / cleanup: it belongs to a segment that is still being
   * written, or it is a quarantined candidate whose owner could not be determined.
   */
  async function isWriting(filePath) {
    await load(); const target = await realKey(filePath);
    for (const seg of state.segments) if ((seg.state !== 'closed' || needsOwner(seg)) && seg.file?.ref && await realKey(seg.file.ref) === target) return true;
    for (const item of state.quarantine) if (await realKey(item.ref) === target) return true;
    return false;
  }
  /** Cleanup gate: false for a file whose owner was only inferred, or a quarantined candidate. */
  async function mayRemove(filePath) {
    await load(); const target = await realKey(filePath);
    for (const seg of state.segments) if (seg.file?.ref && seg.file.source === 'inferred' && await realKey(seg.file.ref) === target) return false;
    for (const item of state.quarantine) if (await realKey(item.ref) === target) return false;
    return true;
  }
  /** The user declares OBS's current record folder as used by OBS only (inferred files there may be uploaded, never auto-cleaned). */
  async function setDedicatedRecordFolder(enabled) {
    await load();
    if (enabled !== true) { state.settings.dedicatedFolderKey = null; await save(); return { dedicatedRecordFolder: false }; }
    try { if (obs.state !== 'ready') await obs.connect(); } catch { fail('OBS_UNAVAILABLE', '請先開啟 OBS，才能確認它目前的錄影資料夾', 409); }
    const dir = await recordDirectory().catch(() => null); if (!dir) fail('OBS_UNAVAILABLE', '讀不到 OBS 錄影資料夾', 409);
    let real; try { real = await realpath(dir); } catch { fail('RECORD_FOLDER_MISSING', 'OBS 的錄影資料夾不存在', 409); }
    state.settings.dedicatedFolderKey = caseKey(real); await save(); return { dedicatedRecordFolder: true };
  }
  /** Any file this service knows (segment or quarantined candidate) — the legacy folder watcher must skip it. */
  async function isLiveFile(filePath) {
    await load(); const target = await realKey(filePath);
    return (await knownKeys()).has(target);
  }
  /** Start time (ms) of the session OBS is recording for right now, or null. */
  /**
   * Should the legacy recordings-folder watcher keep its hands off this file? True for every file a live session
   * knows (segments, quarantine) and for any media file that appeared in OBS's folder during a live session whose
   * paths are not fully resolved yet (recording, stopping, processing, or blocked on a path problem) — including
   * the moments right after a stop. Files written outside those windows (normal recordings, imports) are not held.
   */
  async function holdsFile(filePath, mtimeMs) {
    await load();
    if ((await knownKeys()).has(await realKey(filePath))) return true;
    if (!Number.isFinite(mtimeMs)) return false;
    for (const session of state.sessions) {
      const unresolved = ['preparing', 'recording', 'stopping', 'processing'].includes(session.status)
        || (session.status === 'blocked' && (session.obs?.mayStillBeRecording || PATH_BLOCKERS.has(session.blocker?.code) || segmentsOf(session.id).some((seg) => seg.pathIssue)));
      if (!unresolved) continue;
      const start = session.actualStartAt ? Date.parse(session.actualStartAt) - 10_000 : now() - 10_000;
      const end = session.actualStopAt ? Date.parse(session.actualStopAt) + 120_000 : Infinity;
      if (mtimeMs >= start && mtimeMs <= end) return true;
    }
    return false;
  }
  function recordingSince() {
    const session = state?.sessions.find((item) => ['preparing', 'recording', 'stopping'].includes(item.status) || (item.status === 'blocked' && item.obs?.mayStillBeRecording));
    if (!session) return null;
    return session.actualStartAt ? Date.parse(session.actualStartAt) - 10_000 : now() - 10_000;
  }

  return { holdsFile, reconcile: () => serial(async () => { await load(); const ids = await reconcile(); await save(); return ids; }), load, idle: async () => { let current; do { current = chain; await current; } while (current !== chain); }, isLiveFile, recordingSince, createSource, createPlan, updatePlan, setPlanStatus, tick, recover, act, overview, get: async (id) => { await load(); const session = sessionOf(id); return view(session, await repairOptions(session)); }, backupSources, isWriting, mayRemove, setDedicatedRecordFolder, courseIdForLive, _state: () => state };
}
