import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { normalizeSpans } from '../domain/timemap.mjs';
import { tempNameFor } from './files.mjs';

/**
 * ffprobe / ffmpeg helpers. Every invocation is an argument array (see process-runner.mjs). File paths are
 * passed as `file:<absolute path>` so a name such as `concat:a|b`, `pipe:1` or `-y` can never be read as a
 * protocol or an option. Outputs always go to a temp name next to the destination and are renamed
 * into place; an output may never be one of the inputs.
 */

export class MediaError extends Error {
  constructor(code, message) { super(message); this.name = 'MediaError'; this.code = code; }
}

export const SAMPLE_RATE = 16000;
const BYTES_PER_SECOND = SAMPLE_RATE * 2; // mono, signed 16-bit
export const fileArg = (file) => `file:${path.resolve(file)}`;

function mapProcessError(error, tool) {
  if (error?.code === 'COMMAND_NOT_FOUND') return new MediaError(tool === 'ffprobe' ? 'FFPROBE_UNAVAILABLE' : 'FFMPEG_UNAVAILABLE', `${tool} 找不到，請安裝並設定路徑`);
  if (error?.code === 'PROCESS_ABORTED') return new MediaError('CANCELLED', '已取消');
  if (error?.code === 'PROCESS_TIMEOUT') return new MediaError('MEDIA_TIMEOUT', `${tool} 逾時`);
  return new MediaError(tool === 'ffprobe' ? 'PROBE_FAILED' : 'FFMPEG_FAILED', `${tool} 失敗${error?.exitCode != null ? `（exit ${error.exitCode}）` : ''}`);
}

function assertDistinct(output, inputs) {
  const target = path.resolve(output).toLowerCase();
  if (inputs.some((input) => path.resolve(input).toLowerCase() === target)) throw new MediaError('OUTPUT_IS_INPUT', '輸出路徑不得覆蓋原始檔');
}

/** Reads duration and stream layout. Fails with NO_AUDIO_TRACK when the container has no audio stream. */
export async function probeMedia({ run, ffprobe = 'ffprobe', file, signal, requireAudio = true }) {
  let result;
  try { result = await run(ffprobe, ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', fileArg(file)], { signal, timeoutMs: 60_000 }); }
  catch (error) { throw mapProcessError(error, 'ffprobe'); }
  let data; try { data = JSON.parse(result.stdout); } catch { throw new MediaError('PROBE_FAILED', 'ffprobe 輸出無法解析'); }
  const streams = Array.isArray(data.streams) ? data.streams : [];
  const audioStream = streams.find((stream) => stream.codec_type === 'audio');
  const videoStream = streams.find((stream) => stream.codec_type === 'video' && stream.disposition?.attached_pic !== 1);
  const duration = Number(data.format?.duration ?? audioStream?.duration ?? videoStream?.duration);
  const fps = (() => { const [a, b] = String(videoStream?.avg_frame_rate || '').split('/').map(Number); return a > 0 && b > 0 ? Math.round((a / b) * 1000) / 1000 : undefined; })();
  const info = {
    durationSec: Number.isFinite(duration) && duration >= 0 ? duration : null,
    audio: audioStream ? { rate: Number(audioStream.sample_rate) || null, ch: Number(audioStream.channels) || null, codec: audioStream.codec_name || null } : null,
    video: videoStream ? { w: Number(videoStream.width) || null, h: Number(videoStream.height) || null, ...(fps ? { fps } : {}) } : null,
    formatName: data.format?.format_name || null
  };
  if (requireAudio && !info.audio) throw new MediaError('NO_AUDIO_TRACK', '媒體檔沒有音軌');
  return info;
}

/** Extracts (and concatenates, for segmented recordings) the first audio stream as mono 16 kHz PCM WAV. */
export async function extractAudio({ run, ffmpeg = 'ffmpeg', inputs, output, signal }) {
  if (!Array.isArray(inputs) || !inputs.length) throw new MediaError('NO_INPUT', '沒有輸入檔');
  assertDistinct(output, inputs);
  await fsp.mkdir(path.dirname(output), { recursive: true });
  const temporary = tempNameFor(output);
  const args = ['-hide_banner', '-nostdin', '-v', 'error'];
  for (const input of inputs) args.push('-i', fileArg(input));
  if (inputs.length === 1) args.push('-map', '0:a:0');
  else args.push('-filter_complex', `${inputs.map((_, index) => `[${index}:a:0]`).join('')}concat=n=${inputs.length}:v=0:a=1[aout]`, '-map', '[aout]');
  args.push('-vn', '-ac', '1', '-ar', String(SAMPLE_RATE), '-c:a', 'pcm_s16le', '-f', 'wav', '-y', fileArg(temporary));
  try { await run(ffmpeg, args, { signal }); await fsp.rename(temporary, output); }
  catch (error) { await fsp.unlink(temporary).catch(() => {}); throw error instanceof MediaError ? error : mapProcessError(error, 'ffmpeg'); }
  return output;
}

/**
 * ffmpeg's atempo accepts 0.5–2.0 per instance in every supported release, so larger factors are chained.
 * Playback at `rate` is undone with a total factor of 1/rate (2× → 0.5; 0.5× → 2.0; 4× → 0.5,0.5).
 */
export function atempoChain(rate) {
  const value = Number(rate);
  if (!Number.isFinite(value) || value <= 0) throw new MediaError('INVALID_RATE', `無效倍速：${rate}`);
  let factor = 1 / value; const chain = [];
  if (Math.abs(factor - 1) < 1e-9) return chain;
  while (factor < 0.5 - 1e-12) { chain.push(0.5); factor /= 0.5; }
  while (factor > 2 + 1e-12) { chain.push(2); factor /= 2; }
  if (Math.abs(factor - 1) > 1e-9) chain.push(Math.round(factor * 1e6) / 1e6);
  return chain;
}

const MIN_PIECE_SEC = 0.2;

/**
 * Decides how the recording is fed to Whisper.
 * - `direct`: every play span is 1× (or there is no TimeMap). The whole file is transcribed; times are `rec`.
 * - `per-span`: some play span is not 1×. Each play span is cut on its own and tempo-restored with its own
 *   atempo chain, then the pieces are joined with silence. paused / buffering / ad / preroll audio is never
 *   included. A single speed is never applied to the whole recording.
 * `windows` map a time `t` in the transcribed audio back to rec and src:
 *   rec = recStart + (t − inStart) × recPerIn,  src = srcStart + (t − inStart) × srcPerIn (null when unmapped).
 */
export function planTranscriptionInput({ spans, durationRec, timeMapSource }) {
  if (!spans) {
    const end = Number(durationRec); if (!(end > 0)) throw new MediaError('DURATION_UNKNOWN', '無法取得媒體長度');
    // `identity`: the file IS the original (an owned import), so src = rec. `none`: a recording without a
    // TimeMap — src is unknown and stays null rather than being assumed equal to rec.
    const identity = timeMapSource === 'identity';
    return { strategy: 'direct', timeMapSource: identity ? 'identity' : 'none', windows: [{ kind: 'play', inStart: 0, inEnd: end, recStart: 0, recPerIn: 1, srcStart: identity ? 0 : null, srcPerIn: identity ? 1 : null, rate: identity ? 1 : null }] };
  }
  const map = normalizeSpans(spans);
  const plays = map.filter((span) => span.kind === 'play' && span.recEnd - span.recStart >= MIN_PIECE_SEC);
  if (!plays.length) throw new MediaError('NO_PLAYBACK', 'TimeMap 沒有任何播放區段');
  const allUnit = plays.every((span) => Math.abs(span.rate - 1) < 1e-9);
  if (allUnit) {
    return { strategy: 'direct', timeMapSource: timeMapSource || 'recording', windows: map.map((span) => ({ kind: span.kind, inStart: span.recStart, inEnd: span.recEnd, recStart: span.recStart, recPerIn: 1, srcStart: span.srcStart, srcPerIn: span.kind === 'play' ? span.rate : 0, rate: span.rate })) };
  }
  return {
    strategy: 'per-span', timeMapSource: timeMapSource || 'recording',
    pieces: plays.map((span) => ({ recStart: span.recStart, recEnd: span.recEnd, srcStart: span.srcStart, rate: span.rate, atempo: atempoChain(span.rate) })),
    windows: null
  };
}

/** Cuts one play span from the normalized 16 kHz WAV and restores its original tempo. */
export async function renderPiece({ run, ffmpeg = 'ffmpeg', audio, piece, output, signal }) {
  assertDistinct(output, [audio]);
  const temporary = tempNameFor(output);
  const filters = [...piece.atempo.map((factor) => `atempo=${factor}`)];
  const args = ['-hide_banner', '-nostdin', '-v', 'error', '-ss', piece.recStart.toFixed(3), '-t', (piece.recEnd - piece.recStart).toFixed(3), '-i', fileArg(audio), '-vn'];
  if (filters.length) args.push('-af', filters.join(','));
  args.push('-ac', '1', '-ar', String(SAMPLE_RATE), '-c:a', 'pcm_s16le', '-f', 'wav', '-y', fileArg(temporary));
  try { await run(ffmpeg, args, { signal }); await fsp.rename(temporary, output); }
  catch (error) { await fsp.unlink(temporary).catch(() => {}); throw error instanceof MediaError ? error : mapProcessError(error, 'ffmpeg'); }
  return output;
}

/** Locates the PCM `data` chunk of a mono 16 kHz s16le WAV. */
export async function readWavLayout(file) {
  const handle = await fsp.open(file, 'r');
  try {
    const header = Buffer.alloc(12); await handle.read(header, 0, 12, 0);
    if (header.toString('ascii', 0, 4) !== 'RIFF' || header.toString('ascii', 8, 12) !== 'WAVE') throw new MediaError('WAV_INVALID', '不是 WAV 檔');
    const { size } = await handle.stat(); let offset = 12; let format = null;
    while (offset + 8 <= size) {
      const chunk = Buffer.alloc(8); await handle.read(chunk, 0, 8, offset);
      const id = chunk.toString('ascii', 0, 4); const length = chunk.readUInt32LE(4);
      if (id === 'fmt ') { const body = Buffer.alloc(16); await handle.read(body, 0, 16, offset + 8); format = { audioFormat: body.readUInt16LE(0), channels: body.readUInt16LE(2), sampleRate: body.readUInt32LE(4), bits: body.readUInt16LE(14) }; }
      if (id === 'data') {
        if (!format || format.audioFormat !== 1 || format.channels !== 1 || format.sampleRate !== SAMPLE_RATE || format.bits !== 16) throw new MediaError('WAV_FORMAT', 'WAV 必須是 mono 16 kHz PCM s16le');
        const dataLength = Math.min(length === 0xffffffff ? size - offset - 8 : length, size - offset - 8);
        return { dataOffset: offset + 8, dataLength: dataLength - (dataLength % 2) };
      }
      offset += 8 + length + (length % 2);
    }
    throw new MediaError('WAV_INVALID', 'WAV 缺少 data 區塊');
  } finally { await handle.close(); }
}

export function wavHeader(dataLength) {
  const header = Buffer.alloc(44);
  header.write('RIFF', 0, 'ascii'); header.writeUInt32LE(36 + dataLength, 4); header.write('WAVE', 8, 'ascii');
  header.write('fmt ', 12, 'ascii'); header.writeUInt32LE(16, 16); header.writeUInt16LE(1, 20); header.writeUInt16LE(1, 22);
  header.writeUInt32LE(SAMPLE_RATE, 24); header.writeUInt32LE(BYTES_PER_SECOND, 28); header.writeUInt16LE(2, 32); header.writeUInt16LE(16, 34);
  header.write('data', 36, 'ascii'); header.writeUInt32LE(dataLength, 40);
  return header;
}

/**
 * Joins tempo-restored pieces into one WAV with `gapSec` of silence between them and returns the exact
 * windows (measured from the real sample counts, not from the nominal rate).
 */
export async function joinPieces({ pieces, files, output, gapSec = 1 }) {
  if (pieces.length !== files.length || !pieces.length) throw new MediaError('NO_INPUT', '沒有可合併的片段');
  const layouts = []; for (const file of files) layouts.push(await readWavLayout(file));
  const gapBytes = Math.round(gapSec * SAMPLE_RATE) * 2;
  const total = layouts.reduce((sum, layout) => sum + layout.dataLength, 0) + gapBytes * (layouts.length - 1);
  const windows = []; let cursor = 0;
  layouts.forEach((layout, index) => {
    const piece = pieces[index]; const inStart = cursor / BYTES_PER_SECOND; const inEnd = (cursor + layout.dataLength) / BYTES_PER_SECOND;
    windows.push({ kind: 'play', inStart, inEnd, recStart: piece.recStart, recPerIn: 1 / piece.rate, srcStart: piece.srcStart, srcPerIn: 1, rate: piece.rate, recEnd: piece.recEnd });
    cursor += layout.dataLength + (index < layouts.length - 1 ? gapBytes : 0);
  });
  await fsp.mkdir(path.dirname(output), { recursive: true });
  const temporary = tempNameFor(output);
  try {
    await new Promise((resolve, reject) => {
      const out = fs.createWriteStream(temporary); out.on('error', reject);
      const pump = async () => {
        out.write(wavHeader(total));
        for (let index = 0; index < files.length; index += 1) {
          const { dataOffset, dataLength } = layouts[index];
          if (dataLength > 0) await new Promise((done, fail) => { const input = fs.createReadStream(files[index], { start: dataOffset, end: dataOffset + dataLength - 1 }); input.on('error', fail); input.on('end', done); input.pipe(out, { end: false }); });
          if (index < files.length - 1 && gapBytes) out.write(Buffer.alloc(gapBytes));
        }
        out.end(resolve);
      };
      pump().catch(reject);
    });
    await fsp.rename(temporary, output);
  } catch (error) { await fsp.unlink(temporary).catch(() => {}); throw error; }
  return { output, windows, durationSec: total / BYTES_PER_SECOND };
}

/** Writes a short synthetic mono 16 kHz WAV (tones and silence). Used for self-made test fixtures only. */
export function synthWav({ seconds = 1, toneHz = 440, amplitude = 0.3, silenceEvery = 0 } = {}) {
  const samples = Math.round(seconds * SAMPLE_RATE); const data = Buffer.alloc(samples * 2);
  for (let index = 0; index < samples; index += 1) {
    const t = index / SAMPLE_RATE; const silent = silenceEvery > 0 && Math.floor(t / silenceEvery) % 2 === 1;
    data.writeInt16LE(silent ? 0 : Math.round(Math.sin(2 * Math.PI * toneHz * t) * amplitude * 32767), index * 2);
  }
  return Buffer.concat([wavHeader(data.length), data]);
}
