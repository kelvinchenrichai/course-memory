import { spawn as nodeSpawn } from 'node:child_process';
import path from 'node:path';

/**
 * The only way the pipeline starts child processes. Always `spawn(command, argsArray, { shell: false })`:
 * arguments are never concatenated into a shell string, so quotes, spaces, `&`, `|`, `;`, `$()` and
 * non-ASCII file names reach the program verbatim. Logs carry the program name and argument count only.
 */

export class ProcessError extends Error {
  constructor(code, message, details = {}) { super(message); this.name = 'ProcessError'; this.code = code; Object.assign(this, details); }
}

const MAX_CAPTURE = 1024 * 1024;
const silent = { info() {}, warn() {}, error() {} };

/** Removes secrets and personal path segments from text that may end up in logs or job errors. */
export function redactText(value, { max = 2000 } = {}) {
  let text = String(value ?? '');
  text = text
    .replace(/\b(sk-[A-Za-z0-9_-]{8,}|AIza[0-9A-Za-z_-]{20,}|ghp_[A-Za-z0-9]{20,}|xox[abprs]-[A-Za-z0-9-]{10,})/g, '[redacted-key]')
    .replace(/(Bearer\s+)[A-Za-z0-9._~+/=-]+/gi, '$1[redacted]')
    .replace(/((?:api[_-]?key|password|passwd|token|secret|authorization|cookie)\s*[:=]\s*)("[^"]*"|'[^']*'|[^\s,;]+)/gi, '$1[redacted]')
    .replace(/([A-Za-z]:\\Users\\)[^\\/\r\n]+/gi, '$1<user>')
    .replace(/(\/(?:home|Users)\/)[^/\r\n]+/g, '$1<user>');
  return text.length > max ? `…${text.slice(-max)}` : text;
}

function assertInvocation(command, args) {
  if (typeof command !== 'string' || !command.trim()) throw new ProcessError('INVALID_COMMAND', 'command must be a non-empty string');
  if (!Array.isArray(args) || args.some((arg) => typeof arg !== 'string')) throw new ProcessError('INVALID_ARGS', 'args must be an array of strings');
  if (args.some((arg) => arg.includes('\0'))) throw new ProcessError('INVALID_ARGS', 'args must not contain NUL bytes');
}

export function createProcessRunner({ spawn = nodeSpawn, logger = silent } = {}) {
  const label = (command) => path.basename(command);

  /** Runs to completion. Rejects with COMMAND_NOT_FOUND, PROCESS_FAILED, PROCESS_TIMEOUT or PROCESS_ABORTED. */
  function run(command, args = [], { cwd, timeoutMs = 0, signal, env, input } = {}) {
    assertInvocation(command, args);
    return new Promise((resolve, reject) => {
      if (signal?.aborted) { reject(new ProcessError('PROCESS_ABORTED', 'aborted before start')); return; }
      let stdout = ''; let stderr = ''; let settled = false; let timer = null;
      logger.info({ event: 'process_start', program: label(command), argc: args.length });
      const child = spawn(command, args, { cwd, env, shell: false, windowsHide: true, stdio: [input == null ? 'ignore' : 'pipe', 'pipe', 'pipe'] });
      const finish = (error, value) => {
        if (settled) return; settled = true; if (timer) clearTimeout(timer); signal?.removeEventListener?.('abort', onAbort);
        if (error) { logger.warn({ event: 'process_failed', program: label(command), code: error.code }); reject(error); } else resolve(value);
      };
      const onAbort = () => { try { child.kill(); } catch {} finish(new ProcessError('PROCESS_ABORTED', 'aborted')); };
      signal?.addEventListener?.('abort', onAbort, { once: true });
      if (timeoutMs > 0) timer = setTimeout(() => { try { child.kill(); } catch {} finish(new ProcessError('PROCESS_TIMEOUT', `${label(command)} timed out`)); }, timeoutMs);
      child.stdout?.on('data', (chunk) => { if (stdout.length < MAX_CAPTURE) stdout += chunk; });
      child.stderr?.on('data', (chunk) => { if (stderr.length < MAX_CAPTURE) stderr += chunk; });
      if (input != null) { child.stdin?.end(input); }
      child.on('error', (error) => finish(error?.code === 'ENOENT' ? new ProcessError('COMMAND_NOT_FOUND', `${label(command)} not found`) : new ProcessError('PROCESS_FAILED', redactText(error?.message))));
      child.on('close', (code) => {
        if (code === 0) finish(null, { code, stdout, stderr });
        else finish(new ProcessError('PROCESS_FAILED', `${label(command)} exited with ${code}`, { exitCode: code, stderrTail: redactText(stderr, { max: 1200 }), stdout, stderr }));
      });
    });
  }

  /** Starts a long-running process (audio capture). Returns a small handle; the caller owns its lifetime. */
  function start(command, args = [], { cwd, env, onStderr } = {}) {
    assertInvocation(command, args);
    logger.info({ event: 'process_start', program: label(command), argc: args.length });
    const child = spawn(command, args, { cwd, env, shell: false, windowsHide: true, stdio: ['pipe', 'ignore', 'pipe'] });
    let stderr = ''; let exit = null; const waiters = [];
    child.stderr?.on('data', (chunk) => { if (stderr.length < 64 * 1024) stderr += chunk; try { onStderr?.(String(chunk)); } catch {} });
    const done = (value) => { if (exit) return; exit = value; for (const fn of waiters.splice(0)) fn(value); };
    child.on('error', (error) => done({ code: null, error: error?.code === 'ENOENT' ? 'COMMAND_NOT_FOUND' : 'PROCESS_FAILED' }));
    child.on('close', (code, sig) => done({ code, signal: sig ?? null, error: null }));
    return {
      get pid() { return child.pid; },
      get exited() { return exit; },
      write(text) { try { child.stdin?.write(text); return true; } catch { return false; } },
      kill() { try { child.kill(); } catch {} },
      wait() { return exit ? Promise.resolve(exit) : new Promise((resolve) => waiters.push(resolve)); },
      stderrTail: () => redactText(stderr, { max: 1200 })
    };
  }

  return { run, start };
}
