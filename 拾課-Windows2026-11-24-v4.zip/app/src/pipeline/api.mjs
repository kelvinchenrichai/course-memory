import { isLocalHost, isLocalUiOrigin } from '../services/companion.mjs';

/**
 * Local-only API for P4A: audio device selection and transcription jobs. Same guard as the Agent API
 * (Host must be localhost; Origin must be the local UI or absent; POST/PUT bodies must be JSON).
 *   GET  /api/audio/devices                 → { inputFormat, devices, selected }
 *   PUT  /api/audio/device   { name }        → stores the choice in config.json
 *   GET  /api/pipeline/jobs                 → jobs
 *   POST /api/pipeline/jobs  { recordingSessionId } | { importFile }
 *   GET  /api/pipeline/jobs/:id
 *   POST /api/pipeline/jobs/:id/cancel | /retry
 */

const STATUS = { JOB_NOT_FOUND: 404, SESSION_NOT_FOUND: 404, PATH_NOT_ALLOWED: 403, INVALID_TRANSITION: 409, MEDIA_BUSY: 409, SESSION_NOT_READY: 409, FFMPEG_UNAVAILABLE: 503, PIPELINE_UNAVAILABLE: 503, AUDIO_DEVICE_LISTING_UNSUPPORTED: 501, AUDIO_DEVICE_UNAVAILABLE: 409 };
const json = (status, body) => ({ status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }, body });

export const isPipelineRoute = (pathname) => pathname === '/api/audio/devices' || pathname === '/api/audio/device' || pathname === '/api/pipeline/jobs' || pathname.startsWith('/api/pipeline/jobs/');

export async function handlePipelineRequest(runtime, request, { port } = {}) {
  const { method, pathname, headers = {} } = request;
  if (!isPipelineRoute(pathname)) return null;
  if (!isLocalHost(headers.host)) return json(403, { error: 'BAD_HOST' });
  if (!isLocalUiOrigin(headers.origin ?? null, port)) return json(403, { error: 'BAD_ORIGIN' });
  if (['POST', 'PUT'].includes(method) && !String(headers['content-type'] || '').startsWith('application/json')) return json(415, { error: 'JSON_REQUIRED' });
  const body = request.body && typeof request.body === 'object' ? request.body : {};
  try {
    if (pathname === '/api/audio/devices' && method === 'GET') return json(200, await runtime.audio.list());
    if (pathname === '/api/audio/device' && method === 'PUT') { if (typeof body.name !== 'string' || !body.name || body.name.length > 300) return json(400, { error: 'INVALID_DEVICE' }); return json(200, await runtime.audio.select(body.name)); }
    if (!runtime.pipeline) return json(503, { error: 'PIPELINE_UNAVAILABLE', message: runtime.pipelineUnavailableReason || 'pipeline 尚未設定' });
    if (pathname === '/api/pipeline/jobs' && method === 'GET') return json(200, await runtime.pipeline.list());
    if (pathname === '/api/pipeline/jobs' && method === 'POST') {
      if (typeof body.recordingSessionId === 'string') return json(202, await runtime.enqueueSession(body.recordingSessionId, body.options));
      if (typeof body.importFile === 'string') return json(202, await runtime.enqueueImport(body.importFile, body.options));
      return json(400, { error: 'INVALID_SOURCE' });
    }
    const match = pathname.match(/^\/api\/pipeline\/jobs\/(job_[0-9a-f]{12})(?:\/(cancel|retry))?$/);
    if (!match) return json(404, { error: 'NOT_FOUND' });
    const [, id, action] = match;
    if (!action && method === 'GET') return json(200, await runtime.pipeline.get(id));
    if (method !== 'POST') return json(405, { error: 'METHOD_NOT_ALLOWED' });
    return json(200, action === 'cancel' ? await runtime.pipeline.cancel(id) : await runtime.pipeline.retry(id));
  } catch (error) {
    const code = typeof error?.code === 'string' && /^[A-Z][A-Z0-9_]{2,60}$/.test(error.code) ? error.code : 'PIPELINE_ERROR';
    return json(STATUS[code] ?? 400, { error: code, message: String(error?.message || code).slice(0, 300) });
  }
}
