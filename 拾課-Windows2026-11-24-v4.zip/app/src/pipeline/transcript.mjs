import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { createId } from '../domain/ids.mjs';

/**
 * Whisper providers behind one interface, and the mapping from raw Whisper output to a TranscriptTrack.
 *
 * provider.transcribe({ audio, outDir, language, wordTimestamps, signal }) → RawTranscript
 * RawTranscript = { engine: { name, model, version }, language, languageProbability, durationSec,
 *                   segments: [{ index, start, end, text, avgLogprob, noSpeechProb, words: [{ w, start, end, probability }] | null }] }
 * Fields an engine cannot provide are null — never estimated.
 */

export class TranscriptError extends Error {
  constructor(code, message) { super(message); this.name = 'TranscriptError'; this.code = code; }
}

export const LANGUAGES = Object.freeze(['auto', 'en', 'zh-Hant', 'zh-Hans']);
/** Whisper only knows `zh`; the script (Hant/Hans) is a P4B concern and is never guessed here. */
export function whisperLanguage(language) {
  if (!LANGUAGES.includes(language)) throw new TranscriptError('LANGUAGE_UNSUPPORTED', `不支援的語言：${language}`);
  return language === 'auto' ? null : language.startsWith('zh') ? 'zh' : language;
}

const num = (value) => (typeof value === 'number' && Number.isFinite(value) ? value : null);

function validateRaw(raw) {
  if (!raw || !Array.isArray(raw.segments)) throw new TranscriptError('WHISPER_OUTPUT_INVALID', 'Whisper 輸出缺少 segments');
  raw.segments.forEach((segment, index) => {
    if (!Number.isFinite(segment.start) || !Number.isFinite(segment.end) || segment.end < segment.start || segment.start < 0) throw new TranscriptError('WHISPER_OUTPUT_INVALID', `segment ${index} 時間無效`);
    if (typeof segment.text !== 'string') throw new TranscriptError('WHISPER_OUTPUT_INVALID', `segment ${index} 缺少文字`);
  });
  return raw;
}

/**
 * Errors that mean "this engine cannot run on this computer at all" (not installed, a native DLL refused by a
 * Windows application-control policy, a missing model). Only these let `auto` switch engines; an engine that
 * loads but fails on this audio (bad output, timeout, crash during transcription) never triggers a switch.
 */
const engineUnavailable = (error) => Object.assign(error, { engineUnavailable: true });
const POLICY_BLOCKED = /WinError (4551|4556|1260|225)\b/;

function mapRunError(error, unavailableCode) {
  if (error instanceof TranscriptError) return error;
  if (error?.code === 'COMMAND_NOT_FOUND') return engineUnavailable(new TranscriptError(unavailableCode, '找不到轉錄程式，請確認設定'));
  if (error?.code === 'PROCESS_ABORTED') return new TranscriptError('CANCELLED', '已取消');
  if (error?.code === 'PROCESS_TIMEOUT') return new TranscriptError('WHISPER_TIMEOUT', 'Whisper 逾時');
  if (error?.exitCode === 3) return engineUnavailable(new TranscriptError(unavailableCode, 'faster-whisper 尚未安裝（requirements.txt）'));
  if (error?.exitCode === 5 || POLICY_BLOCKED.test(String(error?.stderrTail || ''))) return engineUnavailable(new TranscriptError('ENGINE_BLOCKED', 'Windows 應用程式控制（例如智慧型應用程式控制）擋下了 faster-whisper 需要的 ctranslate2.dll'));
  if (error?.exitCode === 6) return engineUnavailable(new TranscriptError('ENGINE_LOAD_FAILED', 'faster-whisper 的元件無法載入'));
  return new TranscriptError('WHISPER_FAILED', `Whisper 失敗${error?.exitCode != null ? `（exit ${error.exitCode}）` : ''}`);
}

/** faster-whisper through scripts/transcribe.py (JSON contract `cms.whisper-raw/1`). */
export function createFasterWhisperProvider({ run, python, script, model = 'small', device = 'auto', computeType = 'int8', beamSize = 5, vad = true, timeoutMs = 0 }) {
  if (!python || !script) throw new TranscriptError('WHISPER_NOT_CONFIGURED', 'faster-whisper 需要 pythonCommand');
  return {
    name: 'faster-whisper', origin: 'whisper', model, heavy: true,
    params: { model, device, computeType, beamSize, vad },
    async transcribe({ audio, outDir, language = 'auto', wordTimestamps = true, signal }) {
      const lang = whisperLanguage(language);
      const output = path.join(outDir, 'faster-whisper.raw.json');
      const args = [script, audio, output, '--model', model, '--language', lang || 'auto', '--device', device, '--compute-type', computeType, '--beam-size', String(beamSize), wordTimestamps ? '--word-timestamps' : '--no-word-timestamps', vad ? '--vad' : '--no-vad'];
      try { await run(python, args, { signal, timeoutMs }); } catch (error) { throw mapRunError(error, 'FASTER_WHISPER_UNAVAILABLE'); }
      let data; try { data = JSON.parse(await fsp.readFile(output, 'utf8')); } catch { throw new TranscriptError('WHISPER_OUTPUT_INVALID', 'faster-whisper 輸出無法解析'); }
      if (data.schema !== 'cms.whisper-raw/1') throw new TranscriptError('WHISPER_OUTPUT_INVALID', 'faster-whisper 輸出版本不符');
      return validateRaw({
        engine: { name: 'faster-whisper', model, version: typeof data.engine?.version === 'string' ? data.engine.version.slice(0, 40) : null },
        language: typeof data.language === 'string' ? data.language : null,
        languageProbability: num(data.languageProbability), durationSec: num(data.duration),
        segments: (data.segments || []).map((segment, index) => ({
          index, start: Number(segment.start), end: Number(segment.end), text: String(segment.text ?? ''),
          avgLogprob: num(segment.avgLogprob), noSpeechProb: num(segment.noSpeechProb),
          words: Array.isArray(segment.words) ? segment.words.filter((word) => Number.isFinite(word.start) && Number.isFinite(word.end) && typeof word.w === 'string').map((word) => ({ w: word.w, start: word.start, end: word.end, probability: num(word.probability) })) : null
        }))
      });
    }
  };
}

/** First model file that exists, or null. Resolved at transcription time so a model added later is found. */
function firstExisting(candidates) { return candidates.find((file) => typeof file === 'string' && file && fs.existsSync(file)) || null; }
const modelMissing = (name) => engineUnavailable(new TranscriptError('WHISPER_CPP_MODEL_MISSING', `找不到 whisper.cpp 模型 ${name}`));
/** whisper.cpp marks silence/music with bracketed tags; they are not speech. */
const NON_SPEECH = /^\s*[\[(（【]\s*(BLANK_AUDIO|MUSIC|NOISE|SILENCE|音樂|音乐|無聲|无声)[^\])）】]*[\])）】]\s*$/i;

/**
 * whisper.cpp (`whisper-cli` / legacy `main`), user-configured executable and model. Uses the same flags the
 * existing server already used (-m -f -oj -of) plus -l. Its basic JSON has no per-segment log-probability,
 * no-speech probability, language probability or word timestamps, so those stay null.
 */
export function createWhisperCppProvider({ run, command, model, models = null, threads = null, timeoutMs = 0 }) {
  const candidates = models || [model];
  if (!command || !candidates.some(Boolean)) throw new TranscriptError('WHISPER_NOT_CONFIGURED', 'whisper.cpp 需要 whisperCppCommand 與 whisperCppModel');
  const label = path.win32.basename(path.posix.basename(String(candidates.find(Boolean))));
  return {
    name: 'whisper.cpp', origin: 'whisper.cpp', backend: 'cli', model: label, heavy: true,
    params: { model: label, threads, backend: 'cli' },
    async transcribe({ audio, outDir, language = 'auto', signal }) {
      const lang = whisperLanguage(language);
      const modelFile = models ? firstExisting(candidates) : candidates[0];
      if (!modelFile) throw modelMissing(label);
      const prefix = path.join(outDir, 'whisper-cpp.raw');
      const args = ['-m', modelFile, '-f', audio, '-oj', '-of', prefix, '-l', lang || 'auto', ...(threads ? ['-t', String(threads)] : [])];
      try { await run(command, args, { signal, timeoutMs }); } catch (error) { throw mapRunError(error, 'WHISPER_CPP_UNAVAILABLE'); }
      let data; try { data = JSON.parse(await fsp.readFile(`${prefix}.json`, 'utf8')); } catch { throw new TranscriptError('WHISPER_OUTPUT_INVALID', 'whisper.cpp 輸出無法解析'); }
      const items = Array.isArray(data.transcription) ? data.transcription : null;
      if (!items) throw new TranscriptError('WHISPER_OUTPUT_INVALID', 'whisper.cpp 輸出缺少 transcription');
      return validateRaw({
        engine: { name: 'whisper.cpp', model: path.win32.basename(modelFile), backend: 'cli', version: null },
        language: typeof data.result?.language === 'string' ? data.result.language : null,
        languageProbability: null, durationSec: null,
        segments: items.filter((item) => !NON_SPEECH.test(String(item.text ?? ''))).map((item, index) => ({ index, start: Number(item.offsets?.from) / 1000, end: Number(item.offsets?.to) / 1000, text: String(item.text ?? ''), avgLogprob: null, noSpeechProb: null, words: null }))
      });
    }
  };
}

/** Escapes a value for an ffmpeg filter option inside a filtergraph (both escaping levels). */
export function escapeFilterValue(value) {
  const option = String(value).replace(/\\/g, '/').replace(/[\\':]/g, (char) => `\\${char}`);
  return option.replace(/[\\'[\],;]/g, (char) => `\\${char}`);
}

/**
 * Parses the ffmpeg whisper filter's `format=json` output: one object per line,
 * {"start": ms, "end": ms, "text": "…"[, "language": "xx"]}. The filter does not JSON-escape the text, so a
 * line that is not valid JSON is read with a strict pattern instead; anything else is rejected.
 */
export function parseFfmpegWhisperLines(text) {
  const segments = []; let language = null;
  for (const line of String(text).split(/\r?\n/)) {
    if (!line.trim()) continue;
    let item = null;
    try { item = JSON.parse(line); } catch {
      const match = line.match(/^\{"start":(-?\d+),"end":(-?\d+),"text":"([\s\S]*?)"(?:,"language":"([a-z]{0,8}|unknown)")?\}\s*$/);
      if (match) item = { start: Number(match[1]), end: Number(match[2]), text: match[3].replace(/\\"/g, '"'), language: match[4] };
    }
    if (!item || !Number.isFinite(Number(item.start)) || !Number.isFinite(Number(item.end)) || typeof item.text !== 'string') throw new TranscriptError('WHISPER_OUTPUT_INVALID', 'whisper.cpp 輸出無法解析');
    if (typeof item.language === 'string' && /^[a-z]{2,3}$/.test(item.language)) language ??= item.language;
    if (!item.text.trim() || NON_SPEECH.test(item.text)) continue;
    segments.push({ index: segments.length, start: Number(item.start) / 1000, end: Math.max(Number(item.end), Number(item.start)) / 1000, text: item.text, avgLogprob: null, noSpeechProb: null, words: null });
  }
  return { segments, language };
}

/**
 * whisper.cpp built into ffmpeg (the `whisper` audio filter, FFmpeg ≥ 8). No extra executable or DLL is
 * installed: the already-present ffmpeg runs it and only a ggml model file is needed. Language detection is
 * only reported by newer builds; otherwise it stays null (never guessed).
 */
export function createFfmpegWhisperProvider({ run, ffmpeg = 'ffmpeg', models, queueSec = 30, useGpu = false, timeoutMs = 0 }) {
  const candidates = (models || []).filter(Boolean);
  if (!candidates.length) throw new TranscriptError('WHISPER_NOT_CONFIGURED', 'whisper.cpp 需要模型檔');
  const label = path.win32.basename(path.posix.basename(String(candidates[0])));
  return {
    name: 'whisper.cpp', origin: 'whisper.cpp', backend: 'ffmpeg', model: label, heavy: true,
    params: { model: label, backend: 'ffmpeg', queueSec, useGpu },
    async transcribe({ audio, outDir, language = 'auto', signal }) {
      const lang = whisperLanguage(language);
      const modelFile = firstExisting(candidates);
      if (!modelFile) throw modelMissing(label);
      const output = 'whisper-cpp.raw.jsonl';
      await fsp.rm(path.join(outDir, output), { force: true });
      const filter = `whisper=model=${escapeFilterValue(path.resolve(modelFile))}:language=${lang || 'auto'}:queue=${queueSec}:use_gpu=${useGpu ? 'true' : 'false'}:destination=${output}:format=json`;
      try { await run(ffmpeg, ['-hide_banner', '-nostats', '-nostdin', '-i', audio, '-af', filter, '-f', 'null', '-'], { cwd: outDir, signal, timeoutMs }); }
      catch (error) {
        if (/No such filter: 'whisper'|Unknown filter 'whisper'|Filter not found/i.test(String(error?.stderrTail || error?.stderr || ''))) throw engineUnavailable(new TranscriptError('WHISPER_CPP_FILTER_MISSING', '這個 ffmpeg 沒有內建 whisper.cpp（whisper 濾鏡）'));
        throw mapRunError(error, 'FFMPEG_UNAVAILABLE');
      }
      let text = '';
      try { text = await fsp.readFile(path.join(outDir, output), 'utf8'); } catch (error) { if (error?.code !== 'ENOENT') throw new TranscriptError('WHISPER_OUTPUT_INVALID', 'whisper.cpp 輸出無法讀取'); }
      const parsed = parseFfmpegWhisperLines(text);
      return validateRaw({ engine: { name: 'whisper.cpp', model: path.win32.basename(path.posix.basename(modelFile)), backend: 'ffmpeg', version: null }, language: parsed.language, languageProbability: null, durationSec: null, segments: parsed.segments });
    }
  };
}

/**
 * `auto`: faster-whisper first; only when it cannot run on this computer at all (not installed, DLL blocked
 * by Windows application control, DLL load failure) does it switch to whisper.cpp — once per call, never
 * back and forth. The switch is remembered until `reset()` (the settings check found faster-whisper loadable
 * again), so later jobs do not pay for a known-failing start. Transcription failures are never retried here.
 */
export function createAutoProvider({ primary, fallback = null, logger = null }) {
  let blocked = null;
  const describe = (provider) => (provider ? { engine: provider.name, ...provider.params } : null);
  async function useFallback(args, reason) {
    if (!fallback) throw engineUnavailable(new TranscriptError('WHISPER_FALLBACK_UNAVAILABLE', 'faster-whisper 無法使用，也沒有設定 whisper.cpp 備援'));
    const raw = await fallback.transcribe(args);
    raw.engine = { ...raw.engine, fallbackFrom: primary.name, fallbackReason: reason };
    return raw;
  }
  return {
    name: 'auto', origin: 'whisper', model: primary.model, heavy: true,
    params: { primary: describe(primary), fallback: describe(fallback) },
    get primaryBlocked() { return blocked ? { ...blocked } : null; },
    reset() { blocked = null; },
    async transcribe(args) {
      if (blocked) return useFallback(args, blocked.code);
      try { return await primary.transcribe(args); }
      catch (error) {
        if (!error?.engineUnavailable || error.code === 'CANCELLED') throw error;
        blocked = { code: error.code, at: new Date().toISOString() };
        logger?.warn?.({ event: 'transcriber_fallback', from: primary.name, to: fallback?.name || null, code: error.code });
        return useFallback(args, error.code);
      }
    }
  };
}

/**
 * User-facing reason + advice for every engine availability code (繁中). Shared by the settings check and the
 * processing centre. Never asks the user to turn off Windows security features.
 */
export const ENGINE_TEXT = Object.freeze({
  ENGINE_BLOCKED: ['Windows「智慧型應用程式控制」擋下了 faster-whisper 需要的 ctranslate2.dll', '不需要關閉 Windows 安全防護：把「轉錄工具」設為「自動」，並放好 whisper.cpp 模型，系統會改用 ffmpeg 內建的 whisper.cpp。'],
  ENGINE_LOAD_FAILED: ['faster-whisper 的元件無法載入', '可以把「轉錄工具」設為「自動」改用 whisper.cpp；或重新執行 Setup.ps1 修復 Python 套件。'],
  FASTER_WHISPER_UNAVAILABLE: ['尚未安裝 faster-whisper', '請執行 Setup.ps1 安裝；或把「轉錄工具」設為「自動」改用 whisper.cpp。'],
  PYTHON_NOT_FOUND: ['找不到 Python 執行環境', '請執行 Setup.ps1 建立 .venv；或把「轉錄工具」設為「自動」改用 whisper.cpp。'],
  ENGINE_CHECK_TIMEOUT: ['檢查 faster-whisper 逾時', 'Windows 可能正在掃描或詢問是否允許；稍後按「重新檢查」。'],
  WHISPER_CPP_MODEL_MISSING: ['找不到 whisper.cpp 模型', '從 whisper.cpp 官方模型庫（Hugging Face：ggerganov/whisper.cpp）下載 ggml-small.bin（約 488 MB），放到專案的 models\\whisper\\ 資料夾後按重試。'],
  WHISPER_CPP_FILTER_MISSING: ['目前的 ffmpeg 沒有內建 whisper.cpp', '請改用 FFmpeg 8 以上的 full build（例如 gyan.dev 版），或另外安裝 whisper-cli。'],
  WHISPER_CPP_UNAVAILABLE: ['找不到 whisper.cpp（whisper-cli）', '請確認 whisper-cli 的位置，或把 whisper.cpp 執行方式設為「ffmpeg 內建」。'],
  WHISPER_FALLBACK_UNAVAILABLE: ['faster-whisper 無法使用，也沒有 whisper.cpp 備援', '請放好 whisper.cpp 模型（models\\whisper\\ggml-small.bin）後按重試。'],
  FFMPEG_UNAVAILABLE: ['找不到 ffmpeg', '請到「設定」檢查 ffmpeg 狀態，安裝後按重試。']
});

const TRANSCRIBERS = ['auto', 'faster-whisper', 'whisper.cpp'];
/** Model files whisper.cpp may use, in order: the configured file, then models/whisper/ggml-<whisperModel>.bin. */
export function whisperCppModelCandidates(config, root) {
  const configured = typeof config.whisperCppModel === 'string' && config.whisperCppModel ? path.resolve(root, config.whisperCppModel) : null;
  const name = `ggml-${String(config.whisperModel || 'small').replace(/[^a-z0-9.-]/gi, '')}.bin`;
  return [...new Set([configured, path.join(root, 'models', 'whisper', name)].filter(Boolean))];
}

/** whisper.cpp backend: an existing whisper-cli wins when chosen/available, otherwise ffmpeg's built-in filter. */
export function createWhisperCppEngine(config, { run, root, ffmpeg = config.ffmpegCommand || 'ffmpeg' }) {
  const models = whisperCppModelCandidates(config, root);
  const backend = config.whisperCppBackend || 'auto';
  const cli = typeof config.whisperCppCommand === 'string' && config.whisperCppCommand ? path.resolve(root, config.whisperCppCommand) : null;
  if (backend === 'cli' || (backend === 'auto' && cli && fs.existsSync(cli))) return createWhisperCppProvider({ run, command: cli, models, threads: config.whisperCppThreads ?? null });
  return createFfmpegWhisperProvider({ run, ffmpeg, models, queueSec: Number(config.whisperCppQueueSec) || 30, useGpu: config.whisperCppUseGpu === true });
}

export function createWhisperProvider(config, { run, root, logger = null }) {
  const transcriber = config.transcriber || 'auto';
  if (!TRANSCRIBERS.includes(transcriber)) throw new TranscriptError('WHISPER_NOT_CONFIGURED', `未知的 transcriber：${transcriber}`);
  if (transcriber === 'whisper.cpp') return createWhisperCppEngine(config, { run, root });
  const faster = createFasterWhisperProvider({ run, python: config.pythonCommand, script: path.join(root, 'scripts', 'transcribe.py'), model: config.whisperModel || 'small', device: config.whisperDevice || 'auto', computeType: config.whisperComputeType || 'int8' });
  if (transcriber === 'faster-whisper') return faster;
  return createAutoProvider({ primary: faster, fallback: createWhisperCppEngine(config, { run, root }), logger });
}

// ---------------------------------------------------------------------------------------------------------
// Raw → TranscriptTrack

const LOW_CONFIDENCE = { noSpeechProb: 0.6, avgLogprob: -1.0 };
const round = (value) => (value == null ? null : Math.round(value * 1000) / 1000);
const EPS = 1e-6;

function windowAt(windows, t) { return windows.find((window) => t >= window.inStart - EPS && t < window.inEnd + EPS) || null; }
function overlap(a0, a1, b0, b1) { return Math.max(0, Math.min(a1, b1) - Math.max(a0, b0)); }
const toRec = (window, t) => window.recStart + (t - window.inStart) * window.recPerIn;
const toSrc = (window, t) => (window.srcStart == null ? null : window.srcStart + (t - window.inStart) * window.srcPerIn);

/** pass = 1 + number of earlier play windows whose src range overlaps this one (rewatch after a seek back). */
function passes(windows) {
  const plays = windows.filter((window) => window.kind === 'play');
  return new Map(plays.map((window, index) => {
    if (window.srcStart == null) return [window, 1];
    const a0 = toSrc(window, window.inStart), a1 = toSrc(window, window.inEnd);
    const earlier = plays.slice(0, index).filter((other) => other.srcStart != null && overlap(a0, a1, toSrc(other, other.inStart), toSrc(other, other.inEnd)) > 0.05);
    return [window, 1 + earlier.length];
  }));
}

/**
 * Places raw segments on rec/src time. A segment is kept only where it overlaps a `play` window; text in
 * paused/buffering/ad/preroll time is excluded from the source transcript. A segment that crosses a
 * window boundary is split by its word timestamps when present; otherwise it is kept whole in the window
 * holding most of it and clipped to that window (counted in stats.boundaryClipped).
 */
export function placeSegments(raw, windows) {
  const plays = windows.filter((window) => window.kind === 'play');
  const passOf = passes(windows); const placed = []; const stats = { rawSegments: raw.segments.length, kept: 0, empty: 0, excluded: { paused: 0, buffering: 0, ad: 0, preroll: 0, outside: 0 }, boundaryClipped: 0, splitByWords: 0 };
  for (const segment of raw.segments) {
    const text = segment.text.trim();
    if (!text) { stats.empty += 1; continue; }
    const hits = plays.map((window) => ({ window, amount: overlap(segment.start, Math.max(segment.end, segment.start + EPS), window.inStart, window.inEnd) })).filter((hit) => hit.amount > 0);
    if (!hits.length) {
      const where = windows.find((window) => overlap(segment.start, Math.max(segment.end, segment.start + EPS), window.inStart, window.inEnd) > 0);
      stats.excluded[where && where.kind in stats.excluded ? where.kind : 'outside'] += 1; continue;
    }
    const groups = [];
    if (hits.length > 1 && segment.words?.length) {
      for (const word of segment.words) {
        const window = windowAt(plays, (word.start + word.end) / 2); if (!window) continue;
        const last = groups.at(-1);
        if (last && last.window === window) last.words.push(word); else groups.push({ window, words: [word] });
      }
      if (groups.length > 1) stats.splitByWords += 1;
    }
    if (!groups.length) {
      const best = hits.sort((a, b) => b.amount - a.amount)[0];
      if (segment.start < best.window.inStart - EPS || segment.end > best.window.inEnd + EPS) stats.boundaryClipped += 1;
      groups.push({ window: best.window, words: segment.words ? segment.words.filter((word) => windowAt([best.window], (word.start + word.end) / 2)) : null, whole: true });
    }
    for (const group of groups) {
      const { window } = group;
      const start = group.whole ? Math.max(segment.start, window.inStart) : group.words[0].start;
      const end = group.whole ? Math.min(segment.end, window.inEnd) : group.words.at(-1).end;
      const t0 = Math.max(start, window.inStart), t1 = Math.min(Math.max(end, t0), window.inEnd);
      const groupText = group.whole || groups.length === 1 ? text : group.words.map((word) => word.w).join('').trim();
      if (!groupText || t1 - t0 < 0.01) { stats.empty += 1; continue; }
      placed.push({
        rawIndex: segment.index, pass: passOf.get(window) || 1,
        rec: [round(toRec(window, t0)), round(toRec(window, t1))], src: [round(toSrc(window, t0)), round(toSrc(window, t1))], text: groupText,
        words: (group.words || []).map((word) => {
          const w0 = Math.max(window.inStart, Math.min(word.start, window.inEnd)), w1 = Math.max(w0, Math.min(word.end, window.inEnd));
          return { w: String(word.w).slice(0, 200), rec: [round(toRec(window, w0)), round(toRec(window, w1))], src: [round(toSrc(window, w0)), round(toSrc(window, w1))] };
        }),
        avgLogprob: segment.avgLogprob ?? null, noSpeechProb: segment.noSpeechProb ?? null
      });
      stats.kept += 1;
    }
  }
  placed.sort((a, b) => a.rec[0] - b.rec[0] || a.rec[1] - b.rec[1]);
  return { placed, stats };
}

/** The engine that actually produced `raw` (auto mode may have switched), never the configured one. */
function engineOf(raw, provider, strategy) {
  const actual = raw.engine && typeof raw.engine.name === 'string' ? raw.engine : null;
  const engine = { name: String(actual?.name || provider.name).slice(0, 80), model: String(actual?.model || provider.model).slice(0, 200), tempoNormalized: strategy === 'per-span' };
  if (typeof actual?.backend === 'string') engine.backend = actual.backend.slice(0, 40);
  if (typeof actual?.fallbackFrom === 'string') { engine.fallbackFrom = actual.fallbackFrom.slice(0, 80); engine.fallbackReason = String(actual.fallbackReason || '').slice(0, 60); }
  return engine;
}

/** Builds TranscriptTrack revision 1. The raw Whisper JSON is stored separately and never rewritten. */
export function buildTranscriptTrack({ raw, windows, assetId, provider, requestedLanguage, stageKey, strategy, timeMapSource, rawFile, now = new Date().toISOString() }) {
  const { placed, stats } = placeSegments(raw, windows);
  const segments = placed.map((item, index) => {
    const segment = { id: `s${String(index + 1).padStart(4, '0')}`, rec: item.rec, src: item.src, text: item.text, rawIndex: item.rawIndex, pass: item.pass, avgLogprob: item.avgLogprob, noSpeechProb: item.noSpeechProb };
    if (item.words.length) segment.words = item.words;
    if (item.noSpeechProb != null && item.avgLogprob != null && item.noSpeechProb > LOW_CONFIDENCE.noSpeechProb && item.avgLogprob < LOW_CONFIDENCE.avgLogprob) segment.flag = 'low-confidence';
    return segment;
  });
  const playDuration = windows.filter((window) => window.kind === 'play').reduce((sum, window) => sum + (window.inEnd - window.inStart) * window.recPerIn, 0);
  const covered = segments.reduce((sum, segment) => sum + (segment.rec[1] - segment.rec[0]), 0);
  const logprobs = segments.map((segment) => segment.avgLogprob).filter((value) => value != null);
  const noSpeech = segments.map((segment) => segment.noSpeechProb).filter((value) => value != null);
  const quality = { auto: false };
  if (playDuration > 0) quality.coverage = Math.min(1, Math.round((covered / playDuration) * 1000) / 1000);
  if (logprobs.length) quality.avgLogprob = Math.round((logprobs.reduce((a, b) => a + b, 0) / logprobs.length) * 1000) / 1000;
  if (noSpeech.length) quality.noSpeechRatio = Math.round((noSpeech.filter((value) => value > LOW_CONFIDENCE.noSpeechProb).length / noSpeech.length) * 1000) / 1000;
  const detected = typeof raw.language === 'string' && /^[a-z]{2,3}$/.test(raw.language) ? raw.language : null;
  const track = {
    id: createId('trk', `${assetId}:${stageKey}`), schemaVersion: 1, createdAt: now, updatedAt: now,
    assetId, revision: 1, parentRevision: null, origin: raw.engine?.name === 'whisper.cpp' ? 'whisper.cpp' : raw.engine?.name === 'faster-whisper' ? 'whisper' : provider.origin,
    language: detected || (requestedLanguage === 'auto' ? 'auto' : requestedLanguage.startsWith('zh') ? 'zh' : requestedLanguage),
    script: null, requestedLanguage, detectedLanguage: detected, languageProbability: raw.languageProbability ?? null,
    engine: engineOf(raw, provider, strategy),
    stageKey, timeBase: { strategy, timeMapSource },
    raw: rawFile ? { file: rawFile.file, sha256: rawFile.sha256 } : undefined,
    quality, segments
  };
  if (!track.raw) delete track.raw;
  return { track, stats };
}

/** Pure validation used by tests and before writing: ids unique and ordered, times monotonic and valid. */
export function assertTrackInvariants(track) {
  const ids = new Set(); let previous = -Infinity;
  for (const segment of track.segments) {
    if (ids.has(segment.id)) throw new TranscriptError('TRACK_INVALID', `重複的 segment id ${segment.id}`);
    ids.add(segment.id);
    if (!(segment.rec[1] > segment.rec[0])) throw new TranscriptError('TRACK_INVALID', `${segment.id} rec 時間無效`);
    if (segment.rec[0] < previous - 1e-9) throw new TranscriptError('TRACK_INVALID', `${segment.id} rec 未遞增`);
    previous = segment.rec[0];
    if ((segment.src[0] == null) !== (segment.src[1] == null)) throw new TranscriptError('TRACK_INVALID', `${segment.id} src 不完整`);
    if (segment.src[0] != null && !(segment.src[1] >= segment.src[0])) throw new TranscriptError('TRACK_INVALID', `${segment.id} src 時間無效`);
  }
  return true;
}
