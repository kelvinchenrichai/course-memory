import path from 'node:path';
import { makeId } from '../../lib/core.mjs';
import { buildKnowledgePack, knowledgePackToCourseChapters, normalizeKnowledgeSegments } from '../services/knowledge.mjs';

/**
 * Turns a completed P4A pipeline job + its TranscriptTrack into a library course (knowledge整理).
 * Shared by server.mjs and the P7B acceptance script so both publish exactly the same way.
 *
 * An empty transcript (no segments, or only blank text) is a final, user-facing outcome —
 * KNOWLEDGE_TRANSCRIPT_EMPTY — not a transient failure: it is recorded once per transcript revision and
 * not retried in a loop, so the course never sits in「處理中」forever.
 */

export const TRANSCRIPT_EMPTY = 'KNOWLEDGE_TRANSCRIPT_EMPTY';
export const PUBLISH_FAILED = 'KNOWLEDGE_PUBLISH_FAILED';

const fail = (code) => Object.assign(new Error(code), { code });

/** Identifies the transcript a publish attempt was based on (ids only, never a path). */
export const trackKeyOf = (job) => `${job?.result?.trackId || ''}:${job?.result?.revision ?? ''}`;

/** False when this exact transcript was already found empty: retrying cannot change the outcome. */
export function shouldAttemptPublish(job, previousError) {
  return !(previousError?.code === TRANSCRIPT_EMPTY && previousError.trackKey === trackKeyOf(job));
}

export function publishErrorCode(error) {
  return error?.code === TRANSCRIPT_EMPTY || error?.message === TRANSCRIPT_EMPTY ? TRANSCRIPT_EMPTY : PUBLISH_FAILED;
}

/** Throws KNOWLEDGE_TRANSCRIPT_EMPTY unless the track has at least one segment with text. */
export function publishableSegments(track) {
  if (!Array.isArray(track?.segments) || !track.segments.length) throw fail(TRANSCRIPT_EMPTY);
  const normalized = normalizeKnowledgeSegments(track.segments);
  if (!normalized.length || normalized.every((segment) => !String(segment.text || '').trim())) throw fail(TRANSCRIPT_EMPTY);
  return normalized;
}

/**
 * Builds (or updates) the course object. Does not write anything; the caller saves it.
 * `existing`: a course already pointing at the same media (keeps its id/title).
 */
export async function buildPipelineCourse({ job, track, existing = null, workRoot, chapterMinutes, generate, now } = {}) {
  const media = job?.asset?.files?.[0]?.path;
  if (!media) throw fail(PUBLISH_FAILED);
  const normalized = publishableSegments(track);
  const id = existing?.id || makeId(`pipeline:${job.asset.id}`);
  const title = existing?.title || job.displayTitle || path.basename(media, path.extname(media));
  let knowledge;
  try { knowledge = await buildKnowledgePack({ title, track, chapterMinutes, generate, ...(now ? { now } : {}) }); }
  catch (error) { throw fail(publishErrorCode(error)); }
  const audioStage = job.stages?.find((stage) => stage.name === 'audio' && stage.status === 'completed');
  const playbackMedia = job.source?.kind === 'audio' && audioStage?.outputs?.file
    ? path.join(workRoot, job.result.assetDir, 'stages', `audio-${audioStage.stageKey.slice('sha256:'.length, 'sha256:'.length + 16)}`, audioStage.outputs.file)
    : media;
  const course = existing || { id, title, video: playbackMedia, rights: { basis: 'private-learning', privateOnly: true }, markers: [], createdAt: job.createdAt };
  Object.assign(course, {
    pipelineJobId: job.id, sourceKind: job.source?.kind, sourceMedia: media, video: playbackMedia, status: 'ready', language: track.detectedLanguage || track.language,
    segments: normalized.map((segment) => ({ id: segment.id, start: segment.rec[0], end: segment.rec[1], src: segment.src, text: segment.text })),
    knowledge, chapters: knowledgePackToCourseChapters(knowledge, normalized), error: ''
  });
  return course;
}
