import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';

/** Small file helpers shared by the pipeline. Every write goes to a unique temp name, then rename. */

export const tempNameFor = (target) => `${target}.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`;

export async function writeFileAtomic(target, data) {
  await fsp.mkdir(path.dirname(target), { recursive: true });
  const temporary = tempNameFor(target);
  try { await fsp.writeFile(temporary, data); await fsp.rename(temporary, target); }
  catch (error) { await fsp.unlink(temporary).catch(() => {}); throw error; }
  return target;
}

export const writeJsonAtomic = (target, value) => writeFileAtomic(target, `${JSON.stringify(value, null, 2)}\n`);

export async function readJson(target, fallback) {
  try { return JSON.parse(await fsp.readFile(target, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT' && arguments.length > 1) return fallback; throw error; }
}

export async function exists(target) { try { await fsp.access(target); return true; } catch { return false; } }

export function hashFile(file) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256'); const stream = fs.createReadStream(file);
    stream.on('error', reject); stream.on('data', (chunk) => hash.update(chunk)); stream.on('end', () => resolve(hash.digest('hex')));
  });
}

const normalizeCase = (value, platform) => platform === 'win32' ? value.toLowerCase() : value;

/** True when `target` is `root` or below it. Both are resolved with the platform's path rules. */
export function isInside(root, target, { platform = process.platform } = {}) {
  const lib = platform === 'win32' ? path.win32 : path.posix;
  const base = normalizeCase(lib.resolve(root), platform); const candidate = normalizeCase(lib.resolve(target), platform);
  if (candidate === base) return true;
  const relative = lib.relative(base, candidate);
  return Boolean(relative) && !relative.startsWith('..') && !lib.isAbsolute(relative);
}

/** Resolves symlinks and checks the real path is still inside one of the allowed roots. */
export async function assertAllowedPath(target, roots, { platform = process.platform, realpath = fsp.realpath } = {}) {
  const real = await realpath(target);
  for (const root of roots) {
    let realRoot = root; try { realRoot = await realpath(root); } catch {}
    if (isInside(realRoot, real, { platform })) return real;
  }
  throw Object.assign(new Error('path is outside the configured folders'), { code: 'PATH_NOT_ALLOWED' });
}

/** Opaque, stable reference for a value that must not appear in logs (device names, user paths). */
export const opaqueRef = (value) => crypto.createHash('sha256').update(String(value)).digest('hex').slice(0, 10);
