/**
 * SRT / WebVTT from a TranscriptTrack.
 * - `rec`: recording-file time. `src`: original-video time.
 * - Segments without src (ad / preroll / no TimeMap) produce no src cue.
 * - Cues keep their segment id (VTT cue identifier; SRT via the returned manifest).
 * - Start times are non-decreasing and every cue has end > start. A rewatched passage (same src shown
 *   twice) yields two src cues — one per pass — which may overlap; nothing is merged or overwritten.
 * - Long segments are split into ≤ 2 lines of ≤ 42 Latin / 18 CJK characters, using word timestamps when
 *   present and proportional character timing otherwise (AI_PIPELINE_SPEC §4).
 */

const CJK = /[぀-ヿ㐀-鿿豈-﫿＀-￯]/;
export const LAYOUT = Object.freeze({ latinLine: 42, cjkLine: 18, maxLines: 2, minDuration: 0.3 });

const isCjk = (text) => CJK.test(text);
const lineLimit = (text) => (isCjk(text) ? LAYOUT.cjkLine : LAYOUT.latinLine);

function wrap(text) {
  const limit = lineLimit(text); const lines = [];
  if (isCjk(text)) { const chars = [...text.replace(/\s+/g, ' ').trim()]; for (let i = 0; i < chars.length; i += limit) lines.push(chars.slice(i, i + limit).join('').trim()); return lines.filter(Boolean); }
  let line = '';
  for (const word of text.split(/\s+/).filter(Boolean)) {
    if (!line) line = word; else if ((`${line} ${word}`).length <= limit) line = `${line} ${word}`; else { lines.push(line); line = word; }
  }
  if (line) lines.push(line);
  return lines.flatMap((item) => (item.length > limit ? item.match(new RegExp(`.{1,${limit}}`, 'g')) : [item]));
}

/** Splits one segment into cue chunks of at most maxLines lines. */
function chunk(segment, timeline) {
  const [start, end] = segment[timeline];
  const lines = wrap(segment.text);
  if (lines.length <= LAYOUT.maxLines) return [{ start, end, text: lines.join('\n') }];
  const groups = []; for (let i = 0; i < lines.length; i += LAYOUT.maxLines) groups.push(lines.slice(i, i + LAYOUT.maxLines));
  const total = groups.reduce((sum, group) => sum + group.join('').length, 0) || 1;
  let cursor = start; let consumed = 0;
  return groups.map((group, index) => {
    consumed += group.join('').length;
    const next = index === groups.length - 1 ? end : start + (end - start) * (consumed / total);
    const piece = { start: cursor, end: next, text: group.join('\n') }; cursor = next; return piece;
  });
}

export function buildCues(track, timeline) {
  if (!['rec', 'src'].includes(timeline)) throw new Error('timeline must be rec or src');
  const usable = track.segments.filter((segment) => segment[timeline][0] != null && segment[timeline][1] != null && segment[timeline][1] > segment[timeline][0]);
  const ordered = timeline === 'rec' ? usable : [...usable].sort((a, b) => a.src[0] - b.src[0] || a.rec[0] - b.rec[0]);
  const cues = [];
  for (const segment of ordered) {
    const pieces = chunk(segment, timeline);
    pieces.forEach((piece, index) => {
      const startAt = Math.round(piece.start * 1000) / 1000; let endAt = Math.round(piece.end * 1000) / 1000;
      if (endAt <= startAt) endAt = startAt + 0.001;
      cues.push({ id: pieces.length > 1 ? `${segment.id}-${index + 1}` : segment.id, segmentId: segment.id, pass: segment.pass ?? 1, start: startAt, end: endAt, text: piece.text });
    });
  }
  for (let index = 1; index < cues.length; index += 1) if (cues[index].start < cues[index - 1].start) throw new Error('cue start times are not monotonic');
  return cues;
}

function clock(seconds, separator) {
  const ms = Math.max(0, Math.round(seconds * 1000));
  const h = Math.floor(ms / 3_600_000), m = Math.floor((ms % 3_600_000) / 60_000), s = Math.floor((ms % 60_000) / 1000), r = ms % 1000;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}${separator}${String(r).padStart(3, '0')}`;
}
export const srtTime = (seconds) => clock(seconds, ',');
export const vttTime = (seconds) => clock(seconds, '.');

/** Cue text must not be able to forge a new cue: blank lines collapse and a bare `-->` is neutralised. */
const safeText = (text) => text.replace(/\r/g, '').split('\n').map((line) => line.replace(/-->/g, '→').trimEnd()).filter((line) => line.trim()).join('\n');

export function toSrt(cues, { bom = true } = {}) {
  const body = cues.map((cue, index) => `${index + 1}\n${srtTime(cue.start)} --> ${srtTime(cue.end)}\n${safeText(cue.text)}\n`).join('\n');
  return `${bom ? '﻿' : ''}${body}`;
}

export function toVtt(cues) {
  return `WEBVTT\n\n${cues.map((cue) => `${cue.id}\n${vttTime(cue.start)} --> ${vttTime(cue.end)}\n${safeText(cue.text)}\n`).join('\n')}`;
}

export function buildSubtitleSet(track, { vtt = false } = {}) {
  const rec = buildCues(track, 'rec'); const src = buildCues(track, 'src');
  const files = { 'transcript.rec.srt': toSrt(rec), 'transcript.src.srt': toSrt(src) };
  if (vtt) { files['transcript.rec.vtt'] = toVtt(rec); files['transcript.src.vtt'] = toVtt(src); }
  const manifest = {
    trackId: track.id, revision: track.revision,
    rec: rec.map((cue, index) => ({ index: index + 1, cueId: cue.id, segmentId: cue.segmentId, start: cue.start, end: cue.end })),
    src: src.map((cue, index) => ({ index: index + 1, cueId: cue.id, segmentId: cue.segmentId, pass: cue.pass, start: cue.start, end: cue.end })),
    srcOverlaps: src.filter((cue, index) => index && cue.start < src[index - 1].end - 1e-9).map((cue) => cue.id),
    srcExcludedSegments: track.segments.filter((segment) => segment.src[0] == null).map((segment) => segment.id)
  };
  return { files, manifest, cues: { rec, src } };
}
