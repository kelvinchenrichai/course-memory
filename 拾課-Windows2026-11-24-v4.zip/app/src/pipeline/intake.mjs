import path from 'node:path';

/**
 * The three sources enter the same pipeline through here:
 *  - audio : an Agent RecordingSession made by the audio capture adapter (captureMode 'audio')
 *  - video : an Agent RecordingSession made by OBS (captureMode 'video')
 *  - import: a file the user placed in the imports folder (their own, legally obtained media)
 * Recording sessions carry their TimeMap. An import is the original itself, so src = rec (identity).
 * A recording file with no matching session gets no TimeMap: rec subtitles only, src stays null.
 */

export class IntakeError extends Error {
  constructor(code, message) { super(message); this.name = 'IntakeError'; this.code = code; }
}

const READY_SESSION = new Set(['completed', 'partial']);

export function jobInputFromSession(session) {
  if (!session || !READY_SESSION.has(session.status)) throw new IntakeError('SESSION_NOT_READY', '錄製尚未結束');
  if (!['audio', 'video'].includes(session.captureMode)) throw new IntakeError('INVALID_SOURCE', 'RecordingSession 缺少 captureMode');
  const files = Array.isArray(session.obsOutputFiles) && session.obsOutputFiles.length ? session.obsOutputFiles : session.obsOutputPath ? [session.obsOutputPath] : [];
  if (!files.length) throw new IntakeError('NO_OUTPUT', 'RecordingSession 沒有輸出檔');
  const spans = session.timeMap?.spans;
  return {
    source: { kind: session.captureMode }, recordingSessionId: session.id, title: session.title || null, files,
    timeMap: Array.isArray(spans) && spans.length ? { source: 'recording', spans } : { source: 'none' }
  };
}

const samePath = (a, b) => path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase();

export function createIntake({ pipeline, findSessions = async () => [], options = {} }) {
  return {
    async fromSession(session) { return pipeline.enqueue({ ...jobInputFromSession(session), options }); },
    async fromImport(file) { return pipeline.enqueue({ source: { kind: 'import' }, files: [file], timeMap: { source: 'identity' }, options }); },
    /** Routes a stable file reported by the watcher. Returns { deferred } while its session is still recording. */
    async fromWatchEntry(entry) {
      if (entry.kind === 'import') return pipeline.enqueue({ source: { kind: 'import' }, files: [{ path: entry.file, sha256: entry.sha256, bytes: entry.bytes }], timeMap: { source: 'identity' }, options });
      const sessions = await findSessions();
      const session = sessions.find((item) => [item.obsOutputPath, ...(item.obsOutputFiles || [])].filter(Boolean).some((file) => samePath(file, entry.file)));
      if (session?.status === 'failed') return { skipped: true, reason: 'SESSION_FAILED' };
      if (session && !READY_SESSION.has(session.status)) return { deferred: true, reason: 'SESSION_NOT_READY' };
      if (session) return pipeline.enqueue({ ...jobInputFromSession(session), options });
      return pipeline.enqueue({ source: { kind: entry.kind === 'audio-capture' ? 'audio' : 'video' }, files: [{ path: entry.file, sha256: entry.sha256, bytes: entry.bytes }], timeMap: { source: 'none' }, options });
    }
  };
}
