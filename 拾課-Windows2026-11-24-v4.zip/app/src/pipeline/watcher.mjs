import fsp from 'node:fs/promises';
import path from 'node:path';
import { assertAllowedPath, hashFile, readJson, writeJsonAtomic } from './files.mjs';

/**
 * Polling watcher for the configured folders (OBS recordings, audio captures, imports).
 * Polling instead of fs.watch: it behaves the same on local disks, external drives and network shares on
 * Windows, and tests drive it with explicit scan() calls instead of waiting.
 *
 * A file is handed to the pipeline only when:
 *  - it lives under a configured root (real path, symlinks resolved) — nothing outside is ever read;
 *  - it is not hidden / temporary / partial and has an allowed media extension;
 *  - its size and mtime were identical on `stableChecks` consecutive scans (and again after hashing);
 *  - its identity (sha256 + size + mtime) is not in the persisted ledger (no re-import after restart);
 *  - its content (sha256 + size) was not already imported under another name (reported as duplicate).
 */

export const MEDIA_EXTENSIONS = Object.freeze(['.mp4', '.mkv', '.mov', '.webm', '.flv', '.ts', '.m4a', '.flac', '.wav', '.mp3', '.ogg', '.opus', '.aac']);
const TEMP_SUFFIXES = ['.tmp', '.temp', '.part', '.partial', '.crdownload', '.download', '.!ut', '.lock'];

export function isIgnoredName(name) {
  const lower = name.toLowerCase();
  if (!name || name.startsWith('.') || name.startsWith('~$') || name.startsWith('~')) return true;
  if (TEMP_SUFFIXES.some((suffix) => lower.endsWith(suffix))) return true;
  if (/\.(tmp|part)\.[^.]+$/.test(lower)) return true;
  return false;
}

export function identityKey({ sha256, bytes, mtimeMs }) { return `${sha256}:${bytes}:${Math.trunc(mtimeMs)}`; }

export function createWatchLedger(file) {
  let state = null;
  const load = async () => { if (!state) { const data = await readJson(file, { version: 1, entries: [] }); state = { version: 1, entries: Array.isArray(data.entries) ? data.entries : [] }; } return state; };
  return {
    async has(key) { return (await load()).entries.some((entry) => entry.key === key); },
    async findContent(sha256, bytes) { return (await load()).entries.find((entry) => entry.sha256 === sha256 && entry.bytes === bytes && !entry.duplicateOf) || null; },
    async add(entry) { const data = await load(); if (!data.entries.some((item) => item.key === entry.key)) { data.entries.push(entry); await writeJsonAtomic(file, data); } return entry; },
    async entries() { return [...(await load()).entries]; }
  };
}

export function createFileWatcher({ roots, ledger, stableChecks = 2, maxDepth = 2, extensions = MEDIA_EXTENSIONS, platform = process.platform, now = () => new Date().toISOString(), hash = hashFile, logger = { info() {}, warn() {} } }) {
  if (!Array.isArray(roots) || !roots.length) throw new Error('watcher needs at least one root');
  if (!ledger) throw new Error('watcher needs a ledger');
  const normalized = roots.map((root) => ({ ...root, dir: path.resolve(root.dir) }));
  const allowedDirs = normalized.map((root) => root.dir);
  const observed = new Map(); // absolute path → { bytes, mtimeMs, seen, settled }
  let timer = null; let scanning = null;

  async function list(root, dir, depth, out) {
    let entries; try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const entry of entries) {
      if (isIgnoredName(entry.name)) continue;
      const full = path.join(dir, entry.name);
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) { if (depth < maxDepth) await list(root, full, depth + 1, out); continue; }
      if (!entry.isFile()) continue;
      if (!extensions.includes(path.extname(entry.name).toLowerCase())) continue;
      out.push({ root, file: full });
    }
  }

  async function scanOnce() {
    const result = { ready: [], pending: 0, duplicates: [], known: 0, rejected: 0 };
    const seenNow = new Set();
    for (const root of normalized) {
      const files = []; await list(root, root.dir, 0, files);
      for (const { file } of files) {
        seenNow.add(file);
        let real; try { real = await assertAllowedPath(file, [root.dir], { platform }); } catch { result.rejected += 1; continue; }
        let stat; try { stat = await fsp.stat(real); } catch { continue; }
        const prior = observed.get(file);
        if (prior?.settled && prior.bytes === stat.size && prior.mtimeMs === stat.mtimeMs) { result.known += 1; continue; }
        const same = prior && prior.bytes === stat.size && prior.mtimeMs === stat.mtimeMs;
        const entry = { bytes: stat.size, mtimeMs: stat.mtimeMs, seen: same ? prior.seen + 1 : 1, settled: false };
        observed.set(file, entry);
        if (stat.size === 0 || entry.seen < stableChecks) { result.pending += 1; continue; }
        const sha256 = await hash(real);
        let after; try { after = await fsp.stat(real); } catch { continue; }
        if (after.size !== stat.size || after.mtimeMs !== stat.mtimeMs) { observed.set(file, { bytes: after.size, mtimeMs: after.mtimeMs, seen: 1, settled: false }); result.pending += 1; continue; }
        entry.settled = true;
        const record = { key: identityKey({ sha256, bytes: stat.size, mtimeMs: stat.mtimeMs }), sha256, bytes: stat.size, mtimeMs: Math.trunc(stat.mtimeMs), rootId: root.id, kind: root.kind, relPath: path.relative(root.dir, real), addedAt: now() };
        if (await ledger.has(record.key)) { result.known += 1; continue; }
        const original = await ledger.findContent(sha256, stat.size);
        if (original) { await ledger.add({ ...record, duplicateOf: original.key }); result.duplicates.push({ ...record, file: real, duplicateOf: original.key }); logger.info({ event: 'watch_duplicate', rootId: root.id }); continue; }
        await ledger.add(record);
        result.ready.push({ ...record, file: real });
        logger.info({ event: 'watch_ready', rootId: root.id, kind: root.kind });
      }
    }
    for (const file of [...observed.keys()]) if (!seenNow.has(file)) observed.delete(file);
    return result;
  }

  return {
    roots: allowedDirs,
    /** One polling pass. Concurrent calls share the same pass. */
    scan() { if (!scanning) scanning = scanOnce().finally(() => { scanning = null; }); return scanning; },
    start({ intervalMs = 3000, onReady } = {}) {
      if (timer) return;
      const tick = async () => { try { const result = await this.scan(); for (const item of result.ready) await onReady?.(item); } catch (error) { logger.warn({ event: 'watch_error', code: error?.code || 'ERROR' }); } };
      timer = setInterval(tick, intervalMs); timer.unref?.();
    },
    stop() { if (timer) clearInterval(timer); timer = null; }
  };
}
