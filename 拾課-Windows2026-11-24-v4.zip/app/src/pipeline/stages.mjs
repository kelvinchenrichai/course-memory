import fsp from 'node:fs/promises';
import path from 'node:path';
import { createStageKey } from '../domain/ids.mjs';
import { hashFile, writeFileAtomic, writeJsonAtomic } from './files.mjs';
import { MediaError, extractAudio, joinPieces, planTranscriptionInput, probeMedia, readWavLayout, renderPiece } from './media.mjs';
import { assertTrackInvariants, buildTranscriptTrack } from './transcript.mjs';
import { buildSubtitleSet, LAYOUT } from './subtitles.mjs';

/**
 * P4A stage definitions. Each stage declares the inputs and parameters that make up its stageKey, and a
 * run() that writes into its own directory (named after the key). A stage directory whose stage.json says
 * `completed` for the same key is reused as-is, so identical input + params + version is never redone and
 * an earlier result (e.g. raw Whisper output) is never overwritten.
 *
 *   probe ─► audio ─► prepare ─► transcribe ─► track ─► subtitles
 */

export const PIPELINE_VERSION = 'p4a-1';
export const STAGE_NAMES = Object.freeze(['probe', 'audio', 'prepare', 'transcribe', 'track', 'subtitles']);

const spansParam = (job) => job.timeMap?.spans ?? null;

export const STAGES = Object.freeze([
  {
    name: 'probe',
    key: (job) => ({ inputIds: job.asset.files.map((file) => `${file.sha256}:${file.bytes}`), params: { requireAudio: true } }),
    async run(ctx) {
      const inputs = [];
      for (const file of ctx.job.asset.files) inputs.push(await probeMedia({ run: ctx.run, ffprobe: ctx.tools.ffprobe, file: file.path, signal: ctx.signal }));
      if (ctx.job.source.kind === 'audio' && inputs.some((info) => info.video)) throw new MediaError('NOT_AUDIO_ONLY', '音訊模式的來源含有影像軌；不得把影片當成純音訊處理');
      const durationRec = inputs.reduce((sum, info) => sum + (info.durationSec || 0), 0);
      return { inputs, durationRec: Math.round(durationRec * 1000) / 1000 };
    }
  },
  {
    name: 'audio',
    key: (job, keys) => ({ inputIds: [keys.probe], params: { sampleRate: 16000, channels: 1, codec: 'pcm_s16le' } }),
    async run(ctx) {
      const output = path.join(ctx.dir, 'audio.wav');
      await extractAudio({ run: ctx.run, ffmpeg: ctx.tools.ffmpeg, inputs: ctx.job.asset.files.map((file) => file.path), output, signal: ctx.signal });
      const layout = await readWavLayout(output);
      return { file: 'audio.wav', durationSec: layout.dataLength / 32000 };
    }
  },
  {
    name: 'prepare',
    key: (job, keys) => ({ inputIds: [keys.audio], params: { timeMapSource: job.timeMap.source, spans: spansParam(job), gapSec: 1 } }),
    async run(ctx) {
      const audio = ctx.output('audio');
      const plan = planTranscriptionInput({ spans: spansParam(ctx.job), durationRec: audio.durationSec, timeMapSource: ctx.job.timeMap.source });
      if (plan.strategy === 'direct') return { strategy: 'direct', timeMapSource: plan.timeMapSource, input: { stage: 'audio', file: audio.file }, windows: plan.windows };
      const files = [];
      for (const [index, piece] of plan.pieces.entries()) {
        const file = path.join(ctx.dir, `piece-${String(index + 1).padStart(3, '0')}.wav`);
        await renderPiece({ run: ctx.run, ffmpeg: ctx.tools.ffmpeg, audio: ctx.file('audio', audio.file), piece, output: file, signal: ctx.signal });
        files.push(file);
      }
      const joined = await joinPieces({ pieces: plan.pieces, files, output: path.join(ctx.dir, 'input.wav'), gapSec: 1 });
      for (const file of files) await fsp.unlink(file).catch(() => {});
      return { strategy: 'per-span', timeMapSource: plan.timeMapSource, input: { stage: 'prepare', file: 'input.wav' }, windows: joined.windows, pieces: plan.pieces.map(({ recStart, recEnd, srcStart, rate, atempo }) => ({ recStart, recEnd, srcStart, rate, atempo })) };
    }
  },
  {
    name: 'transcribe', heavy: true,
    key: (job, keys, deps) => ({ inputIds: [keys.prepare], params: { engine: deps.provider.name, ...deps.provider.params, language: job.options.language, wordTimestamps: job.options.wordTimestamps } }),
    async run(ctx) {
      const prepared = ctx.output('prepare');
      const raw = await ctx.provider.transcribe({ audio: ctx.file(prepared.input.stage, prepared.input.file), outDir: ctx.dir, language: ctx.job.options.language, wordTimestamps: ctx.job.options.wordTimestamps, signal: ctx.signal });
      const file = path.join(ctx.dir, 'raw.json');
      await writeJsonAtomic(file, raw);
      // The engine that actually ran (auto mode may have switched); names only, never a path.
      const engine = { name: raw.engine?.name || ctx.provider.name, model: raw.engine?.model || ctx.provider.model, ...(raw.engine?.backend ? { backend: raw.engine.backend } : {}), ...(raw.engine?.fallbackFrom ? { fallbackFrom: raw.engine.fallbackFrom, fallbackReason: raw.engine.fallbackReason } : {}) };
      return { file: 'raw.json', sha256: await hashFile(file), segments: raw.segments.length, language: raw.language, engine };
    }
  },
  {
    name: 'track',
    key: (job, keys) => ({ inputIds: [keys.transcribe, keys.prepare], params: { assetId: job.asset.id, revision: 1 } }),
    async run(ctx) {
      const prepared = ctx.output('prepare'); const transcribed = ctx.output('transcribe');
      const raw = JSON.parse(await fsp.readFile(ctx.file('transcribe', transcribed.file), 'utf8'));
      const { track, stats } = buildTranscriptTrack({
        raw, windows: prepared.windows, assetId: ctx.job.asset.id, provider: ctx.provider, requestedLanguage: ctx.job.options.language,
        stageKey: ctx.stageKey, strategy: prepared.strategy, timeMapSource: prepared.timeMapSource, now: ctx.now(),
        rawFile: { file: path.posix.join('stages', ctx.dirName('transcribe'), transcribed.file), sha256: transcribed.sha256 }
      });
      assertTrackInvariants(track);
      await writeJsonAtomic(path.join(ctx.dir, 'transcript.json'), track);
      return { file: 'transcript.json', trackId: track.id, revision: track.revision, segments: track.segments.length, stats };
    }
  },
  {
    name: 'subtitles',
    key: (job, keys) => ({ inputIds: [keys.track], params: { layout: LAYOUT, vtt: job.options.vtt === true } }),
    async run(ctx) {
      const tracked = ctx.output('track');
      const track = JSON.parse(await fsp.readFile(ctx.file('track', tracked.file), 'utf8'));
      const { files, manifest } = buildSubtitleSet(track, { vtt: ctx.job.options.vtt === true });
      for (const [name, text] of Object.entries(files)) await writeFileAtomic(path.join(ctx.dir, name), text);
      await writeJsonAtomic(path.join(ctx.dir, 'subtitles.manifest.json'), manifest);
      // Publish the latest results next to the asset. Stage directories keep the immutable originals.
      await writeFileAtomic(path.join(ctx.assetDir, 'transcript.json'), await fsp.readFile(ctx.file('track', tracked.file)));
      for (const [name, text] of Object.entries(files)) await writeFileAtomic(path.join(ctx.assetDir, name), text);
      return { files: Object.keys(files), manifest: 'subtitles.manifest.json', recCues: manifest.rec.length, srcCues: manifest.src.length, srcOverlaps: manifest.srcOverlaps.length };
    }
  }
]);

/** Computes every stage key up front; a key depends only on upstream keys, never on upstream results. */
export function computeStageKeys(job, deps) {
  const keys = {};
  for (const stage of STAGES) {
    const { inputIds, inputRevisions = [], params } = stage.key(job, keys, deps);
    keys[stage.name] = createStageKey({ stage: stage.name, inputIds, inputRevisions, params, pipelineVersion: PIPELINE_VERSION });
  }
  return keys;
}

export const stageDirName = (name, stageKey) => `${name}-${stageKey.slice('sha256:'.length, 'sha256:'.length + 16)}`;
