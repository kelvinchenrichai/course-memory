import fsp from 'node:fs/promises';
import path from 'node:path';
import { createId } from '../domain/ids.mjs';
import { normalizeSpans } from '../domain/timemap.mjs';
import { assertAllowedPath, exists, hashFile, readJson, writeJsonAtomic } from './files.mjs';
import { redactText } from './process-runner.mjs';
import { LANGUAGES } from './transcript.mjs';
import { PIPELINE_VERSION, STAGES, computeStageKeys, stageDirName } from './stages.mjs';

/**
 * Pipeline job runner.
 *  - Job states: queued → running → completed | failed | cancelled. Stage states are the same five.
 *  - One job per media at a time (mediaKey lock); enqueueing media that already has an active job returns it.
 *  - Heavy stages (Whisper) share a semaphore, default 1 → GPU work is single-concurrency.
 *  - Every job/stage write is atomic. A failure keeps completed stages; retry() / recover() resume from the
 *    first unfinished stage. Stage results are deduplicated by stageKey across jobs and restarts.
 *  - Job documents keep local file paths (like RecordingSession). Events and logs never do.
 */

export class PipelineError extends Error {
  constructor(code, message) { super(message); this.name = 'PipelineError'; this.code = code; }
}

export const JOB_STATUSES = Object.freeze(['queued', 'running', 'completed', 'failed', 'cancelled']);
export const SOURCE_KINDS = Object.freeze(['audio', 'video', 'import']);
const TERMINAL = new Set(['completed', 'failed', 'cancelled']);
const MAX_EVENTS = 200;
const silent = { info() {}, warn() {}, error() {} };

function semaphore(limit) {
  let active = 0; const waiting = [];
  return {
    async acquire(signal) {
      if (active < limit) { active += 1; return; }
      await new Promise((resolve, reject) => {
        const entry = { resolve, reject }; waiting.push(entry);
        signal?.addEventListener?.('abort', () => { const index = waiting.indexOf(entry); if (index >= 0) { waiting.splice(index, 1); reject(new PipelineError('CANCELLED', '已取消')); } }, { once: true });
      });
      active += 1;
    },
    release() { active -= 1; const next = waiting.shift(); next?.resolve(); },
    get active() { return active; }
  };
}

export function createPipelineRunner({ dataDir, workRoot, allowedRoots = [], tools = {}, run, provider, logger = silent, now = () => new Date().toISOString(), concurrency = 2, heavyConcurrency = 1, autoStart = true, platform = process.platform, defaults = {} } = {}) {
  if (!dataDir || !workRoot || typeof run !== 'function' || !provider) throw new PipelineError('MISSING_DEPENDENCY', 'pipeline 缺少必要相依');
  const jobsDir = path.join(dataDir, 'jobs');
  const jobs = new Map(); const queue = []; const running = new Map(); const locks = new Map();
  const heavy = semaphore(Math.max(1, heavyConcurrency));
  const idleWaiters = []; let loaded = false;
  const deps = { provider };
  const toolset = { ffmpeg: tools.ffmpeg || 'ffmpeg', ffprobe: tools.ffprobe || 'ffprobe' };
  const assetDirOf = (job) => path.join(workRoot, 'assets', job.asset.id);

  const event = (job, name, extra = {}) => { job.events.push({ at: now(), event: name, ...extra }); if (job.events.length > MAX_EVENTS) job.events.splice(0, job.events.length - MAX_EVENTS); };
  async function persist(job) { job.updatedAt = now(); await writeJsonAtomic(path.join(jobsDir, `${job.id}.json`), job); }
  const snapshot = (job) => JSON.parse(JSON.stringify(job));

  async function load() {
    if (loaded) return; loaded = true;
    let names = []; try { names = await fsp.readdir(jobsDir); } catch {}
    for (const name of names.filter((item) => /^job_[0-9a-f]{12}\.json$/.test(item))) {
      const job = await readJson(path.join(jobsDir, name), null); if (job?.id) jobs.set(job.id, job);
    }
  }

  function settleIdle() { if (!running.size && !queue.length) for (const resolve of idleWaiters.splice(0)) resolve(); }

  function pump() {
    for (let index = 0; index < queue.length && running.size < concurrency;) {
      const job = jobs.get(queue[index]);
      if (!job || job.status !== 'queued') { queue.splice(index, 1); continue; }
      if (locks.has(job.mediaKey)) { index += 1; continue; }
      queue.splice(index, 1); locks.set(job.mediaKey, job.id);
      const controller = new AbortController();
      const promise = runJob(job, controller.signal).catch((error) => logger.error({ event: 'pipeline_internal_error', jobId: job.id, code: error?.code || 'ERROR' }))
        .finally(() => { running.delete(job.id); locks.delete(job.mediaKey); pump(); settleIdle(); });
      running.set(job.id, { controller, promise });
    }
    settleIdle();
  }

  async function stageCompletedOnDisk(dir, stageKey) {
    const record = await readJson(path.join(dir, 'stage.json'), null);
    if (!record || record.status !== 'completed' || record.stageKey !== stageKey) return null;
    for (const file of record.files || []) if (!(await exists(path.join(dir, file)))) return null;
    return record;
  }

  function filesOf(name, outputs) {
    if (name === 'subtitles') return [...outputs.files, outputs.manifest];
    if (name === 'prepare') return outputs.input?.stage === 'prepare' ? [outputs.input.file] : [];
    return ['audio', 'transcribe', 'track'].includes(name) ? [outputs.file] : [];
  }

  async function runJob(job, signal) {
    const assetDir = assetDirOf(job);
    job.status = 'running'; job.error = null; event(job, 'job_started'); await persist(job);
    logger.info({ event: 'pipeline_job_started', jobId: job.id, source: job.source.kind });
    for (const stage of STAGES) {
      const state = job.stages.find((item) => item.name === stage.name);
      const dirName = stageDirName(stage.name, state.stageKey); const dir = path.join(assetDir, 'stages', dirName);
      if (state.status === 'completed' && await stageCompletedOnDisk(dir, state.stageKey)) continue;
      const reused = await stageCompletedOnDisk(dir, state.stageKey);
      if (reused) { Object.assign(state, { status: 'completed', outputs: reused.outputs, reused: true, finishedAt: now(), error: null }); event(job, 'stage_reused', { stage: stage.name }); await persist(job); continue; }
      if (signal.aborted) return finishCancelled(job, state);
      Object.assign(state, { status: 'running', startedAt: now(), finishedAt: null, attempts: (state.attempts || 0) + 1, error: null, reused: false });
      job.currentStage = stage.name; event(job, 'stage_started', { stage: stage.name }); await persist(job);
      let acquired = false;
      try {
        await fsp.mkdir(dir, { recursive: true });
        if (stage.heavy) { await heavy.acquire(signal); acquired = true; }
        if (signal.aborted) throw new PipelineError('CANCELLED', '已取消');
        const ctx = {
          job, dir, assetDir, stageKey: state.stageKey, run, tools: toolset, provider, signal, now,
          dirName: (name) => stageDirName(name, job.stages.find((item) => item.name === name).stageKey),
          output: (name) => job.stages.find((item) => item.name === name).outputs,
          file: (name, file) => path.join(assetDir, 'stages', stageDirName(name, job.stages.find((item) => item.name === name).stageKey), file)
        };
        const outputs = await stage.run(ctx);
        await writeJsonAtomic(path.join(dir, 'stage.json'), { name: stage.name, stageKey: state.stageKey, pipelineVersion: PIPELINE_VERSION, status: 'completed', finishedAt: now(), files: filesOf(stage.name, outputs), outputs });
        Object.assign(state, { status: 'completed', finishedAt: now(), outputs });
        event(job, 'stage_completed', { stage: stage.name }); await persist(job);
      } catch (error) {
        if (signal.aborted || error?.code === 'CANCELLED') return finishCancelled(job, state);
        const code = typeof error?.code === 'string' && /^[A-Z][A-Z0-9_]{2,60}$/.test(error.code) ? error.code : 'STAGE_FAILED';
        const message = redactText(error?.message || code, { max: 300 });
        Object.assign(state, { status: 'failed', finishedAt: now(), error: { code, message } });
        job.status = 'failed'; job.error = { stage: stage.name, code, message }; job.currentStage = stage.name;
        event(job, 'stage_failed', { stage: stage.name, code }); await persist(job);
        logger.warn({ event: 'pipeline_stage_failed', jobId: job.id, stage: stage.name, code });
        return;
      } finally { if (acquired) heavy.release(); }
    }
    job.status = 'completed'; job.currentStage = null;
    const track = job.stages.find((item) => item.name === 'track').outputs; const subs = job.stages.find((item) => item.name === 'subtitles').outputs;
    job.result = { assetDir: path.relative(workRoot, assetDir).split(path.sep).join('/'), transcript: 'transcript.json', trackId: track.trackId, revision: track.revision, subtitles: subs.files };
    event(job, 'job_completed'); await persist(job);
    logger.info({ event: 'pipeline_job_completed', jobId: job.id });
  }

  async function finishCancelled(job, state) {
    if (state && state.status === 'running') Object.assign(state, { status: 'cancelled', finishedAt: now() });
    job.status = 'cancelled'; event(job, 'job_cancelled'); await persist(job);
  }

  function normalizeOptions(options = {}) {
    const language = options.language ?? defaults.language ?? 'auto';
    if (!LANGUAGES.includes(language)) throw new PipelineError('INVALID_OPTIONS', `language 必須是 ${LANGUAGES.join(' / ')}`);
    return { language, wordTimestamps: options.wordTimestamps ?? defaults.wordTimestamps ?? true, vtt: options.vtt ?? defaults.vtt ?? false };
  }

  function normalizeTimeMap(kind, timeMap) {
    const source = timeMap?.source ?? (kind === 'import' ? 'identity' : 'none');
    if (!['recording', 'identity', 'none'].includes(source)) throw new PipelineError('INVALID_TIMEMAP', 'timeMap.source 無效');
    if (source === 'recording') {
      try { return { source, spans: normalizeSpans(timeMap.spans).map(({ recStart, recEnd, srcStart, srcEnd, rate, kind: spanKind }) => ({ recStart, recEnd, srcStart, srcEnd, rate, kind: spanKind })) }; }
      catch (error) { throw new PipelineError('INVALID_TIMEMAP', error.message); }
    }
    if (source === 'identity' && kind !== 'import') throw new PipelineError('INVALID_TIMEMAP', '只有自有匯入檔可以假設 src = rec');
    return { source, spans: null };
  }

  const api = {
    async enqueue({ source, files, timeMap, options, recordingSessionId = null, title = null } = {}) {
      await load();
      const kind = source?.kind ?? source;
      if (!SOURCE_KINDS.includes(kind)) throw new PipelineError('INVALID_SOURCE', 'source 必須是 audio / video / import');
      if (!Array.isArray(files) || !files.length || files.length > 64) throw new PipelineError('INVALID_SOURCE', '需要 1–64 個輸入檔');
      const resolved = [];
      for (const item of files) {
        const input = typeof item === 'string' ? { path: item } : item;
        let real; try { real = await assertAllowedPath(input.path, allowedRoots, { platform }); } catch (error) { throw new PipelineError('PATH_NOT_ALLOWED', '輸入檔不在設定的資料夾內'); }
        const stat = await fsp.stat(real); if (!stat.isFile()) throw new PipelineError('INVALID_SOURCE', '輸入不是檔案');
        const sha256 = input.sha256 && /^[0-9a-f]{64}$/.test(input.sha256) && input.bytes === stat.size ? input.sha256 : await hashFile(real);
        resolved.push({ path: real, sha256, bytes: stat.size, mtimeMs: Math.trunc(stat.mtimeMs) });
      }
      const normalizedTimeMap = normalizeTimeMap(kind, timeMap);
      const normalizedOptions = normalizeOptions(options);
      const identity = resolved.map((file) => `${file.sha256}:${file.bytes}`).join('|');
      const assetId = createId('ast', identity); const mediaKey = assetId;
      const active = [...jobs.values()].find((job) => job.mediaKey === mediaKey && !TERMINAL.has(job.status));
      if (active) return { job: snapshot(active), deduplicated: true };
      const createdAt = now();
      const displayTitle = String(title || '').replace(/\s+/g, ' ').trim().slice(0, 120) || null;
      const job = {
        id: createId('job'), schemaVersion: 1, createdAt, updatedAt: createdAt, type: 'transcription', pipelineVersion: PIPELINE_VERSION,
        status: 'queued', source: { kind, recordingSessionId: recordingSessionId ?? null }, displayTitle, mediaKey,
        asset: { id: assetId, kind: kind === 'import' ? 'import' : 'recording', files: resolved },
        timeMap: normalizedTimeMap, options: normalizedOptions, currentStage: null, error: null, result: null, events: [], stages: []
      };
      const keys = computeStageKeys(job, deps);
      job.stages = STAGES.map((stage) => ({ name: stage.name, status: 'queued', stageKey: keys[stage.name], attempts: 0, outputs: null, error: null }));
      event(job, 'job_queued', { source: kind });
      jobs.set(job.id, job); await persist(job);
      queue.push(job.id); if (autoStart) pump();
      return { job: snapshot(job), deduplicated: false };
    },
    async get(id) { await load(); const job = jobs.get(id); if (!job) throw new PipelineError('JOB_NOT_FOUND', '找不到工作'); return snapshot(job); },
    async list() { await load(); return [...jobs.values()].map(snapshot).sort((a, b) => a.createdAt.localeCompare(b.createdAt)); },
    async cancel(id) {
      await load(); const job = jobs.get(id); if (!job) throw new PipelineError('JOB_NOT_FOUND', '找不到工作');
      if (TERMINAL.has(job.status)) return snapshot(job);
      const active = running.get(id);
      if (active) { active.controller.abort(); await active.promise; }
      else { job.status = 'cancelled'; event(job, 'job_cancelled'); await persist(job); }
      return snapshot(job);
    },
    /** Puts a failed / cancelled job back in the queue. Completed stages are kept and skipped. */
    async retry(id) {
      await load(); const job = jobs.get(id); if (!job) throw new PipelineError('JOB_NOT_FOUND', '找不到工作');
      if (!['failed', 'cancelled'].includes(job.status)) throw new PipelineError('INVALID_TRANSITION', `無法從 ${job.status} 重試`);
      const other = [...jobs.values()].find((item) => item.id !== id && item.mediaKey === job.mediaKey && !TERMINAL.has(item.status));
      if (other) throw new PipelineError('MEDIA_BUSY', '同一媒體已有進行中的工作');
      // The transcription engine may have changed since the job was queued (e.g. 自動 now falls back to
      // whisper.cpp). Unfinished stages take the keys of the current setup; finished stages keep theirs, so
      // probe/audio/prepare are reused and the media is never copied or extracted again.
      const keys = computeStageKeys(job, deps);
      for (const stage of job.stages) if (stage.status !== 'completed') {
        if (stage.stageKey !== keys[stage.name]) { stage.previousStageKey = stage.stageKey; stage.stageKey = keys[stage.name]; }
        Object.assign(stage, { status: 'queued', error: null });
      }
      job.status = 'queued'; job.error = null; event(job, 'job_retried'); await persist(job);
      queue.push(job.id); if (autoStart) pump();
      return snapshot(job);
    },
    /** After a restart: interrupted (running) jobs go back to queued and resume at their unfinished stage. */
    async recover() {
      await load(); const ids = [];
      for (const job of [...jobs.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt))) {
        if (job.status === 'running') {
          for (const stage of job.stages) if (stage.status === 'running') Object.assign(stage, { status: 'queued', interrupted: true });
          job.status = 'queued'; event(job, 'job_recovered'); await persist(job);
        }
        if (job.status === 'queued' && !queue.includes(job.id)) { queue.push(job.id); ids.push(job.id); }
      }
      if (autoStart) pump();
      return ids;
    },
    start() { pump(); },
    idle() { return !running.size && !queue.length ? Promise.resolve() : new Promise((resolve) => idleWaiters.push(resolve)); },
    get activeCount() { return running.size; },
    get heavyActive() { return heavy.active; }
  };
  return api;
}
