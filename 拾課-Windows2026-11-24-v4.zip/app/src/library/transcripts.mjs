import { checkLocalRequest } from '../settings/api.mjs';

const ITEM_ROUTE = /^\/api\/transcripts\/([a-z0-9_-]{4,64})\/(rename|trash|restore)$/i;
const TEXT_ROUTE = /^\/api\/transcripts\/([a-z0-9_-]{4,64})\/text$/i;

const duration = (course) => Math.max(0, Number(course?.segments?.at(-1)?.end) || 0);
const transcriptText = (course) => (course?.segments || []).map((segment) => String(segment?.text || '')).join(' ').trim();

export function transcriptSummary(course) {
  const text = transcriptText(course);
  const extension = String(course.video || course.sourceMedia || '').match(/\.([a-z0-9]{2,5})$/i)?.[1]?.toLowerCase() || null;
  const mediaKind = course.sourceKind === 'audio' || ['wav', 'flac', 'm4a', 'mp3', 'aac', 'ogg'].includes(extension) ? 'audio' : course.video || course.sourceMedia ? 'video' : 'none';
  return { id: course.id, title: String(course.title || '未命名逐字稿').slice(0, 120), createdAt: course.createdAt || null,
    updatedAt: course.updatedAt || course.createdAt || null, status: course.status || 'unknown', language: course.language || null,
    segmentCount: course.segments?.length || 0, chapterCount: course.chapters?.length || 0, duration: duration(course),
    characterCount: text.length, archived: Boolean(course.archived), trashed: Boolean(course.trashed),
    trashedAt: course.trashedAt || null, demo: Boolean(course.demo), mediaKind, mediaExtension: extension,
    hasTranscript: Boolean(course.segments?.length), hasKnowledge: Boolean(course.knowledge || course.chapters?.length) };
}

export function renameCourse(course, title, now = new Date().toISOString()) {
  const clean = String(title || '').replace(/\s+/g, ' ').trim();
  if (!clean || clean.length > 120) throw Object.assign(new Error('名稱需為 1～120 個字'), { code: 'INVALID_TITLE' });
  course.title = clean; course.updatedAt = now; return course;
}

export function setCourseTrashed(course, trashed, now = new Date().toISOString()) {
  if (trashed) {
    course.archivedBeforeTrash = Boolean(course.archived);
    Object.assign(course, { trashed: true, trashedAt: now, archived: true, archivedAt: course.archivedAt || now });
  } else {
    const wasArchived = Boolean(course.archivedBeforeTrash);
    delete course.trashed; delete course.trashedAt; delete course.archivedBeforeTrash;
    if (!wasArchived) { delete course.archived; delete course.archivedAt; }
  }
  course.updatedAt = now; return course;
}

export async function handleTranscriptLibraryRequest(ctx, request) {
  if (request.pathname === '/api/transcripts' && request.method === 'GET') {
    const rejected = checkLocalRequest(request, ctx.port);
    if (rejected) return { status: 403, body: { error: rejected, message: '只接受本機介面的請求' } };
    return { status: 200, body: ctx.courses().map(transcriptSummary) };
  }
  const textMatch = String(request.pathname || '').match(TEXT_ROUTE);
  if (textMatch && request.method === 'GET') {
    const rejected = checkLocalRequest(request, ctx.port);
    if (rejected) return { status: 403, body: { error: rejected, message: '只接受本機介面的請求' } };
    const course = ctx.courses().find((item) => item.id === textMatch[1]);
    if (!course) return { status: 404, body: { error: 'COURSE_NOT_FOUND', message: '找不到這筆逐字稿' } };
    return { status: 200, body: { id: course.id, title: String(course.title || '未命名逐字稿').slice(0, 120), text: transcriptText(course), segmentCount: course.segments?.length || 0 } };
  }
  const match = String(request.pathname || '').match(ITEM_ROUTE);
  if (!match || request.method !== 'POST') return null;
  const rejected = checkLocalRequest(request, ctx.port);
  if (rejected) return { status: 403, body: { error: rejected, message: '只接受本機介面的請求' } };
  const course = ctx.courses().find((item) => item.id === match[1]);
  if (!course || course.demo) return { status: 404, body: { error: 'COURSE_NOT_FOUND', message: '找不到可修改的逐字稿' } };
  const action = match[2].toLowerCase();
  if (action === 'rename') {
    try { renameCourse(course, request.body?.title, ctx.now?.() || new Date().toISOString()); }
    catch (error) { return { status: 400, body: { error: error.code || 'INVALID_TITLE', message: error.message } }; }
  } else {
    if (request.body?.confirm !== true) return { status: 400, body: { error: 'CONFIRM_REQUIRED', message: '請先確認這項操作' } };
    if (action === 'trash' && course.status === 'processing') return { status: 409, body: { error: 'COURSE_BUSY', message: '逐字稿仍在處理中，完成後才能移到垃圾桶' } };
    setCourseTrashed(course, action === 'trash', ctx.now?.() || new Date().toISOString());
  }
  await ctx.saveCourse(course);
  return { status: 200, body: transcriptSummary(course) };
}

