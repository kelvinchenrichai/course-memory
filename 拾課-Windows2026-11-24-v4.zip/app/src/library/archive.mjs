import { checkLocalRequest } from '../settings/api.mjs';

/**
 * 封存／取消封存 a library course. Archiving only hides the course from the 處理中心 and the default library
 * list: course.json, the transcript, the source recording and any cloud backup are kept untouched and nothing
 * is ever deleted. Needs `confirm: true` and a local same-origin request.
 *
 * ctx: { port, courses(): Course[], saveCourse(course): Promise<void>, now?(): string }
 */
export const ARCHIVE_ROUTE = /^\/api\/courses\/([a-z0-9_-]{4,64})\/(archive|unarchive)$/i;

export function setCourseArchived(course, archived, now = new Date().toISOString()) {
  if (archived) Object.assign(course, { archived: true, archivedAt: now });
  else { delete course.archived; delete course.archivedAt; }
  return course;
}

export async function handleCourseArchiveRequest(ctx, request) {
  const match = String(request.pathname || '').match(ARCHIVE_ROUTE);
  if (!match || request.method !== 'POST') return null;
  const rejected = checkLocalRequest(request, ctx.port);
  if (rejected) return { status: 403, body: { error: rejected, message: '只接受本機介面的請求' } };
  if (request.body?.confirm !== true) return { status: 400, body: { error: 'CONFIRM_REQUIRED', message: '請先確認；封存不會刪除任何檔案' } };
  const course = ctx.courses().find((item) => item.id === match[1]);
  if (!course || course.demo) return { status: 404, body: { error: 'COURSE_NOT_FOUND', message: '找不到課程' } };
  const archive = match[2].toLowerCase() === 'archive';
  if (archive && course.status === 'processing') return { status: 409, body: { error: 'COURSE_BUSY', message: '課程還在處理中，完成或失敗後才能封存' } };
  setCourseArchived(course, archive, ctx.now?.() || new Date().toISOString());
  await ctx.saveCourse(course);
  return { status: 200, body: { id: course.id, title: String(course.title || '').slice(0, 120), status: course.status, archived: Boolean(course.archived), archivedAt: course.archivedAt || null } };
}
