import crypto from 'node:crypto';
import fsp from 'node:fs/promises';
import path from 'node:path';

export const IMPORT_MEDIA_EXTENSIONS = Object.freeze(new Set(['.mp4', '.mkv', '.mov', '.webm', '.flv', '.ts', '.m4a', '.flac', '.wav', '.mp3', '.ogg', '.opus', '.aac']));
export const MAX_IMPORT_BYTES = 20 * 1024 ** 3;

export function normalizeImportName(raw) {
  let decoded;
  try { decoded = decodeURIComponent(String(raw || '')); } catch { decoded = String(raw || ''); }
  const original = decoded.normalize('NFKC').trim();
  if (!original || original !== path.basename(original) || /[\\/\0]/.test(original)) throw Object.assign(new Error('檔名不合法'), { code: 'INVALID_FILE_NAME' });
  const extension = path.extname(original).toLowerCase();
  if (!IMPORT_MEDIA_EXTENSIONS.has(extension)) throw Object.assign(new Error('只支援常見影片與音訊檔'), { code: 'UNSUPPORTED_MEDIA' });
  const stem = path.basename(original, path.extname(original)).replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/g, '').trim().slice(0, 140) || 'media';
  return `${stem}${extension}`;
}

async function uniqueTarget(folder, name) {
  const extension = path.extname(name); const stem = path.basename(name, extension);
  for (let index = 0; index < 1000; index += 1) {
    const suffix = index ? `-${index}` : '';
    const target = path.join(folder, `${stem}${suffix}${extension}`);
    try { await fsp.access(target); } catch { return target; }
  }
  throw Object.assign(new Error('同名檔案過多'), { code: 'IMPORT_NAME_CONFLICT' });
}

export async function receiveMediaImport({ request, importsFolder, maxBytes = MAX_IMPORT_BYTES }) {
  if (String(request.headers['x-rights-ack'] || '').toLowerCase() !== 'true') throw Object.assign(new Error('請先確認你有權處理這份素材'), { code: 'RIGHTS_REQUIRED', status: 400 });
  const declared = Number(request.headers['content-length']);
  if (Number.isFinite(declared) && declared > maxBytes) throw Object.assign(new Error('檔案超過 20 GB 上限'), { code: 'IMPORT_TOO_LARGE', status: 413 });
  const name = normalizeImportName(request.headers['x-file-name']);
  await fsp.mkdir(importsFolder, { recursive: true });
  const target = await uniqueTarget(importsFolder, name);
  const temporary = path.join(importsFolder, `.upload-${crypto.randomUUID()}.part`);
  const handle = await fsp.open(temporary, 'wx'); let bytes = 0;
  try {
    for await (const chunk of request) {
      bytes += chunk.length;
      if (bytes > maxBytes) throw Object.assign(new Error('檔案超過 20 GB 上限'), { code: 'IMPORT_TOO_LARGE', status: 413 });
      await handle.write(chunk);
    }
    if (!bytes) throw Object.assign(new Error('檔案是空的'), { code: 'EMPTY_IMPORT', status: 400 });
    await handle.close(); await fsp.rename(temporary, target);
    return { name: path.basename(target), bytes };
  } catch (error) {
    await handle.close().catch(() => {}); await fsp.unlink(temporary).catch(() => {}); throw error;
  }
}
