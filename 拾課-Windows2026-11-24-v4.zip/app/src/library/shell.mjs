import { spawn } from 'node:child_process';
import { checkLocalRequest } from '../settings/api.mjs';

/** Opens only the configured recordings folder. The browser never supplies or receives a path. */
export function createLibraryShell({ recordingsFolder, platform = process.platform, spawnProcess = spawn } = {}) {
  return {
    openRecordingsFolder() {
      if (platform !== 'win32') throw Object.assign(new Error('目前只支援 Windows 檔案總管'), { code: 'WINDOWS_ONLY' });
      const child = spawnProcess('explorer.exe', [recordingsFolder], { detached: true, stdio: 'ignore', windowsHide: false, shell: false });
      child.unref?.();
      return { ok: true };
    }
  };
}

export function handleLibraryShellRequest(ctx, request) {
  if (request.pathname !== '/api/library/open-recordings' || request.method !== 'POST') return null;
  const rejected = checkLocalRequest(request, ctx.port);
  if (rejected) return { status: 403, body: { error: rejected, message: '只接受本機介面的請求' } };
  try { return { status: 200, body: ctx.shell.openRecordingsFolder() }; }
  catch (error) { return { status: 409, body: { error: error.code || 'OPEN_FOLDER_FAILED', message: '無法開啟錄影資料夾，請從設定頁確認資料夾位置' } }; }
}
