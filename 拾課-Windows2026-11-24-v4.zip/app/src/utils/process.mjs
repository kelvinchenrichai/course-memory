import { spawn } from 'node:child_process';

export function runCommand(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { windowsHide: true, ...options });
    let stdout = '', stderr = '';
    child.stdout?.on('data', (chunk) => { stdout += chunk; options.onStdout?.(String(chunk)); });
    child.stderr?.on('data', (chunk) => { stderr += chunk; options.onStderr?.(String(chunk)); });
    child.on('error', reject);
    child.on('close', (code) => code === 0 ? resolve({ stdout: stdout.trim(), stderr: stderr.trim() }) : reject(new Error(stderr.slice(-2000) || `${command} exited with code ${code}`)));
  });
}

export async function commandExists(command) {
  try { await runCommand('where.exe', [command]); return true; } catch { return false; }
}
