import { redactText } from '../pipeline/process-runner.mjs';

/**
 * Translation providers (P6). Uses the provider the user chose in 設定 (`aiProvider`); it never falls back
 * to another provider, and never switches from local Ollama to an external service.
 *   ollama  → stays on this computer
 *   openai / gemini → sends transcript text to that external service with the user's own key
 * Keys are read from the live config at call time and only placed in request headers. Errors carry codes
 * only; response bodies and keys are never logged or returned.
 */

export class TranslationError extends Error {
  constructor(code, message, status = 409) { super(message); this.name = 'TranslationError'; this.code = code; this.status = status; }
}

export const TARGETS = Object.freeze(['none', 'zh-Hant', 'en']);
export const PROMPT_VERSION = 'translate-segments.v1';
const LANGUAGE_NAME = { 'zh-Hant': '繁體中文（台灣用詞）', en: 'English' };

export function buildPrompt({ sourceLanguage, targetLanguage, segments }) {
  return [
    `You are a professional subtitle translator. Translate every segment into ${LANGUAGE_NAME[targetLanguage]}.`,
    'Rules:',
    '1. Output ONE JSON object only: {"segments":[{"id":"…","text":"…"}]}. No other text.',
    '2. Return exactly the same ids, in exactly the same order, one output per input segment. Never merge, split, drop or add segments.',
    '3. Translate only what each segment says. Do not add facts, explanations, names or numbers that are not in that segment.',
    '4. Keep technical terms, product names and code in their original form when unsure.',
    `Source language: ${sourceLanguage || 'auto'}.`,
    `Input: ${JSON.stringify({ targetLanguage, segments })}`
  ].join('\n');
}

function parseObject(text) {
  if (typeof text !== 'string') throw new TranslationError('TRANSLATION_NOT_JSON', '模型沒有輸出 JSON');
  const body = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  let value; try { value = JSON.parse(body); } catch { throw new TranslationError('TRANSLATION_NOT_JSON', '模型輸出不是 JSON'); }
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TranslationError('TRANSLATION_NOT_JSON', '模型輸出不是 JSON 物件');
  return value;
}

const httpCode = (status) => (status === 401 || status === 403 ? 'TRANSLATION_AUTH_FAILED' : status === 429 ? 'TRANSLATION_RATE_LIMITED' : status === 404 ? 'TRANSLATION_MODEL_NOT_FOUND' : 'TRANSLATION_PROVIDER_ERROR');

export function createTranslationProvider(config, { fetch: fetchImpl = globalThis.fetch, timeoutMs = 120_000 } = {}) {
  const name = config.aiProvider || 'ollama';
  const model = name === 'ollama' ? config.ollamaModel || 'qwen2.5:7b' : name === 'openai' ? config.openaiModel || 'gpt-4.1-mini' : name === 'gemini' ? config.geminiModel || 'gemini-2.5-flash' : null;
  const external = name === 'openai' || name === 'gemini';
  const describe = () => ({ name, model: model ? String(model).slice(0, 80) : null, external });

  async function post(url, headers, body, signal) {
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), timeoutMs);
    const onAbort = () => controller.abort(); signal?.addEventListener?.('abort', onAbort, { once: true });
    try {
      const response = await fetchImpl(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal: controller.signal, redirect: 'error' });
      if (!response.ok) throw new TranslationError(httpCode(response.status), `翻譯服務回應 HTTP ${response.status}`);
      try { return await response.json(); } catch { throw new TranslationError('TRANSLATION_NOT_JSON', '翻譯服務回應不是 JSON'); }
    } catch (error) {
      if (error instanceof TranslationError) throw error;
      if (controller.signal.aborted) throw new TranslationError('TRANSLATION_TIMEOUT', '翻譯逾時');
      throw new TranslationError('TRANSLATION_UNAVAILABLE', name === 'ollama' ? '無法連線到本機 Ollama' : '無法連線到翻譯服務');
    } finally { clearTimeout(timer); signal?.removeEventListener?.('abort', onAbort); }
  }

  return {
    ...describe(), describe,
    /** Throws TRANSLATION_PROVIDER_DISABLED / TRANSLATION_KEY_MISSING before any network call. */
    assertReady() {
      if (name === 'none') throw new TranslationError('TRANSLATION_PROVIDER_DISABLED', '設定中已關閉 AI，無法翻譯；請到「設定」選擇 Ollama 或自備金鑰的服務');
      if (!['ollama', 'openai', 'gemini'].includes(name)) throw new TranslationError('TRANSLATION_PROVIDER_DISABLED', '不支援的 AI 提供者');
      if (external && config.externalTranscriptSharing !== 'confirmed') throw new TranslationError('TRANSLATION_EXTERNAL_CONSENT_REQUIRED', '尚未允許把逐字稿傳送給外部 AI，請先到「設定」確認');
      if (name === 'openai' && !config.openaiApiKey) throw new TranslationError('TRANSLATION_KEY_MISSING', '尚未設定 OpenAI 金鑰，請到「設定」輸入');
      if (name === 'gemini' && !config.geminiApiKey) throw new TranslationError('TRANSLATION_KEY_MISSING', '尚未設定 Gemini 金鑰，請到「設定」輸入');
    },
    async translateBatch({ sourceLanguage, targetLanguage, segments, temperature = 0.2, signal }) {
      this.assertReady();
      const prompt = buildPrompt({ sourceLanguage, targetLanguage, segments });
      try {
        if (name === 'ollama') {
          const data = await post(`${String(config.ollamaUrl || 'http://127.0.0.1:11434').replace(/\/+$/, '')}/api/generate`, {}, { model, prompt, stream: false, format: 'json', options: { temperature } }, signal);
          return parseObject(data?.response);
        }
        if (name === 'openai') {
          const data = await post(`${String(config.openaiBaseUrl || 'https://api.openai.com/v1').replace(/\/+$/, '')}/chat/completions`, { authorization: `Bearer ${config.openaiApiKey}` }, { model, temperature, response_format: { type: 'json_object' }, messages: [{ role: 'user', content: prompt }] }, signal);
          return parseObject(data?.choices?.[0]?.message?.content);
        }
        const data = await post(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, { 'x-goog-api-key': config.geminiApiKey }, { contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature, responseMimeType: 'application/json' } }, signal);
        return parseObject(data?.candidates?.[0]?.content?.parts?.map((part) => part.text || '').join(''));
      } catch (error) {
        if (error instanceof TranslationError) throw error;
        throw new TranslationError('TRANSLATION_PROVIDER_ERROR', redactText(error?.message || 'error', { max: 120 }));
      }
    }
  };
}

/**
 * The whole batch is rejected unless the output has exactly the input ids, in order, once each, with a
 * non-empty string for every one. Nothing is repaired or partially accepted.
 */
export function validateBatch(output, input) {
  const list = Array.isArray(output?.segments) ? output.segments : null;
  if (!list) throw new TranslationError('TRANSLATION_NOT_JSON', '模型輸出缺少 segments');
  const expected = input.map((segment) => segment.id); const ids = list.map((item) => item?.id);
  const seen = new Set();
  for (const id of ids) { if (seen.has(id)) throw new TranslationError('TRANSLATION_DUPLICATE_ID', `重複的段落 ${String(id).slice(0, 20)}`); seen.add(id); }
  const unknown = ids.find((id) => !expected.includes(id));
  if (unknown !== undefined) throw new TranslationError('TRANSLATION_UNKNOWN_ID', '模型回傳了不存在的段落');
  const missing = expected.find((id) => !seen.has(id));
  if (missing) throw new TranslationError('TRANSLATION_MISSING_ID', '模型漏掉了段落');
  if (ids.some((id, index) => id !== expected[index])) throw new TranslationError('TRANSLATION_ORDER_MISMATCH', '段落順序不一致');
  return list.map((item, index) => {
    const text = typeof item.text === 'string' ? item.text.trim() : '';
    const limit = input[index].text.length * 6 + 200;
    if (!text || text.length > limit) throw new TranslationError('TRANSLATION_BAD_TEXT', '段落翻譯為空或異常過長');
    return { id: item.id, text };
  });
}
