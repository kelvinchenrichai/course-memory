import path from 'node:path';
import { readJson } from '../pipeline/files.mjs';
import { checkLocalRequest } from '../settings/api.mjs';
import { TARGETS, TranslationError } from './provider.mjs';
import { sourceFromCourse } from './stage.mjs';

/**
 * P6 glue: which courses get translated into what, bilingual search, and the local API.
 * Preference order for a course produced by the P4A pipeline:
 *   1. the Agent task's translationLanguage (P5 console preferences, looked up via the RecordingSession)
 *   2. 設定 → 預設翻譯語言 (`translationLanguage`, default none)
 * `none` never calls a model. Automatic runs only start once per stageKey; a batch that needs a retry waits
 * for the user's「重試」. Only completed results are shown or searched.
 */

const COURSE = /^[A-Za-z0-9_-]{6,64}$/;
const clock = (seconds = 0) => { const n = Math.max(0, Math.floor(Number(seconds) || 0)); const h = Math.floor(n / 3600), m = Math.floor((n % 3600) / 60), s = n % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`; };

export function createTranslationService({ stage, config, dataDir, listCourses, listPipelineJobs = async () => [], listSessions = async () => [], logger = { warn() {} } }) {
  const attempted = new Set(); // stageKeys started automatically in this process

  async function trackFor(course) {
    if (!course.pipelineJobId) return null;
    const job = (await listPipelineJobs()).find((item) => item.id === course.pipelineJobId);
    if (typeof job?.result?.assetDir !== 'string') return null;
    const workRoot = path.resolve(dataDir, 'pipeline', 'work');
    const assetRoot = path.resolve(workRoot, job.result.assetDir);
    const relative = path.relative(workRoot, assetRoot);
    if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) return null;
    return readJson(path.join(assetRoot, 'transcript.json'), null);
  }

  /** P5 → P6: the Agent task's translation preference, resolved without touching the Agent runner. */
  async function preferenceFor(course) {
    if (course.pipelineJobId) {
      const job = (await listPipelineJobs()).find((item) => item.id === course.pipelineJobId);
      const session = job?.source?.recordingSessionId ? (await listSessions()).find((item) => item.id === job.source.recordingSessionId) : null;
      if (/^job_[0-9a-f]{12}$/.test(String(session?.agentJobId))) {
        const prefs = await readJson(path.join(dataDir, 'agent-console', `${session.agentJobId}.json`), null);
        if (TARGETS.includes(prefs?.translationLanguage)) return { target: prefs.translationLanguage, from: 'agent-task' };
      }
    }
    return { target: TARGETS.includes(config.translationLanguage) ? config.translationLanguage : 'none', from: 'settings' };
  }

  async function source(course) { return sourceFromCourse(course, await trackFor(course)); }
  const findCourse = async (courseId) => {
    if (!COURSE.test(String(courseId))) throw new TranslationError('INVALID_COURSE', '課程代碼不正確', 400);
    const course = (await listCourses()).find((item) => item.id === courseId);
    if (!course) throw new TranslationError('COURSE_NOT_FOUND', '找不到課程', 404);
    if (course.status !== 'ready') throw new TranslationError('COURSE_NOT_READY', '逐字稿完成後才能翻譯', 409);
    return course;
  };

  return {
    preferenceFor,
    /** User-initiated (viewer button or retry). Resumes from accepted batches. */
    async request(courseId, targetLanguage) {
      if (!TARGETS.includes(targetLanguage)) throw new TranslationError('INVALID_TARGET', '翻譯語言只能是 none、zh-Hant 或 en', 400);
      const course = await findCourse(courseId);
      const task = stage.translate(await source(course), targetLanguage);
      task.catch((error) => logger.warn({ event: 'translation_failed', courseId, code: error?.code || 'ERROR' }));
      return { started: targetLanguage !== 'none', targetLanguage };
    },
    /** Background pass: translate finished pipeline courses according to their preference, once per stageKey. */
    async autoPass() {
      for (const course of await listCourses()) {
        if (course.status !== 'ready' || course.demo || !course.pipelineJobId) continue;
        const { target } = await preferenceFor(course); if (target === 'none') continue;
        const src = await source(course); if (!src.segments.length) continue;
        const marker = `${course.id}:${target}:${src.sourceKey}`;
        if (attempted.has(marker)) continue; attempted.add(marker);
        await stage.translate(src, target).catch((error) => logger.warn({ event: 'translation_failed', courseId: course.id, code: error?.code || 'ERROR' }));
      }
    },
    async view(courseId, targetLanguage) {
      const course = await findCourse(courseId);
      const preference = await preferenceFor(course);
      if (!TARGETS.includes(targetLanguage) || targetLanguage === 'none') return { courseId, targetLanguage: 'none', preference: preference.target, state: 'none', segments: [] };
      const entry = await stage.read(courseId, targetLanguage);
      let status = entry?.status;
      // A run that was interrupted (app closed mid-way) left status "running" behind: offer a resume instead of spinning forever.
      if (status?.state === 'running' && !entry.running) status = { ...status, state: 'needs-retry', code: 'TRANSLATION_INTERRUPTED', failedBatch: (status.done ?? 0) + 1 };
      const state = entry?.running ? 'running' : status?.state === 'needs-retry' ? 'needs-retry' : entry?.result ? 'completed' : status?.state || 'none';
      const result = entry?.result;
      return {
        courseId, targetLanguage, preference: preference.target, state,
        code: state === 'needs-retry' ? status.code : null, failedBatch: state === 'needs-retry' ? status.failedBatch : null,
        progress: status ? { done: status.done ?? 0, total: status.batches ?? 0 } : null,
        provider: result?.provider || status?.provider || null, sourceLanguage: result?.sourceLanguage || null, method: result?.method || null,
        // A previous complete result stays visible even when a newer attempt needs a retry.
        segments: result ? result.segments.map(({ segmentId, translatedText }) => ({ segmentId, translatedText })) : []
      };
    },
    /** Bilingual search: original transcript + completed translations, each hit labelled with its language. */
    async search(query, { limit = 50 } = {}) {
      const q = String(query || '').trim().toLowerCase(); if (!q || q.length > 200) return [];
      const results = [];
      const hit = (course, segment, text, lang, language) => {
        const at = text.toLowerCase().indexOf(q); if (at < 0) return false;
        results.push({ courseId: course.id, title: String(course.title || '').slice(0, 200), segmentId: segment.id, start: segment.start, clock: clock(segment.start), excerpt: text.slice(Math.max(0, at - 35), at + q.length + 65), lang, language });
        return results.length >= limit;
      };
      for (const course of await listCourses()) {
        const segments = course.segments || []; const byId = new Map(segments.map((segment) => [segment.id, segment]));
        for (const segment of segments) if (hit(course, segment, String(segment.text || ''), 'original', course.language || null)) return results;
        if (!COURSE.test(String(course.id))) continue;
        for (const target of ['zh-Hant', 'en']) {
          const entry = await stage.read(course.id, target);
          for (const item of entry?.result?.segments || []) {
            const segment = byId.get(item.segmentId) || { id: item.segmentId, start: item.rec?.[0] ?? 0 };
            if (hit(course, segment, item.translatedText, 'translation', target)) return results;
          }
        }
      }
      return results;
    }
  };
}

const ROUTE = /^\/api\/translations\/(search|[A-Za-z0-9_-]{6,64})$/;
const json = (status, body) => ({ status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }, body });

/**
 *   GET  /api/translations/search?q=          → [{ courseId, title, segmentId, start, clock, excerpt, lang: original|translation, language }]
 *   GET  /api/translations/:courseId?target=  → { state, code, provider: { name, model, external }, segments: [{ segmentId, translatedText }] }
 *   POST /api/translations/:courseId { targetLanguage }  → start / resume (202)
 */
export async function handleTranslationRequest(ctx, request) {
  const match = request.pathname.match(ROUTE); if (!match) return null;
  const rejected = checkLocalRequest(request, ctx.port);
  if (rejected) return json(rejected === 'JSON_REQUIRED' ? 415 : 403, { error: rejected });
  try {
    if (match[1] === 'search' && request.method === 'GET') return json(200, await ctx.translations.search(request.query?.get?.('q')));
    if (match[1] !== 'search' && request.method === 'GET') return json(200, await ctx.translations.view(match[1], request.query?.get?.('target') || 'none'));
    if (match[1] !== 'search' && request.method === 'POST') { const body = request.body && typeof request.body === 'object' ? request.body : {}; return json(202, await ctx.translations.request(match[1], body.targetLanguage)); }
    return json(405, { error: 'METHOD_NOT_ALLOWED' });
  } catch (error) {
    const code = typeof error?.code === 'string' && /^[A-Z][A-Z0-9_]{2,60}$/.test(error.code) ? error.code : 'TRANSLATION_ERROR';
    return json(error?.status || 400, { error: code, message: typeof error?.message === 'string' && /[一-鿿]/.test(error.message) ? error.message.slice(0, 200) : '處理失敗' });
  }
}

export async function routeTranslationApis(ctx, req, res, url) {
  if (!ROUTE.test(url.pathname)) return false;
  let body;
  if (req.method === 'POST' && !checkLocalRequest({ method: req.method, headers: req.headers }, ctx.port)) {
    let size = 0; const chunks = [];
    try { for await (const chunk of req) { size += chunk.length; if (size > 16 * 1024) throw new Error('too large'); chunks.push(chunk); } body = size ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}; }
    catch { res.writeHead(400, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ error: 'BAD_JSON' })); return true; }
  }
  const result = await handleTranslationRequest(ctx, { method: req.method, pathname: url.pathname, query: url.searchParams, headers: req.headers, body });
  res.writeHead(result.status, result.headers); res.end(JSON.stringify(result.body));
  return true;
}
