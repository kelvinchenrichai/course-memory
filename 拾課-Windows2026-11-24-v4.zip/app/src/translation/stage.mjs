import crypto from 'node:crypto';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { createId, createStageKey } from '../domain/ids.mjs';
import { readJson, writeJsonAtomic } from '../pipeline/files.mjs';
import { PROMPT_VERSION, TARGETS, TranslationError, validateBatch } from './provider.mjs';

/**
 * Translation stage (P6). Input: the course's existing transcript segments (P4A TranscriptTrack ids and
 * rec/src times). Output: a versioned `cms.translation/1` JSON with one entry per source segment, same ids,
 * same times, same order.
 *
 * Layout (data/translations/<courseId>/):
 *   <target>-<key16>/batch-0001.json …   accepted batches (atomic; reused on resume)
 *   <target>-<key16>/status.json         running | needs-retry | completed (+ failed batch and code)
 *   <target>-<key16>/translation.json    the complete result for this stageKey
 *   <target>.json                        latest COMPLETE result shown in the UI; only replaced on success
 * stageKey = source track + revision + target + provider + model + prompt version + batching → identical
 * input is never translated twice. A rejected batch never overwrites anything already accepted.
 */

export const STAGE_VERSION = 'p6-1';
export const BATCH = Object.freeze({ maxSegments: 40, maxChars: 1500 });
const COURSE = /^[A-Za-z0-9_-]{6,64}$/;

export function splitBatches(segments, { maxSegments = BATCH.maxSegments, maxChars = BATCH.maxChars } = {}) {
  const batches = []; let current = []; let chars = 0;
  for (const segment of segments) {
    if (current.length && (current.length >= maxSegments || chars + segment.text.length > maxChars)) { batches.push(current); current = []; chars = 0; }
    current.push(segment); chars += segment.text.length;
  }
  if (current.length) batches.push(current);
  return batches;
}

/** Normalises a course / TranscriptTrack into the stage input. */
export function sourceFromCourse(course, track = null) {
  const segments = (track?.segments || course.segments || []).map((segment) => ({
    id: segment.id, rec: Array.isArray(segment.rec) ? segment.rec : [Number(segment.start) || 0, Number(segment.end) || Number(segment.start) || 0],
    src: Array.isArray(segment.src) ? segment.src : [null, null], text: String(segment.text || '').trim()
  })).filter((segment) => /^s[0-9]{4,}$/.test(String(segment.id)) && segment.text);
  const fingerprint = crypto.createHash('sha256').update(JSON.stringify(segments.map(({ id, text }) => [id, text]))).digest('hex');
  return { courseId: course.id, trackId: track?.id || null, revision: track?.revision || 1, sourceKey: track?.stageKey || `sha256:${fingerprint}`, language: track?.detectedLanguage || track?.language || course.language || 'auto', segments };
}

export function createTranslationStage({ dataDir, provider: providerOrFactory, now = () => new Date().toISOString(), logger = { info() {}, warn() {} }, batch = BATCH }) {
  const root = path.join(dataDir, 'translations');
  // A factory lets settings changes (provider / model / key) apply without a restart.
  const current = () => (typeof providerOrFactory === 'function' ? providerOrFactory() : providerOrFactory);
  const running = new Map();
  const dirFor = (courseId, target, key) => path.join(root, courseId, `${target}-${key.slice(7, 23)}`);

  function stageKeyFor(source, targetLanguage, provider = current()) {
    const p = provider.describe();
    return createStageKey({ stage: 'translate', inputIds: [source.sourceKey], inputRevisions: [source.revision], params: { targetLanguage, provider: p.name, model: p.model, prompt: PROMPT_VERSION, batch }, pipelineVersion: STAGE_VERSION });
  }

  async function run(source, targetLanguage) {
    const provider = current();
    if (!COURSE.test(String(source.courseId))) throw new TranslationError('INVALID_COURSE', '課程代碼不正確', 400);
    if (!TARGETS.includes(targetLanguage)) throw new TranslationError('INVALID_TARGET', '翻譯語言只能是 none、zh-Hant 或 en', 400);
    if (targetLanguage === 'none') return { status: 'skipped' };
    if (!source.segments.length) throw new TranslationError('TRANSCRIPT_EMPTY', '沒有可翻譯的逐字稿', 409);
    const sameLanguage = targetLanguage === 'en' && /^en/.test(source.language);
    const p = sameLanguage ? { name: 'identity', model: null, external: false } : provider.describe();
    const key = sameLanguage ? createStageKey({ stage: 'translate', inputIds: [source.sourceKey], inputRevisions: [source.revision], params: { targetLanguage, method: 'identity' }, pipelineVersion: STAGE_VERSION }) : stageKeyFor(source, targetLanguage, provider);
    const dir = dirFor(source.courseId, targetLanguage, key);
    const done = await readJson(path.join(dir, 'translation.json'), null);
    if (done?.stageKey === key) { await publish(source.courseId, targetLanguage, done); return { status: 'completed', reused: true, result: done }; }
    const batches = splitBatches(source.segments, batch);
    const setStatus = (value) => writeJsonAtomic(path.join(dir, 'status.json'), { stageKey: key, targetLanguage, provider: p, batches: batches.length, updatedAt: now(), ...value });
    if (!sameLanguage) {
      try { provider.assertReady(); }
      catch (error) { await setStatus({ state: 'needs-retry', done: 0, failedBatch: null, code: error.code }); return { status: 'needs-retry', code: error.code, failedBatch: null, batches: batches.length }; }
    }
    const translated = [];
    for (const [index, items] of batches.entries()) {
      const file = path.join(dir, `batch-${String(index + 1).padStart(4, '0')}.json`);
      const saved = await readJson(file, null);
      if (saved?.stageKey === key && Array.isArray(saved.segments) && saved.segments.length === items.length && saved.segments.every((item, i) => item.id === items[i].id)) { translated.push(...saved.segments); continue; }
      await setStatus({ state: 'running', done: index });
      let accepted = null; let lastError = null;
      if (sameLanguage) accepted = items.map(({ id, text }) => ({ id, text }));
      for (let attempt = 0; !accepted && attempt < 2; attempt += 1) {
        try { accepted = validateBatch(await provider.translateBatch({ sourceLanguage: source.language, targetLanguage, segments: items.map(({ id, text }) => ({ id, text })), temperature: attempt ? 0 : 0.2 }), items); }
        catch (error) {
          lastError = error;
          if (['TRANSLATION_KEY_MISSING', 'TRANSLATION_PROVIDER_DISABLED', 'TRANSLATION_EXTERNAL_CONSENT_REQUIRED', 'TRANSLATION_AUTH_FAILED', 'TRANSLATION_UNAVAILABLE'].includes(error.code)) break; // retrying now would not help
        }
      }
      if (!accepted) {
        const code = lastError instanceof TranslationError ? lastError.code : 'TRANSLATION_FAILED';
        await setStatus({ state: 'needs-retry', done: index, failedBatch: index + 1, code });
        logger.warn({ event: 'translation_batch_rejected', courseId: source.courseId, batch: index + 1, code });
        return { status: 'needs-retry', code, failedBatch: index + 1, batches: batches.length };
      }
      await writeJsonAtomic(file, { stageKey: key, index: index + 1, segments: accepted });
      translated.push(...accepted);
    }
    const byId = new Map(translated.map((item) => [item.id, item.text]));
    const at = now();
    const result = {
      schema: 'cms.translation/1', id: createId('trn', key), schemaVersion: 1, createdAt: at, updatedAt: at, courseId: source.courseId,
      sourceTrackId: source.trackId, sourceRevision: source.revision, sourceLanguage: source.language, targetLanguage,
      method: sameLanguage ? 'identity' : 'llm', provider: { name: p.name, model: p.model, external: p.external }, promptVersion: sameLanguage ? null : PROMPT_VERSION, stageKey: key,
      segments: source.segments.map((segment) => ({ segmentId: segment.id, rec: segment.rec, src: segment.src, translatedText: byId.get(segment.id) }))
    };
    if (result.segments.some((segment) => typeof segment.translatedText !== 'string')) throw new TranslationError('TRANSLATION_INCOMPLETE', '翻譯結果不完整');
    await writeJsonAtomic(path.join(dir, 'translation.json'), result);
    await setStatus({ state: 'completed', done: batches.length });
    await publish(source.courseId, targetLanguage, result);
    logger.info({ event: 'translation_completed', courseId: source.courseId, targetLanguage, provider: p.name });
    return { status: 'completed', result };
  }

  async function publish(courseId, target, result) {
    const file = path.join(root, courseId, `${target}.json`);
    const current = await readJson(file, null);
    if (current?.stageKey !== result.stageKey) await writeJsonAtomic(file, result);
  }

  return {
    stageKeyFor,
    /** Runs (or resumes) one course × target. Concurrent calls for the same pair share one run. */
    translate(source, targetLanguage) {
      const id = `${source.courseId}:${targetLanguage}`;
      if (running.has(id)) return running.get(id);
      const task = run(source, targetLanguage).finally(() => running.delete(id));
      running.set(id, task); return task;
    },
    /** Latest complete result (never a partial one) + the status of the most recent attempt. */
    async read(courseId, targetLanguage) {
      if (!COURSE.test(String(courseId)) || !TARGETS.includes(targetLanguage) || targetLanguage === 'none') return null;
      const result = await readJson(path.join(root, courseId, `${targetLanguage}.json`), null);
      let latest = null;
      try {
        for (const name of await fsp.readdir(path.join(root, courseId))) {
          if (!name.startsWith(`${targetLanguage}-`)) continue;
          const status = await readJson(path.join(root, courseId, name, 'status.json'), null);
          if (status && (!latest || String(status.updatedAt) > String(latest.updatedAt))) latest = status;
        }
      } catch {}
      return { result, status: latest, running: running.has(`${courseId}:${targetLanguage}`) };
    },
    async languages(courseId) {
      const out = [];
      for (const target of ['zh-Hant', 'en']) { const entry = await this.read(courseId, target); if (entry?.result) out.push({ targetLanguage: target, result: entry.result }); }
      return out;
    }
  };
}
