import crypto from 'node:crypto';
import { createId } from '../domain/ids.mjs';
import { RIGHTS_BASES, validateRights } from '../services/rights.mjs';
import { platformForHost, platformView } from '../discovery/platforms.mjs';

/**
 * P5 "Agent 學習" console — a thin bridge over the existing Agent service (P3A Runner + P3B Companion).
 * It only turns a friendly form into the Runner's draft input, adds estimates and plain-language status,
 * and creates the private-study rights record when (and only when) the user ticks both confirmations.
 * It never talks to the page, never reads cookies, passwords or media URLs, and never resumes by itself.
 */

export class ConsoleError extends Error {
  constructor(code, message, status = 400) { super(message); this.name = 'ConsoleError'; this.code = code; this.status = status; }
}

export const RATES = Object.freeze([1, 1.25, 1.5, 1.75, 2]);
export const TRANSCRIPT_LANGUAGES = Object.freeze(['auto', 'zh-Hant', 'zh-Hans', 'en']);
export const TRANSLATION_LANGUAGES = Object.freeze(['none', 'zh-Hant', 'en']);
export const CAPTION_LANGUAGES = Object.freeze(['zh-Hant', 'zh-Hans', 'zh', 'en', 'ja', 'ko']);
const LIMITS = { courses: 20, lessonsPerCourse: 200, totalLessons: 300, title: 120 };
// Estimates (shown as estimates): OBS 1080p ≈ 3 GB per recorded hour; FLAC stereo ≈ 0.35 GB per hour.
export const ESTIMATE = Object.freeze({ videoGbPerHour: 3, audioGbPerHour: 0.35, overheadSecPerLesson: 45 });

const MEDIA_PATH = /\.(mp4|m4v|m4a|mp3|webm|mkv|mov|m3u8|mpd|ts|flv|wav|aac|ogg|opus)$/i;
const MEDIA_HOST = /(^|\.)(googlevideo\.com|akamaized\.net|cloudfront\.net|vimeocdn\.com|bilivideo\.com)$/i;
const YOUTUBE_HOSTS = new Set(['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be']);
const YOUTUBE_ID = /^[A-Za-z0-9_-]{11}$/;

/**
 * Accepts a course PAGE address the user is allowed to watch. Rejects direct media files / CDN links,
 * credentials in the URL, non-http(s) schemes. YouTube pages map to the video id the YouTube adapter reports.
 */
export function parseLessonUrl(value) {
  if (typeof value !== 'string' || !value.trim() || value.length > 2000) throw new ConsoleError('INVALID_URL', '網址不正確');
  let url; try { url = new URL(value.trim()); } catch { throw new ConsoleError('INVALID_URL', '網址不正確'); }
  if (!['https:', 'http:'].includes(url.protocol)) throw new ConsoleError('INVALID_URL', '只接受 http／https 課程頁網址');
  if (url.username || url.password) throw new ConsoleError('INVALID_URL', '網址不可包含帳號或密碼');
  if (MEDIA_PATH.test(url.pathname) || MEDIA_HOST.test(url.hostname)) throw new ConsoleError('MEDIA_URL_NOT_ALLOWED', '請貼「課程頁面」網址，不要貼影片檔或串流網址');
  url.hash = '';
  if (YOUTUBE_HOSTS.has(url.hostname)) {
    const id = url.hostname === 'youtu.be' ? url.pathname.slice(1).split('/')[0] : url.pathname === '/watch' ? url.searchParams.get('v') : (url.pathname.match(/^\/(?:shorts|live|embed)\/([^/]+)/) || [])[1];
    if (!YOUTUBE_ID.test(String(id))) throw new ConsoleError('INVALID_URL', 'YouTube 網址需要指向單一影片');
    const list = url.searchParams.get('list');
    const canonical = new URL('https://www.youtube.com/watch'); canonical.searchParams.set('v', id); if (list && /^[A-Za-z0-9_-]{2,64}$/.test(list)) canonical.searchParams.set('list', list);
    return { url: canonical.toString(), platform: 'youtube', platformLessonId: id, host: 'www.youtube.com' };
  }
  for (const key of [...url.searchParams.keys()]) if (/token|auth|sig|signature|key|session|cookie|password/i.test(key)) throw new ConsoleError('INVALID_URL', '網址含有登入或簽章參數，請改貼一般課程頁網址');
  const normalized = url.toString();
  return { url: normalized, platform: 'other', platformLessonId: `web-${crypto.createHash('sha1').update(normalized).digest('hex').slice(0, 12)}`, host: url.hostname };
}

/** What each platform can do through the Companion. "需要你操作" is shown instead of pretending. */
export function platformNotes(platform) {
  if (platform === 'youtube') return { label: 'YouTube', automatic: ['開啟影片', '倍速', '字幕（CC）', '播放／暫停', '偵測登入與年齡驗證畫面'], needsYou: ['第一次使用前，在擴充功能允許 youtube.com'] };
  return { label: '其他網站', automatic: ['播放／暫停', '倍速（標準 HTML5 播放器）'], needsYou: ['第一次使用前，在擴充功能允許這個網站', '登入、付款、驗證畫面無法自動偵測：出現時 Agent 會停下來，需要你在瀏覽器處理', '字幕（CC）只有網站提供標準字幕軌時才能自動開啟'] };
}

const cleanTitle = (value, fallback) => (typeof value === 'string' && value.trim() ? value.trim().replace(/\s+/g, ' ').slice(0, LIMITS.title) : fallback);

/**
 * Form → Runner draft input. courses: [{ title, rightsBasis?, lessons: [{ url, title?, minutes? }], from?, to? }]
 * from/to are 1-based positions ("第 N 部 ～ 第 M 部").
 */
export function buildDraftInput(form = {}) {
  const mode = form.captureMode; if (!['video', 'audio'].includes(mode)) throw new ConsoleError('INVALID_PLAN', '請選擇錄影或純錄音');
  const rate = Number(form.rate); if (!RATES.includes(rate)) throw new ConsoleError('INVALID_PLAN', '倍速只能是 1、1.25、1.5、1.75 或 2');
  const transcriptLanguage = form.transcriptLanguage ?? 'auto'; if (!TRANSCRIPT_LANGUAGES.includes(transcriptLanguage)) throw new ConsoleError('INVALID_PLAN', '逐字稿語言不正確');
  const translationLanguage = form.translationLanguage ?? 'none'; if (!TRANSLATION_LANGUAGES.includes(translationLanguage)) throw new ConsoleError('INVALID_PLAN', '翻譯語言不正確');
  const captionsEnabled = form.captions?.enabled === true;
  const captionLanguages = Array.isArray(form.captions?.languages) ? form.captions.languages.filter((item) => CAPTION_LANGUAGES.includes(item)).slice(0, 3) : [];
  if (!Array.isArray(form.courses) || !form.courses.length || form.courses.length > LIMITS.courses) throw new ConsoleError('INVALID_PLAN', `請加入 1–${LIMITS.courses} 個課程`);
  const items = []; const meta = []; let total = 0;
  for (const [courseIndex, course] of form.courses.entries()) {
    if (!Array.isArray(course?.lessons) || !course.lessons.length || course.lessons.length > LIMITS.lessonsPerCourse) throw new ConsoleError('INVALID_PLAN', `第 ${courseIndex + 1} 個課程需要 1–${LIMITS.lessonsPerCourse} 部影片`);
    const basis = course.rightsBasis ?? 'personal-study'; if (!RIGHTS_BASES.includes(basis)) throw new ConsoleError('INVALID_PLAN', '授權依據不正確');
    const seen = new Set();
    const lessons = course.lessons.map((lesson, index) => {
      const parsed = parseLessonUrl(lesson?.url);
      if (seen.has(parsed.platformLessonId)) throw new ConsoleError('DUPLICATE_LESSON', `第 ${courseIndex + 1} 個課程有重複的影片`); seen.add(parsed.platformLessonId);
      const minutes = Number(lesson?.minutes);
      return { platformLessonId: parsed.platformLessonId, url: parsed.url, title: cleanTitle(lesson?.title, `第 ${index + 1} 部（${parsed.platform === 'youtube' ? 'YouTube' : parsed.host}）`), ...(Number.isFinite(minutes) && minutes > 0 && minutes <= 24 * 60 ? { durationSec: Math.round(minutes * 60) } : {}), platform: parsed.platform };
    });
    const from = course.from == null ? 1 : Number(course.from); const to = course.to == null ? lessons.length : Number(course.to);
    if (!Number.isInteger(from) || !Number.isInteger(to) || from < 1 || to > lessons.length || from > to) throw new ConsoleError('INVALID_RANGE', `第 ${courseIndex + 1} 個課程的章節範圍不正確`);
    total += to - from + 1; if (total > LIMITS.totalLessons) throw new ConsoleError('INVALID_PLAN', `一次最多 ${LIMITS.totalLessons} 部影片`);
    const courseId = createId('crs', lessons.map((lesson) => lesson.platformLessonId).join('|'));
    // Include the declared basis so a prior, broader record can never be silently reused after the
    // user changes this course to personal-study (or vice versa).
    const rightsId = createId('rts', `console:${courseId}:${basis}`);
    items.push({ courseId, rightsId, lessons: lessons.map(({ platform, ...lesson }) => lesson), from: { order: from }, to: { order: to } });
    meta.push({ courseId, rightsId, title: cleanTitle(course.title, `課程 ${courseIndex + 1}`), rightsBasis: basis, platforms: [...new Set(lessons.map((lesson) => lesson.platform))], hosts: [...new Set(lessons.map((lesson) => (lesson.platform === 'youtube' ? 'www.youtube.com' : new URL(lesson.url).hostname)))], from, to, count: to - from + 1 });
  }
  return {
    draft: { items, captureMode: mode, rate, captions: { enabled: captionsEnabled, languages: captionsEnabled ? (captionLanguages.length ? captionLanguages : ['zh-Hant', 'en']) : [] }, markComplete: false, cloudBackup: { enabled: false } },
    preferences: { transcriptLanguage, translationLanguage, courses: meta }
  };
}

/** Estimates for the confirmation card. Durations the user did not give are reported as unknown. */
export function estimatePlan(plan, { freeBytes = null } = {}) {
  const lessons = plan.lessons.filter((lesson) => !lesson.skip);
  const known = lessons.filter((lesson) => Number.isFinite(lesson.durationSec));
  const sourceSec = known.reduce((sum, lesson) => sum + lesson.durationSec, 0);
  const recordSec = sourceSec / plan.rate;
  const totalSec = recordSec + lessons.length * ESTIMATE.overheadSecPerLesson;
  const gbPerHour = plan.captureMode === 'audio' ? ESTIMATE.audioGbPerHour : ESTIMATE.videoGbPerHour;
  const bytes = Math.round((recordSec / 3600) * gbPerHour * 1024 ** 3);
  return {
    lessons: lessons.length, skipped: plan.lessons.length - lessons.length, unknownDurations: lessons.length - known.length,
    sourceSeconds: Math.round(sourceSec), recordSeconds: Math.round(recordSec), totalSeconds: Math.round(totalSec), bytes,
    freeBytes: Number.isFinite(freeBytes) ? freeBytes : null, spaceOk: Number.isFinite(freeBytes) ? bytes < freeBytes : null,
    basis: `錄製時間 = 影片長度 ÷ ${plan.rate} 倍速；每部另加約 ${ESTIMATE.overheadSecPerLesson} 秒準備。${plan.captureMode === 'audio' ? '錄音' : '錄影'}約 ${gbPerHour} GB／小時。`
  };
}

/** Creates the private-study rights record only after both confirmations are ticked. Existing records are kept. */
export async function ensureRights({ store, preferences, acknowledgements, now }) {
  if (acknowledgements?.recordPermission !== true || acknowledgements?.privateProcessing !== true) throw new ConsoleError('RIGHTS_REQUIRED', '請先勾選兩項授權確認', 403);
  for (const course of preferences.courses) {
    if (await store.readRights(course.rightsId)) continue;
    const record = validateRights({ id: course.rightsId, basis: course.rightsBasis, acknowledged: true, privateTransformAllowed: true, allowDerivative: false, note: 'Agent 學習：私人學習用途' }, { now });
    await store.saveRights(record);
  }
}

const BLOCKERS = {
  DOM_CHANGED: ['網站的播放器畫面改版了', 'Agent 找不到原本的按鈕，所以停下來。請在瀏覽器確認影片能正常播放，再按「繼續」；若一直出現，可能要等程式更新。'],
  LOGIN_REQUIRED: ['平台要求登入', '請你自己在瀏覽器登入（Agent 不會代為登入、也不會讀取密碼），登入完成後按「繼續」。'],
  CAPTCHA: ['平台要求驗證（我不是機器人）', '請你在瀏覽器完成驗證後按「繼續」。Agent 不會嘗試破解驗證。'],
  PAYMENT_PROMPT: ['平台要求付款或訂閱', '這部影片需要付費或訂閱才能觀看。Agent 不會處理付款或繞過付費牆；確認有權觀看後再按「繼續」，或取消這個任務。'],
  PAYWALL: ['平台要求付款或訂閱', '這部影片需要付費或訂閱才能觀看。Agent 不會處理付款或繞過付費牆；確認有權觀看後再按「繼續」，或取消這個任務。'],
  NETWORK_OFFLINE: ['網路中斷', '已安全停止並保存進度。網路恢復後按「繼續」。'],
  COMPANION_DISCONNECTED: ['瀏覽器擴充功能斷線', '請確認瀏覽器開著、擴充功能已連線並選好分頁，然後按「繼續」。'],
  BUFFERING_TIMEOUT: ['影片一直在緩衝', '可能是網路太慢。確認影片能播放後按「繼續」。'],
  MEDIA_ERROR: ['影片播放錯誤', '請在瀏覽器重新整理頁面，確認能播放後按「繼續」。'],
  PLAYER_NOT_FOUND: ['找不到播放器', '請確認分頁停在課程影片頁面（不是首頁或登入頁），然後按「繼續」。'],
  AMBIGUOUS_PLAYER: ['頁面上有多個播放器', 'Agent 無法判斷要看哪一個。請關閉其他影片或改用單一影片頁面。'],
  UNEXPECTED_LESSON: ['頁面跳到計畫外的影片', '請回到正確的影片頁面後按「繼續」。'],
  PLAYBACK_BLOCKED: ['瀏覽器擋下了自動播放', '請在課程頁面上自己按一次播放，再回來按「繼續」。'],
  PLAYER_PAUSED_EXTERNALLY: ['影片被手動暫停', '準備好後按「繼續」。'],
  LESSON_TIMEOUT: ['這部影片比預期久很多', '已安全停止。請確認影片狀態後按「繼續」。'],
  USER_PAUSED: ['你已暫停', '已安全停止並保存進度。準備好後按「繼續」。'],
  SERVER_RESTARTED: ['程式重新啟動', '為了安全，Agent 不會自動繼續播放或錄影。請確認瀏覽器與錄影狀態後按「繼續」。'],
  RIGHTS_REQUIRED: ['缺少授權確認', '請重新建立任務並勾選授權確認。'],
  DISK_LOW: ['磁碟空間不足', '請清出空間（或到「雲端備份」清理已備份的檔案）後按「繼續」。'],
  OBS_DISCONNECTED: ['OBS 連線中斷', '請確認 OBS 開著並啟用 WebSocket，必要時在 OBS 手動停止錄影，然後按「繼續」。'],
  OBS_ALREADY_RECORDING: ['OBS 已經在錄影', '請先在 OBS 停止原本的錄影，再按「繼續」。'],
  OBS_START_UNCONFIRMED: ['OBS 沒有確認開始錄影', '請看 OBS 畫面確認狀態，必要時手動停止，再按「繼續」。'],
  OBS_STOP_UNCONFIRMED: ['OBS 沒有確認停止錄影', '請到 OBS 確認是否仍在錄影，然後按「繼續」。'],
  CAPTURE_STOPPED_EXTERNALLY: ['錄製被外部停止', '已保存錄到的部分。確認錄影／錄音工具正常後按「繼續」。'],
  CAPTURE_PAUSED_EXTERNALLY: ['錄製被外部暫停', '請在錄影工具恢復後按「繼續」。'],
  AUDIO_DEVICE_UNAVAILABLE: ['找不到選定的音訊裝置', '請到「設定」重新選擇音訊裝置後按「繼續」。'],
  FFMPEG_UNAVAILABLE: ['找不到 ffmpeg', '請先執行 Setup.ps1 安裝後按「繼續」。'],
  AUDIO_CAPTURE_FAILED: ['錄音無法開始', '請確認裝置沒有被其他程式佔用後按「繼續」。']
};

export function describeBlocker(code) {
  const [title, next] = BLOCKERS[code] || ['Agent 已停下來', '請確認瀏覽器與錄製狀態後按「繼續」，或取消任務。'];
  return { code: /^[A-Z][A-Z0-9_]{2,60}$/.test(String(code)) ? code : 'UNKNOWN', title, next, needsYou: true };
}

const STATUS_TEXT = { draft: '草稿', 'awaiting-confirmation': '等待你確認', queued: '準備開始', preparing: '準備下一部', running: '觀看與錄製中', stopping: '安全停止中', completed: '已完成', blocked: '需要你處理', failed: '失敗', cancelled: '已取消' };
const num = (value) => (typeof value === 'number' && Number.isFinite(value) ? Math.round(value * 10) / 10 : null);

/**
 * Plain-language live view. Only allow-listed fields: no URLs, no cookies/tokens, no file paths.
 */
export function liveView(job, { preferences = null, companion = null, now = Date.now() } = {}) {
  const plan = job.plan; const lessons = plan.lessons; const done = new Set(job.checkpoint?.completedLessonIds || []);
  const active = lessons.filter((lesson) => !lesson.skip);
  const index = Number.isInteger(job.checkpoint?.lessonIndex) ? job.checkpoint.lessonIndex : lessons.findIndex((lesson) => !lesson.skip && !done.has(lesson.lessonId));
  const lesson = index >= 0 ? lessons[index] : null;
  const courseMeta = preferences?.courses?.find((course) => course.courseId === lesson?.courseId);
  const state = companion?.latestState && lesson && companion.latestState.lessonId === lesson.platformLessonId && (companion.latestState.ageMs ?? Infinity) < 10_000 ? companion.latestState : null;
  const live = ['preparing', 'running'].includes(job.status);
  const started = live ? [...(job.events || [])].reverse().find((event) => event.type === 'capture_started') : null;
  const startedAt = started ? Date.parse(started.at) : NaN;
  return {
    id: job.id, status: job.status, statusText: STATUS_TEXT[job.status] || job.status, createdAt: job.createdAt, updatedAt: job.updatedAt,
    captureMode: plan.captureMode, modeText: plan.captureMode === 'audio' ? '純錄音' : '錄影', rate: plan.rate, captions: plan.captionsEnabled ? plan.captions : [],
    transcriptLanguage: preferences?.transcriptLanguage || 'auto', translationLanguage: preferences?.translationLanguage || 'none',
    courses: (preferences?.courses || []).map(({ courseId, title, count, platforms }) => ({ courseId, title, count, platforms })),
    progress: { done: active.filter((item) => done.has(item.lessonId)).length, total: active.length, skipped: lessons.length - active.length },
    current: lesson ? {
      index: index + 1, lessonTitle: lesson.title, courseTitle: courseMeta?.title || null,
      sourceTime: num(state?.currentTime) ?? num(job.checkpoint?.sourceTime), duration: num(state?.duration) ?? (Number.isFinite(lesson.durationSec) ? lesson.durationSec : null),
      recordingSeconds: live && Number.isFinite(startedAt) ? Math.max(0, Math.round((now - startedAt) / 1000)) : null,
      playerRate: num(state?.rate), paused: state ? state.paused === true : null, buffering: state ? state.buffering === true : null,
      // P8: what the user sees while away — CC, platform, recording state and the next planned lesson.
      captionsOn: state?.captions ? state.captions.on === true : null, captionsAvailable: state?.captions ? state.captions.available === true : null,
      platform: hostOf(lesson.url) ? platformView(platformForHost(hostOf(lesson.url))).label : null,
      recording: live && Number.isFinite(startedAt) ? (job.status === 'running' ? 'recording' : 'starting') : job.status === 'blocked' && job.blocker?.obsMayStillBeRecording ? 'maybe' : 'idle'
    } : null,
    next: nextOf(lessons, index, done),
    automation: lesson && hostOf(lesson.url) ? (({ automatic, needsUser, label }) => ({ platform: label, automatic, needsUser }))(platformView(platformForHost(hostOf(lesson.url)))) : null,
    checkpoint: job.checkpoint ? { savedAt: job.checkpoint.savedAt, subState: job.checkpoint.subState, lessonIndex: (job.checkpoint.lessonIndex ?? 0) + 1, completed: (job.checkpoint.completedLessonIds || []).length } : null,
    blocker: job.status === 'blocked' && job.blocker ? describeBlocker(job.blocker.code) : null,
    obsMayStillBeRecording: job.status === 'blocked' && job.blocker?.obsMayStillBeRecording === true,
    actions: {
      start: job.status === 'queued',
      pause: live, resume: job.status === 'blocked', cancel: ['draft', 'awaiting-confirmation', 'queued', 'preparing', 'running', 'blocked'].includes(job.status)
    }
  };
}

const hostOf = (url) => { try { return new URL(url).hostname; } catch { return null; } };
function nextOf(lessons, index, done) {
  for (let i = Math.max(0, index + 1); i < lessons.length; i += 1) if (!lessons[i].skip && !done.has(lessons[i].lessonId)) return { index: i + 1, title: lessons[i].title };
  return null;
}
/** P8 Companion needs at least this extension version (Bilibili adapter, page blockers, read-only test). */
export const MIN_EXTENSION_VERSION = '0.5.0';
const versionAtLeast = (value, min) => { const a = String(value || '').split('.').map(Number); const b = min.split('.').map(Number); for (let i = 0; i < 3; i += 1) { if ((a[i] || 0) !== b[i]) return (a[i] || 0) > b[i]; } return true; };

/** Companion status reduced to what the UI needs (no tab URLs, no tokens). */
export function companionView(status) {
  if (!status) return { paired: false, connected: false, tabSelected: false, browserOnline: null, adapter: null };
  const tab = (status.tabs || []).find((item) => item.bound);
  let site = null; try { site = tab?.origin ? new URL(tab.origin).hostname : null; } catch { site = null; }
  const platform = site ? platformView(platformForHost(site)) : null;
  return {
    paired: Boolean(status.paired), connected: Boolean(status.connected), tabSelected: Boolean(tab), site, sitePermission: tab ? tab.permissionGranted !== false : null, browserOnline: status.browserOnline ?? null, adapter: status.latestState?.adapterId ?? null,
    extensionVersion: typeof status.extensionVersion === 'string' ? status.extensionVersion.slice(0, 20) : null,
    extensionOk: status.extensionVersion ? versionAtLeast(status.extensionVersion, MIN_EXTENSION_VERSION) : null, minExtensionVersion: MIN_EXTENSION_VERSION,
    platform: platform ? { id: platform.id, label: platform.label, discovery: platform.discovery } : null,
    playerBlocker: status.latestState?.blocker ? describeBlocker(status.latestState.blocker) : null
  };
}

/**
 *「測試連線」result: only Companion `detect` + `getState` (both read-only). Never plays, pauses, seeks,
 * records or navigates. Returned fields are display-only; no URLs.
 */
export function companionTestView({ detect, state, error = null, status = null, now = Date.now() }) {
  const companion = companionView(status);
  if (error) return { ok: false, testedAt: new Date(now).toISOString(), readOnly: true, companion, error: { code: error.code, ...describeCompanionError(error.code) } };
  const platformId = state?.platform || detect?.platform || (companion.site ? platformForHost(companion.site) : 'generic');
  const platform = platformView(platformId);
  const blockerCode = state?.blocker || detect?.blocker || (detect && !detect.ok ? detect.stop || detect.reason : null);
  const caps = state?.capabilities || detect?.capabilities || {};
  return {
    ok: Boolean(detect?.ok) && !blockerCode, testedAt: new Date(now).toISOString(), readOnly: true, companion,
    adapter: state?.adapterId || detect?.adapterId || null, platform: { id: platform.id, label: platform.label, automatic: platform.automatic, needsUser: platform.needsUser },
    player: state && !state.blocker ? { found: true, title: state.title || null, currentTime: num(state.currentTime), duration: num(state.duration), rate: num(state.rate), paused: state.paused ?? null, captions: state.captions || null, isPlaylist: state.isPlaylist ?? null } : { found: false },
    capabilities: { play: caps.play === true, pause: caps.pause === true, setRate: caps.setRate === true, captions: caps.captions === true, nextLesson: caps.nextLesson === true, blockerDetection: caps.blockerDetection === true },
    blocker: blockerCode ? describeBlocker(blockerCode) : null
  };
}

const COMPANION_ERROR_TEXT = {
  COMPANION_NOT_PAIRED: ['擴充功能尚未配對', '先依步驟 1、2 安裝並配對 Course Memory Companion。'],
  COMPANION_UNPAIRED: ['擴充功能已解除配對', '請重新產生配對碼並在擴充功能貼上。'],
  COMPANION_DISCONNECTED: ['擴充功能沒有連線', '確認瀏覽器開著、擴充功能已啟用，再按一次「測試連線」。'],
  COMPANION_TAB_UNBOUND: ['還沒選擇課程分頁', '打開課程頁，在擴充功能視窗按「使用這個分頁」並允許這個網站。'],
  COMPANION_TIMEOUT: ['頁面沒有回應', '重新整理課程頁後再測試；若仍失敗，請重新載入擴充功能。'],
  COMPANION_UNAVAILABLE: ['這個版本無法測試', '請重新啟動 Course Memory。']
};
export const describeCompanionError = (code) => { const [title, next] = COMPANION_ERROR_TEXT[code] || ['無法連線到擴充功能', '請確認擴充功能已安裝、配對並選好分頁。']; return { title, next }; };
