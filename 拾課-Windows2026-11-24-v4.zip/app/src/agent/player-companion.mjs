/**
 * Runner player/network interfaces backed by the browser Companion hub.
 * Every call is a single command with its own commandId; nothing is resent automatically.
 * Errors keep stable Companion codes (COMPANION_DISCONNECTED, COMPANION_TIMEOUT, ...) so the Runner can
 * tell a lost browser link apart from a network outage (NETWORK_OFFLINE) or OBS (OBS_DISCONNECTED).
 */
export function createCompanionPlayer({ hub, ttlMs = {} } = {}) {
  if (!hub) throw new Error('companion hub is required');
  const call = (type, args = {}) => hub.sendCommand({ type, args, ttlMs: ttlMs[type] });
  const lessonArgs = (lesson = {}) => ({ platformLessonId: String(lesson.platformLessonId ?? '').slice(0, 200), url: typeof lesson.url === 'string' ? lesson.url.slice(0, 2000) : null });
  return {
    id: 'companion',
    navigate: (lesson) => call('navigate', lessonArgs(lesson)),
    verifyPage: (lesson) => call('verifyPage', lessonArgs(lesson)),
    setRate: (rate) => call('setRate', { rate: Number(rate) }),
    enableCaptions: ({ languages = [] } = {}) => call('enableCaptions', { languages: Array.isArray(languages) ? languages.slice(0, 5).map(String) : [] }),
    play: () => call('play'),
    pause: () => call('pause'),
    nextLesson: () => call('nextLesson'),
    async getState() { const result = await call('getState'); return result.state ?? {}; },
    on(name, fn) { return name === 'disconnected' ? hub.on('disconnected', fn) : () => {}; }
  };
}

/** Browser-reported online state. Unknown (no report yet) counts as online; a lost Companion is handled separately. */
export function createCompanionNetwork({ hub }) {
  return {
    isOnline: () => hub.browserOnline !== false,
    on(name, fn) { return name === 'change' ? hub.on('network', fn) : () => {}; }
  };
}
