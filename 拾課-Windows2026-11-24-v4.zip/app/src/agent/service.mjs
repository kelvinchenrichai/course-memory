import { AgentError, CAPTURE_MODES, createAgentRunner } from './runner.mjs';
import { createCompanionNetwork, createCompanionPlayer } from './player-companion.mjs';

/**
 * Wires the P3A Runner to real dependencies. One Runner per capture mode (the Runner enforces that its
 * capture adapter matches the confirmed plan); at most one job runs across both. Each job is only ever
 * loaded into the Runner of its own mode so no two in-memory copies exist.
 * `captureFactory(mode)` must return a Runner capture adapter (e.g. createObsCapture). Nothing here
 * bypasses draft → confirmation → confirm; the API is a thin layer over the Runner.
 */
export function createAgentService({ hub, store, captureFactory, disk, clock, runnerOptions = {}, player, network, onUpdate } = {}) {
  if (!hub || !store || typeof captureFactory !== 'function' || !disk) throw new AgentError('MISSING_DEPENDENCY', 'agent service 缺少必要相依');
  const sharedPlayer = player || createCompanionPlayer({ hub });
  const sharedNetwork = network || createCompanionNetwork({ hub });
  const runners = new Map(); const running = new Map();

  const captures = new Map();
  const captureFor = (mode) => { if (!captures.has(mode)) captures.set(mode, captureFactory(mode)); return captures.get(mode); };
  function runnerFor(mode) {
    if (!CAPTURE_MODES.includes(mode)) throw new AgentError('INVALID_PLAN', 'captureMode 必須是 audio 或 video');
    if (!runners.has(mode)) runners.set(mode, createAgentRunner({ player: sharedPlayer, capture: captureFor(mode), store, clock, network: sharedNetwork, disk, options: runnerOptions, onUpdate }));
    return runners.get(mode);
  }
  /** A capture that cannot work (e.g. audio without a confirmed audio-only OBS profile) is refused up front. */
  function assertCaptureAvailable(mode) {
    const capture = captureFor(mode);
    if (capture?.kind === 'unavailable') throw new AgentError('CAPTURE_UNAVAILABLE', capture.unavailableReason || `${mode} capture 尚未設定`);
  }

  async function modeOf(jobId) {
    if (!/^job_[0-9a-f]{12}$/.test(String(jobId))) throw new AgentError('JOB_NOT_FOUND', '工作 ID 無效');
    const job = await store.loadJob(jobId); if (!job) throw new AgentError('JOB_NOT_FOUND', `找不到工作 ${jobId}`);
    return job.plan.captureMode;
  }
  const busy = () => [...runners.values()].some((runner) => runner.activeJobId);

  /** Starts the long-running job in the background; the HTTP call returns immediately. */
  function launch(jobId, promise) {
    running.set(jobId, promise);
    promise.catch(() => {}).finally(() => running.delete(jobId));
    return promise;
  }

  async function begin(jobId, method) {
    const mode = await modeOf(jobId); assertCaptureAvailable(mode); const runner = runnerFor(mode);
    if (busy()) throw new AgentError('RUNNER_BUSY', '已有工作在執行');
    // Validate synchronously-detectable errors (NOT_CONFIRMED, INVALID_TRANSITION...) before answering.
    const promise = runner[method](jobId);
    const early = await Promise.race([promise.then(() => null, (error) => error), new Promise((resolve) => setImmediate(() => resolve(null)))]);
    if (early) throw early;
    launch(jobId, promise);
    return runner.getJob(jobId);
  }

  return {
    async createDraft(input) { const runner = runnerFor(input?.captureMode); assertCaptureAvailable(input.captureMode); return runner.createDraft(input); },
    async requestConfirmation(jobId) { return runnerFor(await modeOf(jobId)).requestConfirmation(jobId); },
    async confirm(jobId, payload) { return runnerFor(await modeOf(jobId)).confirm(jobId, payload); },
    start: (jobId) => begin(jobId, 'start'),
    resume: (jobId) => begin(jobId, 'resume'),
    async pause(jobId) { return runnerFor(await modeOf(jobId)).pause(jobId); },
    async cancel(jobId) { return runnerFor(await modeOf(jobId)).cancel(jobId); },
    async getJob(jobId) { return runnerFor(await modeOf(jobId)).getJob(jobId); },
    async recover() { const ids = []; for (const mode of CAPTURE_MODES) ids.push(...await runnerFor(mode).recoverInterruptedJobs()); return [...new Set(ids)]; },
    companionStatus: () => hub.status(),
    waitForIdle: async () => { await Promise.allSettled([...running.values()]); }
  };
}
