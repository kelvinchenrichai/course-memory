import { isLocalHost, isLocalUiOrigin } from '../services/companion.mjs';

const STATUS = { NOT_CONFIRMED: 409, INVALID_TRANSITION: 409, PLAN_CHANGED: 409, RUNNER_BUSY: 409, CAPTURE_MODE_MISMATCH: 409, CAPTURE_UNAVAILABLE: 409, JOB_NOT_FOUND: 404, RIGHTS_REQUIRED: 403, INVALID_PLAN: 400, INVALID_RANGE: 400 };
const json = (status, body) => ({ status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }, body });

/**
 * Local-only Agent API. Same-origin UI or no Origin (local tools); JSON bodies only; Host must be localhost.
 * Every route maps 1:1 to a Runner operation, so draft → confirmation → confirm cannot be skipped.
 */
export async function handleAgentRequest(service, request, { port } = {}) {
  const { method, pathname, headers = {} } = request;
  const isJobs = pathname === '/api/agent/jobs' || pathname.startsWith('/api/agent/jobs/');
  if (!isJobs && pathname !== '/api/agent/companion') return null;
  if (!isLocalHost(headers.host)) return json(403, { error: 'BAD_HOST' });
  if (!isLocalUiOrigin(headers.origin ?? null, port)) return json(403, { error: 'BAD_ORIGIN' });
  if (method === 'POST' && !String(headers['content-type'] || '').startsWith('application/json')) return json(415, { error: 'JSON_REQUIRED' });
  const body = request.body && typeof request.body === 'object' ? request.body : {};
  try {
    if (pathname === '/api/agent/companion' && method === 'GET') return json(200, service.companionStatus());
    if (pathname === '/api/agent/jobs' && method === 'POST') return json(201, await service.createDraft(body));
    const match = pathname.match(/^\/api\/agent\/jobs\/(job_[0-9a-f]{12})(?:\/([a-z-]+))?$/);
    if (!match) return json(404, { error: 'NOT_FOUND' });
    const [, jobId, action] = match;
    if (!action && method === 'GET') return json(200, await service.getJob(jobId));
    if (method !== 'POST') return json(405, { error: 'METHOD_NOT_ALLOWED' });
    switch (action) {
      case 'confirmation': return json(200, await service.requestConfirmation(jobId));
      case 'confirm': return json(200, await service.confirm(jobId, { planHash: body.planHash, acknowledgements: body.acknowledgements }));
      case 'start': return json(202, await service.start(jobId));
      case 'pause': return json(200, await service.pause(jobId));
      case 'cancel': return json(200, await service.cancel(jobId));
      case 'resume': return json(202, await service.resume(jobId));
      default: return json(404, { error: 'NOT_FOUND' });
    }
  } catch (error) {
    const code = typeof error?.code === 'string' ? error.code : 'AGENT_ERROR';
    return json(STATUS[code] ?? 400, { error: code, message: String(error?.message || code).slice(0, 300) });
  }
}
