import { CAPTURE_MODES } from './runner.mjs';

/**
 * Adapts the P2 OBS client to the Runner's capture interface.
 * Video works with the normal OBS profile. Audio mode requires an explicitly confirmed
 * audio-only OBS profile so the product never silently stores video under an "audio" label.
 */
export function createObsCapture({ obs, mode, audioOnlyConfirmed = false }) {
  if (!obs) throw new Error('obs client is required');
  if (!CAPTURE_MODES.includes(mode)) throw new Error('capture mode must be audio or video');
  if (mode === 'audio' && !audioOnlyConfirmed) throw new Error('audio mode requires a confirmed audio-only OBS profile or a dedicated audio capture adapter');
  const listeners = new Map(); let active = false; let stopping = false; let files = [];
  const emit = (name, value) => { for (const fn of [...(listeners.get(name) || [])]) fn(value); };
  const unsubscribe = [
    obs.on('disconnected', (value) => { if (active) emit('disconnected', { code: value?.code ?? null }); }),
    obs.on('obsExiting', () => { if (active) emit('disconnected', { code: 'obs_exiting' }); }),
    obs.on('recordFileChanged', (value) => { if (active && value?.outputPath) files.push(value.outputPath); }),
    obs.on('recordState', (value) => {
      if (!active || stopping) return;
      if (value?.state === 'OBS_WEBSOCKET_OUTPUT_STOPPED') { active = false; emit('stoppedExternally', { outputPath: value.outputPath ?? null }); }
      else if (value?.state === 'OBS_WEBSOCKET_OUTPUT_PAUSED') emit('paused', {});
    })
  ];
  return {
    mode, kind: 'obs',
    async start() {
      if (obs.state !== 'ready') await obs.connect();
      const result = await obs.startRecord(); active = true; files = [];
      return { startedAtMs: result.startedAtMs };
    },
    async stop() {
      stopping = true;
      try {
        const result = await obs.stopRecord(); active = false;
        const outputFiles = result.outputPath ? [...files, result.outputPath].filter((item, index, list) => list.indexOf(item) === index) : [...files];
        return { wasActive: result.wasActive, outputPath: result.outputPath, outputFiles, pathSource: result.pathSource, ...(typeof result.pathMismatch === 'boolean' ? { pathMismatch: result.pathMismatch } : {}) };
      } finally { stopping = false; }
    },
    status: () => obs.getRecordStatus(),
    on(name, fn) { const set = listeners.get(name) || new Set(); set.add(fn); listeners.set(name, set); return () => set.delete(fn); },
    dispose() { for (const off of unsubscribe) off?.(); listeners.clear(); }
  };
}
