import fsp from 'node:fs/promises';
import path from 'node:path';
import { CAPTURE_MODES } from './runner.mjs';
import { AudioDeviceError, deviceRef, dshowInputArg, listAudioDevices, resolveAudioDevice } from '../services/audio-devices.mjs';

/**
 * Audio-only capture adapter for the Agent Runner (same interface as capture-obs.mjs).
 *
 * Records the ONE input device the user selected (config.audioCapture.deviceName) with ffmpeg/DirectShow
 * into segmented files (15–30 min each). It never picks a device on its own and never records video.
 * Whether that device carries "system audio" depends on the user's Windows setup (e.g. Stereo Mix or a
 * virtual cable); ffmpeg's DirectShow input has no native WASAPI loopback, so none is claimed.
 *
 * Errors carry `code`: FFMPEG_UNAVAILABLE, AUDIO_DEVICE_UNAVAILABLE, DISK_LOW, AUDIO_CAPTURE_FAILED,
 * AUDIO_CAPTURE_BUSY. stop() asks ffmpeg to finish ('q' on stdin) so the last segment is closed properly;
 * if ffmpeg does not exit in time it is killed and whatever segments exist are returned (partial).
 */

export const AUDIO_FORMATS = Object.freeze({
  flac: { ext: '.flac', args: ['-c:a', 'flac'], segmentFormat: 'flac' },
  m4a: { ext: '.m4a', args: ['-c:a', 'aac', '-b:a', '160k'], segmentFormat: 'mp4', formatOptions: 'movflags=+frag_keyframe+empty_moov' }
});
export const SEGMENT_LIMITS = Object.freeze({ min: 900, max: 1800, default: 1200 });
const STARTED = /Press \[q\] to stop|Output #0/;
const DEVICE_GONE = /Could not find audio only device|Could not enumerate|Could not run graph|I\/O error|Error opening input|No such device/i;

const fail = (code, message) => Object.assign(new Error(message), { code });

export function createAudioCapture({
  processRunner, ffmpeg = 'ffmpeg', audioConfig = {}, outputDir, disk, minFreeBytes = 512 * 1024 ** 2,
  listDevices, platform = process.platform, clock = { now: () => Date.now() },
  timers = { setTimeout, clearTimeout }, startConfirmMs = 5000, stopTimeoutMs = 10_000, logger = { info() {}, warn() {} }
} = {}) {
  if (!processRunner?.start || !processRunner?.run) throw new Error('processRunner is required');
  if (!outputDir) throw new Error('outputDir is required');
  if (!CAPTURE_MODES.includes('audio')) throw new Error('runner does not support audio mode');
  const format = AUDIO_FORMATS[audioConfig.format || 'flac'];
  if (!format) throw new Error('audioCapture.format must be flac or m4a');
  const requested = Number(audioConfig.segmentSeconds ?? SEGMENT_LIMITS.default);
  const segmentSeconds = Number.isFinite(requested) ? Math.min(SEGMENT_LIMITS.max, Math.max(SEGMENT_LIMITS.min, Math.round(requested))) : SEGMENT_LIMITS.default;
  const enumerate = listDevices || (() => listAudioDevices({ run: processRunner.run, ffmpeg, platform, inputFormat: audioConfig.inputFormat || 'dshow' }));
  const listeners = new Map(); let handle = null; let active = false; let stopping = false; let prefix = null; let startedAtMs = null;
  const emit = (name, value) => { for (const fn of [...(listeners.get(name) || [])]) fn(value); };

  async function outputFiles() {
    if (!prefix) return [];
    let names = []; try { names = await fsp.readdir(outputDir); } catch { return []; }
    return names.filter((name) => name.startsWith(prefix) && name.endsWith(format.ext)).sort().map((name) => path.join(outputDir, name));
  }

  function waitExit(child, ms) {
    return new Promise((resolve) => {
      let done = false; const timer = timers.setTimeout(() => { if (!done) { done = true; resolve(null); } }, ms);
      child.wait().then((value) => { if (!done) { done = true; timers.clearTimeout(timer); resolve(value); } });
    });
  }

  return {
    mode: 'audio', segmentSeconds, format: audioConfig.format || 'flac',
    /** `unavailable` until the user has picked a device; read live so a later selection takes effect. */
    get kind() { return typeof audioConfig.deviceName === 'string' && audioConfig.deviceName.trim() ? 'ffmpeg-audio' : 'unavailable'; },
    get unavailableReason() { return this.kind === 'unavailable' ? '尚未選擇音訊輸入裝置（AUDIO_DEVICE_UNAVAILABLE）' : null; },
    async start({ sessionId } = {}) {
      if (active || handle) throw fail('AUDIO_CAPTURE_BUSY', '音訊錄製已在進行中');
      const free = await disk?.freeBytes?.();
      if (disk && !(free >= minFreeBytes)) throw fail('DISK_LOW', '剩餘空間不足，無法開始音訊錄製');
      let devices;
      try { ({ devices } = await enumerate()); }
      catch (error) { throw fail(error?.code === 'FFMPEG_UNAVAILABLE' ? 'FFMPEG_UNAVAILABLE' : error?.code === 'AUDIO_DEVICE_LISTING_UNSUPPORTED' ? 'AUDIO_DEVICE_UNAVAILABLE' : 'AUDIO_CAPTURE_FAILED', error?.message || '無法列出音訊裝置'); }
      let device;
      try { device = resolveAudioDevice(audioConfig, devices); } catch (error) { throw fail(error.code || 'AUDIO_DEVICE_UNAVAILABLE', error.message); }
      let input; try { input = dshowInputArg(device); } catch (error) { throw fail('AUDIO_DEVICE_UNAVAILABLE', error.message); }
      await fsp.mkdir(outputDir, { recursive: true });
      const stamp = new Date(clock.now()).toISOString().replace(/[-:]/g, '').replace(/\..+$/, '');
      const safeSession = /^rec_[0-9a-f]{12}$/.test(String(sessionId)) ? sessionId : 'manual';
      prefix = `audio-${safeSession}-${stamp}-`;
      const pattern = path.join(outputDir.replace(/%/g, '%%'), `${prefix}%03d${format.ext}`); // ffmpeg treats % in the template specially
      const args = ['-hide_banner', '-nostats', '-loglevel', 'info', '-f', 'dshow', '-i', input, '-vn', ...format.args,
        '-f', 'segment', '-segment_time', String(segmentSeconds), '-reset_timestamps', '1', '-segment_format', format.segmentFormat,
        ...(format.formatOptions ? ['-segment_format_options', format.formatOptions] : []), `file:${pattern}`];
      let confirmed = false; let resolveStarted;
      const started = new Promise((resolve) => { resolveStarted = resolve; });
      const child = processRunner.start(ffmpeg, args, { onStderr: (text) => { if (!confirmed && STARTED.test(text)) { confirmed = true; resolveStarted('started'); } } });
      handle = child;
      child.wait().then((exit) => {
        if (!confirmed) { resolveStarted({ exit }); return; }
        if (active && !stopping) { active = false; handle = null; logger.warn({ event: 'audio_capture_exited', code: exit?.code ?? null }); emit('stoppedExternally', { reason: 'ffmpeg_exited' }); }
      });
      const timer = timers.setTimeout(() => resolveStarted('timeout'), startConfirmMs);
      const outcome = await started; timers.clearTimeout(timer);
      if (outcome !== 'started') {
        handle = null;
        if (outcome === 'timeout') { child.kill(); throw fail('AUDIO_CAPTURE_FAILED', 'ffmpeg 未確認開始錄音'); }
        if (outcome.exit?.error === 'COMMAND_NOT_FOUND') throw fail('FFMPEG_UNAVAILABLE', '找不到 ffmpeg');
        throw fail(DEVICE_GONE.test(child.stderrTail()) ? 'AUDIO_DEVICE_UNAVAILABLE' : 'AUDIO_CAPTURE_FAILED', '音訊錄製無法開始');
      }
      active = true; startedAtMs = clock.now();
      logger.info({ event: 'audio_capture_started', deviceRef: deviceRef(device), segmentSeconds });
      return { startedAtMs };
    },
    async stop() {
      const child = handle;
      if (!child || !active) { const files = await outputFiles(); handle = null; active = false; return { wasActive: false, outputPath: files.at(-1) ?? null, outputFiles: files, pathSource: 'response' }; }
      stopping = true;
      try {
        child.write('q');
        let exit = await waitExit(child, stopTimeoutMs);
        if (!exit) { logger.warn({ event: 'audio_capture_stop_timeout' }); child.kill(); exit = await waitExit(child, 2000); }
        active = false; handle = null;
        const files = await outputFiles();
        logger.info({ event: 'audio_capture_stopped', segments: files.length });
        return { wasActive: true, outputPath: files.at(-1) ?? null, outputFiles: files, pathSource: 'response' };
      } finally { stopping = false; }
    },
    async status() { return { active, outputActive: active, startedAtMs, segmentSeconds, segments: (await outputFiles()).length }; },
    on(name, fn) { const set = listeners.get(name) || new Set(); set.add(fn); listeners.set(name, set); return () => set.delete(fn); },
    dispose() { listeners.clear(); }
  };
}

export { AudioDeviceError };
