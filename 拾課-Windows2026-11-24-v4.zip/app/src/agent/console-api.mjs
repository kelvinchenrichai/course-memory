import path from 'node:path';
import { checkLocalRequest } from '../settings/api.mjs';
import { readJson, writeJsonAtomic } from '../pipeline/files.mjs';
import { ConsoleError, buildDraftInput, companionTestView, companionView, ensureRights, estimatePlan, liveView, platformNotes } from './console.mjs';

/**
 * P5 Agent 學習 API — a minimal bridge over the existing Agent service. Every action maps to an existing
 * service call (createDraft / requestConfirmation / confirm / start / pause / resume / cancel / getJob).
 * Guard: same as P4C (localhost Host, same-origin, Sec-Fetch-Site, JSON bodies).
 *
 *   GET  /api/agent-console                      → { companion, jobs: [liveView…] }
 *   POST /api/agent-console/plans  {form}        → draft + confirmation summary + estimates   (201)
 *   GET  /api/agent-console/jobs/:id             → liveView
 *   POST /api/agent-console/jobs/:id/confirm  { planHash, acknowledgements }
 *   POST /api/agent-console/jobs/:id/start | pause | resume | cancel
 *   GET  /api/agent-console/companion             → setup-wizard view (P8)
 *   POST /api/agent-console/companion/test        → read-only「測試連線」(detect + getState only)
 */

const ROUTES = /^\/api\/agent-console(?:\/plans|\/companion(?:\/test)?|\/jobs\/(job_[0-9a-f]{12})(?:\/(confirm|start|pause|resume|cancel))?)?$/;
// The only Companion commands the wizard may send: both read the page, neither plays, records or navigates.
const READ_ONLY_TEST = Object.freeze(['detect', 'getState']);
const json = (status, body) => ({ status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }, body });
const STATUS = { NOT_CONFIRMED: 409, INVALID_TRANSITION: 409, PLAN_CHANGED: 409, RUNNER_BUSY: 409, CAPTURE_UNAVAILABLE: 409, JOB_NOT_FOUND: 404, RIGHTS_REQUIRED: 403, INVALID_PLAN: 400, INVALID_RANGE: 400, INVALID_URL: 400, MEDIA_URL_NOT_ALLOWED: 400, DUPLICATE_LESSON: 400 };

export const isConsoleRoute = (pathname) => ROUTES.test(pathname);

/** ctx: { service, store, port, dataDir, freeBytes(), now() } */
export function createConsole(ctx) {
  const prefsFile = (jobId) => path.join(ctx.dataDir, 'agent-console', `${jobId}.json`);
  const prefs = (jobId) => readJson(prefsFile(jobId), null);
  const view = async (job) => liveView(job, { preferences: await prefs(job.id), companion: ctx.service.companionStatus(), now: ctx.now ? ctx.now() : Date.now() });

  return {
    async overview() {
      const jobs = (await ctx.store.listJobs()).filter((job) => job?.plan && job.status !== 'draft').sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 30);
      return { companion: companionView(ctx.service.companionStatus()), jobs: await Promise.all(jobs.map(view)) };
    },
    async plan(form) {
      const { draft, preferences } = buildDraftInput(form);
      const job = await ctx.service.createDraft(draft);
      await writeJsonAtomic(prefsFile(job.id), preferences);
      const confirmation = await ctx.service.requestConfirmation(job.id);
      const free = await Promise.resolve(ctx.freeBytes?.()).catch(() => null);
      const fresh = await ctx.service.getJob(job.id);
      return {
        job: await view(fresh), planHash: confirmation.planHash,
        summary: {
          lessons: confirmation.summary.lessons.map(({ title, skip }) => ({ title, ...(skip ? { skip } : {}) })),
          captureMode: fresh.plan.captureMode, rate: fresh.plan.rate, captions: fresh.plan.captionsEnabled ? fresh.plan.captions : [],
          transcriptLanguage: preferences.transcriptLanguage, translationLanguage: preferences.translationLanguage,
          courses: preferences.courses.map(({ title, count, from, to, platforms, hosts, rightsBasis }) => ({ title, count, from, to, rightsBasis, hosts, platforms: platforms.map(platformNotes) })),
          estimate: estimatePlan(fresh.plan, { freeBytes: Number.isFinite(free) ? free : null }),
          requiredAcknowledgements: confirmation.summary.requiredAcknowledgements
        }
      };
    },
    async confirm(jobId, body) {
      const preferences = await prefs(jobId); if (!preferences) throw new ConsoleError('JOB_NOT_FOUND', '找不到任務', 404);
      await ensureRights({ store: ctx.store, preferences, acknowledgements: body.acknowledgements, now: new Date(ctx.now ? ctx.now() : Date.now()).toISOString() });
      return view(await ctx.service.confirm(jobId, { planHash: body.planHash, acknowledgements: { recordPermission: true, privateProcessing: true } }));
    },
    async act(jobId, action) {
      if (action === 'start') await ctx.service.start(jobId);
      else if (action === 'resume') await ctx.service.resume(jobId);
      else if (action === 'pause') await ctx.service.pause(jobId);
      else if (action === 'cancel') await ctx.service.cancel(jobId);
      return view(await ctx.service.getJob(jobId));
    },
    async get(jobId) { return view(await ctx.service.getJob(jobId)); },
    companion() { return companionView(ctx.service.companionStatus()); },
    /** P8「測試連線」: reads the bound tab's player through `detect` and `getState` only. */
    async testCompanion() {
      const now = ctx.now ? ctx.now() : Date.now();
      const status = ctx.service.companionStatus();
      const send = ctx.companionCommand;
      if (typeof send !== 'function') return companionTestView({ error: { code: 'COMPANION_UNAVAILABLE' }, status, now });
      const companion = companionView(status);
      const early = !companion.paired ? 'COMPANION_NOT_PAIRED' : !companion.connected ? 'COMPANION_DISCONNECTED' : !companion.tabSelected ? 'COMPANION_TAB_UNBOUND' : null;
      if (early) return companionTestView({ error: { code: early }, status, now });
      try {
        const [detect, state] = [await send({ type: READ_ONLY_TEST[0], args: {} }), await send({ type: READ_ONLY_TEST[1], args: {} })];
        return companionTestView({ detect, state: state?.state || null, status: ctx.service.companionStatus(), now });
      } catch (error) { return companionTestView({ error: { code: /^COMPANION_[A-Z_]+$/.test(String(error?.code)) ? error.code : 'COMPANION_DISCONNECTED' }, status, now }); }
    }
  };
}

export async function handleConsoleRequest(ctx, request) {
  const match = request.pathname.match(ROUTES); if (!match) return null;
  const rejected = checkLocalRequest(request, ctx.port);
  if (rejected) return json(rejected === 'JSON_REQUIRED' ? 415 : 403, { error: rejected });
  const { method } = request; const [, jobId, action] = match;
  const body = request.body && typeof request.body === 'object' && !Array.isArray(request.body) ? request.body : {};
  try {
    if (!jobId && request.pathname === '/api/agent-console' && method === 'GET') return json(200, await ctx.console.overview());
    if (request.pathname === '/api/agent-console/companion' && method === 'GET') return json(200, ctx.console.companion());
    if (request.pathname === '/api/agent-console/companion/test' && method === 'POST') return json(200, await ctx.console.testCompanion());
    if (request.pathname === '/api/agent-console/plans' && method === 'POST') return json(201, await ctx.console.plan(body));
    if (jobId && !action && method === 'GET') return json(200, await ctx.console.get(jobId));
    if (jobId && action === 'confirm' && method === 'POST') return json(200, await ctx.console.confirm(jobId, body));
    if (jobId && action && method === 'POST') return json(action === 'start' || action === 'resume' ? 202 : 200, await ctx.console.act(jobId, action));
    return json(405, { error: 'METHOD_NOT_ALLOWED' });
  } catch (error) {
    const code = typeof error?.code === 'string' && /^[A-Z][A-Z0-9_]{2,60}$/.test(error.code) ? error.code : 'AGENT_ERROR';
    const message = typeof error?.message === 'string' && /[一-鿿]/.test(error.message) ? error.message.replace(/[A-Za-z]:\\[^\s]*|\/(?:home|Users|sessions)\/[^\s]*/g, '').slice(0, 200) : '操作失敗';
    return json(error?.status || STATUS[code] || 400, { error: code, message });
  }
}

async function readBody(req, limit = 256 * 1024) {
  let size = 0; const chunks = [];
  for await (const chunk of req) { size += chunk.length; if (size > limit) throw Object.assign(new Error('too large'), { status: 413 }); chunks.push(chunk); }
  if (!size) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw Object.assign(new Error('bad json'), { status: 400 }); }
}

export async function routeConsoleApis(ctx, req, res, url) {
  if (!isConsoleRoute(url.pathname)) return false;
  let result;
  try {
    const rejected = checkLocalRequest({ method: req.method, headers: req.headers }, ctx.port);
    const body = !rejected && req.method === 'POST' ? await readBody(req) : undefined;
    result = await handleConsoleRequest(ctx, { method: req.method, pathname: url.pathname, headers: req.headers, body });
  } catch (error) { result = json(error.status === 413 ? 413 : 400, { error: error.status === 413 ? 'TOO_LARGE' : 'BAD_JSON' }); }
  res.writeHead(result.status, result.headers); res.end(JSON.stringify(result.body));
  return true;
}
