import fsp from 'node:fs/promises';
import path from 'node:path';
import { JsonStore } from '../domain/store.mjs';
import { createObsClient } from '../services/obs.mjs';
import { createCompanionHub, handleCompanionRequest } from '../services/companion.mjs';
import { createObsCapture } from './capture-obs.mjs';
import { createStorageGuard } from '../backup/storage-guard.mjs';
import { createAudioCapture } from './capture-audio.mjs';
import { listAudioDevices, saveAudioDeviceSelection } from '../services/audio-devices.mjs';
import { createProcessRunner } from '../pipeline/process-runner.mjs';
import { createPipelineRunner } from '../pipeline/runner.mjs';
import { createWhisperProvider } from '../pipeline/transcript.mjs';
import { createFileWatcher, createWatchLedger } from '../pipeline/watcher.mjs';
import { createIntake } from '../pipeline/intake.mjs';
import { handlePipelineRequest, isPipelineRoute } from '../pipeline/api.mjs';
import { isInside } from '../pipeline/files.mjs';
import { createJsonAgentStore } from './json-store.mjs';
import { createAgentService } from './service.mjs';
import { handleAgentRequest } from './api.mjs';

const MAX_BODY = 64 * 1024;

/** Production wiring used by server.mjs. Pairing persists as a token hash only (data/companion.json). */
export async function createLocalAgentRuntime({ root, config, logger, sessionOptionsResolver: initialSessionOptionsResolver } = {}) {
  const dataDir = path.join(root, 'data'); const files = new JsonStore(dataDir);
  const persistence = { load: () => files.read('companion.json', null), save: (value) => files.write('companion.json', value) };
  const hub = createCompanionHub({ logger, persistence, options: { allowedExtensionIds: Array.isArray(config.companionExtensionIds) ? config.companionExtensionIds : [] } });
  await hub.restore();
  const baseStore = createJsonAgentStore(path.join(dataDir, 'agent'));
  // P4A intake is initialized later, after the Agent service has recovered its sessions. Keep the
  // store hook small and non-blocking so a transcription failure can never turn a valid recording
  // into a failed Agent job.
  let scheduleReadySession = () => {};
  let sessionOptionsResolver = typeof initialSessionOptionsResolver === 'function' ? initialSessionOptionsResolver : null;
  const store = {
    ...baseStore,
    async saveSession(session) {
      await baseStore.saveSession(session);
      scheduleReadySession(session);
    }
  };
  let obs = null;
  try { obs = createObsClient({ url: config.obsUrl || 'ws://127.0.0.1:4455', getPassword: () => config.obsPassword || null }); } catch { obs = null; }
  const processRunner = createProcessRunner({ logger: logger || undefined });
  const ffmpeg = config.ffmpegCommand || 'ffmpeg'; const ffprobe = config.ffprobeCommand || 'ffprobe';
  // Shared, mutable: a device chosen later through the API takes effect without a restart.
  const audioConfig = config.audioCapture && typeof config.audioCapture === 'object' ? config.audioCapture : (config.audioCapture = {});
  const audioDir = audioConfig.outputFolder ? path.resolve(root, audioConfig.outputFolder) : path.resolve(config.recordingsFolder, 'audio');
  const warnings = [];
  // Deprecated (P4A): audio mode no longer needs an OBS audio-only profile. The key is still read so old
  // config files keep loading; it only matters with the explicit legacy backend `obs-audio-profile`.
  if (config.obsAudioOnlyProfileConfirmed === true && audioConfig.backend !== 'obs-audio-profile') warnings.push('OBS_AUDIO_ONLY_PROFILE_DEPRECATED');
  const unavailable = (mode, reason) => ({ mode, kind: 'unavailable', unavailableReason: reason, start: async () => { throw Object.assign(new Error(reason), { code: 'OBS_DISCONNECTED' }); }, stop: async () => ({ wasActive: false, outputPath: null }), status: async () => ({ active: false }), on: () => () => {} });
  // P4D: the Runner's own disk check, with thresholds raised to the user's warning level and an optional
  // reclaimer (verified-backup cleanup) attached later by the backup service. No Runner logic changes.
  const storage = createStorageGuard({ folder: config.recordingsFolder, warnFreeBytes: () => Math.max(1, Number(config.backup?.warnFreeGb) || 10) * 1024 ** 3, logger: logger || undefined });
  const disk = storage;
  const captureFactory = (mode) => {
    if (mode === 'audio') {
      if (audioConfig.backend === 'obs-audio-profile') {
        if (!obs) return unavailable(mode, 'OBS 連線設定無效');
        if (config.obsAudioOnlyProfileConfirmed !== true) return unavailable(mode, '舊版 OBS 純音訊設定檔模式需要 obsAudioOnlyProfileConfirmed（已淘汰，建議改用音訊裝置錄音）');
        return createObsCapture({ obs, mode, audioOnlyConfirmed: true });
      }
      return createAudioCapture({ processRunner, ffmpeg, audioConfig, outputDir: audioDir, disk, logger: logger || undefined });
    }
    if (!obs) return unavailable(mode, 'OBS 連線設定無效');
    return createObsCapture({ obs, mode });
  };
  const service = createAgentService({ hub, store, captureFactory, disk, runnerOptions: { minFreeBytes: storage.minFreeBytes() } });
  const recovered = await service.recover();

  const audio = {
    list: async () => { const result = await listAudioDevices({ run: processRunner.run, ffmpeg, inputFormat: audioConfig.inputFormat || 'dshow' }); return { ...result, selected: audioConfig.deviceName || null, systemAudioLoopback: 'user-selected-device-only' }; },
    select: async (name) => {
      const { devices } = await listAudioDevices({ run: processRunner.run, ffmpeg, inputFormat: audioConfig.inputFormat || 'dshow' });
      const result = await saveAudioDeviceSelection({ configFile: path.join(root, 'config.json'), name, devices });
      Object.assign(audioConfig, result.audioCapture);
      return { selected: audioConfig.deviceName, deviceRef: result.deviceRef };
    }
  };

  const allowedRoots = [config.recordingsFolder, config.importsFolder, audioDir].map((dir) => path.resolve(dir));
  let pipeline = null; let pipelineUnavailableReason = null;
  // One transcription engine for the pipeline and the legacy library path, so「faster-whisper 被 Windows 擋下」
  // is learned once and both paths use the same fallback.
  let transcriber = null;
  try {
    const provider = createWhisperProvider(config, { run: processRunner.run, root, logger: logger || null });
    transcriber = provider;
    pipeline = createPipelineRunner({ dataDir: path.join(dataDir, 'pipeline'), workRoot: path.join(dataDir, 'pipeline', 'work'), allowedRoots, tools: { ffmpeg, ffprobe }, run: processRunner.run, provider, logger: logger || undefined, defaults: { language: { auto: 'auto', en: 'en', zh: 'zh-Hant', 'zh-Hant': 'zh-Hant', 'zh-Hans': 'zh-Hans' }[config.whisperLanguage] || 'auto', vtt: config.pipeline?.vtt === true } });
    await pipeline.recover();
  } catch (error) { pipeline = null; pipelineUnavailableReason = String(error?.message || error?.code || 'pipeline 無法啟動').slice(0, 200); }
  const findSessions = () => store.listSessions();
  const intake = pipeline ? createIntake({ pipeline, findSessions }) : null;
  let intakeTail = Promise.resolve();
  const readyForAutomaticIntake = (session) => {
    if (!['completed', 'partial'].includes(session?.status)) return false;
    if (session.status === 'partial' && session.captureStopConfirmed !== true) return false;
    return Boolean(session.obsOutputPath || session.obsOutputFiles?.length);
  };
  const enqueueReadySessionOnce = async (session) => {
    if (!pipeline || !intake || !readyForAutomaticIntake(session)) return null;
    const existing = (await pipeline.list()).find((job) => job.source?.recordingSessionId === session.id);
    if (existing) return { job: existing, deduplicated: true };
    // P5: an Agent-console job may carry its own transcript language; everything else keeps the defaults.
    const options = await Promise.resolve(sessionOptionsResolver?.(session)).catch(() => null);
    return options ? createIntake({ pipeline, findSessions, options }).fromSession(session) : intake.fromSession(session);
  };
  const logAutomaticIntakeError = (error, sessionId) => logger?.warn?.({
    event: 'pipeline_auto_enqueue_failed', sessionId, code: error?.code || 'PIPELINE_ERROR'
  });
  if (pipeline && config.pipeline?.autoEnqueue !== false) {
    scheduleReadySession = (session) => {
      if (!readyForAutomaticIntake(session)) return;
      intakeTail = intakeTail.then(() => enqueueReadySessionOnce(session))
        .catch((error) => logAutomaticIntakeError(error, session.id));
    };
    // Covers a process exit after the media was finalized but before it could be queued. Existing
    // jobs are detected by recordingSessionId, so restart recovery is idempotent.
    for (const session of await findSessions()) scheduleReadySession(session);
  }
  const enqueueSession = async (id, options) => {
    const session = (await findSessions()).find((item) => item.id === id);
    if (!session) throw Object.assign(new Error('找不到錄製紀錄'), { code: 'SESSION_NOT_FOUND' });
    return createIntake({ pipeline, findSessions, options }).fromSession(session);
  };
  const enqueueImport = async (name, options) => {
    const file = path.resolve(config.importsFolder, name);
    if (!isInside(config.importsFolder, file) || file === path.resolve(config.importsFolder)) throw Object.assign(new Error('只能處理匯入資料夾內的檔案'), { code: 'PATH_NOT_ALLOWED' });
    return createIntake({ pipeline, findSessions, options }).fromImport(file);
  };
  // Off by default: server.mjs still runs the legacy recordings/imports processing. Turning this on before
  // that is retired would transcribe the same file twice (docs/P4A_OPEN_QUESTIONS.md).
  let watcher = null;
  if (pipeline && config.pipeline?.watch === true) {
    watcher = createFileWatcher({ roots: [{ id: 'recordings', dir: config.recordingsFolder, kind: 'recording' }, { id: 'audio', dir: audioDir, kind: 'audio-capture' }, { id: 'imports', dir: config.importsFolder, kind: 'import' }].filter((item, index, list) => list.findIndex((other) => path.resolve(other.dir) === path.resolve(item.dir)) === index), ledger: createWatchLedger(path.join(dataDir, 'pipeline', 'watch-ledger.json')), maxDepth: 1, logger: logger || undefined });
    watcher.start({ intervalMs: Number(config.pipeline.watchIntervalMs) || 5000, onReady: (entry) => intake.fromWatchEntry(entry) });
  }
  return {
    hub, service, recovered, port: config.port, audio, pipeline, pipelineUnavailableReason, transcriber,
    enqueueSession, enqueueImport, watcher, warnings,
    // P4C: read-only views for the processing centre, and the same capture factory the Agent uses so a
    // manual learning session records through exactly the same (rights-gated, confirmed) adapters.
    agentStore: baseStore, setSessionOptionsResolver: (fn) => { sessionOptionsResolver = typeof fn === 'function' ? fn : null; },
    storage, listAgentJobs: () => baseStore.listJobs(), listSessions: () => baseStore.listSessions(), captureFactory, obsClient: obs,
    waitForAutomaticIntake: () => intakeTail
  };
}

async function readJson(req) {
  let text = '';
  for await (const chunk of req) { text += chunk; if (text.length > MAX_BODY) throw Object.assign(new Error('too large'), { status: 413 }); }
  if (!text) return undefined;
  try { return JSON.parse(text); } catch { throw Object.assign(new Error('bad json'), { status: 400 }); }
}

/** Node http adapter for the Companion and Agent handlers. Returns true when the route was handled. */
export async function routeLocalAgentApis(runtime, req, res, url) {
  const isCompanion = url.pathname.startsWith('/api/companion/');
  const isAgent = url.pathname === '/api/agent/companion' || url.pathname === '/api/agent/jobs' || url.pathname.startsWith('/api/agent/jobs/');
  const isPipeline = isPipelineRoute(url.pathname);
  if (!isCompanion && !isAgent && !isPipeline) return false;
  const controller = new AbortController();
  res.on('close', () => { if (!res.writableEnded) controller.abort(); });
  let result;
  try {
    const body = ['POST', 'PUT', 'DELETE'].includes(req.method) ? await readJson(req) : undefined;
    const request = { method: req.method, pathname: url.pathname, query: url.searchParams, headers: req.headers, body, signal: controller.signal };
    result = isCompanion ? await handleCompanionRequest(runtime.hub, request, { port: runtime.port })
      : isPipeline ? await handlePipelineRequest(runtime, request, { port: runtime.port })
        : await handleAgentRequest(runtime.service, request, { port: runtime.port });
  } catch (error) {
    result = { status: error.status || 500, headers: { 'content-type': 'application/json; charset=utf-8' }, body: { error: error.status === 413 ? 'TOO_LARGE' : error.status === 400 ? 'BAD_JSON' : 'INTERNAL_ERROR' } };
  }
  if (res.writableEnded || controller.signal.aborted) return true;
  res.writeHead(result.status, result.headers);
  res.end(result.body == null ? undefined : JSON.stringify(result.body));
  return true;
}
