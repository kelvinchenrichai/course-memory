import crypto from 'node:crypto';
import path from 'node:path';
import { createId, stableStringify } from '../domain/ids.mjs';
import { buildSpans } from '../domain/timemap.mjs';
import { assertPrivateUse } from '../services/rights.mjs';

export const JOB_STATES = Object.freeze(['draft', 'awaiting-confirmation', 'queued', 'preparing', 'running', 'stopping', 'completed', 'blocked', 'failed', 'cancelled']);

export const TRANSITIONS = Object.freeze({
  draft: ['awaiting-confirmation', 'cancelled'],
  'awaiting-confirmation': ['draft', 'queued', 'cancelled'],
  queued: ['preparing', 'cancelled'],
  preparing: ['running', 'stopping'],
  running: ['preparing', 'stopping'],
  stopping: ['completed', 'blocked', 'cancelled', 'failed'],
  blocked: ['queued', 'cancelled'],
  completed: [],
  failed: [],
  cancelled: []
});

export const STOP_CODES = Object.freeze({
  NETWORK_OFFLINE: 'NETWORK_OFFLINE',
  BUFFERING_TIMEOUT: 'BUFFERING_TIMEOUT',
  MEDIA_ERROR: 'MEDIA_ERROR',
  OBS_DISCONNECTED: 'OBS_DISCONNECTED',
  OBS_ALREADY_RECORDING: 'OBS_ALREADY_RECORDING',
  OBS_START_UNCONFIRMED: 'OBS_START_UNCONFIRMED',
  OBS_STOP_UNCONFIRMED: 'OBS_STOP_UNCONFIRMED',
  DOM_CHANGED: 'DOM_CHANGED',
  LOGIN_REQUIRED: 'LOGIN_REQUIRED',
  RIGHTS_REQUIRED: 'RIGHTS_REQUIRED',
  DISK_LOW: 'DISK_LOW',
  USER_CANCELLED: 'USER_CANCELLED',
  PLAYER_PAUSED_EXTERNALLY: 'PLAYER_PAUSED_EXTERNALLY',
  LESSON_TIMEOUT: 'LESSON_TIMEOUT',
  UNEXPECTED_LESSON: 'UNEXPECTED_LESSON',
  CAPTURE_STOPPED_EXTERNALLY: 'CAPTURE_STOPPED_EXTERNALLY',
  CAPTURE_PAUSED_EXTERNALLY: 'CAPTURE_PAUSED_EXTERNALLY',
  SERVER_RESTARTED: 'SERVER_RESTARTED',
  COMPANION_DISCONNECTED: 'COMPANION_DISCONNECTED',
  PLAYER_NOT_FOUND: 'PLAYER_NOT_FOUND',
  AMBIGUOUS_PLAYER: 'AMBIGUOUS_PLAYER',
  CAPTCHA: 'CAPTCHA',
  PAYMENT_PROMPT: 'PAYMENT_PROMPT',
  USER_PAUSED: 'USER_PAUSED',
  AUDIO_DEVICE_UNAVAILABLE: 'AUDIO_DEVICE_UNAVAILABLE',
  FFMPEG_UNAVAILABLE: 'FFMPEG_UNAVAILABLE',
  AUDIO_CAPTURE_FAILED: 'AUDIO_CAPTURE_FAILED',
  // P8: the browser refused to start playback (autoplay policy) — one click by the user, then「繼續」.
  PLAYBACK_BLOCKED: 'PLAYBACK_BLOCKED'
});

/** Definitive start failures reported by a non-OBS capture adapter (P4A audio). Nothing is recording. */
const CAPTURE_START_FAILURES = new Set([STOP_CODES.AUDIO_DEVICE_UNAVAILABLE, STOP_CODES.FFMPEG_UNAVAILABLE, STOP_CODES.AUDIO_CAPTURE_FAILED, STOP_CODES.DISK_LOW]);

/** Errors raised by a remote player bridge when the browser Companion is unreachable. Never retried. */
const COMPANION_ERRORS = new Set(['COMPANION_DISCONNECTED', 'COMPANION_TIMEOUT', 'COMPANION_UNPAIRED', 'COMPANION_NOT_PAIRED', 'COMPANION_TAB_UNBOUND']);
/** Stop codes a player adapter may request explicitly (result.stop / result.blocker / state.blocker). */
const PLAYER_STOPS = new Set(['DOM_CHANGED', 'PLAYER_NOT_FOUND', 'AMBIGUOUS_PLAYER', 'LOGIN_REQUIRED', 'CAPTCHA', 'PAYMENT_PROMPT', 'UNEXPECTED_LESSON', 'MEDIA_ERROR', 'PLAYBACK_BLOCKED']);

export const CAPTURE_MODES = Object.freeze(['audio', 'video']);
const RATES = [1, 1.25, 1.5, 1.75, 2];
const ACTIVE_STATES = new Set(['preparing', 'running']);
const SECRET_KEY = /pass(word)?|cookie|token|secret|authori[sz]ation|credential|session[-_]?id/i;

const DEFAULT_OPTIONS = Object.freeze({
  sampleIntervalMs: 500,
  bufferingTimeoutMs: 60_000,
  pausedGraceMs: 1_500,
  lessonTimeoutFactor: 1.5,
  lessonTimeoutPaddingMs: 120_000,
  lessonTimeoutUnknownMs: 4 * 60 * 60 * 1000,
  minFreeBytes: { audio: 512 * 1024 ** 2, video: 5 * 1024 ** 3 },
  maxEvents: 500,
  epochMs: 0
});

export class AgentError extends Error {
  constructor(code, message = code, details = {}) { super(message); this.name = 'AgentError'; this.code = code; Object.assign(this, details); }
}

class StopSignal extends Error {
  constructor(code, detail = '', flags = {}) { super(code); this.code = code; this.detail = detail; this.flags = flags; }
}

export function assertTransition(from, to) {
  if (!JOB_STATES.includes(from) || !JOB_STATES.includes(to)) throw new AgentError('INVALID_STATE', `未知狀態：${from} → ${to}`, { from, to });
  if (!TRANSITIONS[from].includes(to)) throw new AgentError('INVALID_TRANSITION', `不允許的狀態轉換：${from} → ${to}`, { from, to });
}

export const planHashOf = (plan) => `sha256:${crypto.createHash('sha256').update(stableStringify(plan)).digest('hex')}`;

/** Removes secret-looking keys and reduces filesystem paths to basenames before anything reaches job events. */
export function sanitizeEventValue(value, depth = 0) {
  if (value == null || typeof value === 'number' || typeof value === 'boolean') return value;
  if (typeof value === 'string') { const text = /[\\/]/.test(value) && /\.[a-z0-9]{2,5}$/i.test(value) ? path.win32.basename(value) : value; return text.slice(0, 300); }
  if (depth > 3) return null;
  if (Array.isArray(value)) return value.slice(0, 50).map((item) => sanitizeEventValue(item, depth + 1));
  if (typeof value === 'object') return Object.fromEntries(Object.entries(value).filter(([key]) => !SECRET_KEY.test(key)).map(([key, item]) => [key, sanitizeEventValue(item, depth + 1)]));
  return null;
}

function resolveRange(lessons, from, to) {
  const find = (ref, fallback) => {
    if (ref == null) return fallback;
    if (Number.isInteger(ref.order)) { if (ref.order < 1 || ref.order > lessons.length) throw new AgentError('INVALID_RANGE', `章節序號超出範圍：${ref.order}`); return ref.order - 1; }
    if (ref.platformLessonId) { const index = lessons.findIndex((item) => item.platformLessonId === ref.platformLessonId); if (index < 0) throw new AgentError('INVALID_RANGE', `找不到章節：${ref.platformLessonId}`); return index; }
    throw new AgentError('INVALID_RANGE', '章節範圍必須使用 order 或 platformLessonId');
  };
  const start = find(from, 0); const end = find(to, lessons.length - 1);
  if (start > end) throw new AgentError('INVALID_RANGE', '起始章節不可晚於結束章節');
  return lessons.slice(start, end + 1);
}

function buildPlan(input) {
  if (!CAPTURE_MODES.includes(input.captureMode)) throw new AgentError('INVALID_PLAN', 'captureMode 必須是 audio 或 video');
  if (!RATES.includes(input.rate)) throw new AgentError('INVALID_PLAN', '播放倍速必須是 1、1.25、1.5、1.75 或 2');
  if (input.markComplete) throw new AgentError('INVALID_PLAN', '本版不支援自動點擊平台「標記完成」');
  if (!Array.isArray(input.items) || !input.items.length) throw new AgentError('INVALID_PLAN', '至少需要一個課程或影片');
  const selection = []; const lessons = [];
  for (const item of input.items) {
    if (!/^crs_[0-9a-f]{12}$/.test(item.courseId || '')) throw new AgentError('INVALID_PLAN', 'courseId 格式錯誤');
    if (!/^rts_[0-9a-f]{12}$/.test(item.rightsId || '')) throw new AgentError('RIGHTS_REQUIRED', '每個課程都必須指定授權紀錄');
    if (!Array.isArray(item.lessons) || !item.lessons.length) throw new AgentError('INVALID_PLAN', '課程沒有章節');
    selection.push({ courseId: item.courseId, ...(item.from ? { from: item.from } : {}), ...(item.to ? { to: item.to } : {}) });
    for (const lesson of resolveRange(item.lessons, item.from, item.to)) {
      if (!lesson.platformLessonId || !lesson.title) throw new AgentError('INVALID_PLAN', '章節需要 platformLessonId 與 title');
      lessons.push({
        lessonId: lesson.lessonId || createId('les', `${item.courseId}:${lesson.platformLessonId}`), courseId: item.courseId, rightsId: item.rightsId,
        platformLessonId: String(lesson.platformLessonId).slice(0, 200), title: String(lesson.title).slice(0, 300),
        ...(lesson.url ? { url: String(lesson.url).slice(0, 2000) } : {}),
        ...(Number.isFinite(lesson.durationSec) ? { durationSec: lesson.durationSec } : {})
      });
    }
  }
  const backup = input.cloudBackup || {};
  return {
    captureMode: input.captureMode, rate: input.rate, record: true, markComplete: false,
    captionsEnabled: Boolean(input.captions?.enabled), captions: Array.isArray(input.captions?.languages) ? input.captions.languages.slice(0, 5) : [],
    cloudBackup: { enabled: Boolean(backup.enabled), ...(backup.destinationLabel ? { destinationLabel: String(backup.destinationLabel).slice(0, 200) } : {}), include: Array.isArray(backup.include) ? backup.include.filter((x) => typeof x === 'string').slice(0, 10) : [] },
    selection, lessons
  };
}

const defaultClock = { now: () => Date.now(), setTimeout: (fn, ms) => setTimeout(fn, ms), clearTimeout: (id) => clearTimeout(id) };

/**
 * Platform-independent learning agent. All side effects go through injected interfaces:
 * player, capture, store, clock, network and disk. The runner never retries a stopped job by itself.
 */
export function createAgentRunner({ player, capture, store, clock = defaultClock, network, disk, options = {}, onUpdate = () => {} } = {}) {
  for (const [name, dep] of Object.entries({ player, capture, store, network, disk })) if (!dep) throw new AgentError('MISSING_DEPENDENCY', `缺少 ${name}`);
  const opts = { ...DEFAULT_OPTIONS, ...options, minFreeBytes: { ...DEFAULT_OPTIONS.minFreeBytes, ...(options.minFreeBytes || {}) } };
  const jobs = new Map(); const listeners = new Set([onUpdate]);
  let active = null;
  const iso = (ms = clock.now()) => new Date(opts.epochMs + ms).toISOString();
  const clone = (value) => structuredClone(value);

  function notify(job) { const snapshot = clone(job); for (const fn of listeners) { try { fn(snapshot); } catch {} } }
  function event(job, type, value) { job.events.push({ at: iso(), type, ...(value === undefined ? {} : { value: sanitizeEventValue(value) }) }); if (job.events.length > opts.maxEvents) job.events.splice(0, job.events.length - opts.maxEvents); }
  function transition(job, to) { assertTransition(job.status, to); event(job, 'status', { from: job.status, to }); job.status = to; job.updatedAt = iso(); }
  /** Persist first, then notify the UI, so a notified state is always durable. */
  async function persist(job) { job.updatedAt = iso(); await store.saveJob(clone(job)); notify(job); }

  async function getJob(jobId) {
    if (jobs.has(jobId)) return jobs.get(jobId);
    const loaded = await store.loadJob?.(jobId); if (!loaded) throw new AgentError('JOB_NOT_FOUND', `找不到工作 ${jobId}`);
    jobs.set(jobId, loaded); return loaded;
  }

  async function createDraft(input) {
    const plan = buildPlan(input);
    for (const lesson of plan.lessons) if (await store.isLessonCompleted?.(lesson.lessonId)) lesson.skip = 'already-completed';
    const now = iso();
    const job = { id: createId('job'), schemaVersion: 1, createdAt: now, updatedAt: now, status: 'draft', plan, confirmedAt: null, checkpoint: null, blocker: null, events: [] };
    event(job, 'draft_created', { lessons: plan.lessons.length, captureMode: plan.captureMode, rate: plan.rate });
    jobs.set(job.id, job); await persist(job); return clone(job);
  }

  async function requestConfirmation(jobId) {
    const job = await getJob(jobId); transition(job, 'awaiting-confirmation');
    job.planHash = planHashOf(job.plan); await persist(job);
    const p = job.plan;
    return { jobId, planHash: job.planHash, summary: {
      lessons: p.lessons.map(({ courseId, platformLessonId, title, skip }) => ({ courseId, platformLessonId, title, ...(skip ? { skip } : {}) })),
      captureMode: p.captureMode, rate: p.rate, captionsEnabled: p.captionsEnabled, captions: p.captions, cloudBackup: p.cloudBackup,
      requiredAcknowledgements: ['recordPermission', 'privateProcessing']
    } };
  }

  async function checkRights(rightsId) {
    let record;
    try { record = await store.readRights(rightsId); } catch { record = null; }
    if (!record) throw new StopSignal(STOP_CODES.RIGHTS_REQUIRED, `找不到授權紀錄 ${rightsId}`);
    if (record.needsReconfirmation) throw new StopSignal(STOP_CODES.RIGHTS_REQUIRED, `授權紀錄 ${rightsId} 需要重新確認`);
    try { assertPrivateUse(record); } catch (error) { throw new StopSignal(STOP_CODES.RIGHTS_REQUIRED, error.message); }
  }

  async function confirm(jobId, { planHash, acknowledgements = {} } = {}) {
    const job = await getJob(jobId);
    if (job.status !== 'awaiting-confirmation') throw new AgentError('INVALID_TRANSITION', `工作狀態為 ${job.status}，不能確認`, { from: job.status, to: 'queued' });
    if (planHash !== job.planHash || planHashOf(job.plan) !== job.planHash) throw new AgentError('PLAN_CHANGED', '確認內容與目前計畫不一致，請重新檢視');
    if (acknowledgements.recordPermission !== true || acknowledgements.privateProcessing !== true) throw new AgentError(STOP_CODES.RIGHTS_REQUIRED, '必須確認錄製與私人處理授權');
    for (const rightsId of new Set(job.plan.lessons.map((lesson) => lesson.rightsId))) {
      try { await checkRights(rightsId); } catch (error) { throw new AgentError(STOP_CODES.RIGHTS_REQUIRED, error.detail || error.message, { rightsId }); }
    }
    job.confirmedAt = iso(); job.confirmation = { at: job.confirmedAt, planHash: job.planHash, acknowledgements: { recordPermission: true, privateProcessing: true } };
    transition(job, 'queued'); await persist(job); return clone(job);
  }

  function nextLessonIndex(job) {
    const done = new Set(job.checkpoint?.completedLessonIds || []);
    return job.plan.lessons.findIndex((lesson) => !lesson.skip && !done.has(lesson.lessonId));
  }

  function checkpointFor(ctx, subState) {
    const job = ctx.job; const lesson = job.plan.lessons[ctx.index]; const last = ctx.samples.at(-1);
    return {
      lessonIndex: Math.max(0, ctx.index), ...(lesson ? { lessonId: lesson.lessonId, platformLessonId: lesson.platformLessonId } : {}),
      subState, recordingSessionId: ctx.session?.id ?? null,
      sourceTime: last && Number.isFinite(last.src) ? last.src : null, rate: job.plan.rate,
      completedLessonIds: [...(job.checkpoint?.completedLessonIds || [])], savedAt: iso()
    };
  }

  async function saveCheckpoint(ctx, subState) { ctx.job.checkpoint = checkpointFor(ctx, subState); await store.saveCheckpoint(ctx.job.id, clone(ctx.job.checkpoint)); }

  function guard(ctx) { if (ctx.halted) throw new StopSignal('__HALTED__'); }

  async function act(ctx, name, fn, verify) {
    let lastReason = null;
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      let result; let ok = false;
      try { result = await fn(); ok = result?.ok !== false && (verify ? Boolean(await verify(result)) : true); }
      catch (error) {
        // A remote command that timed out may already have run; never repeat it.
        if (COMPANION_ERRORS.has(error?.code)) throw new StopSignal(STOP_CODES.COMPANION_DISCONNECTED, `${name}：${error.code}`);
        ok = false;
      }
      guard(ctx);
      if (ok) return result;
      if (PLAYER_STOPS.has(result?.stop)) throw new StopSignal(result.stop, `${name}：${result.stop}`);
      if (PLAYER_STOPS.has(result?.reason)) lastReason = result.reason;
      event(ctx.job, 'action_verification_failed', { action: name, attempt, ...(result?.reason ? { reason: String(result.reason).slice(0, 40) } : {}) });
    }
    throw new StopSignal(lastReason || STOP_CODES.DOM_CHANGED, `${name} 連續兩次驗證失敗`);
  }

  async function readState() { return (await player.getState()) || {}; }

  function sampleFrom(ctx, state, planRate) {
    return { rec: (clock.now() - ctx.captureStartedAtMs) / 1000, src: state.ad ? null : Number(state.currentTime), rate: Number(state.rate) || planRate, paused: Boolean(state.paused || state.ended), buffering: Boolean(state.buffering), ad: Boolean(state.ad) };
  }

  function timeMapFrom(ctx, endMs) {
    const endRec = Math.max((endMs - ctx.captureStartedAtMs) / 1000, (ctx.samples.at(-1)?.rec ?? 0) + 0.001, 0.001);
    try { return buildSpans(ctx.samples, { endRec, recOrigin: 0 }); }
    catch { return { quality: 'degraded', spans: [{ recStart: 0, recEnd: endRec, srcStart: null, srcEnd: null, rate: 0, kind: 'preroll' }] }; }
  }

  async function saveSession(ctx) { ctx.session.updatedAt = iso(); await store.saveSession(clone(ctx.session)); }

  function mapCaptureError(error) {
    const code = error?.code;
    if ([STOP_CODES.OBS_ALREADY_RECORDING, STOP_CODES.OBS_START_UNCONFIRMED, STOP_CODES.OBS_STOP_UNCONFIRMED, STOP_CODES.OBS_DISCONNECTED].includes(code)) return code;
    if (CAPTURE_START_FAILURES.has(code)) return code;
    return STOP_CODES.OBS_DISCONNECTED;
  }

  async function prepareLesson(ctx) {
    const { job } = ctx; const lesson = job.plan.lessons[ctx.index];
    ctx.subState = 'verifying_lesson';
    if (!(await network.isOnline())) throw new StopSignal(STOP_CODES.NETWORK_OFFLINE, '開始章節前偵測到離線');
    await checkRights(lesson.rightsId); guard(ctx);
    const free = await disk.freeBytes(); guard(ctx);
    if (!(free >= opts.minFreeBytes[job.plan.captureMode])) throw new StopSignal(STOP_CODES.DISK_LOW, `剩餘空間不足（${job.plan.captureMode}）`);
    ctx.subState = 'navigating';
    await act(ctx, 'navigate', () => player.navigate(clone(lesson)));
    ctx.subState = 'verifying_lesson';
    const page = await act(ctx, 'verifyPage', () => player.verifyPage(clone(lesson)), (result) => result.loginRequired || result.blocker || result.lessonId != null);
    if (PLAYER_STOPS.has(page.blocker)) throw new StopSignal(page.blocker, `平台頁面需要使用者處理：${page.blocker}`);
    if (page.loginRequired) throw new StopSignal(STOP_CODES.LOGIN_REQUIRED, '平台要求重新登入');
    if (page.lessonId !== lesson.platformLessonId) throw new StopSignal(STOP_CODES.UNEXPECTED_LESSON, '頁面上的章節與計畫不一致');
    ctx.subState = 'configuring';
    await act(ctx, 'setRate', () => player.setRate(job.plan.rate), async () => (await readState()).rate === job.plan.rate);
    event(job, 'rate_set', job.plan.rate);
    if (job.plan.captionsEnabled) {
      const captions = await act(ctx, 'enableCaptions', () => player.enableCaptions({ languages: job.plan.captions }));
      ctx.captions = { on: captions.available !== false, trackLabel: captions.trackLabel ?? null };
      event(job, captions.available === false ? 'captions_unavailable' : 'captions_on');
    } else ctx.captions = { on: false, trackLabel: null };
    ctx.subState = 'arming_obs';
    const now = iso();
    ctx.session = { id: createId('rec'), schemaVersion: 1, createdAt: now, updatedAt: now, lessonId: lesson.lessonId, agentJobId: job.id, title: lesson.title, status: 'starting', captureMode: job.plan.captureMode, requestedRate: job.plan.rate, captions: ctx.captions, obs: { startRequestedAt: now } };
    await saveSession(ctx); guard(ctx);
    // The wrapper marks the capture as started before any other continuation runs, so a halt that
    // arrives while start() is in flight can await it and still stop the recording it produced.
    ctx.captureStarting = capture.start({ jobId: job.id, lessonId: lesson.lessonId, sessionId: ctx.session.id, mode: job.plan.captureMode }).then((started) => {
      ctx.captureStarted = true; ctx.captureStartedAtMs = Number.isFinite(started?.startedAtMs) ? started.startedAtMs : clock.now();
      ctx.session.status = 'recording'; ctx.session.obs.startedAt = iso(ctx.captureStartedAtMs);
      return started;
    });
    try { await ctx.captureStarting; }
    catch (error) { const code = mapCaptureError(error); throw new StopSignal(code, `capture 啟動失敗：${error?.code || 'unknown'}`, { captureMayBeRecording: [STOP_CODES.OBS_DISCONNECTED, STOP_CODES.OBS_START_UNCONFIRMED].includes(code) }); }
    finally { ctx.captureStarting = null; }
    event(job, 'capture_started', { mode: job.plan.captureMode });
    guard(ctx);
    await saveSession(ctx); guard(ctx);
    ctx.subState = 'playing';
    await act(ctx, 'play', () => player.play(), async () => !(await readState()).paused);
    ctx.lessonStartedAtMs = clock.now();
    const first = await readState(); guard(ctx);
    ctx.samples.push(sampleFrom(ctx, first, job.plan.rate));
    await saveCheckpoint(ctx, 'playing'); guard(ctx);
  }

  function lessonTimeoutMs(lesson, rate) {
    return Number.isFinite(lesson.durationSec) ? (lesson.durationSec / rate) * 1000 * opts.lessonTimeoutFactor + opts.lessonTimeoutPaddingMs : opts.lessonTimeoutUnknownMs;
  }

  function playLesson(ctx) {
    const { job } = ctx; const lesson = job.plan.lessons[ctx.index]; const timeout = lessonTimeoutMs(lesson, job.plan.rate);
    let bufferingSince = null; let pausedSince = null;
    return new Promise((resolve) => {
      ctx.resolveLesson = resolve;
      const tick = async () => {
        ctx.tickTimer = null; if (ctx.halted) return;
        let state;
        try { state = await readState(); }
        catch (error) {
          if (COMPANION_ERRORS.has(error?.code)) { halt(ctx, new StopSignal(STOP_CODES.COMPANION_DISCONNECTED, `getState：${error.code}`)); return; }
          state = { error: 'state_unavailable' };
        }
        if (ctx.halted) return;
        const now = clock.now();
        ctx.samples.push(sampleFrom(ctx, state, job.plan.rate));
        const online = await network.isOnline(); if (ctx.halted) return;
        let stop = null;
        if (!online) stop = [STOP_CODES.NETWORK_OFFLINE, '播放中偵測到離線'];
        else if (state.loginRequired) stop = [STOP_CODES.LOGIN_REQUIRED, '平台要求重新登入'];
        else if (PLAYER_STOPS.has(state.blocker)) stop = [state.blocker, `平台頁面需要使用者處理：${state.blocker}`];
        else if (state.error) stop = [STOP_CODES.MEDIA_ERROR, '播放器回報媒體錯誤'];
        else if (state.lessonId != null && state.lessonId !== lesson.platformLessonId) stop = [STOP_CODES.UNEXPECTED_LESSON, '播放器切換到計畫外的章節'];
        if (!stop && state.ended) { resolve('ended'); return; }
        if (!stop) {
          bufferingSince = state.buffering && !state.ad ? (bufferingSince ?? now) : null;
          pausedSince = state.paused && !state.buffering && !state.ad ? (pausedSince ?? now) : null;
          if (bufferingSince != null && now - bufferingSince >= opts.bufferingTimeoutMs) stop = [STOP_CODES.BUFFERING_TIMEOUT, `緩衝超過 ${opts.bufferingTimeoutMs} ms`];
          else if (pausedSince != null && now - pausedSince >= opts.pausedGraceMs) stop = [STOP_CODES.PLAYER_PAUSED_EXTERNALLY, '播放器被外部暫停'];
          else if (now - ctx.lessonStartedAtMs >= timeout) stop = [STOP_CODES.LESSON_TIMEOUT, '章節播放時間超過上限'];
        }
        if (stop) { halt(ctx, new StopSignal(stop[0], stop[1])); return; }
        ctx.tickTimer = clock.setTimeout(tick, opts.sampleIntervalMs);
      };
      ctx.tickTimer = clock.setTimeout(tick, opts.sampleIntervalMs);
    });
  }

  async function finishLesson(ctx) {
    const { job } = ctx; const lesson = job.plan.lessons[ctx.index];
    ctx.subState = 'finishing';
    await act(ctx, 'pause', () => player.pause());
    ctx.session.status = 'stopping'; ctx.session.obs.stopRequestedAt = iso(); ctx.stopping = true;
    let result;
    try { result = await capture.stop(); }
    catch (error) { ctx.stopping = false; const code = mapCaptureError(error); throw new StopSignal(code === STOP_CODES.OBS_DISCONNECTED ? code : STOP_CODES.OBS_STOP_UNCONFIRMED, `capture 停止未確認：${error?.code || 'unknown'}`, { stopAttempted: true }); }
    ctx.stopping = false; ctx.captureStopped = true; guard(ctx);
    const endMs = clock.now(); ctx.session.timeMap = timeMapFrom(ctx, endMs);
    ctx.session.obs.stoppedAt = iso(endMs); ctx.session.captureStopConfirmed = true;
    if (!result?.wasActive || !result.outputPath) throw new StopSignal(STOP_CODES.CAPTURE_STOPPED_EXTERNALLY, '停止時 capture 已不在錄製', { captureAlreadyStopped: true });
    Object.assign(ctx.session, { status: 'completed', obsOutputPath: result.outputPath, obsOutputFiles: result.outputFiles?.length ? result.outputFiles : [result.outputPath], stopReason: { code: 'LESSON_ENDED' } });
    ctx.session.obs.pathSource = result.pathSource || 'response';
    if (typeof result.pathMismatch === 'boolean') ctx.session.obs.pathMismatch = result.pathMismatch;
    await saveSession(ctx);
    job.checkpoint = { ...(job.checkpoint || {}), completedLessonIds: [...(job.checkpoint?.completedLessonIds || []), lesson.lessonId] };
    event(job, 'lesson_completed', { platformLessonId: lesson.platformLessonId, outputFile: result.outputPath });
    await saveCheckpoint(ctx, 'processing_enqueued'); await persist(job);
  }

  /** Fixed stop procedure: pause player → stop capture → save session → checkpoint → status + notify. */
  function halt(ctx, signal) {
    if (ctx.haltPromise) return ctx.haltPromise;
    ctx.halted = true; if (ctx.tickTimer != null) { clock.clearTimeout(ctx.tickTimer); ctx.tickTimer = null; }
    ctx.haltPromise = (async () => {
      const { job } = ctx; const code = signal.code; const flags = signal.flags || {};
      const subState = ctx.subState || 'verifying_lesson';
      if (job.status !== 'stopping') transition(job, 'stopping');
      event(job, 'halt_requested', { code });
      if (code === STOP_CODES.COMPANION_DISCONNECTED) event(job, 'halt_player_pause_skipped');
      else { try { await player.pause(); event(job, 'halt_player_paused'); } catch { event(job, 'halt_player_pause_failed'); } }
      if (ctx.captureStarting) { try { await ctx.captureStarting; } catch {} }
      let captureStopConfirmed = null; let mayStillRecord = false;
      if (ctx.captureStarted && !ctx.captureStopped) {
        if (code === STOP_CODES.OBS_DISCONNECTED || flags.stopAttempted) { captureStopConfirmed = false; mayStillRecord = true; event(job, 'halt_capture_stop_skipped'); }
        else if (flags.captureAlreadyStopped || code === STOP_CODES.CAPTURE_STOPPED_EXTERNALLY) { captureStopConfirmed = true; }
        else {
          try { const result = await capture.stop(); ctx.captureStopped = true; captureStopConfirmed = true; ctx.stopResult = result; event(job, 'halt_capture_stopped'); }
          catch (error) { captureStopConfirmed = false; mayStillRecord = true; event(job, 'halt_capture_stop_failed', { code: error?.code || 'unknown' }); }
        }
      } else if (flags.captureMayBeRecording) { mayStillRecord = true; }
      if (ctx.session && ctx.session.status !== 'completed') {
        const s = ctx.session; const endMs = clock.now();
        if (ctx.captureStarted) {
          s.status = 'partial'; s.timeMap = s.timeMap || timeMapFrom(ctx, endMs);
          if (captureStopConfirmed) s.obs.stoppedAt = iso(endMs);
          const outputPath = ctx.stopResult?.outputPath; if (outputPath) { s.obsOutputPath = outputPath; s.obsOutputFiles = ctx.stopResult.outputFiles?.length ? ctx.stopResult.outputFiles : [outputPath]; s.obs.pathSource = ctx.stopResult.pathSource || 'response'; }
        } else s.status = 'failed';
        s.captureStopConfirmed = captureStopConfirmed ?? !mayStillRecord;
        s.stopReason = { code, ...(signal.detail ? { detail: String(signal.detail).slice(0, 500) } : {}) };
        if (mayStillRecord) s.stopReason.detail = `${s.stopReason.detail ? `${s.stopReason.detail}；` : ''}OBS 可能仍在錄影，請手動確認並停止`.slice(0, 500);
        await saveSession(ctx); event(job, 'halt_session_saved', { status: s.status });
      }
      await saveCheckpoint(ctx, subState); event(job, 'halt_checkpoint_saved');
      const final = code === STOP_CODES.USER_CANCELLED ? 'cancelled' : 'blocked';
      job.blocker = { code, at: iso(), ...(signal.detail ? { detail: String(signal.detail).slice(0, 500) } : {}), captureStopConfirmed: captureStopConfirmed ?? !mayStillRecord, obsMayStillBeRecording: mayStillRecord };
      if (mayStillRecord) job.blocker.detail = `${job.blocker.detail ? `${job.blocker.detail}；` : ''}OBS 可能仍在錄影`.slice(0, 500);
      if (code === STOP_CODES.COMPANION_DISCONNECTED) job.blocker.detail = `${job.blocker.detail ? `${job.blocker.detail}；` : ''}瀏覽器 Companion 失聯，播放器可能仍在播放`.slice(0, 500);
      transition(job, final); await persist(job);
      ctx.resolveLesson?.('halted');
    })();
    return ctx.haltPromise;
  }

  async function run(job) {
    const ctx = { job, index: -1, samples: [], halted: false };
    active = ctx;
    const offNetwork = network.on?.('change', (online) => { if (!online && active === ctx && ACTIVE_STATES.has(job.status)) halt(ctx, new StopSignal(STOP_CODES.NETWORK_OFFLINE, '網路中斷')); });
    const offCapture = [
      capture.on?.('disconnected', () => { if (active === ctx && ctx.captureStarted && !ctx.captureStopped) halt(ctx, new StopSignal(STOP_CODES.OBS_DISCONNECTED, 'capture 連線中斷')); }),
      capture.on?.('stoppedExternally', () => { if (active === ctx && ctx.captureStarted && !ctx.stopping) { ctx.captureStopped = true; halt(ctx, new StopSignal(STOP_CODES.CAPTURE_STOPPED_EXTERNALLY, '錄製被外部停止', { captureAlreadyStopped: true })); } }),
      capture.on?.('paused', () => { if (active === ctx && ctx.captureStarted && !ctx.captureStopped) halt(ctx, new StopSignal(STOP_CODES.CAPTURE_PAUSED_EXTERNALLY, '錄製被外部暫停')); })
    ];
    const offPlayer = player.on?.('disconnected', () => { if (active === ctx && ACTIVE_STATES.has(job.status)) halt(ctx, new StopSignal(STOP_CODES.COMPANION_DISCONNECTED, '瀏覽器 Companion 失聯')); });
    ctx.cancel = () => halt(ctx, new StopSignal(STOP_CODES.USER_CANCELLED, '使用者取消'));
    ctx.pause = () => halt(ctx, new StopSignal(STOP_CODES.USER_PAUSED, '使用者暫停'));
    try {
      while (true) {
        const index = nextLessonIndex(job);
        if (index < 0) { if (job.status === 'queued') transition(job, 'preparing'); transition(job, 'stopping'); job.blocker = null; ctx.index = job.plan.lessons.length - 1; transition(job, 'completed'); await persist(job); return clone(job); }
        Object.assign(ctx, { index, samples: [], session: null, captureStarting: null, captureStarted: false, captureStopped: false, stopResult: null, subState: 'navigating', captions: null });
        transition(job, 'preparing'); await persist(job);
        try {
          await prepareLesson(ctx);
          if (ctx.halted) { await ctx.haltPromise; return clone(job); }
          transition(job, 'running'); await persist(job);
          const outcome = await playLesson(ctx);
          if (outcome !== 'ended') { await ctx.haltPromise; return clone(job); }
          await finishLesson(ctx);
        } catch (error) {
          if (ctx.halted) { await ctx.haltPromise; return clone(job); }
          const signal = error instanceof StopSignal ? error
            : COMPANION_ERRORS.has(error?.code) ? new StopSignal(STOP_CODES.COMPANION_DISCONNECTED, `瀏覽器 Companion 錯誤：${error.code}`)
              : new StopSignal(STOP_CODES.OBS_DISCONNECTED, `未預期錯誤：${error?.message || error}`);
          await halt(ctx, signal); return clone(job);
        }
      }
    } finally {
      if (ctx.tickTimer != null) clock.clearTimeout(ctx.tickTimer);
      offNetwork?.(); offPlayer?.(); for (const off of offCapture) off?.();
      if (active === ctx) active = null;
    }
  }

  async function start(jobId) {
    const job = await getJob(jobId);
    if (['draft', 'awaiting-confirmation'].includes(job.status) || !job.confirmedAt) throw new AgentError('NOT_CONFIRMED', '工作尚未由使用者確認，不能開始');
    if (job.status !== 'queued') throw new AgentError('INVALID_TRANSITION', `工作狀態為 ${job.status}，不能開始`, { from: job.status, to: 'preparing' });
    if (capture.mode !== job.plan.captureMode) throw new AgentError('CAPTURE_MODE_MISMATCH', `capture 模式 ${capture.mode} 與計畫 ${job.plan.captureMode} 不符`);
    if (active) throw new AgentError('RUNNER_BUSY', '已有工作在執行');
    return run(job);
  }

  async function resume(jobId) {
    const job = await getJob(jobId);
    if (job.status !== 'blocked') throw new AgentError('INVALID_TRANSITION', `工作狀態為 ${job.status}，不能繼續`, { from: job.status, to: 'queued' });
    if (active) throw new AgentError('RUNNER_BUSY', '已有工作在執行');
    event(job, 'resumed_by_user', { previousBlocker: job.blocker?.code });
    job.blocker = null; transition(job, 'queued'); await persist(job);
    return start(jobId);
  }

  /** User pause: same fixed stop procedure, ends in blocked so the user can resume later. */
  async function pause(jobId) {
    const job = await getJob(jobId);
    if (!(active?.job === job && ['preparing', 'running'].includes(job.status))) throw new AgentError('INVALID_TRANSITION', `工作狀態為 ${job.status}，不能暫停`, { from: job.status, to: 'blocked' });
    await active.pause(); return clone(job);
  }

  async function cancel(jobId) {
    const job = await getJob(jobId);
    if (active?.job === job && ['preparing', 'running', 'stopping'].includes(job.status)) { await active.cancel(); return clone(job); }
    assertTransition(job.status, 'cancelled');
    event(job, 'cancelled_by_user'); transition(job, 'cancelled'); await persist(job); return clone(job);
  }

  /**
   * Crash-safe startup recovery. We never resume playback automatically because the browser,
   * capture process and persisted checkpoint may no longer describe the same external state.
   */
  async function recoverInterruptedJobs() {
    const recovered = [];
    for (const loaded of await store.listJobs?.() || []) {
      if (!['preparing', 'running', 'stopping'].includes(loaded.status)) continue;
      const job = clone(loaded); job.events ||= [];
      event(job, 'recovered_after_restart', { from: job.status });
      job.status = 'blocked'; job.updatedAt = iso();
      job.blocker = { code: STOP_CODES.SERVER_RESTARTED, at: iso(), detail: '程式重新啟動；請先確認播放器與錄製狀態，再由使用者繼續', captureStopConfirmed: false, obsMayStillBeRecording: true };
      for (const loadedSession of await store.listSessionsByJob?.(job.id) || []) {
        if (!['starting', 'recording', 'stopping'].includes(loadedSession.status)) continue;
        const session = clone(loadedSession); session.updatedAt = iso(); session.captureStopConfirmed = false;
        session.stopReason = { code: STOP_CODES.SERVER_RESTARTED, detail: '程式重新啟動，無法確認 capture 是否仍在執行' };
        if (session.status === 'starting') session.status = 'failed';
        else {
          session.status = 'partial';
          session.timeMap ||= { quality: 'degraded', spans: [{ recStart: 0, recEnd: 0.001, srcStart: null, srcEnd: null, rate: 0, kind: 'preroll' }] };
        }
        await store.saveSession(session);
      }
      jobs.set(job.id, job); await persist(job); recovered.push(job.id);
    }
    return recovered;
  }

  return {
    createDraft, requestConfirmation, confirm, start, resume, pause, cancel, recoverInterruptedJobs,
    async getJob(jobId) { return clone(await getJob(jobId)); },
    on(name, fn) { if (name !== 'update') throw new AgentError('UNKNOWN_EVENT', name); listeners.add(fn); return () => listeners.delete(fn); },
    get activeJobId() { return active?.job.id ?? null; }
  };
}
