import { JsonStore } from '../domain/store.mjs';
import fsp from 'node:fs/promises';

const ID = { job: /^job_[0-9a-f]{12}$/, rec: /^rec_[0-9a-f]{12}$/, rts: /^rts_[0-9a-f]{12}$/, les: /^les_[0-9a-f]{12}$/ };
const checked = (kind, id) => { if (!ID[kind].test(String(id))) throw new Error(`invalid ${kind} id`); return id; };

/** File-backed Runner store. Layout: agent-jobs/<jobId>.json, recording-sessions/<recId>.json, rights/<rtsId>.json. */
export function createJsonAgentStore(root) {
  const store = new JsonStore(root);
  async function list(folder) {
    let names; try { names = await fsp.readdir(store.resolve(folder)); } catch (error) { if (error.code === 'ENOENT') return []; throw error; }
    return Promise.all(names.filter((name) => name.endsWith('.json') && name !== 'completed-lessons.json').sort().map((name) => store.read(`${folder}/${name}`)));
  }
  return {
    async loadJob(id) { return store.read(`agent-jobs/${checked('job', id)}.json`, null); },
    async saveJob(job) { return store.write(`agent-jobs/${checked('job', job.id)}.json`, job); },
    async saveCheckpoint(jobId, checkpoint) { const job = await store.read(`agent-jobs/${checked('job', jobId)}.json`, null); if (job) await store.write(`agent-jobs/${jobId}.json`, { ...job, checkpoint }); },
    async saveSession(session) {
      await store.write(`recording-sessions/${checked('rec', session.id)}.json`, session);
      if (session.status !== 'completed') return;
      const index = await store.read('recording-sessions/completed-lessons.json', []);
      if (!index.includes(session.lessonId)) await store.write('recording-sessions/completed-lessons.json', [...index, checked('les', session.lessonId)]);
    },
    async readRights(id) { return store.read(`rights/${checked('rts', id)}.json`, null); },
    /** P5: the Agent console creates a private-study record only after the user's explicit confirmation. */
    async saveRights(record) { return store.write(`rights/${checked('rts', record.id)}.json`, record); },
    async listJobs() { return list('agent-jobs'); },
    async listSessions() { return list('recording-sessions'); },
    async listSessionsByJob(jobId) { checked('job', jobId); return (await list('recording-sessions')).filter((session) => session.agentJobId === jobId); },
    async isLessonCompleted(lessonId) {
      checked('les', lessonId);
      const index = await store.read('recording-sessions/completed-lessons.json', []);
      return Array.isArray(index) && index.includes(lessonId);
    }
  };
}
