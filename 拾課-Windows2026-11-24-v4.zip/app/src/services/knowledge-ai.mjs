const trimFence = (text) => String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
const parse = (text) => JSON.parse(trimFence(text));

function prompt(input, detail = 'standard') {
  const detailText = { concise: '只保留最重要的少量內容。', standard: '提供適量且實用的重點、名詞、待辦與複習題。', deep: '在引用充分的前提下，提供較完整的重點、名詞、待辦與複習題。' }[detail] || '提供適量且實用的整理。';
  return `你是課程助教。只根據輸入逐字稿整理內容，只輸出 JSON，不可虛構。所有項目必須提供輸入內的 segment id 作為 cite。使用繁體中文。整理詳細度：${detailText}\n輸出格式：{"title":"","keyPoints":[{"text":"","cite":["s0001"]}],"terms":[{"term":"","zh":"","definition":"","cite":["s0001"]}],"actions":[{"text":"","cite":["s0001"]}],"quiz":[{"q":"","type":"short","answer":"","cite":["s0001"]}]}\n輸入：${JSON.stringify(input)}`;
}

export function createKnowledgeGenerator(config = {}, { fetchImpl = globalThis.fetch } = {}) {
  const provider = config.aiProvider || 'ollama';
  // Undefined keeps older programmatic callers compatible. The real app always receives the explicit
  // config.example default (`basic`), so a fresh install never calls a model without the user's choice.
  if (provider === 'none' || config.knowledgeMode === 'basic') return null;
  if ((provider === 'openai' || provider === 'gemini') && config.externalTranscriptSharing !== 'confirmed') return null;
  return async (input) => {
    const content = prompt(input, config.summaryDetail); let response; let text;
    if (provider === 'ollama') {
      response = await fetchImpl(`${config.ollamaUrl || 'http://127.0.0.1:11434'}/api/generate`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ model: config.ollamaModel || 'qwen2.5:7b', stream: false, format: 'json', prompt: content }), signal: AbortSignal.timeout(90000) });
      if (!response.ok) throw new Error(`AI_HTTP_${response.status}`); text = (await response.json()).response;
    } else if (provider === 'openai') {
      if (!config.openaiApiKey) throw new Error('OPENAI_KEY_REQUIRED');
      response = await fetchImpl(`${String(config.openaiBaseUrl || 'https://api.openai.com/v1').replace(/\/$/, '')}/chat/completions`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${config.openaiApiKey}` }, body: JSON.stringify({ model: config.openaiModel || 'gpt-4.1-mini', response_format: { type: 'json_object' }, messages: [{ role: 'user', content }] }), signal: AbortSignal.timeout(90000) });
      if (!response.ok) throw new Error(`AI_HTTP_${response.status}`); text = (await response.json()).choices?.[0]?.message?.content;
    } else if (provider === 'gemini') {
      if (!config.geminiApiKey) throw new Error('GEMINI_KEY_REQUIRED');
      const model = encodeURIComponent(config.geminiModel || 'gemini-2.5-flash');
      response = await fetchImpl(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': config.geminiApiKey }, body: JSON.stringify({ contents: [{ parts: [{ text: content }] }], generationConfig: { responseMimeType: 'application/json' } }), signal: AbortSignal.timeout(90000) });
      if (!response.ok) throw new Error(`AI_HTTP_${response.status}`); text = (await response.json()).candidates?.[0]?.content?.parts?.[0]?.text;
    } else throw new Error('AI_PROVIDER_UNSUPPORTED');
    return parse(text);
  };
}
