import crypto from 'node:crypto';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { runCommand } from '../utils/process.mjs';
import { validateRights } from './rights.mjs';

export async function ingestAuthorizedUrl({ url, rights, importsFolder, pythonCommand }) {
  const parsed = new URL(url);
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('只接受 HTTP 或 HTTPS 網址');
  const record = validateRights({ ...rights, sourceUrl: url });
  const id = crypto.createHash('sha1').update(`${url}:${Date.now()}`).digest('hex').slice(0, 12);
  const target = path.join(importsFolder, id);
  await fsp.mkdir(target, { recursive: true });
  const template = path.join(target, 'source.%(ext)s');
  const { stdout } = await runCommand(pythonCommand, ['-m', 'yt_dlp', '--no-playlist', '--restrict-filenames', '--merge-output-format', 'mp4', '--write-info-json', '--output', template, '--print', 'after_move:filepath', url]);
  const video = stdout.split(/\r?\n/).filter(Boolean).at(-1);
  if (!video) throw new Error('網址匯入完成，但找不到輸出影片');
  await fsp.writeFile(`${video}.rights.json`, JSON.stringify(record, null, 2), 'utf8');
  return { id, video, rights: record };
}
