import path from 'node:path';
import { opaqueRef, readJson, writeJsonAtomic } from '../pipeline/files.mjs';

/**
 * Audio input devices as ffmpeg sees them. Windows (DirectShow) only in P4A.
 *
 * Nothing here guesses: a device is used only when the user picked it from this list and it is still
 * listed when capture starts. Names are stored only in the local config.json; logs use an opaque ref.
 * `hint: 'possible-system-audio'` is a name heuristic for the UI (e.g. "Stereo Mix", "CABLE Output"),
 * not a detection of loopback support — see docs/P4A_OPEN_QUESTIONS.md.
 */

export class AudioDeviceError extends Error {
  constructor(code, message) { super(message); this.name = 'AudioDeviceError'; this.code = code; }
}

const LOOPBACK_HINT = /stereo mix|立體聲混音|立体声混音|what u hear|wave out|loopback|cable output|virtual-audio-capturer|voicemeeter out/i;

/** Parses `ffmpeg -list_devices true -f dshow -i dummy` (both the ≥ 4.4 "(audio)" form and the older sectioned form). */
export function parseDshowDevices(text) {
  const devices = []; let section = null;
  for (const rawLine of String(text || '').split(/\r?\n/)) {
    const line = rawLine.replace(/^\[[^\]]*\]\s?/, '');
    if (/DirectShow video devices/i.test(line)) { section = 'video'; continue; }
    if (/DirectShow audio devices/i.test(line)) { section = 'audio'; continue; }
    const alternative = line.match(/^\s*Alternative name\s+"(.+)"\s*$/i);
    if (alternative) { const last = devices.at(-1); if (last && !last.alternativeName) last.alternativeName = alternative[1]; continue; }
    const modern = line.match(/^\s*"(.+)"\s+\(([^)]*)\)\s*$/);
    if (modern) { const types = modern[2].split(',').map((item) => item.trim()); devices.push({ name: modern[1], alternativeName: null, audio: types.includes('audio'), video: types.includes('video') }); continue; }
    const legacy = line.match(/^\s*"(.+)"\s*$/);
    if (legacy && section) devices.push({ name: legacy[1], alternativeName: null, audio: section === 'audio', video: section === 'video' });
  }
  return devices.filter((device) => device.audio).map((device) => ({ name: device.name, alternativeName: device.alternativeName, ...(LOOPBACK_HINT.test(device.name) ? { hint: 'possible-system-audio' } : {}) }));
}

export async function checkFfmpeg({ run, ffmpeg = 'ffmpeg' }) {
  try { const result = await run(ffmpeg, ['-hide_banner', '-version'], { timeoutMs: 15_000 }); return { available: true, version: (result.stdout.match(/ffmpeg version (\S+)/) || [])[1]?.slice(0, 40) || null }; }
  catch (error) { if (error?.code === 'COMMAND_NOT_FOUND') return { available: false, version: null }; throw new AudioDeviceError('FFMPEG_UNAVAILABLE', 'ffmpeg 無法執行'); }
}

export async function listAudioDevices({ run, ffmpeg = 'ffmpeg', platform = process.platform, inputFormat = 'dshow' }) {
  if (platform !== 'win32' || inputFormat !== 'dshow') throw new AudioDeviceError('AUDIO_DEVICE_LISTING_UNSUPPORTED', 'P4A 只支援 Windows DirectShow 裝置列表');
  let text;
  try { const result = await run(ffmpeg, ['-hide_banner', '-list_devices', 'true', '-f', 'dshow', '-i', 'dummy'], { timeoutMs: 20_000 }); text = `${result.stderr}\n${result.stdout}`; }
  catch (error) {
    if (error?.code === 'COMMAND_NOT_FOUND') throw new AudioDeviceError('FFMPEG_UNAVAILABLE', '找不到 ffmpeg');
    if (error?.code !== 'PROCESS_FAILED') throw new AudioDeviceError('AUDIO_DEVICE_LISTING_FAILED', '無法列出音訊裝置');
    text = `${error.stderr || ''}\n${error.stdout || ''}`; // -i dummy always exits non-zero after listing
  }
  return { inputFormat: 'dshow', devices: parseDshowDevices(text) };
}

/** Returns the configured device only if ffmpeg still lists it. Never falls back to another device. */
export function resolveAudioDevice(audioConfig, devices) {
  const name = audioConfig?.deviceName;
  if (typeof name !== 'string' || !name.trim()) throw new AudioDeviceError('AUDIO_DEVICE_UNAVAILABLE', '尚未選擇音訊裝置');
  const match = devices.find((device) => device.name === name) || (audioConfig.deviceAlternativeName ? devices.find((device) => device.alternativeName === audioConfig.deviceAlternativeName) : null);
  if (!match) throw new AudioDeviceError('AUDIO_DEVICE_UNAVAILABLE', '選定的音訊裝置目前不存在');
  return match;
}

/**
 * DirectShow input argument. dshow splits `video=…:audio=…` on ':', so a friendly name containing ':' is
 * addressed by its alternative name instead; without one it is refused rather than mangled.
 */
export function dshowInputArg(device) {
  if (!device.name.includes(':')) return `audio=${device.name}`;
  if (device.alternativeName && !device.alternativeName.includes(':')) return `audio=${device.alternativeName}`;
  throw new AudioDeviceError('AUDIO_DEVICE_NAME_UNSUPPORTED', '裝置名稱含有冒號且沒有可用的替代名稱');
}

export const deviceRef = (device) => (device?.name ? opaqueRef(device.name) : null);

/** Stores the user's explicit choice in the local config.json (never in logs or job data). */
export async function saveAudioDeviceSelection({ configFile, name, devices }) {
  const device = devices.find((item) => item.name === name);
  if (!device) throw new AudioDeviceError('AUDIO_DEVICE_UNAVAILABLE', '只能選擇目前列出的裝置');
  if (path.basename(configFile) !== 'config.json') throw new AudioDeviceError('CONFIG_PATH_INVALID', '只能寫入本機 config.json');
  const config = await readJson(configFile, {});
  config.audioCapture = { ...(config.audioCapture || {}), backend: 'ffmpeg', inputFormat: 'dshow', deviceName: device.name, deviceAlternativeName: device.alternativeName || null };
  await writeJsonAtomic(configFile, config);
  return { deviceRef: deviceRef(device), audioCapture: { ...config.audioCapture } };
}
