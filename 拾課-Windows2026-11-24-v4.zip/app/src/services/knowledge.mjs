import { createId, createStageKey } from '../domain/ids.mjs';

const clean = (value, max = 500) => String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
const range = (segment, key, fallback) => Array.isArray(segment?.[key]) ? segment[key] : fallback;

export function normalizeKnowledgeSegments(input = []) {
  return input.map((segment, index) => {
    const rec = range(segment, 'rec', [Number(segment.start) || 0, Number(segment.end) || Number(segment.start) || 0]);
    const src = range(segment, 'src', rec);
    return {
      id: /^s[0-9]{4,}$/.test(segment.id) ? segment.id : `s${String(index + 1).padStart(4, '0')}`,
      rec: [Number(rec[0]) || 0, Math.max(Number(rec[1]) || 0, Number(rec[0]) || 0)],
      src: src[0] == null || src[1] == null ? [null, null] : [Number(src[0]), Number(src[1])],
      text: clean(segment.text, 4000)
    };
  }).filter((segment) => segment.text && segment.rec[1] >= segment.rec[0]);
}

export function fixedKnowledgeChapters(segments, chapterMinutes = 6) {
  if (!segments.length) return [];
  const span = Math.max(60, Number(chapterMinutes) * 60 || 360); const groups = [];
  for (const segment of segments) {
    const sourceTime = segment.src[0] ?? segment.rec[0];
    const index = Math.floor(sourceTime / span);
    (groups[index] ||= []).push(segment);
  }
  return groups.filter(Boolean).map((items, index) => ({
    id: `ch${index + 1}`,
    title: `章節 ${index + 1}`,
    src: items[0].src[0] == null ? [null, null] : [items[0].src[0], items.at(-1).src[1]],
    rec: [items[0].rec[0], items.at(-1).rec[1]],
    segmentIds: items.map((item) => item.id)
  }));
}

function heuristicChapter(chapter, segments) {
  const points = segments.slice(0, 4).map((segment) => ({ text: clean(segment.text, 160), cite: [segment.id] }));
  const counts = new Map();
  for (const segment of segments) for (const token of segment.text.match(/[A-Za-z][A-Za-z0-9_-]{3,}|[\u4e00-\u9fff]{2,6}/g) || []) {
    const key = token.toLowerCase();
    if (/^(這個|一個|我們|你們|就是|可以|because|that|this|with)$/.test(key)) continue;
    const entry = counts.get(key) || { term: token, count: 0, cite: [] }; entry.count += 1;
    if (!entry.cite.includes(segment.id)) entry.cite.push(segment.id); counts.set(key, entry);
  }
  const terms = [...counts.values()].sort((a, b) => b.count - a.count).slice(0, 5).map(({ term, cite }) => ({ term, definition: '逐字稿中反覆出現的關鍵詞，請依引用片段理解其上下文。', cite: cite.slice(0, 3) }));
  const actions = segments.filter((segment) => /(要|應該|記得|步驟|try|should|must|next)/i.test(segment.text)).slice(0, 4).map((segment) => ({ text: clean(segment.text, 160), cite: [segment.id] }));
  const quiz = points.slice(0, 3).map((point, index) => ({ q: `第 ${index + 1} 題：這段內容的核心意思是什麼？`, type: 'short', answer: point.text, cite: point.cite }));
  return { title: clean(points[0]?.text, 20) || chapter.title, keyPoints: points, terms, actions, quiz, fallback: 'heuristic' };
}

function validCite(item, allowed) {
  return Array.isArray(item?.cite) && item.cite.length > 0 && item.cite.every((id) => allowed.has(id));
}

export function validateChapterKnowledge(value, chapter, segments) {
  if (!value || typeof value !== 'object') throw new Error('AI_KNOWLEDGE_INVALID');
  const allowed = new Set(chapter.segmentIds); const byId = new Map(segments.map((segment) => [segment.id, segment.text]));
  const numbersSupported = (item) => {
    const { cite, ...claim } = item; const claims = JSON.stringify(claim).match(/\d+(?:\.\d+)?/g) || [];
    const evidence = item.cite.map((id) => byId.get(id) || '').join(' ');
    return claims.every((number) => evidence.includes(number));
  };
  const take = (name, max) => (Array.isArray(value[name]) ? value[name] : []).filter((item) => validCite(item, allowed) && numbersSupported(item)).slice(0, max);
  const keyPoints = take('keyPoints', 6).map((item) => ({ text: clean(item.text, 160), cite: [...new Set(item.cite)] })).filter((item) => item.text);
  const terms = take('terms', 8).map((item) => ({ term: clean(item.term, 120), ...(clean(item.zh, 120) ? { zh: clean(item.zh, 120) } : {}), definition: clean(item.definition, 240), cite: [...new Set(item.cite)] })).filter((item) => item.term && item.definition);
  const actions = take('actions', 5).map((item) => ({ text: clean(item.text, 160), cite: [...new Set(item.cite)] })).filter((item) => item.text);
  const quiz = take('quiz', 5).map((item) => {
    const type = item.type === 'mcq' ? 'mcq' : 'short'; const options = type === 'mcq' && Array.isArray(item.options) ? item.options.map((option) => clean(option, 160)).filter(Boolean).slice(0, 4) : undefined;
    return { q: clean(item.q, 240), type, ...(options ? { options } : {}), answer: clean(item.answer, 240), cite: [...new Set(item.cite)] };
  }).filter((item) => item.q && item.answer && (item.type !== 'mcq' || item.options?.includes(item.answer)));
  if (!keyPoints.length) return heuristicChapter(chapter, segments);
  return { title: clean(value.title, 120) || chapter.title, keyPoints, terms, actions, quiz };
}

export async function buildKnowledgePack({ title = '', track, chapterMinutes = 6, generate, now = new Date().toISOString() } = {}) {
  const segments = normalizeKnowledgeSegments(track?.segments || []);
  if (!segments.length) throw new Error('KNOWLEDGE_TRANSCRIPT_EMPTY');
  const chapters = fixedKnowledgeChapters(segments, chapterMinutes); const byId = new Map(segments.map((segment) => [segment.id, segment]));
  const results = [];
  for (const chapter of chapters) {
    const rows = chapter.segmentIds.map((id) => byId.get(id)); let value;
    if (typeof generate === 'function') {
      try { value = validateChapterKnowledge(await generate({ chapterId: chapter.id, chapterTitle: chapter.title, lessonTitle: title, language: track.language || 'auto', segments: rows.map(({ id, text }) => ({ id, text })) }), chapter, rows); }
      catch { value = heuristicChapter(chapter, rows); }
    } else value = heuristicChapter(chapter, rows);
    chapter.title = value.title; results.push({ chapter, value });
  }
  const assetId = track.assetId || createId('ast', title || track.id || 'knowledge');
  const trackId = /^trk_[0-9a-f]{12}$/.test(track.id) ? track.id : createId('trk', `${assetId}:legacy`);
  const lessonId = createId('les', `${assetId}:lesson`);
  const stageKey = createStageKey({ stage: 'knowledge', inputIds: [trackId], inputRevisions: [track.revision || 1], params: { chapterMinutes }, pipelineVersion: 'p4b-1' });
  const withChapter = (name) => results.flatMap(({ chapter, value }) => (value[name] || []).map((item) => ({ chapterId: chapter.id, ...item })));
  const fallback = results.some(({ value }) => value.fallback) ? 'heuristic' : undefined;
  return {
    id: createId('kp', stageKey), schemaVersion: 1, createdAt: now, updatedAt: now, lessonId, trackId, trackRevision: track.revision || 1,
    language: 'zh-Hant', stageKey, promptVersion: 'chapter-notes.v1',
    chapters: chapters.map(({ rec, ...chapter }) => chapter), keyPoints: withChapter('keyPoints'), terms: withChapter('terms'), actions: withChapter('actions'), quiz: withChapter('quiz'), ...(fallback ? { fallback } : {})
  };
}

export function knowledgePackToCourseChapters(pack, trackSegments) {
  const segments = normalizeKnowledgeSegments(trackSegments); const byId = new Map(segments.map((segment) => [segment.id, segment]));
  const select = (name, id) => (pack[name] || []).filter((item) => item.chapterId === id);
  return pack.chapters.map((chapter) => {
    const rows = chapter.segmentIds.map((id) => byId.get(id)).filter(Boolean);
    return {
      id: chapter.id, start: rows[0]?.rec[0] || 0, end: rows.at(-1)?.rec[1] || 0, title: chapter.title, segmentIds: chapter.segmentIds,
      summary: select('keyPoints', chapter.id), terms: select('terms', chapter.id).map((item) => ({ ...item, explanation: item.definition })),
      actions: select('actions', chapter.id), questions: select('quiz', chapter.id)
    };
  });
}
