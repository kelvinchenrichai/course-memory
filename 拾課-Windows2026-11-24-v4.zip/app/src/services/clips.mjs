import crypto from 'node:crypto';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { runCommand } from '../utils/process.mjs';

const clipId = () => crypto.randomBytes(6).toString('hex');
const srtTime = (value) => { const ms = Math.max(0, Math.round(value * 1000)); const h = Math.floor(ms / 3600000), m = Math.floor(ms % 3600000 / 60000), s = Math.floor(ms % 60000 / 1000), x = ms % 1000; return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(x).padStart(3, '0')}`; };

export function suggestClips(course) {
  return (course.chapters || []).map((chapter, index) => {
    const start = chapter.start;
    const end = Math.min(chapter.end || start + 60, start + 90);
    const nearbyMarkers = (course.markers || []).filter((marker) => marker.at >= start && marker.at <= end).length;
    const score = Math.min(99, 62 + nearbyMarkers * 9 + Math.min(18, (chapter.summary || []).length * 4));
    return { id: `${course.id}-suggestion-${index + 1}`, courseId: course.id, title: chapter.title, hook: chapter.summary?.[0] || chapter.transcript?.slice(0, 120) || '值得回看的片段', start, end, duration: end - start, score };
  }).sort((a, b) => b.score - a.score);
}

export async function exportClip({ course, start, end, title, format = 'vertical', clipsFolder }) {
  start = Number(start); end = Number(end);
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start || end - start > 180) throw new Error('片段範圍必須介於 1 到 180 秒');
  const id = clipId(); const dir = path.join(clipsFolder, id); await fsp.mkdir(dir, { recursive: true });
  const output = path.join(dir, `${format === 'vertical' ? 'vertical-9x16' : 'horizontal-16x9'}.mp4`);
  const subtitle = path.join(dir, 'captions.srt');
  const segments = (course.segments || []).filter((segment) => segment.end > start && segment.start < end);
  const srt = segments.map((segment, index) => `${index + 1}\n${srtTime(Math.max(0, segment.start - start))} --> ${srtTime(Math.min(end - start, segment.end - start))}\n${segment.text}\n`).join('\n');
  await fsp.writeFile(subtitle, srt, 'utf8');
  const args = ['-y', '-ss', String(start), '-to', String(end), '-i', course.video];
  if (format === 'vertical') args.push('-filter_complex', '[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,gblur=sigma=28[bg];[0:v]scale=1080:1920:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v]', '-map', '[v]', '-map', '0:a?');
  args.push('-c:v', 'libx264', '-preset', 'medium', '-crf', '20', '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', output);
  await runCommand('ffmpeg', args);
  const manifest = { id, courseId: course.id, title: String(title || course.title).slice(0, 160), format, start, end, duration: end - start, file: output, subtitle, createdAt: new Date().toISOString(), status: 'ready' };
  await fsp.writeFile(path.join(dir, 'clip.json'), JSON.stringify(manifest, null, 2), 'utf8');
  return manifest;
}
