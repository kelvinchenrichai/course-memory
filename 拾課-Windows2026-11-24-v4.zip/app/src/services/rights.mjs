import { createId } from '../domain/ids.mjs';

export const RIGHTS_BASES = ['owned', 'licensed', 'cc', 'public-domain', 'platform-permitted', 'personal-study'];

const evidenceList = (value) => (Array.isArray(value) ? value : []).map((item) => typeof item === 'string' ? { type: 'note', value: item } : { type: String(item.type || 'note'), value: String(item.value || '') }).filter((item) => item.value);

export function validateRights(input = {}, { now = new Date().toISOString() } = {}) {
  if (!RIGHTS_BASES.includes(input.basis)) throw new Error('請選擇有效的素材授權依據');
  if (input.acknowledged !== true && input.recordPermissionAcknowledged !== true) throw new Error('請先確認你有權錄製或匯入這份素材');
  if (typeof input.privateTransformAllowed !== 'boolean') throw new Error('請明確設定是否允許私人加工');
  const evidence = evidenceList(input.evidence);
  if (input.allowDerivative && input.basis === 'personal-study') throw new Error('personal-study 不可開啟公開二創');
  if (input.allowDerivative && !evidence.length) throw new Error('開啟公開二創需要授權證據');
  return {
    id: input.id || createId('rts'), schemaVersion: 1, basis: input.basis,
    allowDerivative: Boolean(input.allowDerivative), recordPermissionAcknowledged: true,
    privateTransformAllowed: input.privateTransformAllowed,
    sourceUrl: String(input.sourceUrl || '').slice(0, 2000), licenseUrl: String(input.licenseUrl || '').slice(0, 2000),
    owner: String(input.owner || '').slice(0, 200), note: String(input.note || '').slice(0, 1000),
    evidence, acknowledgedAt: input.acknowledgedAt || now,
    history: Array.isArray(input.history) ? input.history : [], createdAt: input.createdAt || now, updatedAt: now
  };
}

export function assertPrivateUse(rights) {
  if (!rights?.recordPermissionAcknowledged) throw new Error('缺少錄製／匯入權限確認');
  if (rights.privateTransformAllowed !== true) throw new Error('這份素材未明確允許私人加工');
  return true;
}

export function assertPublicExportRecord(rights) {
  if (!rights) throw new Error('找不到授權紀錄');
  if (rights.basis === 'personal-study') throw new Error('personal-study 素材不可公開輸出');
  if (!rights.allowDerivative) throw new Error('尚未開啟公開二創權限');
  if (!evidenceList(rights.evidence).length) throw new Error('公開輸出需要授權證據');
  return true;
}

export async function assertPublicExport(rightsId, { readRights } = {}) {
  if (typeof readRights !== 'function') throw new Error('公開輸出必須重新讀取授權紀錄');
  const fresh = await readRights(rightsId); assertPublicExportRecord(fresh); return fresh;
}

export function updateRightsRecord(record, changes, { now = new Date().toISOString() } = {}) {
  const next = { ...record, evidence: evidenceList(record.evidence), history: [...(record.history || [])] };
  for (const field of ['basis', 'allowDerivative', 'privateTransformAllowed', 'evidence', 'owner', 'licenseUrl', 'note']) {
    if (!(field in changes)) continue; const value = field === 'evidence' ? evidenceList(changes[field]) : changes[field];
    if (JSON.stringify(next[field]) === JSON.stringify(value)) continue;
    next.history.push({ at: now, field, from: next[field] ?? null, to: value }); next[field] = value;
  }
  if (!RIGHTS_BASES.includes(next.basis)) throw new Error('請選擇有效的素材授權依據');
  if (typeof next.privateTransformAllowed !== 'boolean') throw new Error('請明確設定是否允許私人加工');
  if (next.allowDerivative && next.basis === 'personal-study') throw new Error('personal-study 不可開啟公開二創');
  if (next.allowDerivative && !evidenceList(next.evidence).length) throw new Error('開啟公開二創需要授權證據');
  next.updatedAt = now; return next;
}
