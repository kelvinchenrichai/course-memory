import { sanitizeDiscoveryPayload } from '../discovery/urls.mjs';
import crypto from 'node:crypto';

/**
 * Browser Companion hub: a localhost HTTP JSON bridge between this server and the MV3 extension.
 * The extension long-polls for commands and POSTs results/state. No WebSocket server is needed.
 * Security: localhost Host header only, extension-origin CORS only, hashed pairing token compared in
 * constant time, single-delivery commands with ids, TTLs and duplicate/late rejection. Tokens, codes,
 * cookies and page DOM never reach logs or responses (except the token once, in the pairing response).
 */

export const COMPANION_ERROR_CODES = Object.freeze(['COMPANION_DISCONNECTED', 'COMPANION_TIMEOUT', 'COMPANION_UNPAIRED', 'COMPANION_NOT_PAIRED', 'COMPANION_TAB_UNBOUND']);
export const COMMAND_TYPES = Object.freeze(['navigate', 'verifyPage', 'setRate', 'enableCaptions', 'play', 'pause', 'getState', 'nextLesson', 'detect', 'discover']);
export const EXTENSION_ORIGIN = /^chrome-extension:\/\/[a-p]{32}$/;
const LOCAL_HOSTS = new Set(['127.0.0.1', 'localhost', '[::1]']);
const COMMAND_ID = /^[0-9a-f]{32}$/;
const CODE_LIKE = /^[A-Z][A-Z0-9_]{1,47}$/;
const ADAPTERS = new Set(['generic-html5', 'youtube', 'bilibili']);
const PLATFORMS = new Set(['youtube', 'bilibili', 'skool', 'satKnowledge', 'generic']);
const PLAYER_STATUS = new Set(['ok', 'PLAYER_NOT_FOUND', 'AMBIGUOUS_PLAYER', 'NO_PERMISSION', 'NOT_INJECTED']);
const BLOCKERS = new Set(['LOGIN_REQUIRED', 'CAPTCHA', 'PAYMENT_PROMPT', 'PLAYER_NOT_FOUND', 'AMBIGUOUS_PLAYER', 'DOM_CHANGED', 'UNEXPECTED_LESSON', 'MEDIA_ERROR', 'PLAYBACK_BLOCKED']);
const TAB_ERRORS = new Set(['TAB_CLOSED', 'TAB_NOT_BOUND', 'PERMISSION_MISSING', 'CONTENT_NOT_READY']);
const DEFAULT_TTL = { getState: 10000, detect: 10000, discover: 8000, verifyPage: 8000, navigate: 30000, default: 10000 };
const DEFAULTS = { pairingCodeTtlMs: 120_000, maxPairingAttempts: 5, offlineAfterMs: 15_000, maxPollWaitMs: 25_000, finishedMemory: 500 };
const defaultClock = { now: () => Date.now(), setTimeout: (fn, ms) => setTimeout(fn, ms), clearTimeout: (id) => clearTimeout(id) };
const silent = { info() {}, warn() {}, error() {} };

export class CompanionError extends Error {
  constructor(code, message = code) { super(message); this.name = 'CompanionError'; this.code = code; }
}

const sha256 = (value) => crypto.createHash('sha256').update(String(value)).digest();
const safeEqual = (a, b) => Buffer.isBuffer(a) && Buffer.isBuffer(b) && a.length === b.length && crypto.timingSafeEqual(a, b);
const str = (value, max) => (typeof value === 'string' ? value.slice(0, max) : null);
const num = (value, min = -Infinity, max = Infinity) => (typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max ? value : null);
const bool = (value) => (typeof value === 'boolean' ? value : null);
const code = (value) => (typeof value === 'string' && CODE_LIKE.test(value) ? value : null);
const compact = (object) => Object.fromEntries(Object.entries(object).filter(([, value]) => value !== null && value !== undefined));

/** Allowlist for player state coming from the extension. Anything not listed is dropped. */
export function sanitizePlayerState(raw) {
  if (!raw || typeof raw !== 'object') return {};
  const captions = raw.captions && typeof raw.captions === 'object' ? compact({ available: bool(raw.captions.available), on: bool(raw.captions.on), languages: Array.isArray(raw.captions.languages) ? raw.captions.languages.map((x) => str(x, 16)).filter(Boolean).slice(0, 5) : null }) : null;
  const capabilities = raw.capabilities && typeof raw.capabilities === 'object' ? compact(Object.fromEntries(['play', 'pause', 'setRate', 'captions', 'nextLesson', 'navigate', 'blockerDetection'].map((key) => [key, bool(raw.capabilities[key])]))) : null;
  return compact({
    adapterId: ADAPTERS.has(raw.adapterId) ? raw.adapterId : null, platform: PLATFORMS.has(raw.platform) ? raw.platform : null,
    currentTime: num(raw.currentTime, 0), duration: num(raw.duration, 0), rate: num(raw.rate, 0.0625, 16),
    paused: bool(raw.paused), ended: bool(raw.ended), buffering: bool(raw.buffering), ad: bool(raw.ad), online: bool(raw.online),
    error: code(raw.error), blocker: BLOCKERS.has(raw.blocker) ? raw.blocker : null, loginRequired: bool(raw.loginRequired),
    lessonId: str(raw.lessonId, 200), title: str(raw.title, 200), isPlaylist: bool(raw.isPlaylist), captions, capabilities
  });
}

/** Allowlist for a command result; `state` is nested and sanitized separately. */
export function sanitizeCommandResult(raw) {
  if (!raw || typeof raw !== 'object') return { ok: false, reason: 'EMPTY_RESULT' };
  return compact({
    ok: raw.ok === true, reason: code(raw.reason), stop: BLOCKERS.has(raw.stop) ? raw.stop : null, blocker: BLOCKERS.has(raw.blocker) ? raw.blocker : null,
    lessonId: str(raw.lessonId, 200), loginRequired: bool(raw.loginRequired), available: bool(raw.available), trackLabel: str(raw.trackLabel, 80),
    rate: num(raw.rate, 0.0625, 16), adapterId: ADAPTERS.has(raw.adapterId) ? raw.adapterId : null, platform: PLATFORMS.has(raw.platform) ? raw.platform : null, isPlaylist: bool(raw.isPlaylist),
    capabilities: raw.capabilities && typeof raw.capabilities === 'object' ? sanitizePlayerState({ capabilities: raw.capabilities }).capabilities : null,
    state: raw.state ? sanitizePlayerState(raw.state) : null,
    // P7A: course-list discovery result, re-checked against the server-side allowlist.
    discovery: raw.discovery ? sanitizeDiscoveryPayload(raw.discovery) : null
  });
}

function sanitizeTab(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const tabId = Number.isInteger(raw.tabId) && raw.tabId >= 0 ? raw.tabId : null; if (tabId == null) return null;
  let origin = null; try { const url = new URL(String(raw.origin)); if (['http:', 'https:'].includes(url.protocol)) origin = url.origin; } catch {}
  return compact({ tabId, origin, bound: raw.bound === true, adapterId: ADAPTERS.has(raw.adapterId) ? raw.adapterId : null, playerStatus: PLAYER_STATUS.has(raw.playerStatus) ? raw.playerStatus : null, lessonId: str(raw.lessonId, 200), title: str(raw.title, 200), permissionGranted: bool(raw.permissionGranted), capabilities: sanitizePlayerState({ capabilities: raw.capabilities }).capabilities ?? null });
}

export function createCompanionHub({ clock = defaultClock, random = (n) => crypto.randomBytes(n), logger = silent, options = {}, persistence = null } = {}) {
  const opts = { ...DEFAULTS, ...options };
  const instanceId = random(8).toString('hex');
  const listeners = new Map();
  let pairingCode = null; let pairing = null; let lastSeenMs = null; let connected = false; let watchdog = null;
  let browserOnline = null; let extensionVersion = null;
  const inFlightPolls = new Set(); const queue = []; const pending = new Map(); const finished = new Map();
  const tabs = new Map(); const states = new Map();

  const emit = (name, value) => { for (const fn of [...(listeners.get(name) || [])]) { try { fn(value); } catch {} } };
  const log = (level, event, extra = {}) => logger[level]?.({ event, ...extra });
  const remember = (id, outcome) => { finished.set(id, outcome); while (finished.size > opts.finishedMemory) finished.delete(finished.keys().next().value); };

  async function restore() {
    const saved = await persistence?.load?.();
    if (saved && typeof saved.tokenHash === 'string' && EXTENSION_ORIGIN.test(saved.origin || '')) pairing = { tokenHash: Buffer.from(saved.tokenHash, 'hex'), origin: saved.origin, pairedAt: saved.pairedAt || null, clientName: str(saved.clientName, 60) };
  }
  const persist = () => persistence?.save?.(pairing ? { tokenHash: pairing.tokenHash.toString('hex'), origin: pairing.origin, pairedAt: pairing.pairedAt, clientName: pairing.clientName } : null);

  function failAll(errorCode) {
    for (const [id, item] of pending) { clock.clearTimeout(item.timer); remember(id, 'failed'); item.reject(new CompanionError(errorCode)); }
    pending.clear(); queue.length = 0;
  }

  function isConnected() { return Boolean(pairing) && (inFlightPolls.size > 0 || (lastSeenMs != null && clock.now() - lastSeenMs <= opts.offlineAfterMs)); }

  function armWatchdog() {
    if (watchdog != null) clock.clearTimeout(watchdog);
    watchdog = clock.setTimeout(() => { watchdog = null; checkConnection(); }, opts.offlineAfterMs + 1);
  }

  function checkConnection() {
    if (isConnected()) { if (inFlightPolls.size === 0) armWatchdog(); return; }
    if (connected) { connected = false; failAll('COMPANION_DISCONNECTED'); log('warn', 'companion_disconnected'); emit('disconnected', { at: clock.now() }); }
  }

  function touch() {
    lastSeenMs = clock.now();
    if (!connected) { connected = true; log('info', 'companion_connected'); emit('connected', { at: lastSeenMs }); }
    armWatchdog();
  }

  function createPairingCode() {
    const value = String(random(4).readUInt32BE(0) % 1_000_000).padStart(6, '0');
    pairingCode = { hash: sha256(value), expiresAt: clock.now() + opts.pairingCodeTtlMs, attempts: 0 };
    log('info', 'pairing_code_created');
    return { code: value, expiresInMs: opts.pairingCodeTtlMs };
  }

  async function pair({ code: input, origin, clientName }) {
    if (!EXTENSION_ORIGIN.test(origin || '')) throw new CompanionError('COMPANION_BAD_ORIGIN');
    if (opts.allowedExtensionIds?.length && !opts.allowedExtensionIds.includes(origin.slice('chrome-extension://'.length))) throw new CompanionError('COMPANION_BAD_ORIGIN');
    if (!pairingCode || clock.now() > pairingCode.expiresAt) { pairingCode = null; throw new CompanionError('COMPANION_PAIRING_EXPIRED'); }
    pairingCode.attempts += 1;
    const ok = safeEqual(sha256(typeof input === 'string' ? input.trim() : ''), pairingCode.hash);
    if (!ok) { if (pairingCode.attempts >= opts.maxPairingAttempts) pairingCode = null; log('warn', 'pairing_rejected'); throw new CompanionError('COMPANION_PAIRING_REJECTED'); }
    pairingCode = null;
    if (pairing) failAll('COMPANION_UNPAIRED');
    const token = random(32).toString('base64url');
    pairing = { tokenHash: sha256(token), origin, pairedAt: new Date(clock.now()).toISOString(), clientName: str(clientName, 60) };
    await persist(); log('info', 'paired'); touch();
    return { token, instanceId };
  }

  function authenticate({ token, origin }) {
    if (!pairing || typeof token !== 'string' || !token) return false;
    const tokenOk = safeEqual(sha256(token), pairing.tokenHash);
    return tokenOk && origin === pairing.origin;
  }

  async function unpair(reason = 'user') {
    if (!pairing) return false;
    pairing = null; connected = false; lastSeenMs = null; browserOnline = null; tabs.clear(); states.clear();
    failAll('COMPANION_UNPAIRED'); for (const waiter of inFlightPolls) waiter.finish([]);
    if (watchdog != null) { clock.clearTimeout(watchdog); watchdog = null; }
    await persist(); log('info', 'unpaired', { reason: str(reason, 20) }); emit('disconnected', { at: clock.now(), unpaired: true });
    return true;
  }

  function heartbeat({ online, version } = {}) {
    touch();
    if (typeof version === 'string') extensionVersion = version.slice(0, 20);
    if (typeof online === 'boolean' && online !== browserOnline) { const previous = browserOnline; browserOnline = online; if (previous !== null || online === false) emit('network', online); }
    return { instanceId };
  }

  function reportTabs(list) {
    touch(); tabs.clear();
    for (const raw of Array.isArray(list) ? list.slice(0, 20) : []) { const tab = sanitizeTab(raw); if (tab) tabs.set(tab.tabId, tab); }
    return { tabs: tabs.size };
  }

  function reportState(tabId, raw) {
    touch(); if (!Number.isInteger(tabId)) return false;
    const state = sanitizePlayerState(raw); states.set(tabId, { state, receivedAtMs: clock.now() });
    if (typeof state.online === 'boolean') heartbeat({ online: state.online });
    emit('state', { tabId, state }); return true;
  }

  const boundTabId = () => [...tabs.values()].find((tab) => tab.bound)?.tabId ?? null;

  function wire(item) { return { commandId: item.command.commandId, instanceId, type: item.command.type, tabId: item.command.tabId, args: item.command.args, ttlMs: Math.max(0, item.command.expiresAt - clock.now()) }; }

  function poll({ waitMs = 0, signal } = {}) {
    touch();
    const take = () => { const out = []; while (queue.length) { const id = queue.shift(); const item = pending.get(id); if (item && !item.delivered && clock.now() < item.command.expiresAt) { item.delivered = true; out.push(wire(item)); } } return out; };
    const ready = take(); if (ready.length || waitMs <= 0) return Promise.resolve(ready);
    return new Promise((resolve) => {
      const waiter = { finish: (value) => { if (!inFlightPolls.has(waiter)) return; inFlightPolls.delete(waiter); clock.clearTimeout(waiter.timer); signal?.removeEventListener?.('abort', onAbort); lastSeenMs = clock.now(); armWatchdog(); resolve(value); }, take };
      const onAbort = () => waiter.finish([]);
      waiter.timer = clock.setTimeout(() => waiter.finish([]), Math.min(waitMs, opts.maxPollWaitMs));
      inFlightPolls.add(waiter); signal?.addEventListener?.('abort', onAbort, { once: true });
      if (signal?.aborted) onAbort();
    });
  }

  function sendCommand({ type, tabId = boundTabId(), args = {}, ttlMs } = {}) {
    if (!COMMAND_TYPES.includes(type)) return Promise.reject(new CompanionError('COMPANION_BAD_COMMAND'));
    if (!pairing) return Promise.reject(new CompanionError('COMPANION_NOT_PAIRED'));
    if (!isConnected()) return Promise.reject(new CompanionError('COMPANION_DISCONNECTED'));
    if (!Number.isInteger(tabId)) return Promise.reject(new CompanionError('COMPANION_TAB_UNBOUND'));
    const ttl = ttlMs ?? DEFAULT_TTL[type] ?? DEFAULT_TTL.default;
    const command = { commandId: random(16).toString('hex'), type, tabId, args: JSON.parse(JSON.stringify(args ?? {})), issuedAt: clock.now(), expiresAt: clock.now() + ttl };
    return new Promise((resolve, reject) => {
      const item = { command, resolve, reject, delivered: false };
      item.timer = clock.setTimeout(() => {
        if (!pending.has(command.commandId)) return;
        pending.delete(command.commandId); remember(command.commandId, 'timeout');
        const index = queue.indexOf(command.commandId); if (index >= 0) queue.splice(index, 1);
        log('warn', 'command_timeout', { type }); reject(new CompanionError('COMPANION_TIMEOUT'));
      }, ttl);
      pending.set(command.commandId, item); queue.push(command.commandId);
      for (const waiter of [...inFlightPolls]) { const delivered = waiter.take(); if (delivered.length) { waiter.finish(delivered); break; } }
    });
  }

  function completeCommand(commandId, payload = {}) {
    touch();
    if (!COMMAND_ID.test(String(commandId))) return { status: 'unknown' };
    if (payload.instanceId !== instanceId) return { status: 'stale-instance' };
    const item = pending.get(commandId);
    if (!item) { const outcome = finished.get(commandId); return { status: outcome === 'timeout' ? 'late' : outcome ? 'duplicate' : 'unknown' }; }
    if (!item.delivered) return { status: 'not-delivered' };
    pending.delete(commandId); clock.clearTimeout(item.timer); remember(commandId, 'done');
    const transportError = code(payload.error);
    if (transportError) {
      if (TAB_ERRORS.has(transportError)) item.reject(new CompanionError('COMPANION_TAB_UNBOUND'));
      else if (transportError === 'EXPIRED') item.reject(new CompanionError('COMPANION_TIMEOUT'));
      else item.resolve({ ok: false, reason: 'EXECUTION_FAILED' });
    } else {
      const result = sanitizeCommandResult(payload.result);
      if (item.command.type === 'getState' && result.state) states.set(item.command.tabId, { state: result.state, receivedAtMs: clock.now() });
      if (typeof result.state?.online === 'boolean') heartbeat({ online: result.state.online });
      item.resolve(result);
    }
    return { status: 'accepted' };
  }

  function status() {
    const bound = boundTabId(); const latest = bound != null ? states.get(bound) : null;
    return {
      instanceId, paired: Boolean(pairing), connected: isConnected(), clientName: pairing?.clientName ?? null, pairedAt: pairing?.pairedAt ?? null,
      lastSeenAgoMs: lastSeenMs == null ? null : clock.now() - lastSeenMs, browserOnline, extensionVersion,
      pairingCodeActive: Boolean(pairingCode && clock.now() <= pairingCode.expiresAt), pendingCommands: pending.size,
      boundTabId: bound, tabs: [...tabs.values()], latestState: latest ? { ...latest.state, ageMs: clock.now() - latest.receivedAtMs } : null
    };
  }

  function dispose() { failAll('COMPANION_DISCONNECTED'); for (const waiter of inFlightPolls) waiter.finish([]); if (watchdog != null) clock.clearTimeout(watchdog); watchdog = null; }

  return {
    instanceId, restore, createPairingCode, pair, authenticate, unpair, heartbeat, reportTabs, reportState, poll, sendCommand, completeCommand, status, isConnected, dispose,
    get boundTabId() { return boundTabId(); }, get browserOnline() { return browserOnline; }, get pairedOrigin() { return pairing?.origin ?? null; }, get pendingCommands() { return pending.size; },
    on(name, fn) { const set = listeners.get(name) || new Set(); set.add(fn); listeners.set(name, set); return () => set.delete(fn); }
  };
}

const json = (status, body, headers = {}) => ({ status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers }, body });

export function isLocalHost(hostHeader) {
  if (typeof hostHeader !== 'string') return false;
  const host = hostHeader.startsWith('[') ? hostHeader.slice(0, hostHeader.indexOf(']') + 1) : hostHeader.split(':')[0];
  return LOCAL_HOSTS.has(host.toLowerCase());
}

export function isLocalUiOrigin(origin, port) {
  if (origin == null) return true;
  return [`http://127.0.0.1:${port}`, `http://localhost:${port}`].includes(origin);
}

/**
 * Transport-agnostic HTTP handler. `request` = { method, pathname, query, headers (lower-case), body, signal }.
 * Returns { status, headers, body } or null when the path is not a Companion route.
 */
export async function handleCompanionRequest(hub, request, { port } = {}) {
  const { method, pathname, headers = {} } = request;
  if (!pathname.startsWith('/api/companion/')) return null;
  if (!isLocalHost(headers.host)) return json(403, { error: 'COMPANION_BAD_HOST' });
  const origin = headers.origin ?? null; const route = pathname.slice('/api/companion/'.length);
  const localUi = new Set(['pairing-code', 'status', 'pairing']);

  if (localUi.has(route)) {
    if (!isLocalUiOrigin(origin, port)) return json(403, { error: 'COMPANION_BAD_ORIGIN' });
    if (route === 'pairing-code' && method === 'POST') return json(200, hub.createPairingCode());
    if (route === 'status' && method === 'GET') return json(200, hub.status());
    if (route === 'pairing' && method === 'DELETE') return json(200, { ok: await hub.unpair('ui') });
    return json(405, { error: 'METHOD_NOT_ALLOWED' });
  }

  // Extension routes: only a well-formed extension origin, never a web page.
  // Chrome may omit the Origin header on the extension's GET long-poll; then the paired origin is assumed
  // and the request must still carry the secret pairing token (checked by authenticate below).
  const effectiveOrigin = origin ?? (method === 'GET' && route === 'commands' && headers['x-companion-token'] ? hub.pairedOrigin : null);
  if (!EXTENSION_ORIGIN.test(effectiveOrigin || '')) return json(403, { error: 'COMPANION_BAD_ORIGIN' });
  const corsAllowed = route === 'pair' || origin === hub.pairedOrigin;
  const cors = corsAllowed ? { 'access-control-allow-origin': origin, vary: 'Origin' } : {};
  if (method === 'OPTIONS') return corsAllowed ? { status: 204, headers: { ...cors, 'access-control-allow-methods': 'GET, POST', 'access-control-allow-headers': 'content-type, x-companion-token', 'access-control-max-age': '600' }, body: null } : json(403, { error: 'COMPANION_BAD_ORIGIN' });

  if (route === 'pair' && method === 'POST') {
    try { return json(200, await hub.pair({ code: request.body?.code, origin, clientName: request.body?.clientName }), cors); }
    catch (error) { return json(error.code === 'COMPANION_BAD_ORIGIN' ? 403 : 401, { error: error.code || 'COMPANION_PAIRING_REJECTED' }, cors); }
  }

  if (!hub.authenticate({ token: headers['x-companion-token'], origin: effectiveOrigin })) return json(401, { error: 'COMPANION_UNAUTHORIZED' }, cors);
  const body = request.body && typeof request.body === 'object' ? request.body : {};
  if (route === 'heartbeat' && method === 'POST') return json(200, { ...hub.heartbeat({ online: body.online, version: body.extensionVersion }), serverTime: Date.now() }, cors);
  if (route === 'tabs' && method === 'POST') return json(200, hub.reportTabs(body.tabs), cors);
  if (route === 'state' && method === 'POST') return json(hub.reportState(body.tabId, body.state) ? 200 : 400, { ok: true }, cors);
  if (route === 'unpair' && method === 'POST') return json(200, { ok: await hub.unpair('extension') }, cors);
  if (route === 'commands' && method === 'GET') {
    const waitMs = Math.max(0, Math.min(Number(request.query?.get?.('waitMs')) || 0, 25_000));
    return json(200, { instanceId: hub.instanceId, commands: await hub.poll({ waitMs, signal: request.signal }) }, cors);
  }
  const resultMatch = route.match(/^commands\/([^/]+)\/result$/);
  if (resultMatch && method === 'POST') {
    const outcome = hub.completeCommand(resultMatch[1], body);
    const statusCode = { accepted: 200, duplicate: 409, late: 409, 'not-delivered': 409, unknown: 404, 'stale-instance': 410 }[outcome.status] ?? 400;
    return json(statusCode, outcome, cors);
  }
  return json(404, { error: 'NOT_FOUND' }, cors);
}
