import { createHash } from 'node:crypto';

const DEFAULT_TIMEOUTS = { connectMs: 5000, identifyMs: 5000, requestMs: 5000, startConfirmMs: 5000, stopConfirmMs: 30000 };
const defaultClock = { now: () => Date.now(), setTimeout: (fn, ms) => setTimeout(fn, ms), clearTimeout: (id) => clearTimeout(id) };
const defaultLogger = { warn() {}, info() {}, error() {} };

export class ObsError extends Error {
  constructor(code, message = code, details = {}) { super(message); this.name = 'ObsError'; this.code = code; Object.assign(this, details); }
}

const base64Sha256 = (value) => createHash('sha256').update(value).digest('base64');
export const createObsAuthentication = (password, salt, challenge) => base64Sha256(`${base64Sha256(`${password}${salt}`)}${challenge}`);

function assertLocalUrl(value) {
  let url;
  try { url = new URL(value); } catch { throw new ObsError('OBS_INVALID_URL', 'OBS WebSocket URL 無效'); }
  const host = url.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (!['localhost', '127.0.0.1', '::1'].includes(host)) throw new ObsError('OBS_NOT_LOCAL', 'OBS 只允許連線至本機');
  if (!['ws:', 'wss:'].includes(url.protocol)) throw new ObsError('OBS_INVALID_URL', 'OBS WebSocket URL 必須使用 ws 或 wss');
  return url.toString();
}

function emitter() {
  const listeners = new Map();
  return {
    on(name, fn) { const set = listeners.get(name) || new Set(); set.add(fn); listeners.set(name, set); return () => set.delete(fn); },
    off(name, fn) { listeners.get(name)?.delete(fn); },
    emit(name, value) { for (const fn of [...(listeners.get(name) || [])]) fn(value); }
  };
}

export function createObsClient({ url = 'ws://127.0.0.1:4455', socketFactory = (target, protocol) => new WebSocket(target, protocol), clock = defaultClock, getPassword = () => null, logger = defaultLogger, timeouts = {} } = {}) {
  const target = assertLocalUrl(url); const timing = { ...DEFAULT_TIMEOUTS, ...timeouts }; const events = emitter();
  let socket = null, state = 'idle', connectionSeq = 0, requestCounter = 0, connectAttempt = null, recording = false;
  const pending = new Map(); const confirmations = new Set();

  const setTimer = (fn, ms) => clock.setTimeout(fn, ms);
  const clearTimer = (id) => { if (id != null) clock.clearTimeout(id); };
  const send = (message) => socket.send(JSON.stringify(message));

  function rejectPending(error) {
    for (const item of pending.values()) { clearTimer(item.timer); item.reject(error); }
    pending.clear();
    for (const item of confirmations) { clearTimer(item.timer); item.reject(error); }
    confirmations.clear();
  }

  function finishConnect(error, result) {
    if (!connectAttempt) return;
    clearTimer(connectAttempt.timer); const attempt = connectAttempt; connectAttempt = null;
    error ? attempt.reject(error) : attempt.resolve(result);
  }

  function closeForProtocol(message = 'OBS 傳回無效訊息') {
    const error = new ObsError('OBS_PROTOCOL_ERROR', message); state = 'closed'; finishConnect(error); rejectPending(error); events.emit('error', error);
    try { socket?.close(1000, 'protocol error'); } catch {}
  }

  function waitFor(predicate, timeoutMs, errorCode) {
    return new Promise((resolve, reject) => {
      const item = { predicate, resolve: (value) => { clearTimer(item.timer); confirmations.delete(item); resolve(value); }, reject: (error) => { clearTimer(item.timer); confirmations.delete(item); reject(error); } };
      item.timer = setTimer(() => item.reject(new ObsError(errorCode)), timeoutMs); confirmations.add(item);
    });
  }

  // P9: what OBS said about file paths during the current recording. OBS 33 reports the recording's FIRST file in
  // RecordStateChanged(STOPPED) and in the StopRecord response even after SplitRecordFile, so a stop path is not
  // necessarily the last file. The client only reports the facts; the caller decides.
  let leg = { startedPath: null, changedPaths: [] };
  function notifyConfirmations(value) { for (const item of [...confirmations]) if (item.predicate(value)) item.resolve(value); }

  function handleEvent(data) {
    if (data.eventType === 'RecordStateChanged') {
      const raw = data.eventData || {}; const value = { state: raw.outputState, active: Boolean(raw.outputActive), outputPath: raw.outputPath ?? null, atMs: clock.now() };
      if (value.state === 'OBS_WEBSOCKET_OUTPUT_STARTED') { recording = true; leg = { startedPath: value.outputPath, changedPaths: [] }; }
      if (value.state === 'OBS_WEBSOCKET_OUTPUT_STOPPED') recording = false;
      events.emit('recordState', value); notifyConfirmations(value); return;
    }
    if (data.eventType === 'RecordFileChanged') { const value = { outputPath: data.eventData?.newOutputPath ?? null, atMs: clock.now() }; leg.changedPaths.push(value.outputPath); events.emit('recordFileChanged', value); return; }
    if (data.eventType === 'ExitStarted') events.emit('obsExiting', { atMs: clock.now() });
  }

  function requestError(type, status) {
    const details = { requestType: type, status: status.code, comment: status.comment };
    if (status.code === 207) return new ObsError('OBS_NOT_READY', 'OBS 尚未就緒', details);
    if (type === 'StartRecord' && status.code === 500) return new ObsError('OBS_ALREADY_RECORDING', 'OBS 已在錄影', details);
    return new ObsError('OBS_REQUEST_FAILED', status.comment || `${type} 失敗`, details);
  }

  function handleResponse(data) {
    const item = pending.get(data.requestId);
    if (!item) { logger.warn({ event: 'unmatched_response', requestId: data.requestId }); return; }
    pending.delete(data.requestId); clearTimer(item.timer);
    const status = data.requestStatus || {};
    if (!status.result) { item.reject(requestError(item.type, status)); return; }
    item.resolve(data.responseData || {});
  }

  function handleMessage(event) {
    if (typeof event.data !== 'string') { closeForProtocol(); return; }
    let message;
    try { message = JSON.parse(event.data); } catch { closeForProtocol(); return; }
    if (!message || !Number.isInteger(message.op) || !message.d || typeof message.d !== 'object' || Array.isArray(message.d)) { closeForProtocol(); return; }
    if (state === 'connecting') {
      if (message.op !== 0) { closeForProtocol('OBS Hello 順序錯誤'); return; }
      if (socket.protocol && socket.protocol !== 'obswebsocket.json') { closeForProtocol('OBS WebSocket 子協定不相容'); return; }
      clearTimer(connectAttempt?.timer); state = 'identifying'; const auth = message.d.authentication; const identify = { rpcVersion: 1 };
      if (auth) {
        const password = getPassword();
        if (!password) { const error = new ObsError('OBS_AUTH_REQUIRED', 'OBS 需要密碼'); finishConnect(error); state = 'closed'; try { socket.close(1000, 'authentication required'); } catch {} return; }
        identify.authentication = createObsAuthentication(password, auth.salt, auth.challenge);
      }
      identify.eventSubscriptions = 65; send({ op: 1, d: identify });
      connectAttempt.authRequired = Boolean(auth); connectAttempt.timer = setTimer(() => { const error = new ObsError('OBS_CONNECT_TIMEOUT', 'OBS 認證逾時'); finishConnect(error); state = 'closed'; try { socket.close(1000, 'identify timeout'); } catch {} }, timing.identifyMs); return;
    }
    if (state === 'identifying') {
      if (message.op !== 2) { closeForProtocol('OBS Identify 順序錯誤'); return; }
      state = 'ready'; finishConnect(null, { negotiatedRpcVersion: message.d.negotiatedRpcVersion, authRequired: connectAttempt?.authRequired ?? false }); return;
    }
    if (state !== 'ready') return;
    if (message.op === 5) handleEvent(message.d);
    else if (message.op === 7) handleResponse(message.d);
    else logger.warn({ event: 'unknown_op', op: message.op });
  }

  function handleClose(event = {}) {
    const closeCode = Number(event.code || 1006); const wasRecording = recording; state = 'closed';
    const code = closeCode === 4009 ? 'OBS_AUTH_FAILED' : closeCode === 4010 ? 'OBS_RPC_UNSUPPORTED' : 'OBS_DISCONNECTED';
    const error = new ObsError(code, code, { closeCode }); finishConnect(error); rejectPending(error); events.emit('disconnected', { code: closeCode, wasRecording });
  }

  async function request(requestType, requestData) {
    if (state !== 'ready') throw new ObsError('OBS_NOT_READY', 'OBS 尚未連線');
    const requestId = `cm-${connectionSeq}-${++requestCounter}`; const data = { requestType, requestId }; if (requestData !== undefined) data.requestData = requestData;
    const promise = new Promise((resolve, reject) => {
      const timer = setTimer(() => { pending.delete(requestId); reject(new ObsError('OBS_REQUEST_TIMEOUT', `${requestType} 逾時`, { requestType })); }, timing.requestMs);
      pending.set(requestId, { type: requestType, resolve, reject, timer });
    });
    send({ op: 6, d: data }); return promise;
  }

  async function connect() {
    if (state === 'ready') return { negotiatedRpcVersion: 1, authRequired: false };
    if (!['idle', 'closed'].includes(state)) throw new ObsError('OBS_CONNECTING', 'OBS 正在連線');
    state = 'connecting'; connectionSeq += 1; requestCounter = 0; recording = false;
    try { socket = socketFactory(target, 'obswebsocket.json'); }
    catch (error) { state = 'closed'; throw new ObsError('OBS_UNAVAILABLE', '無法建立 OBS 連線', { cause: error }); }
    socket.addEventListener('message', handleMessage); socket.addEventListener('close', handleClose);
    return new Promise((resolve, reject) => { connectAttempt = { resolve, reject, authRequired: false, timer: setTimer(() => { const error = new ObsError('OBS_CONNECT_TIMEOUT', 'OBS 連線逾時'); finishConnect(error); state = 'closed'; try { socket.close(1000, 'connect timeout'); } catch {} }, timing.connectMs) }; });
  }

  async function startRecord() {
    const confirmation = waitFor((event) => event.state === 'OBS_WEBSOCKET_OUTPUT_STARTED', timing.startConfirmMs, 'OBS_START_UNCONFIRMED');
    confirmation.catch(() => {});
    try { await request('StartRecord'); return await confirmation.then((event) => ({ startedAtMs: event.atMs })); }
    catch (error) {
      for (const item of [...confirmations]) if (item.predicate({ state: 'OBS_WEBSOCKET_OUTPUT_STARTED' })) item.reject(error);
      if (error.code === 'OBS_START_UNCONFIRMED') getRecordStatus().then((status) => status.active ? stopRecord().catch(() => {}) : null).catch(() => {});
      throw error;
    }
  }

  async function stopRecord() {
    const confirmation = waitFor((event) => event.state === 'OBS_WEBSOCKET_OUTPUT_STOPPED', timing.stopConfirmMs, 'OBS_STOP_UNCONFIRMED');
    confirmation.catch(() => {});
    let response;
    try { response = await request('StopRecord'); }
    catch (error) {
      for (const item of [...confirmations]) if (item.predicate({ state: 'OBS_WEBSOCKET_OUTPUT_STOPPED' })) item.reject(error);
      if (error.code === 'OBS_REQUEST_FAILED' && error.status === 501) { recording = false; return { wasActive: false, outputPath: null, pathSource: null, eventPath: null, responsePath: null, splitObserved: false, fileChanges: 0, startedPath: null, lastChangedPath: null, pathMismatch: false }; }
      throw error;
    }
    const event = await confirmation; const responsePath = response.outputPath || null; const eventPath = event.outputPath || null;
    const changes = leg.changedPaths.filter(Boolean);
    return {
      wasActive: true,
      // Legacy merged value (single-file callers such as the Agent runner). NOT the last file after a split.
      outputPath: eventPath || responsePath, pathSource: eventPath ? 'event' : responsePath ? 'response' : null,
      eventPath, responsePath, startedPath: leg.startedPath || null,
      splitObserved: changes.length > 0, fileChanges: changes.length, lastChangedPath: changes.at(-1) || null,
      pathMismatch: Boolean(eventPath && responsePath && eventPath !== responsePath)
    };
  }

  async function getRecordStatus() { const data = await request('GetRecordStatus'); return { active: Boolean(data.outputActive), paused: Boolean(data.outputPaused), timecode: data.outputTimecode, durationMs: Number(data.outputDuration), bytes: Number(data.outputBytes) }; }
  const getVersion = () => request('GetVersion');
  /**
   * P9: ask OBS to close the current recording file and continue in a new one (obs-websocket ≥ 5.5.0,
   * needs file splitting enabled in OBS output settings). The new file arrives as `recordFileChanged`.
   * 204 UnknownRequestType (older OBS) / 702 RequestProcessingFailed (splitting not enabled) → OBS_SPLIT_UNAVAILABLE.
   */
  async function splitRecordFile() {
    try { await request('SplitRecordFile'); return { ok: true }; }
    catch (error) {
      if (error?.code === 'OBS_REQUEST_FAILED' && [204, 702].includes(error.status)) throw new ObsError('OBS_SPLIT_UNAVAILABLE', 'OBS 未啟用檔案分割（設定 → 輸出 → 錄影 → 自動分割檔案）', { status: error.status });
      if (error?.code === 'OBS_REQUEST_FAILED' && error.status === 501) throw new ObsError('OBS_NOT_RECORDING', 'OBS 目前沒有在錄影', { status: 501 });
      throw error;
    }
  }
  const getRecordDirectory = async () => (await request('GetRecordDirectory')).recordDirectory;
  function close() { if (state === 'closed') return; state = 'closed'; const error = new ObsError('OBS_DISCONNECTED', 'OBS 連線已關閉', { closeCode: 1000 }); finishConnect(error); rejectPending(error); try { socket?.close(1000, 'client closed'); } catch {} }

  return { connect, close, request, startRecord, stopRecord, getRecordStatus, getVersion, getRecordDirectory, splitRecordFile, on: events.on, off: events.off, get state() { return state; }, get recording() { return recording; }, get pendingRequests() { return pending.size; } };
}
