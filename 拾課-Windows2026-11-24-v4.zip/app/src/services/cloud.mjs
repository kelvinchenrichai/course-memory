import fsp from 'node:fs/promises';
import path from 'node:path';
import { runCommand } from '../utils/process.mjs';

export async function backupCourse({ course, libraryFolder, mode, destination }) {
  if (!destination) throw new Error('請先設定雲端目的地');
  const sourceDir = path.join(libraryFolder, course.id);
  const videoName = `source${path.extname(course.video) || '.mp4'}`;
  if (mode === 'folder') {
    const target = path.resolve(destination, course.id); await fsp.mkdir(target, { recursive: true });
    await fsp.cp(sourceDir, target, { recursive: true, force: true });
    await fsp.copyFile(course.video, path.join(target, videoName));
    return { mode, destination: target, completedAt: new Date().toISOString() };
  }
  if (mode !== 'rclone' || !/^[A-Za-z0-9_.-]+:.+/.test(destination)) throw new Error('rclone 目的地格式應為 remote:資料夾');
  const remote = `${destination.replace(/\/$/, '')}/${course.id}`;
  await runCommand('rclone', ['copy', sourceDir, remote, '--create-empty-src-dirs', '--checksum']);
  await runCommand('rclone', ['copyto', course.video, `${remote}/${videoName}`, '--checksum']);
  return { mode, destination: remote, completedAt: new Date().toISOString() };
}
