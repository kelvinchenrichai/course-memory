import fs from 'node:fs';
import path from 'node:path';
import { createObsClient } from '../services/obs.mjs';
import { ENGINE_TEXT, whisperCppModelCandidates } from '../pipeline/transcript.mjs';

/**
 * Live environment checks for the settings page and home screen. Every value here is measured by the
 * backend — the UI never assumes a tool is present or that OBS is connected.
 * Nothing returned contains paths, passwords, keys or device names (only booleans, short codes, versions).
 */

const VERSION = /(\d+\.\d+(?:\.\d+)?)/;
const short = (value) => (typeof value === 'string' ? value.slice(0, 40) : null);

async function tryRun(run, command, args, timeoutMs = 15_000) {
  try { const result = await run(command, args, { timeoutMs }); return { ok: true, stdout: result.stdout || '', stderr: result.stderr || '' }; }
  catch (error) { return { ok: false, code: error?.code || 'ERROR', exitCode: error?.exitCode ?? null, stdout: String(error?.stdout || '') }; }
}

const withText = (status) => (status.code ? { ...status, reason: ENGINE_TEXT[status.code]?.[0] || '無法使用', advice: ENGINE_TEXT[status.code]?.[1] || null } : { ...status, reason: null, advice: null });

/** Loads faster-whisper for real (ctranslate2 DLL included) through transcribe.py --check. */
export async function checkFasterWhisper({ run, config, root, exists = fs.existsSync }) {
  const model = config.whisperModel || 'small';
  const python = typeof config.pythonCommand === 'string' && config.pythonCommand ? config.pythonCommand : null;
  if (!python || (path.isAbsolute(python) && !exists(python))) return withText({ ready: false, code: 'PYTHON_NOT_FOUND', version: null, model });
  const result = await tryRun(run, python, [path.join(root, 'scripts', 'transcribe.py'), '--check'], 90_000);
  if (result.ok) {
    let info = {}; try { info = JSON.parse(result.stdout.trim().split(/\r?\n/).pop()); } catch {}
    return withText({ ready: info.ok === true, code: info.ok === true ? null : 'ENGINE_LOAD_FAILED', version: short(info.version), model });
  }
  const code = result.code === 'COMMAND_NOT_FOUND' ? 'PYTHON_NOT_FOUND' : result.code === 'PROCESS_TIMEOUT' ? 'ENGINE_CHECK_TIMEOUT'
    : result.exitCode === 5 ? 'ENGINE_BLOCKED' : result.exitCode === 3 ? 'FASTER_WHISPER_UNAVAILABLE' : 'ENGINE_LOAD_FAILED';
  let winerror = null; try { winerror = JSON.parse(result.stdout.trim().split(/\r?\n/).pop()).winerror ?? null; } catch {}
  return withText({ ready: false, code, version: null, model, ...(Number.isInteger(winerror) ? { winerror } : {}) });
}

/** whisper.cpp: an installed whisper-cli, or the `whisper` filter built into ffmpeg; plus the model file. */
export async function checkWhisperCpp({ run, config, root, ffmpegOk, exists = fs.existsSync }) {
  const models = whisperCppModelCandidates(config, root);
  const modelFile = models.find((file) => exists(file)) || null;
  const model = path.win32.basename(path.posix.basename(modelFile || models[0] || '')) || null;
  const backendSetting = config.whisperCppBackend || 'auto';
  const cliPath = typeof config.whisperCppCommand === 'string' && config.whisperCppCommand ? path.resolve(root, config.whisperCppCommand) : null;
  const cli = Boolean(cliPath && exists(cliPath));
  let filter = false;
  if (ffmpegOk && backendSetting !== 'cli') {
    const help = await tryRun(run, config.ffmpegCommand || 'ffmpeg', ['-hide_banner', '-h', 'filter=whisper'], 15_000);
    filter = help.ok && /Filter whisper/.test(help.stdout);
  }
  const backend = backendSetting === 'cli' ? (cli ? 'cli' : null) : backendSetting === 'ffmpeg' ? (filter ? 'ffmpeg' : null) : cli ? 'cli' : filter ? 'ffmpeg' : null;
  const code = !backend ? (backendSetting === 'cli' ? 'WHISPER_CPP_UNAVAILABLE' : !ffmpegOk ? 'FFMPEG_UNAVAILABLE' : 'WHISPER_CPP_FILTER_MISSING') : !modelFile ? 'WHISPER_CPP_MODEL_MISSING' : null;
  return withText({ ready: !code, code, backend, cli, filter, modelPresent: Boolean(modelFile), model });
}

const splitCapable = (version) => { const [a, b] = String(version).split('.').map(Number); return a > 5 || (a === 5 && b >= 5); };

export async function probeObsWebsocket({ url, password, timeoutMs = 3000, clientFactory = createObsClient }) {
  let client;
  try {
    client = clientFactory({ url, getPassword: () => password || null, logger: { info() {}, warn() {}, error() {} }, timeouts: { connectMs: timeoutMs, identifyMs: timeoutMs, requestMs: timeoutMs } });
    await client.connect();
    const status = await client.getRecordStatus().catch(() => null);
    // P9: SplitRecordFile / RecordFileChanged need obs-websocket ≥ 5.5.0 (OBS 30.2+).
    const version = typeof client.getVersion === 'function' ? await client.getVersion().catch(() => null) : null;
    const websocketVersion = /^\d+\.\d+\.\d+$/.test(String(version?.obsWebSocketVersion || '')) ? version.obsWebSocketVersion : null;
    return { state: 'connected', recording: status ? Boolean(status.active) : null, websocketVersion };
  } catch (error) {
    const code = String(error?.code || '');
    return { state: /AUTH/.test(code) ? 'auth-failed' : 'unreachable', recording: null, code: /^[A-Z_]{3,40}$/.test(code) ? code : 'OBS_UNREACHABLE' };
  } finally { try { client?.close(); } catch {} }
}

/**
 * deps: { run (process runner), fetch, config, obsInstalled(), probeObs(), platform, now }
 * Results are cached for `ttlMs` unless refresh is requested.
 */
export function createEnvironmentChecker({ run, fetch: fetchImpl = globalThis.fetch, config, obsInstalled, probeObs, keyConfigured, root = process.cwd(), transcriber = null, platform = process.platform, ttlMs = 15_000, now = () => Date.now() }) {
  let cache = null; let pending = null;
  const defaultObsInstalled = () => {
    const base = process.env.ProgramFiles || 'C:\\Program Files';
    return fs.existsSync(path.join(base, 'obs-studio', 'bin', '64bit', 'obs64.exe'));
  };

  async function measure() {
    const ffmpeg = await tryRun(run, config.ffmpegCommand || 'ffmpeg', ['-hide_banner', '-version']);
    const ffmpegVersion = ffmpeg.ok ? short((ffmpeg.stdout.match(/ffmpeg version (\S+)/) || [])[1]) : null;
    const mode = config.transcriber || 'auto';
    const fasterWhisper = mode === 'whisper.cpp' ? null : await checkFasterWhisper({ run, config, root });
    const whisperCpp = mode === 'faster-whisper' ? null : await checkWhisperCpp({ run, config, root, ffmpegOk: ffmpeg.ok });
    if (fasterWhisper?.ready) transcriber?.reset?.();
    const active = fasterWhisper?.ready ? 'faster-whisper' : whisperCpp?.ready ? 'whisper.cpp' : null;
    const shown = active === 'whisper.cpp' ? whisperCpp : fasterWhisper || whisperCpp;
    const whisper = {
      mode, active, ready: Boolean(active), engine: active || (mode === 'whisper.cpp' ? 'whisper.cpp' : 'faster-whisper'),
      model: shown?.model || null, version: active === 'faster-whisper' ? fasterWhisper.version : null,
      backend: active === 'whisper.cpp' ? whisperCpp.backend : null,
      fallbackInUse: mode === 'auto' && active === 'whisper.cpp',
      // Kept for older views: "an engine runtime exists" / "its package/model is present".
      runtime: Boolean(fasterWhisper?.ready || fasterWhisper?.code === 'ENGINE_BLOCKED' || fasterWhisper?.code === 'ENGINE_LOAD_FAILED' || whisperCpp?.backend),
      package: Boolean(active),
      code: active ? null : (shown?.code || null), reason: active ? null : (shown?.reason || null), advice: active ? null : (shown?.advice || null),
      fasterWhisper, whisperCpp
    };
    const provider = config.aiProvider || 'ollama';
    let ai;
    if (provider === 'ollama') {
      let reachable = false; let modelInstalled = false;
      try {
        const response = await fetchImpl(`${String(config.ollamaUrl || 'http://127.0.0.1:11434').replace(/\/+$/, '')}/api/tags`, { signal: AbortSignal.timeout(2500) });
        if (response.ok) { reachable = true; const data = await response.json(); const wanted = String(config.ollamaModel || ''); modelInstalled = (data.models || []).some((item) => item?.name === wanted || item?.name === `${wanted}:latest` || item?.model === wanted); }
      } catch {}
      ai = { provider, ready: reachable && modelInstalled, reachable, modelInstalled, model: short(config.ollamaModel), external: false };
    } else if (provider === 'openai' || provider === 'gemini') {
      const configured = Boolean(await keyConfigured(provider));
      ai = { provider, ready: configured, keyConfigured: configured, model: short(provider === 'openai' ? config.openaiModel : config.geminiModel), external: true };
    } else ai = { provider: 'none', ready: true, external: false, model: null };
    ai.knowledgeMode = config.knowledgeMode || 'basic'; ai.summaryDetail = config.summaryDetail || 'standard'; ai.translationTarget = config.translationLanguage || 'none';
    const rclone = await tryRun(run, 'rclone', ['version'], 10_000);
    const driveFolder = typeof config.backup?.driveFolder === 'string' && path.isAbsolute(config.backup.driveFolder) && fs.existsSync(config.backup.driveFolder);
    const installed = await (obsInstalled || defaultObsInstalled)();
    const websocket = await probeObs();
    return {
      checkedAt: new Date(now()).toISOString(),
      obs: { installed: Boolean(installed), websocket: websocket.state, recording: websocket.recording ?? null, ready: websocket.state === 'connected',
        // P9 直播分段: version only tells whether OBS *can* split; whether「自動分割檔案」is enabled is known at the first split.
        websocketVersion: websocket.websocketVersion ?? null, splitSupported: websocket.websocketVersion ? splitCapable(websocket.websocketVersion) : null },
      ffmpeg: { available: ffmpeg.ok, version: ffmpegVersion, ready: ffmpeg.ok },
      whisper, ai,
      cloud: { rclone: rclone.ok, driveFolder, destinationConfigured: Boolean(config.cloudDestination), ready: Boolean(config.cloudDestination) && (rclone.ok || driveFolder) },
      audio: { platformSupported: platform === 'win32', deviceConfigured: Boolean(config.audioCapture?.deviceName), ready: platform === 'win32' && Boolean(config.audioCapture?.deviceName) && ffmpeg.ok },
      modes: {
        video: { ready: websocket.state === 'connected', reason: websocket.state === 'connected' ? null : installed ? (websocket.state === 'auth-failed' ? 'OBS_AUTH_FAILED' : 'OBS_WEBSOCKET_UNREACHABLE') : 'OBS_NOT_INSTALLED' },
        audio: { ready: platform === 'win32' && Boolean(config.audioCapture?.deviceName) && ffmpeg.ok, reason: !ffmpeg.ok ? 'FFMPEG_UNAVAILABLE' : platform !== 'win32' ? 'AUDIO_PLATFORM_UNSUPPORTED' : !config.audioCapture?.deviceName ? 'AUDIO_DEVICE_NOT_SELECTED' : null }
      }
    };
  }

  return {
    async check({ refresh = false } = {}) {
      if (!refresh && cache && now() - cache.at < ttlMs) return cache.value;
      if (!pending) pending = measure().then((value) => { cache = { at: now(), value }; return value; }).finally(() => { pending = null; });
      return pending;
    },
    invalidate() { cache = null; }
  };
}
