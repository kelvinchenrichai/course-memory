import { readJson, writeJsonAtomic } from '../pipeline/files.mjs';

/**
 * The home-screen "開始學習" session. The mode is chosen first:
 *  - video + OBS reachable  → OBS is started through obs-websocket; "錄影中" only after OBS confirms.
 *  - video, manual timer    → explicitly labelled "只計時": the app does NOT control or watch OBS.
 *  - audio                  → the P4A audio capture (user-selected device) records; ffmpeg must confirm.
 * Both recording modes require the same "我確認有權錄製" acknowledgement the Agent asks for.
 * The session file (data/session.json) keeps the existing { startedAt, markers } shape so time-stamped
 * notes keep working; output paths are stored there (local, git-ignored) but never returned to the UI.
 */

export class LearningSessionError extends Error {
  constructor(code, message, status = 409) { super(message); this.name = 'LearningSessionError'; this.code = code; this.status = status; }
}

const AGENT_BUSY = new Set(['queued', 'preparing', 'running', 'stopping']);
const cleanTitle = (value) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, 120);

export function createLearningSession({ sessionFile, captureFactory, prepareCapture = async () => null, enqueueCapture = async () => null, enqueueAudio, listAgentJobs = async () => [], clock = { now: () => Date.now() }, logger = { info() {}, warn() {} } }) {
  // enqueueAudio is kept as a compatibility alias for older callers/tests.
  const enqueue = enqueueAudio ? (_mode, files) => enqueueAudio(files) : enqueueCapture;
  let capture = null; let busy = Promise.resolve(); let interruptedChecked = false;
  const serialize = (fn) => { const task = busy.then(fn); busy = task.catch(() => {}); return task; };

  async function load() {
    const session = await readJson(sessionFile, null);
    if (!interruptedChecked) {
      interruptedChecked = true;
      // A recording session cannot survive a restart: the capture object is gone. Mark it, never resume it.
      if (session && session.startedAt && !session.stoppedAt && session.capture && session.capture.kind !== 'manual-timer' && !capture) {
        session.stoppedAt = clock.now(); session.interrupted = true; await writeJsonAtomic(sessionFile, session);
      }
    }
    return session;
  }

  function publicView(session) {
    if (!session) return { active: false, mode: null };
    const active = Boolean(session.startedAt && !session.stoppedAt);
    return {
      active, mode: session.mode || null, startedAt: session.startedAt || null, stoppedAt: session.stoppedAt || null,
      title: session.title || null,
      startedAtIso: session.startedAt ? new Date(session.startedAt).toISOString() : null,
      capture: session.capture ? { kind: session.capture.kind, confirmed: session.capture.confirmed === true } : null,
      markers: Array.isArray(session.markers) ? session.markers.length : 0,
      outputs: Array.isArray(session.outputFiles) ? session.outputFiles.length : 0,
      queued: session.queued === true, interrupted: session.interrupted === true,
      lastError: session.lastError || null
    };
  }

  return {
    async status() { return publicView(await load()); },
    start(input = {}) {
      return serialize(async () => {
        const mode = input.mode;
        if (!['video', 'audio'].includes(mode)) throw new LearningSessionError('INVALID_MODE', '請先選擇錄影或錄音', 400);
        if (input.recordPermissionAcknowledged !== true) throw new LearningSessionError('RECORD_PERMISSION_REQUIRED', '請先確認你有權錄製這份內容', 400);
        const title = cleanTitle(input.title) || (mode === 'audio' ? '未命名錄音' : '未命名錄影');
        const current = await load();
        if (current?.startedAt && !current.stoppedAt) throw new LearningSessionError('SESSION_ACTIVE', '已經有進行中的學習');
        if ((await listAgentJobs()).some((job) => AGENT_BUSY.has(job.status))) throw new LearningSessionError('AGENT_BUSY', 'Agent 正在錄製其他課程，請先等它完成或暫停');
        const manualTimer = mode === 'video' && input.manualTimer === true;
        let startedAt = clock.now(); let kind = 'manual-timer';
        if (!manualTimer) {
          if (mode === 'video') await prepareCapture(mode);
          const next = captureFactory(mode);
          if (!next || next.kind === 'unavailable') throw new LearningSessionError(mode === 'audio' ? 'AUDIO_DEVICE_NOT_SELECTED' : 'OBS_NOT_CONNECTED', mode === 'audio' ? '尚未選擇音訊裝置，請先到「設定」選擇' : 'OBS 連線設定無效');
          try { const result = await next.start({}); startedAt = Number(result?.startedAtMs) || clock.now(); }
          catch (error) {
            next.dispose?.();
            const code = String(error?.code || '');
            if (mode === 'video') throw new LearningSessionError(/AUTH/.test(code) ? 'OBS_AUTH_FAILED' : code === 'OBS_ALREADY_RECORDING' ? code : code === 'OBS_START_UNCONFIRMED' ? code : 'OBS_NOT_CONNECTED', code === 'OBS_ALREADY_RECORDING' ? 'OBS 已經在錄影，請先在 OBS 停止' : code === 'OBS_START_UNCONFIRMED' ? 'OBS 沒有確認開始錄影，請檢查 OBS 畫面' : '無法連線到 OBS：請開啟 OBS 並啟用 WebSocket 伺服器');
            throw new LearningSessionError(/^(FFMPEG_UNAVAILABLE|AUDIO_DEVICE_UNAVAILABLE|DISK_LOW|AUDIO_CAPTURE_BUSY)$/.test(code) ? code : 'AUDIO_CAPTURE_FAILED', { FFMPEG_UNAVAILABLE: '找不到 ffmpeg', AUDIO_DEVICE_UNAVAILABLE: '找不到選定的音訊裝置，請到「設定」重新選擇', DISK_LOW: '磁碟空間不足', AUDIO_CAPTURE_BUSY: '錄音已在進行中' }[code] || '錄音無法開始');
          }
          capture = next; kind = next.kind;
          capture.on?.('stoppedExternally', () => { logger.warn({ event: 'learning_capture_stopped_externally', mode }); });
        }
        const session = { startedAt, mode, title, capture: { kind, confirmed: !manualTimer }, markers: current && !current.stoppedAt ? current.markers || [] : [], recordPermissionAcknowledgedAt: new Date(clock.now()).toISOString() };
        await writeJsonAtomic(sessionFile, session);
        logger.info({ event: 'learning_session_started', mode, capture: kind });
        return publicView(session);
      });
    },
    stop() {
      return serialize(async () => {
        const session = await load();
        if (!session?.startedAt || session.stoppedAt) throw new LearningSessionError('SESSION_NOT_ACTIVE', '目前沒有進行中的學習');
        if (capture) {
          let result = null;
          try { result = await capture.stop(); }
          catch (error) { session.lastError = { code: String(error?.code || 'CAPTURE_STOP_FAILED').slice(0, 60), message: session.mode === 'video' ? 'OBS 沒有確認停止，請到 OBS 檢查是否仍在錄影' : '錄音停止時發生問題，已保存的檔案仍可處理' }; }
          capture.dispose?.(); capture = null;
          session.outputFiles = Array.isArray(result?.outputFiles) ? result.outputFiles : result?.outputPath ? [result.outputPath] : [];
          if (session.outputFiles.length) {
            try { await enqueue(session.mode, session.outputFiles, { title: session.title }); session.queued = true; }
            catch (error) { session.lastError = { code: String(error?.code || 'PIPELINE_ERROR').slice(0, 60), message: `${session.mode === 'video' ? '錄影' : '錄音'}已保存，但無法自動加入處理；請到處理中心確認` }; }
          }
        }
        session.stoppedAt = clock.now();
        await writeJsonAtomic(sessionFile, session);
        logger.info({ event: 'learning_session_stopped', mode: session.mode, outputs: session.outputFiles?.length || 0 });
        return publicView(session);
      });
    },
    get capturing() { return Boolean(capture); }
  };
}
