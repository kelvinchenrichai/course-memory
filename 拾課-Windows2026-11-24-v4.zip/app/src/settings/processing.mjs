import path from 'node:path';
import { redactText } from '../pipeline/process-runner.mjs';
import { ENGINE_TEXT } from '../pipeline/transcript.mjs';

/**
 * Builds the 處理中心 view from backend records only: Agent jobs + RecordingSessions, P4A pipeline jobs,
 * published library courses (knowledge), the manual learning session and legacy server jobs.
 *
 * Phase states shown to the user:
 *   waiting     等待中         not started yet
 *   running     處理中         in progress
 *   done        已完成
 *   needs-user  需要你處理      failed / blocked / cancelled — always with a reason and, when safe, an action
 *   skipped     不適用         e.g. "錄製" for an imported file
 * No message may contain a path, password, key or cookie (redacted and path-stripped).
 */

export const PHASES = Object.freeze([
  { key: 'record', label: '錄製／音訊擷取' },
  { key: 'extract', label: '音訊處理' },
  { key: 'transcribe', label: '轉錄' },
  { key: 'subtitles', label: '字幕' },
  { key: 'knowledge', label: '知識整理' }
]);
const STAGE_GROUPS = { extract: ['probe', 'audio', 'prepare'], transcribe: ['transcribe', 'track'], subtitles: ['subtitles'] };

const ERRORS = {
  FFPROBE_UNAVAILABLE: ['找不到 ffprobe', 'ffprobe 隨 ffmpeg 一起安裝；安裝後按重試。'],
  FFMPEG_FAILED: ['ffmpeg 處理失敗', '檔案可能損壞或格式不支援。'],
  PROBE_FAILED: ['無法讀取媒體檔', '檔案可能損壞或還在寫入中。'],
  NO_AUDIO_TRACK: ['這個檔案沒有聲音', '請確認錄影時有收到聲音（OBS 的音訊來源）。'],
  NOT_AUDIO_ONLY: ['音訊模式的檔案含有影像', '請改用影片模式處理。'],
  ...ENGINE_TEXT,
  WHISPER_NOT_CONFIGURED: ['轉錄工具尚未設定', '請到「設定」選擇轉錄工具。'],
  WHISPER_FAILED: ['轉錄失敗', '可以按重試；若一直失敗，改用較小的 Whisper 模型。'],
  WHISPER_TIMEOUT: ['轉錄逾時', '可以按重試，或改用較小的模型。'],
  WHISPER_OUTPUT_INVALID: ['轉錄結果無法讀取', '請按重試。'],
  LEGACY_TRANSCRIBE_FAILED: ['舊版轉錄失敗（當時 faster-whisper 無法執行）', '這通常是 Windows 擋下了 faster-whisper；新版會自動改用 whisper.cpp。這筆舊紀錄可以封存（不會刪除檔案）。'],
  KNOWLEDGE_TRANSCRIPT_EMPTY: ['沒有辨識到語音', '請確認錄影有收到系統音訊，並用一段有說話聲的影片再測試。'],
  KNOWLEDGE_PUBLISH_FAILED: ['知識整理暫時失敗', '系統會自動重試；逐字稿與字幕不受影響。'],
  PATH_NOT_ALLOWED: ['檔案不在允許的資料夾內', '請把檔案放進錄影或匯入資料夾。'],
  AUDIO_DEVICE_UNAVAILABLE: ['找不到選定的音訊裝置', '請到「設定」重新選擇音訊裝置。'],
  AUDIO_CAPTURE_FAILED: ['錄音無法開始', '請確認裝置沒有被其他程式佔用。'],
  DISK_LOW: ['磁碟空間不足', '請清出空間後再繼續。'],
  OBS_DISCONNECTED: ['OBS 連線中斷', '請確認 OBS 開著並啟用 WebSocket 伺服器。'],
  OBS_START_UNCONFIRMED: ['OBS 沒有確認開始錄影', '請檢查 OBS 畫面，必要時手動停止錄影。'],
  OBS_STOP_UNCONFIRMED: ['OBS 沒有確認停止錄影', '請到 OBS 檢查是否仍在錄影。'],
  OBS_ALREADY_RECORDING: ['OBS 已經在錄影', '請先在 OBS 停止原本的錄影。'],
  NETWORK_OFFLINE: ['網路中斷', '網路恢復後按「繼續」。'],
  COMPANION_DISCONNECTED: ['瀏覽器擴充功能已中斷', '請確認瀏覽器與擴充功能開著。'],
  LOGIN_REQUIRED: ['平台要求登入', '請自己在瀏覽器登入後再繼續；本程式不會代為登入。'],
  CAPTCHA: ['平台出現驗證', '請自己完成驗證後再繼續。'],
  PAYMENT_PROMPT: ['平台要求付款', '本程式不會處理付款；請自行確認後再繼續。'],
  USER_PAUSED: ['你已暫停', '準備好後按「繼續」。'],
  SERVER_RESTARTED: ['程式重新啟動時中斷', '請確認錄影檔後按「繼續」。'],
  CANCELLED: ['已取消', '需要時可以按重試。'],
  INTERRUPTED: ['上次錄音在程式關閉時中斷', '已保存的錄音檔可以在處理中心看到；請確認後重新開始。']
};

/** Removes secrets and any absolute path from a message. */
export function safeMessage(value) {
  const stripped = String(value || '')
    .replace(/[A-Za-z]:\\[^\s"'<>|]*/g, '〈路徑〉')
    .replace(/\\\\[^\s"'<>|]+/g, '〈路徑〉')
    .replace(/(^|[\s"'(])\/(?:[^\s"'<>]+\/)+[^\s"'<>]*/g, '$1〈路徑〉');
  return redactText(stripped, { max: 300 }).slice(0, 300);
}

export function describeError(code, fallbackMessage) {
  const known = ERRORS[code];
  if (known) return { code, message: known[0], hint: known[1] };
  return { code: /^[A-Z][A-Z0-9_]{2,60}$/.test(String(code)) ? code : 'ERROR', message: fallbackMessage ? safeMessage(fallbackMessage) : '處理失敗', hint: '可以按重試；若持續失敗，請把錯誤代碼提供給協助你的人。' };
}

const ENGINE_LABEL = { ffmpeg: 'ffmpeg 內建', cli: 'whisper-cli' };
/** "whisper.cpp・ggml-small.bin（ffmpeg 內建）" — the engine that actually ran; names only, never paths. */
export function engineNote(engine) {
  if (!engine?.name) return null;
  const model = engine.model ? `・${String(engine.model).slice(0, 60)}` : '';
  const backend = engine.backend ? `（${ENGINE_LABEL[engine.backend] || engine.backend}）` : '';
  const fallback = engine.fallbackFrom ? `；${engine.fallbackFrom} 無法在這台電腦執行（${describeError(engine.fallbackReason || 'ENGINE_LOAD_FAILED').message}），已自動改用` : '';
  return `引擎：${String(engine.name).slice(0, 40)}${model}${backend}${fallback}`;
}

const stageState = (status) => ({ queued: 'waiting', running: 'running', completed: 'done', failed: 'needs-user', cancelled: 'needs-user' })[status] || 'waiting';

function groupPhase(stages, names) {
  const items = names.map((name) => stages.find((stage) => stage.name === name)).filter(Boolean);
  if (!items.length) return { state: 'waiting', progress: 0 };
  const states = items.map((stage) => stageState(stage.status));
  const progress = items.reduce((sum, stage) => sum + (stage.status === 'completed' ? 1 : stage.status === 'running' ? 0.5 : 0), 0) / items.length;
  const failed = items.find((stage) => ['failed', 'cancelled'].includes(stage.status));
  const state = failed ? 'needs-user' : states.every((s) => s === 'done') ? 'done' : states.some((s) => s === 'running') || states.some((s) => s === 'done') ? 'running' : 'waiting';
  return { state, progress: Math.round(progress * 100) / 100, ...(failed ? { error: describeError(failed.error?.code || (failed.status === 'cancelled' ? 'CANCELLED' : 'ERROR'), failed.error?.message) } : {}) };
}

export function overallOf(phases) {
  const states = phases.map((phase) => phase.state).filter((state) => state !== 'skipped');
  if (states.includes('needs-user')) return 'needs-user';
  if (states.includes('running')) return 'running';
  if (states.every((state) => state === 'done')) return 'done';
  return states.includes('done') ? 'running' : 'waiting';
}

const fileTitle = (file) => { const base = path.win32.basename(String(file || '')); return base.replace(/\.[^.]+$/, '').slice(0, 120) || '未命名'; };

function recordPhaseFromSession(session, kind) {
  if (kind === 'import') return { state: 'skipped', progress: 1, note: '匯入檔，不需錄製' };
  if (!session) return { state: 'done', progress: 1, note: kind === 'audio' ? '音訊檔已就緒' : '錄影檔已就緒' };
  if (session.status === 'completed') return { state: 'done', progress: 1 };
  if (session.status === 'partial') return { state: 'done', progress: 1, note: '只錄到一部分（已保存）' };
  if (session.status === 'failed') return { state: 'needs-user', progress: 0, error: describeError(session.stopReason?.code || 'ERROR') };
  return { state: 'running', progress: 0.5 };
}

/**
 * input: { agentJobs, sessions, pipelineJobs, courses, learningSession, legacyJobs, now }
 * output: { items: [...], counts: { waiting, running, done, 'needs-user' } }
 */
export function buildProcessingView({ agentJobs = [], sessions = [], pipelineJobs = [], courses = [], learningSession = null, legacyJobs = [], publishErrors = [] } = {}) {
  const items = [];
  const lessonTitle = (session) => {
    const job = agentJobs.find((item) => item.id === session?.agentJobId);
    return job?.plan?.lessons?.find((lesson) => lesson.lessonId === session.lessonId)?.title || null;
  };

  if (learningSession?.active || learningSession?.interrupted) {
    const audio = learningSession.mode === 'audio';
    const recordState = learningSession.interrupted ? 'needs-user' : 'running';
    const confirmed = learningSession.capture?.confirmed === true;
    const note = !confirmed ? '只計時；是否錄影請以 OBS 畫面為準' : audio ? '正在錄音' : 'OBS 正在錄影（已由 OBS 確認）';
    const phases = PHASES.map((phase, index) => ({ ...phase, state: index === 0 ? recordState : 'waiting', progress: index === 0 ? 0.5 : 0, ...(index === 0 ? { note, ...(learningSession.interrupted ? { error: describeError('INTERRUPTED') } : {}) } : {}) }));
    items.push({ id: 'learning-session', kind: 'live', title: learningSession.title || (audio ? '目前的錄音' : '目前的錄影'), source: learningSession.mode, createdAt: learningSession.startedAtIso || null, overall: overallOf(phases), phases, actions: [] });
  }

  for (const job of agentJobs.filter((item) => ['queued', 'preparing', 'running', 'stopping', 'blocked', 'failed'].includes(item.status))) {
    const total = job.plan?.lessons?.length || 0; const done = job.checkpoint?.completedLessonIds?.length || 0;
    const blocked = ['blocked', 'failed'].includes(job.status);
    const record = { key: 'record', label: PHASES[0].label, state: blocked ? 'needs-user' : job.status === 'queued' ? 'waiting' : 'running', progress: total ? Math.round((done / total) * 100) / 100 : 0, note: `${done}/${total} 堂已錄製`, ...(blocked ? { error: describeError(job.blocker?.code || 'ERROR', job.blocker?.detail) } : {}) };
    const phases = [record, ...PHASES.slice(1).map((phase) => ({ ...phase, state: 'waiting', progress: 0, note: '每堂錄好後各自處理' }))];
    items.push({ id: job.id, kind: 'recording-job', title: job.plan?.lessons?.[0]?.title ? `${job.plan.lessons[0].title}${total > 1 ? ` 等 ${total} 堂` : ''}` : '錄製工作', source: job.plan?.captureMode || 'video', createdAt: job.createdAt, overall: overallOf(phases), phases, actions: job.status === 'blocked' ? [{ type: 'resume-agent', label: '確認後繼續', jobId: job.id }] : [] });
  }

  const latestByAsset = new Map();
  for (const job of [...pipelineJobs].sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))) if (!latestByAsset.has(job.asset?.id)) latestByAsset.set(job.asset?.id, job);
  for (const job of latestByAsset.values()) {
    const session = sessions.find((item) => item.id === job.source?.recordingSessionId);
    // A filename is not an identity: two course folders commonly contain lesson-01.mp4.
    // Published pipeline work is linked only by its stable job id.
    const course = courses.find((item) => item.pipelineJobId === job.id);
    const stages = job.stages || [];
    const extract = groupPhase(stages, STAGE_GROUPS.extract); const transcribe = groupPhase(stages, STAGE_GROUPS.transcribe); const subtitles = groupPhase(stages, STAGE_GROUPS.subtitles);
    const usedEngine = engineNote(stages.find((stage) => stage.name === 'transcribe' && stage.status === 'completed')?.outputs?.engine);
    if (usedEngine) transcribe.note = usedEngine;
    let knowledge;
    if (job.status !== 'completed') knowledge = { state: 'waiting', progress: 0 };
    else if (course?.knowledge) knowledge = { state: 'done', progress: 1, ...(course.knowledge.fallback ? { note: '已完成基礎規則式整理（每項仍有逐字稿引用）' } : { note: '已完成 AI 重點整理（每項都有逐字稿引用）' }) };
    else if (publishErrors.some((item) => item.jobId === job.id)) {
      const publishError = publishErrors.find((item) => item.jobId === job.id);
      knowledge = { state: 'needs-user', progress: 0, error: describeError(publishError?.code || 'KNOWLEDGE_PUBLISH_FAILED'), note: '逐字稿與字幕不受影響' };
    }
    else knowledge = { state: 'running', progress: 0.5, note: '整理章節與知識卡中' };
    const phases = [
      { ...PHASES[0], ...recordPhaseFromSession(session, job.source?.kind) },
      { ...PHASES[1], ...extract }, { ...PHASES[2], ...transcribe }, { ...PHASES[3], ...subtitles }, { ...PHASES[4], ...knowledge }
    ];
    const retryable = ['failed', 'cancelled'].includes(job.status);
    items.push({
      id: job.id, kind: 'lesson', title: course?.title || job.displayTitle || lessonTitle(session) || fileTitle(job.asset?.files?.[0]?.path), source: job.source?.kind || 'video', createdAt: job.createdAt,
      overall: overallOf(phases), phases, courseId: course?.id || null, engine: stages.find((stage) => stage.name === 'transcribe' && stage.status === 'completed')?.outputs?.engine ? { ...stages.find((stage) => stage.name === 'transcribe').outputs.engine } : null,
      actions: [...(retryable ? [{ type: 'retry-pipeline', label: '重試', jobId: job.id }] : []), ...(course ? [{ type: 'open-course', label: '打開內容', courseId: course.id }, { type: 'rename-course', label: '更名', courseId: course.id, currentTitle: course.title }] : [])]
    });
  }

  // An archived (封存) course is kept on disk but no longer asks for attention here.
  for (const course of courses.filter((item) => !item.pipelineJobId && !item.demo && !item.archived && ['processing', 'error'].includes(item.status))) {
    const error = course.status === 'error';
    const legacyCode = /TRANSCRIBE_FAILED|RuntimeError|WinError/.test(String(course.error || '')) ? 'LEGACY_TRANSCRIBE_FAILED' : 'LEGACY_PROCESSING_FAILED';
    const failure = error ? (course.errorCode ? describeError(course.errorCode, course.error) : describeError(legacyCode, course.error?.split('\n')[0])) : null;
    const phases = PHASES.map((phase, index) => ({ ...phase, state: index === 0 ? 'done' : error ? (index === 1 ? 'needs-user' : 'waiting') : 'running', progress: index === 0 ? 1 : 0.5, ...(error && index === 1 ? { error: failure } : {}) }));
    items.push({ id: `course:${course.id}`, kind: 'legacy-course', title: String(course.title || '未命名').slice(0, 120), source: 'video', createdAt: course.createdAt, overall: overallOf(phases), phases,
      actions: [{ type: 'rename-course', label: '更名', courseId: course.id, currentTitle: course.title }, ...(error ? [{ type: 'archive-course', label: '封存（不刪除）', courseId: course.id }] : [])] });
  }

  for (const job of legacyJobs.filter((item) => ['queued', 'running', 'failed'].includes(item.status)).slice(0, 20)) {
    const label = { 'url-ingest': '網址匯入', 'clip-export': '短片輸出', 'cloud-backup': '雲端備份' }[job.type] || '背景工作';
    const state = job.status === 'failed' ? 'needs-user' : job.status === 'running' ? 'running' : 'waiting';
    items.push({ id: `job:${job.id}`, kind: 'task', title: label, source: null, createdAt: job.createdAt, overall: state, phases: [{ key: 'task', label, state, progress: (job.progress || 0) / 100, ...(state === 'needs-user' ? { error: describeError('TASK_FAILED', job.error) } : {}) }], actions: [] });
  }

  const order = { 'needs-user': 0, running: 1, waiting: 2, done: 3 };
  items.sort((a, b) => (order[a.overall] - order[b.overall]) || String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
  const counts = { waiting: 0, running: 0, done: 0, 'needs-user': 0 };
  for (const item of items) counts[item.overall] += 1;
  return { items, counts };
}
