import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Starts an installed OBS only when it is not already running, then waits for obs-websocket. */
export function createObsLauncher({ run, probe, spawnProcess = spawn, platform = process.platform, programFiles = process.env.ProgramFiles || 'C:\\Program Files', sleep = wait, attempts = 15 } = {}) {
  const executable = path.join(programFiles, 'obs-studio', 'bin', '64bit', 'obs64.exe');

  async function isRunning() {
    try {
      const result = await run('tasklist.exe', ['/FI', 'IMAGENAME eq obs64.exe', '/NH'], { timeoutMs: 5000 });
      return /\bobs64\.exe\b/i.test(`${result.stdout || ''}\n${result.stderr || ''}`);
    } catch { return false; }
  }

  return {
    async ensureReady() {
      const first = await probe();
      if (first?.state === 'connected') return { ready: true, launched: false };
      if (platform !== 'win32' || !fs.existsSync(executable)) return { ready: false, launched: false, reason: 'OBS_NOT_INSTALLED' };
      let launched = false;
      if (!await isRunning()) {
        const child = spawnProcess(executable, ['--minimize-to-tray'], { cwd: path.dirname(executable), detached: true, stdio: 'ignore', windowsHide: true });
        child.unref?.(); launched = true;
      }
      for (let index = 0; index < attempts; index += 1) {
        await sleep(500);
        const status = await probe();
        if (status?.state === 'connected') return { ready: true, launched };
        if (status?.state === 'auth-failed') return { ready: false, launched, reason: 'OBS_AUTH_FAILED' };
      }
      return { ready: false, launched, reason: 'OBS_WEBSOCKET_UNREACHABLE' };
    }
  };
}
