import { isLocalHost, isLocalUiOrigin } from '../services/companion.mjs';
import { buildProcessingView } from './processing.mjs';

/**
 * P4C local API (settings, environment, processing centre, learning session).
 *
 * Guard for every route: Host is localhost; Origin is absent or this UI; Sec-Fetch-Site (when the browser
 * sends it) is same-origin or none; POST/PUT bodies must be application/json. No route accepts a file path
 * or a command, and no response contains a secret, a device name or a full user path.
 *
 *   GET  /api/settings                      → { values, secrets: { key: { configured } }, options, restartKeys }
 *   PUT  /api/settings  { values, secrets } → same + { changed, restartRequired }
 *   GET  /api/environment[?refresh=1]       → backend-measured tool status
 *   GET  /api/processing                    → { items, counts }
 *   POST /api/processing/:jobId/retry       → retries a failed/cancelled P4A pipeline job
 *   GET  /api/learning                      → current learning session (public view)
 *   POST /api/learning/start { mode, title, recordPermissionAcknowledged, manualTimer? }
 *   POST /api/learning/stop
 */

const ROUTES = /^\/api\/(settings|environment|processing(?:\/job_[0-9a-f]{12}\/retry)?|learning(?:\/(?:start|stop))?)$/;
const json = (status, body) => ({ status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }, body });
const STATUS = { UNKNOWN_SETTING: 400, INVALID_VALUE: 400, INVALID_SETTINGS: 400, INVALID_MODE: 400, TITLE_REQUIRED: 400, RECORD_PERMISSION_REQUIRED: 400, JOB_NOT_FOUND: 404, INVALID_TRANSITION: 409, MEDIA_BUSY: 409, PIPELINE_UNAVAILABLE: 503, CONFIG_UNREADABLE: 500 };

export const isSettingsRoute = (pathname) => ROUTES.test(pathname);

export function checkLocalRequest({ method, headers = {} }, port) {
  if (!isLocalHost(headers.host)) return 'BAD_HOST';
  if (!isLocalUiOrigin(headers.origin ?? null, port)) return 'BAD_ORIGIN';
  const site = headers['sec-fetch-site'];
  if (site != null && !['same-origin', 'none'].includes(site)) return 'CROSS_SITE';
  if (['POST', 'PUT', 'DELETE'].includes(method) && !String(headers['content-type'] || '').toLowerCase().startsWith('application/json')) return 'JSON_REQUIRED';
  return null;
}

/** ctx: { settings, environment, learning, pipeline, listAgentJobs, listSessions, courses(), legacyJobs(), port } */
export async function handleSettingsRequest(ctx, request) {
  const { method, pathname, query } = request;
  if (!isSettingsRoute(pathname)) return null;
  const rejected = checkLocalRequest(request, ctx.port);
  if (rejected) return json(rejected === 'JSON_REQUIRED' ? 415 : 403, { error: rejected });
  const body = request.body && typeof request.body === 'object' && !Array.isArray(request.body) ? request.body : {};
  try {
    if (pathname === '/api/settings') {
      if (method === 'GET') return json(200, ctx.settings.get());
      if (method === 'PUT') { const result = await ctx.settings.update(body); ctx.environment.invalidate(); return json(200, result); }
    }
    if (pathname === '/api/environment' && method === 'GET') return json(200, await ctx.environment.check({ refresh: query?.get?.('refresh') === '1' }));
    if (pathname === '/api/processing' && method === 'GET') {
      const [agentJobs, sessions, pipelineJobs, learningSession] = await Promise.all([ctx.listAgentJobs(), ctx.listSessions(), ctx.pipeline ? ctx.pipeline.list() : [], ctx.learning.status()]);
      return json(200, { ...buildProcessingView({ agentJobs, sessions, pipelineJobs, courses: ctx.courses(), learningSession, legacyJobs: ctx.legacyJobs(), publishErrors: ctx.publishErrors?.() || [] }), pipelineAvailable: Boolean(ctx.pipeline) });
    }
    const retry = pathname.match(/^\/api\/processing\/(job_[0-9a-f]{12})\/retry$/);
    if (retry && method === 'POST') {
      if (!ctx.pipeline) return json(503, { error: 'PIPELINE_UNAVAILABLE', message: '轉錄管線尚未啟用' });
      const job = await ctx.pipeline.retry(retry[1]);
      return json(202, { id: job.id, status: job.status });
    }
    if (pathname === '/api/learning' && method === 'GET') return json(200, await ctx.learning.status());
    if (pathname === '/api/learning/start' && method === 'POST') { const result = await ctx.learning.start({ mode: body.mode, title: body.title, recordPermissionAcknowledged: body.recordPermissionAcknowledged === true, manualTimer: body.manualTimer === true }); ctx.environment.invalidate(); return json(200, result); }
    if (pathname === '/api/learning/stop' && method === 'POST') return json(200, await ctx.learning.stop());
    return json(405, { error: 'METHOD_NOT_ALLOWED' });
  } catch (error) {
    const code = typeof error?.code === 'string' && /^[A-Z][A-Z0-9_]{2,60}$/.test(error.code) ? error.code : 'SETTINGS_ERROR';
    const status = error?.status || STATUS[code] || (code === 'SETTINGS_ERROR' ? 500 : 409);
    // Messages are this module's own fixed Chinese strings; submitted values are never echoed.
    return json(status, { error: code, message: typeof error?.message === 'string' && /[一-鿿]/.test(error.message) ? error.message.slice(0, 200) : '處理失敗', ...(/^[A-Za-z][A-Za-z0-9]{0,39}$/.test(String(error?.field || '')) ? { field: error.field } : {}) });
  }
}

async function readBody(req, limit = 64 * 1024) {
  let size = 0; const chunks = [];
  for await (const chunk of req) { size += chunk.length; if (size > limit) throw Object.assign(new Error('too large'), { status: 413 }); chunks.push(chunk); }
  if (!size) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw Object.assign(new Error('bad json'), { status: 400 }); }
}

/** Node http adapter. Returns true when the request was handled. */
export async function routeSettingsApis(ctx, req, res, url) {
  if (!isSettingsRoute(url.pathname)) return false;
  let result;
  try {
    const rejected = checkLocalRequest({ method: req.method, headers: req.headers }, ctx.port);
    const body = !rejected && ['POST', 'PUT'].includes(req.method) ? await readBody(req) : undefined;
    result = await handleSettingsRequest(ctx, { method: req.method, pathname: url.pathname, query: url.searchParams, headers: req.headers, body });
  } catch (error) {
    result = json(error.status === 413 ? 413 : 400, { error: error.status === 413 ? 'TOO_LARGE' : 'BAD_JSON' });
  }
  res.writeHead(result.status, result.headers); res.end(JSON.stringify(result.body));
  return true;
}
