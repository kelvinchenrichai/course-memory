import fsp from 'node:fs/promises';
import path from 'node:path';
import { readJson, writeJsonAtomic } from '../pipeline/files.mjs';

/**
 * User-editable settings (P4C). Only the keys listed here can be read or written through the API.
 * Folders, commands, executable paths and anything else that points at the file system are NOT editable
 * from the browser. Secrets (API keys, OBS password) are write-only: the API reports `configured`
 * true/false and never returns the value. Everything is written to the git-ignored local config.json.
 */

export class SettingsError extends Error {
  constructor(code, message, field) { super(message); this.name = 'SettingsError'; this.code = code; this.field = field; }
}

const MODEL_NAME = /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,79}$/;
const enumOf = (values) => (value) => (values.includes(value) ? value : undefined);
const pattern = (regex) => (value) => (typeof value === 'string' && regex.test(value.trim()) ? value.trim() : undefined);
const intRange = (min, max) => (value) => (Number.isInteger(value) && value >= min && value <= max ? value : undefined);

function httpsBase(value) {
  if (typeof value !== 'string' || value.length > 200) return undefined;
  let url; try { url = new URL(value.trim()); } catch { return undefined; }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) return undefined;
  return url.href.replace(/\/+$/, '');
}
function loopbackUrl(protocols) {
  return (value) => {
    if (typeof value !== 'string' || value.length > 100) return undefined;
    let url; try { url = new URL(value.trim()); } catch { return undefined; }
    if (!protocols.includes(url.protocol) || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.username || url.password || url.search || url.hash || (url.pathname && url.pathname !== '/')) return undefined;
    return `${url.protocol}//${url.host}`;
  };
}

export const WHISPER_MODELS = Object.freeze(['tiny', 'base', 'small', 'medium', 'large-v3', 'large-v3-turbo']);
export const SETTINGS = Object.freeze({
  learningMode: { validate: enumOf(['video', 'audio']), fallback: 'video' },
  transcriber: { validate: enumOf(['auto', 'faster-whisper', 'whisper.cpp']), fallback: 'auto', restart: true },
  whisperCppBackend: { validate: enumOf(['auto', 'ffmpeg', 'cli']), fallback: 'auto', restart: true },
  whisperModel: { validate: enumOf(WHISPER_MODELS), fallback: 'small', restart: true },
  whisperLanguage: { validate: enumOf(['auto', 'zh', 'en']), fallback: 'auto', restart: true },
  knowledgeMode: { validate: enumOf(['basic', 'ai']), fallback: 'basic' },
  summaryDetail: { validate: enumOf(['concise', 'standard', 'deep']), fallback: 'standard' },
  aiProvider: { validate: enumOf(['ollama', 'openai', 'gemini', 'none']), fallback: 'none' },
  translationLanguage: { validate: enumOf(['none', 'zh-Hant', 'en']), fallback: 'none' },
  externalTranscriptSharing: { validate: enumOf(['disabled', 'confirmed']), fallback: 'disabled' },
  ollamaUrl: { validate: loopbackUrl(['http:', 'https:']), fallback: 'http://127.0.0.1:11434' },
  ollamaModel: { validate: pattern(MODEL_NAME), fallback: 'qwen2.5:7b' },
  openaiBaseUrl: { validate: httpsBase, fallback: 'https://api.openai.com/v1' },
  openaiModel: { validate: pattern(MODEL_NAME), fallback: 'gpt-4.1-mini' },
  geminiModel: { validate: pattern(MODEL_NAME), fallback: 'gemini-2.5-flash' },
  chapterMinutes: { validate: intRange(1, 60), fallback: 6 },
  obsUrl: { validate: loopbackUrl(['ws:', 'wss:']), fallback: 'ws://127.0.0.1:4455', restart: true }
});
export const SECRETS = Object.freeze({ openaiApiKey: { max: 300 }, geminiApiKey: { max: 300 }, obsPassword: { max: 200, restart: true } });

export const OPTIONS = Object.freeze({
  learningMode: [{ value: 'video', label: '錄影（OBS）' }, { value: 'audio', label: '錄音（只錄聲音）' }],
  transcriber: [{ value: 'auto', label: '自動（建議）：faster-whisper；無法在這台電腦執行時改用 whisper.cpp' }, { value: 'faster-whisper', label: '只用 faster-whisper' }, { value: 'whisper.cpp', label: '只用 whisper.cpp' }],
  whisperCppBackend: [{ value: 'auto', label: '自動（有 whisper-cli 就用，否則用 ffmpeg 內建）' }, { value: 'ffmpeg', label: 'ffmpeg 內建 whisper.cpp（不需另外安裝程式）' }, { value: 'cli', label: 'whisper-cli' }],
  whisperModel: WHISPER_MODELS.map((value) => ({ value, label: { tiny: 'tiny（最快、最不準）', base: 'base', small: 'small（建議）', medium: 'medium（較準、較慢）', 'large-v3': 'large-v3（最準、需要好顯卡）', 'large-v3-turbo': 'large-v3-turbo' }[value] })),
  whisperLanguage: [{ value: 'auto', label: '自動偵測' }, { value: 'zh', label: '中文' }, { value: 'en', label: '英文' }],
  knowledgeMode: [{ value: 'basic', label: '基礎整理（預設，不需要 AI）' }, { value: 'ai', label: 'AI 重點整理（使用下方選定的 AI）' }],
  summaryDetail: [{ value: 'concise', label: '精簡' }, { value: 'standard', label: '標準（建議）' }, { value: 'deep', label: '深入' }],
  translationLanguage: [{ value: 'none', label: '不翻譯（預設）' }, { value: 'zh-Hant', label: '翻成繁體中文' }, { value: 'en', label: '翻成英文' }],
  externalTranscriptSharing: [{ value: 'disabled', label: '不允許（預設）' }, { value: 'confirmed', label: '我允許傳送逐字稿給選定的外部 AI' }],
  aiProvider: [{ value: 'none', label: '基礎模式（不使用 AI）' }, { value: 'ollama', label: '本機 AI：Ollama（逐字稿不離開電腦）' }, { value: 'openai', label: '外部 AI：OpenAI（自備金鑰）' }, { value: 'gemini', label: '外部 AI：Gemini（自備金鑰）' }]
});

const hasSecret = (value) => typeof value === 'string' && value.length > 0;

/** What the browser may see. Secrets become { configured }. */
export function publicSettings(config) {
  const values = {}; const restartKeys = [];
  for (const [key, spec] of Object.entries(SETTINGS)) { const value = spec.validate(config[key]); values[key] = value === undefined ? spec.fallback : value; }
  const secrets = Object.fromEntries(Object.keys(SECRETS).map((key) => [key, { configured: hasSecret(config[key]) }]));
  for (const [key, spec] of Object.entries({ ...SETTINGS, ...SECRETS })) if (spec.restart) restartKeys.push(key);
  return { values, secrets, options: OPTIONS, restartKeys };
}

/**
 * Validates a patch: { values: { key: value }, secrets: { key: { set: string } | { clear: true } } }.
 * Unknown keys or invalid values reject the whole patch; values are never echoed back in errors.
 */
export function validatePatch(patch) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new SettingsError('INVALID_SETTINGS', '設定格式錯誤');
  for (const part of [patch.values, patch.secrets]) if (part != null && (typeof part !== 'object' || Array.isArray(part))) throw new SettingsError('INVALID_SETTINGS', '設定格式錯誤');
  const extra = Object.keys(patch).filter((key) => !['values', 'secrets'].includes(key));
  if (extra.length) throw new SettingsError('UNKNOWN_SETTING', '包含不允許修改的設定', extra[0].slice(0, 40));
  const changes = {}; const secretChanges = {};
  for (const [key, value] of Object.entries(patch.values || {})) {
    const spec = Object.hasOwn(SETTINGS, key) ? SETTINGS[key] : null; if (!spec) throw new SettingsError('UNKNOWN_SETTING', '包含不允許修改的設定', key.slice(0, 40));
    const valid = spec.validate(value); if (valid === undefined) throw new SettingsError('INVALID_VALUE', '設定值不正確', key);
    changes[key] = valid;
  }
  for (const [key, action] of Object.entries(patch.secrets || {})) {
    const spec = Object.hasOwn(SECRETS, key) ? SECRETS[key] : null; if (!spec) throw new SettingsError('UNKNOWN_SETTING', '包含不允許修改的設定', key.slice(0, 40));
    if (action?.clear === true && Object.keys(action).length === 1) { secretChanges[key] = ''; continue; }
    const value = typeof action?.set === 'string' ? action.set.trim() : null;
    if (!value || value.length > spec.max || /[\s\u0000-\u001f]/.test(value) || Object.keys(action).length !== 1) throw new SettingsError('INVALID_VALUE', '金鑰／密碼格式不正確', key);
    secretChanges[key] = value;
  }
  return { changes, secretChanges };
}

/**
 * Reads and writes the local config.json. `liveConfig` (the merged object the server uses) is updated in
 * place so most changes apply at once; `restartRequired` lists keys that need a restart.
 */
export function createSettingsStore({ configFile, liveConfig, onChange = () => {} }) {
  if (path.basename(configFile) !== 'config.json') throw new Error('settings may only be written to config.json');
  let queue = Promise.resolve();
  return {
    get: () => publicSettings(liveConfig),
    update(patch) {
      const { changes, secretChanges } = validatePatch(patch);
      const task = queue.then(async () => {
        const raw = await readJson(configFile, {});
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new SettingsError('CONFIG_UNREADABLE', 'config.json 格式錯誤，請手動修正');
        const changed = []; const restartRequired = [];
        for (const [key, value] of Object.entries({ ...changes, ...secretChanges })) {
          if (liveConfig[key] === value && raw[key] === value) continue;
          raw[key] = value; liveConfig[key] = value; changed.push(key);
          if ((SETTINGS[key] || SECRETS[key]).restart) restartRequired.push(key);
        }
        if (changed.length) { await fsp.mkdir(path.dirname(configFile), { recursive: true }); await writeJsonAtomic(configFile, raw); await onChange(changed); }
        return { ...publicSettings(liveConfig), changed, restartRequired };
      });
      queue = task.catch(() => {});
      return task;
    }
  };
}
