import crypto from 'node:crypto';
import { checkLocalRequest } from '../settings/api.mjs';
import { ConsoleError, RATES, TRANSCRIPT_LANGUAGES, TRANSLATION_LANGUAGES, estimatePlan } from '../agent/console.mjs';
import { RIGHTS_BASES } from '../services/rights.mjs';
import { DiscoveryError, cleanLessonUrl, cleanPageUrl, siteOf } from './urls.mjs';
import { listPlatforms, platformView } from './platforms.mjs';

/**
 * P7A「匯入課程清單」. Flow:
 *   scan    → asks the bound browser tab (Companion command `discover`, read-only) for its visible course list,
 *             cleans every link, merges re-scans of the same page without duplicates. Kept in memory only.
 *   preview → estimates for the chosen range (duration, recording size, duplicates).
 *   plan    → only with both acknowledgements: builds the P5 console form and creates + confirms a P5 plan.
 *             The job then waits in the Agent list until the user presses「開始」. Nothing plays or records here.
 * Responses never include URLs, cookies, tokens, passwords or local paths.
 */

const SESSION_TTL_MS = 2 * 3600_000; const MAX_SESSIONS = 20; const MAX_SELECTED = 200;
const ACTIVE_JOB = new Set(['draft', 'awaiting-confirmation', 'queued', 'preparing', 'running', 'stopping', 'blocked', 'completed']);

export const BLOCKER_TEXT = Object.freeze({
  LOGIN_REQUIRED: ['這個頁面需要登入', '請你自己在瀏覽器登入（程式不會代為登入，也不會讀取密碼或 cookie），登入後打開課程目錄再按「重新讀取」。'],
  CAPTCHA: ['頁面出現驗證（我不是機器人）', '請你在瀏覽器完成驗證後再讀取。程式不會嘗試破解或略過驗證。'],
  PAYWALL: ['這門課需要付費或訂閱', '程式不會繞過付費牆。請確認你已購買、能正常觀看，再打開課程目錄讀取。'],
  UNRECOGNIZED_PAGE: ['看不出這頁的課程清單', '請打開課程的目錄／章節列表或播放清單頁，展開所有章節後再讀取；也可以改用下方「手動貼網址」。']
});
const COMPANION_TEXT = {
  COMPANION_NOT_PAIRED: '瀏覽器擴充功能尚未配對。請先在「設定」完成 Course Memory Companion 配對。',
  COMPANION_UNPAIRED: '瀏覽器擴充功能已解除配對，請重新配對。',
  COMPANION_DISCONNECTED: '瀏覽器擴充功能沒有連線。請確認瀏覽器開著、擴充功能已啟用。',
  COMPANION_TAB_UNBOUND: '請先在擴充功能中選擇要讀取的課程分頁（並允許這個網站）。',
  COMPANION_TIMEOUT: '頁面沒有在時間內回應。請重新整理課程頁後再試。'
};
const RESULT_TEXT = {
  PERMISSION_MISSING: '擴充功能還沒有這個網站的權限。請在擴充功能允許這個網站後再試。',
  TAB_NOT_BOUND: COMPANION_TEXT.COMPANION_TAB_UNBOUND, TAB_CLOSED: '選定的分頁已關閉，請重新選擇分頁。',
  CONTENT_NOT_READY: '頁面還沒載入完成，請稍候再試。', UNSUPPORTED: '擴充功能版本太舊，請重新載入擴充功能（需要 0.4.0 以上）。'
};

export const describeDiscoveryBlocker = (code) => { const [title, next] = BLOCKER_TEXT[code] || BLOCKER_TEXT.UNRECOGNIZED_PAGE; return { code: BLOCKER_TEXT[code] ? code : 'UNRECOGNIZED_PAGE', title, next, needsYou: true }; };

export function createDiscoveryService({ sendCommand, companionStatus = () => null, console: agentConsole, listJobs = async () => [], freeBytes = async () => null, listLocalVideos = async () => [], scanLocal = async () => {}, now = () => Date.now(), random = (n) => crypto.randomBytes(n) }) {
  const sessions = new Map();

  function prune() {
    for (const [id, session] of sessions) if (now() - session.updatedAt > SESSION_TTL_MS) sessions.delete(id);
    while (sessions.size > MAX_SESSIONS) sessions.delete(sessions.keys().next().value);
  }
  async function plannedKeys() {
    const keys = new Set();
    for (const job of await listJobs().catch(() => [])) if (ACTIVE_JOB.has(job?.status)) for (const lesson of job.plan?.lessons || []) if (!lesson.skip && lesson.platformLessonId) keys.add(lesson.platformLessonId);
    return keys;
  }
  const ordered = (session) => [...session.items.values()].sort((a, b) => a.order - b.order || a.seq - b.seq);

  async function view(session, extra = {}) {
    const planned = await plannedKeys();
    const items = ordered(session).map((item, index) => ({ id: item.id, index: index + 1, title: item.title, durationSec: item.durationSec, host: item.host, locked: item.locked, alreadyPlanned: planned.has(item.id) }));
    return {
      scanId: session.id, platform: platformView(session.platform), courseTitle: session.courseTitle, pageHost: session.pageHost,
      items, partial: session.partial, blocker: null,
      counts: { total: items.length, locked: items.filter((i) => i.locked).length, alreadyPlanned: items.filter((i) => i.alreadyPlanned).length, unknownDuration: items.filter((i) => i.durationSec == null).length, rejected: { ...session.rejected } },
      updatedAt: new Date(session.updatedAt).toISOString(), ...extra
    };
  }

  function need(id) {
    const session = typeof id === 'string' ? sessions.get(id) : null;
    if (!session) throw new DiscoveryError('SCAN_NOT_FOUND', '找不到這次讀取的清單，請重新從頁面讀取', 404);
    return session;
  }

  function chosen(session, selected) {
    if (!Array.isArray(selected) || !selected.length) throw new DiscoveryError('NOTHING_SELECTED', '請至少勾選一部影片');
    if (selected.length > MAX_SELECTED) throw new DiscoveryError('TOO_MANY', `一次最多 ${MAX_SELECTED} 部影片`);
    const wanted = new Set(selected.map(String));
    for (const id of wanted) { const item = session.items.get(id); if (!item) throw new DiscoveryError('UNKNOWN_ITEM', '選擇的影片不在清單中，請重新讀取'); if (item.locked) throw new DiscoveryError('LOCKED_ITEM', '選到鎖住或需付費的單元；請先取消勾選，或在瀏覽器確認有權觀看後重新讀取'); }
    return ordered(session).filter((item) => wanted.has(item.id));
  }

  const mode = (value) => { if (!['video', 'audio'].includes(value)) throw new DiscoveryError('INVALID_PLAN', '請選擇錄影或純錄音'); return value; };
  const rateOf = (value) => { const rate = Number(value); if (!RATES.includes(rate)) throw new DiscoveryError('INVALID_PLAN', '倍速只能是 1、1.25、1.5、1.75 或 2'); return rate; };

  return {
    platforms: () => listPlatforms(),

    /** Reads the bound tab (read-only). `scanId` merges a re-scan of the same page into the existing list. */
    async scan({ scanId } = {}) {
      prune();
      const status = companionStatus();
      if (status && !status.paired) throw new DiscoveryError('COMPANION_NOT_PAIRED', COMPANION_TEXT.COMPANION_NOT_PAIRED, 409);
      if (status && !status.connected) throw new DiscoveryError('COMPANION_DISCONNECTED', COMPANION_TEXT.COMPANION_DISCONNECTED, 409);
      if (status && !(status.tabs || []).some((tab) => tab.bound)) throw new DiscoveryError('COMPANION_TAB_UNBOUND', COMPANION_TEXT.COMPANION_TAB_UNBOUND, 409);
      let result;
      try { result = await sendCommand({ type: 'discover', args: {} }); }
      catch (error) { const code = COMPANION_TEXT[error?.code] ? error.code : 'COMPANION_DISCONNECTED'; throw new DiscoveryError(code, COMPANION_TEXT[code], 409); }
      if (!result?.ok || !result.discovery) { const reason = result?.reason; throw new DiscoveryError('DISCOVERY_FAILED', RESULT_TEXT[reason] || '無法讀取這個頁面，請重新整理後再試。', 409); }
      const payload = result.discovery;
      const pageUrl = cleanPageUrl(payload.pageUrl || '');
      const pageHost = new URL(pageUrl).hostname; const site = siteOf(pageHost);
      if (payload.blocker) return { scanId: null, platform: platformView(payload.platform), courseTitle: '', pageHost, items: [], counts: null, partial: false, blocker: describeDiscoveryBlocker(payload.blocker) };

      let session = scanId ? sessions.get(String(scanId)) : null;
      if (!session || session.site !== site || session.platform !== payload.platform) {
        session = { id: `scn_${random(6).toString('hex')}`, platform: payload.platform, site, pageHost, courseTitle: payload.courseTitle || pageHost, items: new Map(), seq: 0, partial: false, rejected: { sensitive: 0, crossSite: 0, invalid: 0, media: 0, unavailable: 0, duplicate: 0 }, updatedAt: now() };
        sessions.set(session.id, session);
      }
      const seenNow = new Set(); let added = 0;
      for (const raw of payload.items) {
        if (raw.unavailable) { session.rejected.unavailable += 1; continue; }
        let clean;
        try { clean = cleanLessonUrl(raw.url || '', { pageUrl }); }
        catch (error) { const key = { SENSITIVE_URL: 'sensitive', CROSS_SITE: 'crossSite', MEDIA_URL: 'media' }[error.code] || 'invalid'; session.rejected[key] += 1; continue; }
        if (seenNow.has(clean.lessonKey)) { session.rejected.duplicate += 1; continue; }
        seenNow.add(clean.lessonKey);
        const existing = session.items.get(clean.lessonKey);
        if (existing) { existing.durationSec ??= raw.durationSec; existing.locked = raw.locked; if (!existing.title && raw.title) existing.title = raw.title; continue; }
        session.items.set(clean.lessonKey, { id: clean.lessonKey, url: clean.url, host: clean.host, title: raw.title || `第 ${raw.order} 部`, order: raw.order, seq: (session.seq += 1), durationSec: raw.durationSec, locked: raw.locked });
        added += 1;
      }
      if (payload.courseTitle) session.courseTitle = payload.courseTitle;
      session.partial = payload.partial; session.updatedAt = now();
      if (!session.items.size) { sessions.delete(session.id); return { scanId: null, platform: platformView(payload.platform), courseTitle: '', pageHost, items: [], counts: { total: 0, rejected: { ...session.rejected } }, partial: false, blocker: describeDiscoveryBlocker('UNRECOGNIZED_PAGE') }; }
      return view(session, { added });
    },

    async get(scanId) { return view(need(scanId)); },

    async preview({ scanId, selected, captureMode = 'video', rate = 1 } = {}) {
      const session = need(scanId); const items = chosen(session, selected);
      const planned = await plannedKeys();
      const free = await Promise.resolve(freeBytes()).catch(() => null);
      const estimate = estimatePlan({ lessons: items.map((item) => ({ durationSec: item.durationSec ?? undefined })), rate: rateOf(rate), captureMode: mode(captureMode) }, { freeBytes: Number.isFinite(free) ? free : null });
      return { selected: items.length, estimate, duplicates: items.filter((item) => planned.has(item.id)).map((item) => ({ id: item.id, title: item.title })) };
    },

    /** Creates (and confirms) a P5 plan. Both acknowledgements are checked first; nothing is created without them. */
    async plan(body = {}) {
      const ack = body.acknowledgements || {};
      if (ack.recordPermission !== true || ack.privateProcessing !== true) throw new DiscoveryError('RIGHTS_REQUIRED', '請先勾選兩項授權確認：有權錄製、僅供私人學習', 403);
      const session = need(body.scanId); const items = chosen(session, body.selected);
      if (session.partial) throw new DiscoveryError('DISCOVERY_PARTIAL', '課程清單尚未全部載入。請先在課程目錄捲到最底，再按「重新讀取」，直到畫面不再顯示清單未完整。', 409);
      const transcriptLanguage = body.transcriptLanguage ?? 'auto'; if (!TRANSCRIPT_LANGUAGES.includes(transcriptLanguage)) throw new DiscoveryError('INVALID_PLAN', '逐字稿語言不正確');
      const translationLanguage = body.translationLanguage ?? 'none'; if (!TRANSLATION_LANGUAGES.includes(translationLanguage)) throw new DiscoveryError('INVALID_PLAN', '翻譯語言不正確');
      const rightsBasis = body.rightsBasis ?? 'personal-study'; if (!RIGHTS_BASES.includes(rightsBasis)) throw new DiscoveryError('INVALID_PLAN', '授權依據不正確');
      const form = {
        captureMode: mode(body.captureMode ?? 'video'), rate: rateOf(body.rate ?? 1), transcriptLanguage, translationLanguage,
        captions: { enabled: body.captions === true },
        courses: [{ title: typeof body.title === 'string' && body.title.trim() ? body.title.trim().slice(0, 120) : session.courseTitle, rightsBasis, lessons: items.map((item) => ({ url: item.url, title: item.title, ...(item.durationSec ? { minutes: item.durationSec / 60 } : {}) })) }]
      };
      const plan = await agentConsole.plan(form);
      const job = await agentConsole.confirm(plan.job.id, { planHash: plan.planHash, acknowledgements: { recordPermission: true, privateProcessing: true } });
      return { job, summary: plan.summary };
    },

    async local() { return { folder: '錄影資料夾', files: (await listLocalVideos()).slice(0, 500).map(({ name, sizeBytes, modifiedAt, inLibrary }) => ({ name: String(name).split(/[\\/]/).pop().slice(0, 200), sizeBytes: Number(sizeBytes) || 0, modifiedAt, inLibrary: inLibrary === true })) }; },
    async scanLocal() { await scanLocal(); return { ok: true }; }
  };
}

// ---- HTTP ------------------------------------------------------------------------------------------
const ROUTE = /^\/api\/course-discovery\/(platforms|scan|preview|plan|local|local\/scan|scans\/scn_[0-9a-f]{12})$/;
const json = (status, body) => ({ status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }, body });
const PATHLIKE = /[A-Za-z]:\\[^\s]*|\/(?:home|Users|sessions|root|tmp|var)\/[^\s]*/g;

export const isDiscoveryRoute = (pathname) => ROUTE.test(pathname);

export async function handleDiscoveryRequest(ctx, request) {
  const match = request.pathname.match(ROUTE); if (!match) return null;
  const rejected = checkLocalRequest(request, ctx.port);
  if (rejected) return json(rejected === 'JSON_REQUIRED' ? 415 : 403, { error: rejected });
  const [, action] = match; const { method } = request;
  const body = request.body && typeof request.body === 'object' && !Array.isArray(request.body) ? request.body : {};
  try {
    if (action === 'platforms' && method === 'GET') return json(200, ctx.discovery.platforms());
    if (action === 'local' && method === 'GET') return json(200, await ctx.discovery.local());
    if (action.startsWith('scans/') && method === 'GET') return json(200, await ctx.discovery.get(action.slice(6)));
    if (method !== 'POST') return json(405, { error: 'METHOD_NOT_ALLOWED' });
    if (action === 'scan') return json(200, await ctx.discovery.scan(body));
    if (action === 'preview') return json(200, await ctx.discovery.preview(body));
    if (action === 'plan') return json(201, await ctx.discovery.plan(body));
    if (action === 'local/scan') return json(202, await ctx.discovery.scanLocal());
    return json(405, { error: 'METHOD_NOT_ALLOWED' });
  } catch (error) {
    const known = error instanceof DiscoveryError || error instanceof ConsoleError || typeof error?.code === 'string';
    const code = known && /^[A-Z][A-Z0-9_]{2,60}$/.test(String(error.code)) ? error.code : 'DISCOVERY_ERROR';
    const message = typeof error?.message === 'string' && /[一-鿿]/.test(error.message) ? error.message.replace(PATHLIKE, '').slice(0, 200) : '操作失敗';
    return json(Number.isInteger(error?.status) ? error.status : 400, { error: code, message });
  }
}

export async function routeDiscoveryApis(ctx, req, res, url) {
  if (!isDiscoveryRoute(url.pathname)) return false;
  let body;
  const rejected = checkLocalRequest({ method: req.method, headers: req.headers }, ctx.port);
  if (!rejected && req.method === 'POST') {
    let size = 0; const chunks = [];
    try { for await (const chunk of req) { size += chunk.length; if (size > 64 * 1024) throw new Error('too large'); chunks.push(chunk); } body = size ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}; }
    catch { res.writeHead(400, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ error: 'BAD_JSON' })); return true; }
  }
  const result = await handleDiscoveryRequest(ctx, { method: req.method, pathname: url.pathname, headers: req.headers, body });
  res.writeHead(result.status, result.headers); res.end(JSON.stringify(result.body));
  return true;
}
