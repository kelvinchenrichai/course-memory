/**
 * P7A platform capability registry. One entry per platform the course-list importer knows.
 * `discovery`: auto  = list is read from the visible page without user help;
 *              semi  = only links visible in the user's own browser tab are read; the user must open /
 *                      expand / scroll the course outline first and check the result.
 *              local = files in the configured recordings folder (never a browser-supplied path).
 * `capabilities` describe what the existing Companion adapters can do during an Agent run.
 * Nothing here talks to a platform API.
 */

const CAP = (discover, navigate, rate, captions, autoNext) => Object.freeze({ discover, navigate, rate, captions, autoNext });

export const PLATFORMS = Object.freeze({
  youtube: Object.freeze({
    id: 'youtube', label: 'YouTube', discovery: 'auto', hosts: ['youtube.com', 'www.youtube.com', 'm.youtube.com'],
    capabilities: CAP(true, true, true, true, true),
    automatic: ['讀取播放清單中可見影片的標題、順序、時長', '開啟影片', '倍速', '字幕（CC）', '下一部'],
    needsUser: ['在擴充功能允許 youtube.com 並選擇這個分頁', '播放清單很長時，先捲到底讓全部影片載入，再按「重新讀取」']
  }),
  bilibili: Object.freeze({
    id: 'bilibili', label: 'Bilibili', discovery: 'semi', hosts: ['bilibili.com', 'www.bilibili.com'],
    capabilities: CAP(true, true, true, true, true),
    automatic: ['讀取頁面上可見的分P／合集清單', '開啟計畫中的下一部並驗證 BV 號與分P', '播放／暫停、倍速、字幕（只用播放器原生按鈕與選單）'],
    needsUser: ['在擴充功能允許 bilibili.com 並選擇這個分頁', '展開合集或分P列表後再讀取', '登入、驗證碼與付費／充電提示一律由你處理', '影片本身沒有字幕時無法開啟 CC']
  }),
  skool: Object.freeze({
    id: 'skool', label: 'Skool', discovery: 'semi', hosts: ['skool.com', 'www.skool.com'],
    capabilities: CAP(true, true, true, false, false),
    automatic: ['讀取 Classroom 側欄中可見的課程單元連結', '偵測到播放器時自動播放、倍速', '依計畫開啟下一個單元網址並驗證'],
    needsUser: ['先在瀏覽器登入並打開課程的 Classroom 頁面', '展開所有模組（Module）後再讀取', '嵌入式（YouTube／Vimeo 等 iframe）播放器需要你自己按播放', '沒有明確網址的下一章由你操作', '鎖住的單元需要你自己解鎖，Agent 不會處理']
  }),
  satKnowledge: Object.freeze({
    id: 'satKnowledge', label: '知識衛星（SAT. Knowledge）', discovery: 'semi', hosts: ['sat.cool'],
    capabilities: CAP(true, true, true, false, false),
    automatic: ['讀取課程頁章節列表中可見的單元連結', '偵測到播放器時自動播放、倍速、HTML5 字幕', '依計畫開啟下一個章節網址並驗證'],
    needsUser: ['先在瀏覽器登入並打開已購買課程的章節頁', '展開所有章節後再讀取', '沒有明確網址的下一章由你操作']
  }),
  generic: Object.freeze({
    id: 'generic', label: '其他課程網站', discovery: 'semi', hosts: [],
    capabilities: CAP(true, true, true, false, false),
    automatic: ['讀取課程目錄（側欄、章節列表）中可見、同網站的單元連結', '偵測到單一 HTML5 播放器時自動播放、倍速、字幕'],
    needsUser: ['先在瀏覽器登入並打開課程目錄', '確認清單正確（通用讀取可能多抓或漏抓）', '登入、付款、驗證畫面需要你處理', '頁面有多個或嵌入式播放器時由你操作']
  }),
  local: Object.freeze({
    id: 'local', label: '本機影片', discovery: 'local', hosts: [],
    capabilities: CAP(true, false, false, false, false),
    automatic: ['列出錄影資料夾中的影片檔（只顯示檔名）', '交給既有的匯入與轉錄流程'],
    needsUser: ['把影片檔放進設定中的錄影資料夾（網頁不能指定電腦上的路徑）']
  })
});

const hostMatches = (host, list) => list.some((item) => host === item || host.endsWith(`.${item}`));

/** Platform id for a hostname (lower-case). Unknown sites use the generic reader. */
export function platformForHost(hostname) {
  const host = String(hostname || '').toLowerCase();
  for (const platform of Object.values(PLATFORMS)) if (platform.hosts.length && hostMatches(host, platform.hosts)) return platform.id;
  return 'generic';
}

/** Public view for the API / UI (no host lists needed by the page). */
export function platformView(id) {
  const platform = PLATFORMS[id] || PLATFORMS.generic;
  return { id: platform.id, label: platform.label, discovery: platform.discovery, capabilities: { ...platform.capabilities }, automatic: [...platform.automatic], needsUser: [...platform.needsUser] };
}

export const listPlatforms = () => Object.keys(PLATFORMS).map(platformView);
