import { ConsoleError, parseLessonUrl } from '../agent/console.mjs';

/**
 * P7A URL hygiene for discovered lesson links.
 *  - fragment and known tracking parameters are removed;
 *  - a link with credentials, a token / signature / auth / session style parameter, or a JWT-looking value
 *    is REJECTED (never stored, never shown again) instead of being "cleaned";
 *  - only links on the same site as the page the user is looking at are kept;
 *  - media files / CDN links are refused (same rule as the P5 console).
 * The result is exactly what the P5 console / Runner will accept later (parseLessonUrl).
 */

export class DiscoveryError extends Error {
  constructor(code, message, status = 400) { super(message); this.name = 'DiscoveryError'; this.code = code; this.status = status; }
}

const TRACKING = /^(utm_[a-z_]+|fbclid|gclid|dclid|gbraid|wbraid|msclkid|yclid|mc_cid|mc_eid|igshid|_hsenc|_hsmi|mkt_tok|ref|ref_src|ref_url|referrer|si|pp|feature|ab_channel|spm_id_from|vd_source|from_spmid|share_source|share_medium|share_plat|share_session_id|share_tag|share_from|unique_k|bbid|ts|seid|start_radio|rv|index|t|is_from_webapp|sender_device|_ga|_gl)$/i;
// Superset of the P5 console rule, so anything kept here is also accepted when the plan is built.
const SENSITIVE_KEY = /token|auth|sig|signature|key|session|cookie|passw|secret|credential|jwt|hmac|policy|expires|^code$|^sid$|^otp$|x-amz-|x-goog-/i;
const SENSITIVE_VALUE = /^eyJ[\w-]{8,}\.[\w-]{8,}\./;
const SECOND_LEVEL = /^(com|co|org|net|edu|gov|ac|or|ne|go)$/;

/** "www.example.com.tw" → "example.com.tw"; good enough to compare sites without a public-suffix list. */
export function siteOf(hostname) {
  const labels = String(hostname || '').toLowerCase().split('.').filter(Boolean);
  if (labels.length <= 2) return labels.join('.');
  const take = labels.at(-1).length === 2 && SECOND_LEVEL.test(labels.at(-2)) ? 3 : 2;
  return labels.slice(-take).join('.');
}

/** Throws DiscoveryError(code) or returns { url, lessonKey, host, platform }. */
export function cleanLessonUrl(value, { pageUrl } = {}) {
  if (typeof value !== 'string' || !value.trim() || value.length > 2000) throw new DiscoveryError('INVALID_URL', '網址不正確');
  let url; try { url = new URL(value.trim(), pageUrl || undefined); } catch { throw new DiscoveryError('INVALID_URL', '網址不正確'); }
  if (!['https:', 'http:'].includes(url.protocol)) throw new DiscoveryError('INVALID_URL', '只接受 http／https 課程頁網址');
  if (url.username || url.password) throw new DiscoveryError('SENSITIVE_URL', '網址含有帳號或密碼，已拒絕保存');
  url.hash = '';
  for (const key of [...url.searchParams.keys()]) if (TRACKING.test(key)) url.searchParams.delete(key);
  for (const [key, val] of url.searchParams) if (SENSITIVE_KEY.test(key) || SENSITIVE_VALUE.test(val)) throw new DiscoveryError('SENSITIVE_URL', '網址含有登入、簽章或權杖參數，已拒絕保存');
  if (pageUrl) {
    let page; try { page = new URL(pageUrl); } catch { throw new DiscoveryError('INVALID_URL', '頁面網址不正確'); }
    if (siteOf(page.hostname) !== siteOf(url.hostname)) throw new DiscoveryError('CROSS_SITE', '連結指向其他網站，已略過');
  }
  let parsed;
  try { parsed = parseLessonUrl(url.toString()); }
  catch (error) { if (error instanceof ConsoleError) throw new DiscoveryError(error.code === 'MEDIA_URL_NOT_ALLOWED' ? 'MEDIA_URL' : 'INVALID_URL', error.message); throw error; }
  return { url: parsed.url, lessonKey: parsed.platformLessonId, host: parsed.host, platform: parsed.platform };
}

/** Page address the user is on: same hygiene, but tracking-free and never sensitive. */
export function cleanPageUrl(value) {
  if (typeof value !== 'string' || value.length > 2000) throw new DiscoveryError('INVALID_URL', '頁面網址不正確');
  let url; try { url = new URL(value); } catch { throw new DiscoveryError('INVALID_URL', '頁面網址不正確'); }
  if (!['https:', 'http:'].includes(url.protocol)) throw new DiscoveryError('UNRECOGNIZED_PAGE', '這不是一般網頁');
  if (url.username || url.password) throw new DiscoveryError('SENSITIVE_URL', '頁面網址含有帳號或密碼');
  url.hash = '';
  for (const key of [...url.searchParams.keys()]) if (TRACKING.test(key)) url.searchParams.delete(key);
  for (const [key, val] of url.searchParams) if (SENSITIVE_KEY.test(key) || SENSITIVE_VALUE.test(val)) throw new DiscoveryError('SENSITIVE_URL', '頁面網址含有登入、簽章或權杖參數，請改開一般課程頁');
  return url.toString();
}

// ---- incoming payload allowlist (defence in depth; the extension sanitizes too) -------------------
export const DISCOVERY_PLATFORMS = Object.freeze(['youtube', 'bilibili', 'skool', 'satKnowledge', 'generic']);
export const DISCOVERY_BLOCKERS = Object.freeze(['LOGIN_REQUIRED', 'CAPTCHA', 'PAYWALL', 'UNRECOGNIZED_PAGE']);
const CONTROL = /[\u0000-\u001f\u007f​-‏‪-‮⁦-⁩]/g;
const text = (value, max) => (typeof value === 'string' ? value.replace(CONTROL, ' ').replace(/\s+/g, ' ').trim().slice(0, max) : '');
const str = (value, max) => (typeof value === 'string' && value.length <= max ? value : null);

export function sanitizeDiscoveryPayload(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const items = Array.isArray(raw.items) ? raw.items.slice(0, 500).map((item, index) => {
    if (!item || typeof item !== 'object') return null;
    const duration = typeof item.durationSec === 'number' && Number.isFinite(item.durationSec) && item.durationSec > 0 && item.durationSec <= 86_400 ? Math.round(item.durationSec) : null;
    const order = Number.isInteger(item.order) && item.order > 0 && item.order < 100_000 ? item.order : index + 1;
    return { key: text(item.key, 120), title: text(item.title, 200), order, url: str(item.url, 2000), durationSec: duration, locked: item.locked === true, unavailable: item.unavailable === true };
  }).filter(Boolean) : [];
  return {
    platform: DISCOVERY_PLATFORMS.includes(raw.platform) ? raw.platform : 'generic',
    pageUrl: str(raw.pageUrl, 2000), courseTitle: text(raw.courseTitle, 200), items,
    blocker: DISCOVERY_BLOCKERS.includes(raw.blocker) ? raw.blocker : null, partial: raw.partial === true
  };
}
