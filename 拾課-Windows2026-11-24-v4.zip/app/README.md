# Course Memory：錄影學習 → 自動整理知識 MVP

品牌：CK_Trading

這是一套 Windows 本機優先工具：OBS 錄影完成後，它會監控指定資料夾，用 ffmpeg 擷取音訊、faster-whisper 產生繁中／英文時間戳逐字稿，再用 Ollama（可選）整理章節、重點、名詞、待辦與複習題。網頁介面支援全文搜尋、快捷標記，以及點時間碼回到影片。

## 目前這台電腦的狀態

- 已有：Node.js、Ollama 程式。
- 尚未偵測到：OBS、ffmpeg、可正常執行的 Python。
- 因此目前可直接看內建 Demo；完整轉錄前需執行一次 `Setup.ps1`。

## 最短使用流程

1. 右鍵 `Setup.ps1` →「使用 PowerShell 執行」，安裝 ffmpeg、Python/faster-whisper，並依需要安裝 OBS。
2. 依 [OBS-設定指南.md](OBS-設定指南.md) 把 OBS 的錄影路徑指向本專案的 `recordings`。
3. 右鍵 `Start-Learning.ps1` →「使用 PowerShell 執行」。瀏覽器會開啟 `http://127.0.0.1:4317`。
4. 在網頁按「開始錄影學習」，再開始 OBS 錄影；觀看中按 `Ctrl + Alt + M` 標記重點。
5. 停止 OBS。檔案大小穩定約 5–10 秒後會自動開始處理，完成後即可搜尋與點回影片。

如果 PowerShell 阻擋腳本，可在本專案資料夾執行：

```powershell
powershell -ExecutionPolicy Bypass -File .\Setup.ps1
powershell -ExecutionPolicy Bypass -File .\Start-Learning.ps1
```

## AI 與成本選擇

- **最省事、全本機（預設）：** faster-whisper `small` + Ollama `qwen2.5:7b`。沒有啟動 Ollama 時，仍會用離線規則產生基本整理。
- **較弱電腦：** 把 `config.json` 的 `whisperModel` 改為 `base`，Ollama 模型改小或先不啟動。
- **較重視準確率：** 改為 `medium`；速度與首次模型下載量會增加。
- **whisper.cpp：** 「轉錄工具」預設為「自動」：先用 faster-whisper；只有它無法在這台電腦執行（例如 Windows「智慧型應用程式控制」擋下 ctranslate2.dll）時，才改用 whisper.cpp。FFmpeg 8 以上的 full build 已內建 whisper.cpp，不需另外安裝程式，只要把 ggml 模型（例如 `ggml-small.bin`）放到 `models\whisper\`。不需要也不建議關閉 Windows 安全防護。詳見 `docs/TRANSCRIPTION_ENGINES.md`。
- **自備 API：** MVP 先不把課程內容送往外部；若日後加入 API，應明確顯示哪些文字會外傳，並由使用者主動啟用。

Ollama 首次使用可在命令提示字元執行 `ollama pull qwen2.5:7b`；這會下載數 GB 模型。未下載也不影響轉錄和搜尋。

## 資料位置與隱私

- 原始錄影：`recordings/`
- 逐字稿、音訊與課程 JSON：`library/`
- 進行中的快捷標記：`data/session.json`
- 個人設定：`config.json`

伺服器只監聽 `127.0.0.1`，不對區域網路或網際網路開放。本工具不會自動上傳內容。即使課程允許錄影，也請確認授權範圍；不要公開分享影片、逐字稿或摘要，並避免錄入聊天通知、姓名、信箱等第三人個資。

## 已知 MVP 限制

- 目前章節以固定時間區段切分；下一版可加上語意轉場偵測。
- 快捷鍵時間以按下網頁「開始錄影學習」為零點，因此要和 OBS 開始錄影的時間盡量接近。
- 全文搜尋目前是本機 JSON 線性搜尋；數百堂課後可升級為 SQLite FTS5。
- 第一堂真實錄影會下載 Whisper 模型，需要網路；之後可離線執行。

## 開發驗證

```powershell
npm run check
npm test
node server.mjs
```
