import test from 'node:test';
import assert from 'node:assert/strict';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import Ajv2020 from 'ajv/dist/2020.js';
import addFormats from 'ajv-formats';
import { createPipelineRunner } from '../src/pipeline/runner.mjs';
import { createFakeMedia } from './helpers/fake-process.mjs';
import {
  createAutoProvider, createFasterWhisperProvider, createFfmpegWhisperProvider, createWhisperProvider, escapeFilterValue,
  parseFfmpegWhisperLines, whisperCppModelCandidates
} from '../src/pipeline/transcript.mjs';
import { buildPipelineCourse, publishableSegments, TRANSCRIPT_EMPTY } from '../src/pipeline/publish.mjs';
import { checkFasterWhisper, checkWhisperCpp, createEnvironmentChecker } from '../src/settings/environment.mjs';
import { buildProcessingView, describeError, engineNote } from '../src/settings/processing.mjs';
import { handleCourseArchiveRequest } from '../src/library/archive.mjs';
import { renderEngineDetails, transcriberText } from '../web/p4c-view.js';

/**
 * Transcription engines (P9 收尾): faster-whisper first; whisper.cpp (ffmpeg's built-in filter) only when
 * faster-whisper cannot run on this computer at all (e.g. ctranslate2.dll blocked by Smart App Control).
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const readJson = async (file) => JSON.parse(await fsp.readFile(file, 'utf8'));
const tmp = async (label) => { const base = path.join(process.cwd(), 'tmp-tests'); await fsp.mkdir(base, { recursive: true }); return fsp.mkdtemp(path.join(base, `cms-whisper-${label}-`)); };
const failWith = (code, extra = {}) => Object.assign(new Error(code), { code, ...extra });

let validators;
async function schemas() {
  if (validators) return validators;
  const ajv = new Ajv2020({ allErrors: true, strict: false }); addFormats(ajv);
  for (const name of (await fsp.readdir(path.join(root, 'schemas'))).filter((n) => n.endsWith('.json'))) ajv.addSchema(await readJson(path.join(root, 'schemas', name)));
  const get = (name) => ajv.getSchema(`https://schemas.course-memory.local/v1/${name}.schema.json`);
  validators = { track: get('transcript-track'), job: get('pipeline-job'), text: (v) => ajv.errorsText(v.errors) };
  return validators;
}

/**
 * Fake engines on top of the fake media runner.
 *  python (faster-whisper): mode 'ok' | 'blocked' (exit 5) | 'legacy-blocked' (old script: traceback, exit 1)
 *                           | 'fail' (exit 4: loads, but transcription fails)
 *  ffmpeg -af whisper=…:    writes `lines` (array of strings or objects) to the filter's destination in cwd;
 *                           filter 'missing' → "No such filter" error.
 */
function engines({ media, python = 'ok', fasterSegments = [], lines = [], filter = 'present' } = {}) {
  const fake = createFakeMedia({ media });
  const calls = { python: 0, whisper: 0 }; const filters = [];
  async function run(command, args, options = {}) {
    if (command === 'python') {
      calls.python += 1;
      if (python === 'blocked') throw failWith('PROCESS_FAILED', { exitCode: 5, stderrTail: 'ENGINE_BLOCKED (WinError 4551)' });
      if (python === 'legacy-blocked') throw failWith('PROCESS_FAILED', { exitCode: 1, stderrTail: 'OSError: [WinError 4551] C:\\Users\\someone\\x\\ctranslate2.dll' });
      if (python === 'fail') throw failWith('PROCESS_FAILED', { exitCode: 4, stderrTail: 'TRANSCRIBE_FAILED: RuntimeError' });
      await fsp.writeFile(args[2], JSON.stringify({ schema: 'cms.whisper-raw/1', engine: { name: 'faster-whisper', version: '1.2.1' }, language: 'en', languageProbability: 0.98, duration: 60, segments: fasterSegments }));
      return { code: 0, stdout: '', stderr: '' };
    }
    const af = args.includes('-af') ? args[args.indexOf('-af') + 1] : '';
    if (command === 'ffmpeg' && af.startsWith('whisper=')) {
      calls.whisper += 1; filters.push(af);
      if (filter === 'missing') throw failWith('PROCESS_FAILED', { exitCode: 8, stderrTail: "[AVFilterGraph] No such filter: 'whisper'" });
      const destination = af.match(/destination=([^:]+)/)[1];
      if (lines.length) await fsp.writeFile(path.join(options.cwd, destination), lines.map((line) => (typeof line === 'string' ? line : JSON.stringify(line))).join('\n') + '\n');
      return { code: 0, stdout: '', stderr: '' };
    }
    return fake.run(command, args, options);
  }
  return { run, calls, fake, filters };
}

async function setupJob({ python = 'ok', lines = [], fasterSegments = [], model = true, language = 'auto', durationSec = 60, filter } = {}) {
  const base = await tmp('job');
  await fsp.mkdir(path.join(base, 'imports'), { recursive: true });
  const file = path.join(base, 'imports', 'lesson.mkv'); await fsp.writeFile(file, 'fixture media');
  const media = new Map([[path.resolve(file), { durationSec, audio: true, video: true }]]);
  const modelFile = path.join(base, 'models', 'whisper', 'ggml-small.bin');
  if (model) { await fsp.mkdir(path.dirname(modelFile), { recursive: true }); await fsp.writeFile(modelFile, 'ggml'); }
  const fakes = engines({ media, python, lines, fasterSegments, filter });
  const config = { transcriber: 'auto', pythonCommand: 'python', whisperModel: 'small', ffmpegCommand: 'ffmpeg' };
  const provider = createWhisperProvider(config, { run: fakes.run, root: base });
  const make = (p = provider) => createPipelineRunner({ dataDir: path.join(base, 'data'), workRoot: path.join(base, 'work'), allowedRoots: [path.join(base, 'imports')], run: fakes.run, provider: p, defaults: { language } });
  return { base, file, fakes, provider, config, runner: make(), make, modelFile };
}

const zhLines = [{ start: 0, end: 4200, text: '測試段落一。這是第一段。' }, { start: 4200, end: 9000, text: '老師說：「這裡要注意」' }];
const enLines = [{ start: 1000, end: 5000, text: ' This is the first sentence.' }, { start: 5000, end: 9500, text: ' And the second one.' }];

test('engines 1: faster-whisper loads → auto never starts whisper.cpp', async () => {
  const env = await setupJob({ fasterSegments: [{ id: 0, start: 1, end: 5, text: 'hello', avgLogprob: -0.2, noSpeechProb: 0.01, words: null }] });
  const { job } = await env.runner.enqueue({ source: { kind: 'import' }, files: [env.file] });
  await env.runner.idle();
  const done = await env.runner.get(job.id);
  assert.equal(done.status, 'completed', JSON.stringify(done.error));
  assert.equal(env.fakes.calls.python, 1); assert.equal(env.fakes.calls.whisper, 0, 'fallback not started');
  const track = await readJson(path.join(env.base, 'work', done.result.assetDir, 'transcript.json'));
  assert.deepEqual(track.engine, { name: 'faster-whisper', model: 'small', tempoNormalized: false });
  assert.equal(track.origin, 'whisper');
  assert.equal(env.provider.primaryBlocked, null);
});

test('engines 2: WinError 4551 (ctranslate2.dll blocked) → auto uses ffmpeg whisper.cpp once, remembers it, records the switch', async () => {
  const { track: validateTrack, job: validateJob, text } = await schemas();
  for (const python of ['blocked', 'legacy-blocked']) {
    const env = await setupJob({ python, lines: enLines });
    const { job } = await env.runner.enqueue({ source: { kind: 'import' }, files: [env.file] });
    await env.runner.idle();
    const done = await env.runner.get(job.id);
    assert.equal(done.status, 'completed', `${python}: ${JSON.stringify(done.error)}`);
    assert.equal(validateJob(done), true, text(validateJob));
    assert.deepEqual(env.fakes.calls, { python: 1, whisper: 1 });
    const stage = done.stages.find((item) => item.name === 'transcribe');
    assert.deepEqual(stage.outputs.engine, { name: 'whisper.cpp', model: 'ggml-small.bin', backend: 'ffmpeg', fallbackFrom: 'faster-whisper', fallbackReason: 'ENGINE_BLOCKED' });
    const track = await readJson(path.join(env.base, 'work', done.result.assetDir, 'transcript.json'));
    assert.equal(validateTrack(track), true, text(validateTrack));
    assert.equal(track.origin, 'whisper.cpp'); assert.equal(track.engine.name, 'whisper.cpp'); assert.equal(track.engine.fallbackFrom, 'faster-whisper');
    // The block is remembered: the next transcription goes straight to whisper.cpp (no new failing start).
    await env.provider.transcribe({ audio: path.join(env.base, 'x.wav'), outDir: await tmp('again'), language: 'auto' });
    assert.deepEqual(env.fakes.calls, { python: 1, whisper: 2 });
    env.provider.reset(); // the settings check found faster-whisper loadable again → try it first next time
    assert.equal(env.provider.primaryBlocked, null);
  }
});

test('engines 3: an engine that loads but fails on this audio never switches engines', async () => {
  const env = await setupJob({ python: 'fail', lines: enLines });
  const { job } = await env.runner.enqueue({ source: { kind: 'import' }, files: [env.file] });
  await env.runner.idle();
  const done = await env.runner.get(job.id);
  assert.equal(done.status, 'failed'); assert.equal(done.error.code, 'WHISPER_FAILED');
  assert.deepEqual(env.fakes.calls, { python: 1, whisper: 0 });
  assert.equal(env.provider.primaryBlocked, null);
  // Fallback failure does not bounce back to faster-whisper either.
  let primaryCalls = 0;
  const auto = createAutoProvider({ primary: { name: 'faster-whisper', model: 'small', params: {}, transcribe: async () => { primaryCalls += 1; throw Object.assign(new Error('blocked'), { code: 'ENGINE_BLOCKED', engineUnavailable: true }); } },
    fallback: { name: 'whisper.cpp', model: 'ggml-small.bin', params: {}, transcribe: async () => { throw Object.assign(new Error('bad'), { code: 'WHISPER_FAILED' }); } } });
  await assert.rejects(auto.transcribe({}), { code: 'WHISPER_FAILED' });
  await assert.rejects(auto.transcribe({}), { code: 'WHISPER_FAILED' });
  assert.equal(primaryCalls, 1, 'primary tried once, then remembered as blocked');
});

test('engines 4: whisper.cpp model missing → clear install guidance, job failed (never a fake success)', async () => {
  const env = await setupJob({ python: 'blocked', lines: enLines, model: false });
  const { job } = await env.runner.enqueue({ source: { kind: 'import' }, files: [env.file] });
  await env.runner.idle();
  const done = await env.runner.get(job.id);
  assert.equal(done.status, 'failed'); assert.equal(done.error.code, 'WHISPER_CPP_MODEL_MISSING');
  assert.equal(env.fakes.calls.whisper, 0, 'ffmpeg not run without a model');
  const view = buildProcessingView({ pipelineJobs: [done] });
  const transcribe = view.items[0].phases.find((phase) => phase.key === 'transcribe');
  assert.equal(transcribe.state, 'needs-user');
  assert.match(transcribe.error.message, /找不到 whisper\.cpp 模型/);
  assert.match(transcribe.error.hint, /ggml-small\.bin/); assert.match(transcribe.error.hint, /models\\whisper\\/); assert.match(transcribe.error.hint, /Hugging Face/);
  assert.doesNotMatch(JSON.stringify(view), /cms-whisper-job|tmp-tests/, 'no local path in the view');
  // ffmpeg without the whisper filter: also explicit.
  const noFilter = await setupJob({ python: 'blocked', lines: enLines, filter: 'missing' });
  await noFilter.runner.enqueue({ source: { kind: 'import' }, files: [noFilter.file] }); await noFilter.runner.idle();
  const failed = (await noFilter.runner.list())[0];
  assert.equal(failed.error.code, 'WHISPER_CPP_FILTER_MISSING');
  assert.match(describeError('WHISPER_CPP_FILTER_MISSING').hint, /FFmpeg 8/);
});

test('engines 5: silence stays TRANSCRIPT_EMPTY (the engine worked, nothing was said)', async () => {
  for (const lines of [[], [{ start: 0, end: 30000, text: ' [BLANK_AUDIO]' }, { start: 30000, end: 60000, text: '  ' }]]) {
    const env = await setupJob({ python: 'blocked', lines });
    const { job } = await env.runner.enqueue({ source: { kind: 'import' }, files: [env.file] });
    await env.runner.idle();
    const done = await env.runner.get(job.id);
    assert.equal(done.status, 'completed', 'not an engine failure');
    const track = await readJson(path.join(env.base, 'work', done.result.assetDir, 'transcript.json'));
    assert.equal(track.segments.length, 0);
    assert.throws(() => publishableSegments(track), { code: TRANSCRIPT_EMPTY });
  }
});

test('engines 6: retrying the blocked job switches engine without re-extracting media, stays one job / one course', async () => {
  const env = await setupJob({ python: 'blocked', lines: zhLines });
  // Job created while only faster-whisper was configured (like job_403e51389c97).
  const fasterOnly = createWhisperProvider({ ...env.config, transcriber: 'faster-whisper' }, { run: env.fakes.run, root: env.base });
  const first = env.make(fasterOnly);
  const { job } = await first.enqueue({ source: { kind: 'import' }, files: [env.file] });
  await first.idle();
  let failed = await first.get(job.id);
  assert.equal(failed.status, 'failed'); assert.equal(failed.error.code, 'ENGINE_BLOCKED');
  assert.match(describeError('ENGINE_BLOCKED').hint, /不需要關閉 Windows 安全防護/);
  const extractions = () => env.fakes.fake.calls.filter((call) => call.command === 'ffmpeg' && !call.args.includes('-af')).length;
  const extractedBefore = extractions();
  const oldKeys = Object.fromEntries(failed.stages.map((stage) => [stage.name, stage.stageKey]));
  // Restart with 自動 and press 重試.
  const restarted = env.make(env.provider);
  await restarted.recover();
  await restarted.retry(job.id);
  await assert.rejects(restarted.retry(job.id), { code: 'INVALID_TRANSITION' }); // a second click while queued does nothing
  await restarted.idle();
  const done = await restarted.get(job.id);
  assert.equal(done.status, 'completed', JSON.stringify(done.error));
  assert.equal(extractions(), extractedBefore, 'audio was not extracted again');
  for (const name of ['probe', 'audio', 'prepare']) assert.equal(done.stages.find((s) => s.name === name).stageKey, oldKeys[name]);
  const transcribe = done.stages.find((s) => s.name === 'transcribe');
  assert.notEqual(transcribe.stageKey, oldKeys.transcribe); assert.equal(transcribe.previousStageKey, oldKeys.transcribe);
  assert.equal((await restarted.list()).length, 1, 'still one job');
  // Enqueueing the same media again while it runs or after: deduplicated / same asset.
  const again = await restarted.enqueue({ source: { kind: 'import' }, files: [env.file] });
  assert.equal(again.job.asset.id, done.asset.id);
  const track = await readJson(path.join(env.base, 'work', done.result.assetDir, 'transcript.json'));
  const course = await buildPipelineCourse({ job: done, track, workRoot: path.join(env.base, 'work'), chapterMinutes: 6, generate: null });
  const sameAgain = await buildPipelineCourse({ job: done, track, existing: course, workRoot: path.join(env.base, 'work'), chapterMinutes: 6, generate: null });
  assert.equal(sameAgain.id, course.id); assert.equal(sameAgain, course, 'existing course updated, not a second one');
});

test('engines 7: the same media is never transcribed by two engines at once', async () => {
  const env = await setupJob({ python: 'blocked', lines: enLines });
  let active = 0; let maxActive = 0;
  const slow = { ...env.provider, name: env.provider.name, params: env.provider.params, model: env.provider.model,
    async transcribe(args) { active += 1; maxActive = Math.max(maxActive, active); await new Promise((r) => setTimeout(r, 30)); try { return await env.provider.transcribe(args); } finally { active -= 1; } } };
  const runner = env.make(slow);
  const [a, b] = await Promise.all([runner.enqueue({ source: { kind: 'import' }, files: [env.file] }), runner.enqueue({ source: { kind: 'import' }, files: [env.file] })]);
  assert.equal(a.job.id, b.job.id); assert.equal(b.deduplicated || a.deduplicated, true);
  await runner.idle();
  assert.equal(maxActive, 1);
});

test('engines 8: Chinese and English through whisper.cpp keep times, segment ids and language like faster-whisper', async () => {
  const { track: validateTrack, text } = await schemas();
  const cases = [
    { lines: zhLines, language: 'zh-Hant', expectLanguage: 'zh', texts: ['測試段落一。這是第一段。', '老師說：「這裡要注意」'], times: [[0, 4.2], [4.2, 9]] },
    { lines: enLines, language: 'en', expectLanguage: 'en', texts: ['This is the first sentence.', 'And the second one.'], times: [[1, 5], [5, 9.5]] }
  ];
  for (const item of cases) {
    const env = await setupJob({ python: 'blocked', lines: item.lines, language: item.language });
    const { job } = await env.runner.enqueue({ source: { kind: 'import' }, files: [env.file] });
    await env.runner.idle();
    const done = await env.runner.get(job.id);
    assert.equal(done.status, 'completed', JSON.stringify(done.error));
    assert.match(env.fakes.filters[0], new RegExp(`:language=${item.expectLanguage}:`), 'requested language passed to whisper.cpp');
    const track = await readJson(path.join(env.base, 'work', done.result.assetDir, 'transcript.json'));
    assert.equal(validateTrack(track), true, text(validateTrack));
    assert.deepEqual(track.segments.map((s) => s.id), ['s0001', 's0002']);
    assert.deepEqual(track.segments.map((s) => s.text), item.texts);
    assert.deepEqual(track.segments.map((s) => s.rec), item.times);
    assert.deepEqual(track.segments.map((s) => s.src), item.times, 'import: src = rec');
    assert.equal(track.language, item.expectLanguage); assert.equal(track.requestedLanguage, item.language);
    const srt = await fsp.readFile(path.join(env.base, 'work', done.result.assetDir, 'transcript.rec.srt'), 'utf8');
    assert.match(srt, /00:00:0\d,\d{3} --> 00:00:0\d,\d{3}/);
  }
  // auto: the filter is asked to detect, never told a guessed language.
  const env = await setupJob({ python: 'blocked', lines: zhLines, language: 'auto' });
  await env.runner.enqueue({ source: { kind: 'import' }, files: [env.file] }); await env.runner.idle();
  assert.match(env.fakes.filters[0], /:language=auto:/);
});

test('engines 9: ffmpeg whisper output parser and filter escaping', async () => {
  const parsed = parseFfmpegWhisperLines([
    '{"start":0,"end":8000,"text":"测试段落。"}',
    '{"start":8000,"end":10000,"text":"He said "hi" to me","language":"en"}', // ffmpeg does not escape quotes
    '{"start":10000,"end":12000,"text":"[BLANK_AUDIO]"}',
    ''
  ].join('\n'));
  assert.deepEqual(parsed.segments.map((s) => [s.start, s.end, s.text]), [[0, 8, '测试段落。'], [8, 10, 'He said "hi" to me']]);
  assert.equal(parsed.language, 'en');
  assert.throws(() => parseFfmpegWhisperLines('not json at all'), { code: 'WHISPER_OUTPUT_INVALID' });
  assert.equal(escapeFilterValue('C:\\Users\\x y\\m.bin'), 'C\\\\:/Users/x y/m.bin');
  // Real ffmpeg: a path with : [ ] , ; ' survives both escaping levels (ametadata writes to the given file).
  const ffmpegOk = spawnSync('ffmpeg', ['-hide_banner', '-version']).status === 0;
  if (ffmpegOk) {
    // Windows forbids ':' in names; there the drive letter ("C:") already exercises the colon escaping.
    const dir = path.join(await tmp('esc'), process.platform === 'win32' ? "we ird [dir], it's;x" : "we:ird [dir], it's;x"); await fsp.mkdir(dir, { recursive: true });
    const wav = path.join(dir, 'a.wav');
    spawnSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i', 'sine=d=0.2', wav]);
    const out = path.join(dir, 'out.txt');
    const result = spawnSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-i', wav, '-af', `ametadata=mode=print:file=${escapeFilterValue(out)}`, '-f', 'null', '-']);
    assert.equal(result.status, 0, String(result.stderr)); await fsp.access(out);
  }
  // Model lookup: configured file first, then models/whisper/ggml-<model>.bin. Never a guessed download.
  assert.deepEqual(whisperCppModelCandidates({ whisperModel: 'small' }, '/r').map((p) => p.split(path.sep).join('/')), ['/r/models/whisper/ggml-small.bin']);
});

test('engines 10: transcribe.py --check classifies a policy-blocked DLL (exit 5, no paths)', { skip: spawnSync('python3', ['--version']).status !== 0 }, async () => {
  const stub = await tmp('stub'); await fsp.mkdir(path.join(stub, 'faster_whisper'), { recursive: true });
  await fsp.writeFile(path.join(stub, 'faster_whisper', '__init__.py'), 'e = OSError(22, "blocked")\ne.winerror = 4551\nraise e\n');
  const run = (pythonPath) => spawnSync('python3', [path.join(root, 'scripts', 'transcribe.py'), '--check'], { env: { ...process.env, PYTHONPATH: pythonPath }, encoding: 'utf8' });
  const blocked = run(stub);
  assert.equal(blocked.status, 5);
  assert.deepEqual(JSON.parse(blocked.stdout), { ok: false, code: 'ENGINE_BLOCKED', winerror: 4551, error: 'OSError' });
  await fsp.writeFile(path.join(stub, 'faster_whisper', '__init__.py'), '__version__ = "9.9.9"\n');
  const ok = run(stub);
  assert.equal(ok.status, 0); assert.deepEqual(JSON.parse(ok.stdout), { ok: true, code: null, version: '9.9.9' });
});

test('engines 11: settings check reports each engine with 繁中 reason/advice and never a path', async () => {
  const base = await tmp('env');
  const modelFile = path.join(base, 'models', 'whisper', 'ggml-small.bin'); await fsp.mkdir(path.dirname(modelFile), { recursive: true }); await fsp.writeFile(modelFile, 'x');
  const run = async (command, args) => {
    if (args.includes('--check')) throw failWith('PROCESS_FAILED', { exitCode: 5, stdout: '{"ok": false, "code": "ENGINE_BLOCKED", "winerror": 4551, "error": "OSError"}\n' });
    if (args.includes('filter=whisper')) return { stdout: 'Filter whisper\n  Transcribe audio using whisper.cpp.\n', stderr: '' };
    if (args.includes('-version')) return { stdout: 'ffmpeg version 9.0.2-full_build-www.gyan.dev', stderr: '' };
    throw failWith('COMMAND_NOT_FOUND');
  };
  let reset = 0;
  const config = { transcriber: 'auto', pythonCommand: 'python', whisperModel: 'small', ffmpegCommand: 'ffmpeg', aiProvider: 'none' };
  const checker = createEnvironmentChecker({ run, config, root: base, transcriber: { reset: () => { reset += 1; } }, obsInstalled: () => false, probeObs: async () => ({ state: 'unreachable' }), keyConfigured: () => false });
  const env = await checker.check({ refresh: true });
  assert.equal(env.whisper.ready, true); assert.equal(env.whisper.active, 'whisper.cpp'); assert.equal(env.whisper.fallbackInUse, true);
  assert.equal(env.whisper.model, 'ggml-small.bin'); assert.equal(env.whisper.backend, 'ffmpeg');
  assert.equal(env.whisper.fasterWhisper.code, 'ENGINE_BLOCKED'); assert.equal(env.whisper.fasterWhisper.winerror, 4551);
  assert.match(env.whisper.fasterWhisper.reason, /智慧型應用程式控制/); assert.match(env.whisper.fasterWhisper.advice, /不需要關閉/);
  assert.equal(reset, 0, 'still blocked: the fallback memory is kept');
  const json = JSON.stringify(env);
  assert.equal(json.includes(base), false); assert.doesNotMatch(json, /RuntimeError|Users|tmp-tests/);
  assert.equal(transcriberText(env.whisper), 'whisper.cpp・ggml-small.bin（ffmpeg 內建）');
  assert.match(renderEngineDetails(env.whisper), /智慧型應用程式控制/);
  // No model → explicit, with where to get it.
  await fsp.rm(modelFile);
  const cpp = await checkWhisperCpp({ run, config, root: base, ffmpegOk: true });
  assert.equal(cpp.ready, false); assert.equal(cpp.code, 'WHISPER_CPP_MODEL_MISSING'); assert.match(cpp.advice, /ggml-small\.bin/);
  // faster-whisper loads → ready, sticky fallback memory cleared.
  const okRun = async (command, args) => (args.includes('--check') ? { stdout: '{"ok": true, "code": null, "version": "1.2.1"}\n', stderr: '' } : run(command, args));
  const okChecker = createEnvironmentChecker({ run: okRun, config, root: base, transcriber: { reset: () => { reset += 1; } }, obsInstalled: () => false, probeObs: async () => ({ state: 'unreachable' }), keyConfigured: () => false });
  const okEnv = await okChecker.check({ refresh: true });
  assert.equal(okEnv.whisper.active, 'faster-whisper'); assert.equal(okEnv.whisper.version, '1.2.1'); assert.equal(reset, 1);
  const timeout = await checkFasterWhisper({ run: async () => { throw failWith('PROCESS_TIMEOUT'); }, config, root: base });
  assert.equal(timeout.code, 'ENGINE_CHECK_TIMEOUT');
});

test('engines 12: processing centre shows the engine actually used; legacy RuntimeError gets a readable reason and a safe archive', async () => {
  assert.equal(engineNote({ name: 'whisper.cpp', model: 'ggml-small.bin', backend: 'ffmpeg', fallbackFrom: 'faster-whisper', fallbackReason: 'ENGINE_BLOCKED' }),
    '引擎：whisper.cpp・ggml-small.bin（ffmpeg 內建）；faster-whisper 無法在這台電腦執行（Windows「智慧型應用程式控制」擋下了 faster-whisper 需要的 ctranslate2.dll），已自動改用');
  const legacy = { id: '4dd8ef72590f', title: '2026-11-13 18-24-12', status: 'error', error: 'TRANSCRIBE_FAILED: RuntimeError\r\n\n請執行 Setup.ps1，並確認 OBS 的錄影資料夾與 config.json 相同。', createdAt: '2026-11-13T10:25:11.538Z' };
  const view = buildProcessingView({ courses: [legacy] });
  const item = view.items[0];
  assert.equal(item.phases[1].error.code, 'LEGACY_TRANSCRIBE_FAILED');
  assert.doesNotMatch(item.phases[1].error.message, /RuntimeError/);
  assert.deepEqual(item.actions, [
    { type: 'rename-course', label: '更名', courseId: '4dd8ef72590f', currentTitle: '2026-11-13 18-24-12' },
    { type: 'archive-course', label: '封存（不刪除）', courseId: '4dd8ef72590f' }
  ]);
  const courses = [legacy]; const saved = [];
  const ctx = { port: 4317, courses: () => courses, saveCourse: async (course) => { saved.push({ ...course }); }, now: () => '2026-11-15T00:00:00.000Z' };
  const local = { host: '127.0.0.1:4317', origin: 'http://127.0.0.1:4317', 'content-type': 'application/json' };
  assert.equal((await handleCourseArchiveRequest(ctx, { method: 'POST', pathname: '/api/courses/4dd8ef72590f/archive', headers: local, body: {} })).status, 400, 'needs confirm');
  assert.equal((await handleCourseArchiveRequest(ctx, { method: 'POST', pathname: '/api/courses/4dd8ef72590f/archive', headers: { ...local, origin: 'https://evil.example' }, body: { confirm: true } })).status, 403);
  const archived = await handleCourseArchiveRequest(ctx, { method: 'POST', pathname: '/api/courses/4dd8ef72590f/archive', headers: local, body: { confirm: true } });
  assert.equal(archived.status, 200); assert.equal(archived.body.archived, true);
  assert.equal(courses.length, 1, 'never removed'); assert.equal(courses[0].error.startsWith('TRANSCRIBE_FAILED'), true, 'record untouched apart from the flag');
  assert.equal(buildProcessingView({ courses }).items.length, 0, 'archived: no longer asks for attention');
  const restored = await handleCourseArchiveRequest(ctx, { method: 'POST', pathname: '/api/courses/4dd8ef72590f/unarchive', headers: local, body: { confirm: true } });
  assert.equal(restored.body.archived, false); assert.equal(buildProcessingView({ courses }).items.length, 1);
  assert.equal((await handleCourseArchiveRequest(ctx, { method: 'POST', pathname: '/api/courses/nope1234/archive', headers: local, body: { confirm: true } })).status, 404);
});

test('engines 13: real ffmpeg provider call shape — model by absolute path, output in the stage folder, language passed through', async () => {
  const base = await tmp('shape'); const model = path.join(base, 'm', 'ggml-small.bin'); await fsp.mkdir(path.dirname(model), { recursive: true }); await fsp.writeFile(model, 'x');
  const calls = [];
  const provider = createFfmpegWhisperProvider({ run: async (command, args, options) => { calls.push({ command, args, cwd: options.cwd }); await fsp.writeFile(path.join(options.cwd, 'whisper-cpp.raw.jsonl'), '{"start":0,"end":1500,"text":"你好"}\n'); return {}; }, models: [model] });
  const out = await tmp('out');
  const raw = await provider.transcribe({ audio: path.join(base, 'a.wav'), outDir: out, language: 'zh-Hant' });
  assert.equal(calls.length, 1); assert.equal(calls[0].cwd, out);
  const filter = calls[0].args[calls[0].args.indexOf('-af') + 1];
  assert.match(filter, /^whisper=model=.*ggml-small\.bin:language=zh:queue=30:use_gpu=false:destination=whisper-cpp\.raw\.jsonl:format=json$/);
  assert.deepEqual(raw.segments.map((s) => [s.start, s.end, s.text]), [[0, 1.5, '你好']]);
  assert.deepEqual(raw.engine, { name: 'whisper.cpp', model: 'ggml-small.bin', backend: 'ffmpeg', version: null });
  assert.equal(createFasterWhisperProvider({ run: async () => {}, python: 'p', script: 's' }).name, 'faster-whisper');
});

test('engines 14: fresh-install setup downloads the official fallback model and verifies SHA256 before use', async () => {
  const setup = await fsp.readFile(path.join(root, 'Setup.ps1'), 'utf8');
  const config = await readJson(path.join(root, 'config.example.json'));
  assert.match(setup, /ggerganov\/whisper\.cpp\/resolve\/main\/ggml-small\.bin/);
  assert.match(setup, /1be3a9b2063867b937e64e2ec7483364a79917e157fa98c5d94b5c1fffea987b/);
  assert.match(setup, /Get-FileHash[^\n]+SHA256/);
  assert.match(setup, /Move-Item[^\n]+\$ModelDownload[^\n]+\$ModelFile/, 'publish only after verification');
  assert.equal(config.whisperCppModel, 'models\\whisper\\ggml-small.bin');
});
