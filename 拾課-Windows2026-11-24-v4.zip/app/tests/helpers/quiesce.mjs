// Deterministic waiting for tests that mix a fake clock with real async I/O (JSON file stores).
//
// Instead of sleeping a few real milliseconds and hoping the file writes finished, wrap the store with
// `track()`: every promise it returns is tracked, `quiesce()` waits until none are in flight (and the
// microtask / setImmediate queues are drained), and only then does `pollUntil` advance the fake clock.
// Progress depends on state, never on wall-clock timing.
import { settle } from './agent-fakes.mjs';

export function createIoTracker() {
  const inflight = new Set();
  const track = (target) => new Proxy(target, {
    get(object, key) {
      const value = object[key];
      if (typeof value !== 'function') return value;
      return (...args) => {
        const result = value.apply(object, args);
        if (result && typeof result.then === 'function') {
          const promise = Promise.resolve(result).finally(() => inflight.delete(promise));
          inflight.add(promise);
        }
        return result;
      };
    }
  });
  /** Resolves true when no tracked I/O is pending and the event loop queues are empty. */
  async function quiesce({ maxRounds = 500 } = {}) {
    for (let round = 0; round < maxRounds; round += 1) {
      await settle(3);
      if (!inflight.size) { await settle(2); if (!inflight.size) return true; continue; }
      await Promise.allSettled([...inflight]);
    }
    throw new Error(`I/O did not settle after ${maxRounds} rounds (${inflight.size} pending)`);
  }
  return { track, quiesce, get pending() { return inflight.size; } };
}

/**
 * Checks `cond` after every quiescent step; advances the fake clock by `stepMs` between checks.
 * `maxSteps` bounds simulated time (maxSteps × stepMs), not real time.
 */
export async function pollUntil(cond, { clock, quiesce, stepMs = 500, maxSteps = 400 } = {}) {
  for (let step = 0; ; step += 1) {
    await quiesce();
    if (await cond()) return true;
    if (step >= maxSteps) return false;
    clock.advance(stepMs);
  }
}
