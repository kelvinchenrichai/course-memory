import fsp from 'node:fs/promises';
import path from 'node:path';
import { synthWav } from '../../src/pipeline/media.mjs';

/**
 * Fake child processes for P4A tests. Nothing is spawned: ffprobe answers from a scenario, ffmpeg writes
 * synthetic silent/tone WAVs of the length the real command would produce, and calls are recorded so
 * tests can assert the exact argument arrays.
 */

const stripFile = (arg) => (arg.startsWith('file:') ? arg.slice(5) : arg);
const failWith = (code, extra = {}) => Object.assign(new Error(code), { code, ...extra });

/** `media`: Map(absolute path → { durationSec, audio: bool, video: bool }). `fail`: { ffprobe|ffmpeg|extract|piece: code | n }. */
export function createFakeMedia({ media = new Map(), fail = {}, ffmpeg = 'ffmpeg', ffprobe = 'ffprobe' } = {}) {
  const calls = [];
  const take = (name) => { const value = fail[name]; if (!value) return null; if (typeof value === 'object' && value.times > 0) { value.times -= 1; return value.code; } if (typeof value === 'string') return value; return null; };
  async function run(command, args, options = {}) {
    if (!Array.isArray(args) || args.some((arg) => typeof arg !== 'string')) throw new Error('args must be a string array');
    calls.push({ command, args: [...args] });
    if (options.signal?.aborted) throw failWith('PROCESS_ABORTED');
    if (command === ffprobe) {
      const code = take('ffprobe'); if (code) throw failWith(code, { exitCode: 1 });
      const info = media.get(path.resolve(stripFile(args.at(-1))));
      if (!info) throw failWith('PROCESS_FAILED', { exitCode: 1, stderr: 'No such file' });
      const streams = [];
      if (info.video) streams.push({ codec_type: 'video', width: 1280, height: 720, avg_frame_rate: '30/1' });
      if (info.audio) streams.push({ codec_type: 'audio', sample_rate: '48000', channels: 2, codec_name: 'aac' });
      return { code: 0, stdout: JSON.stringify({ streams, format: { duration: String(info.durationSec), format_name: 'matroska,webm' } }), stderr: '' };
    }
    if (command === ffmpeg) {
      const code = take('ffmpeg'); if (code) throw failWith(code, { exitCode: 1 });
      const output = stripFile(args.at(-1));
      const inputs = args.flatMap((arg, index) => (args[index - 1] === '-i' ? [path.resolve(stripFile(arg))] : []));
      let seconds;
      if (args.includes('-ss')) {
        const pieceCode = take('piece'); if (pieceCode) throw failWith(pieceCode, { exitCode: 1 });
        const t = Number(args[args.indexOf('-t') + 1]);
        const filter = args.includes('-af') ? args[args.indexOf('-af') + 1] : '';
        const factor = [...filter.matchAll(/atempo=([0-9.]+)/g)].reduce((product, match) => product * Number(match[1]), 1);
        seconds = t / factor;
      } else {
        const extractCode = take('extract'); if (extractCode) throw failWith(extractCode, { exitCode: 1 });
        seconds = inputs.reduce((sum, input) => sum + (media.get(input)?.durationSec ?? 0), 0);
      }
      await fsp.mkdir(path.dirname(output), { recursive: true });
      await fsp.writeFile(output, synthWav({ seconds: Math.round(seconds * 16000) / 16000, amplitude: 0 }));
      return { code: 0, stdout: '', stderr: '' };
    }
    throw failWith('COMMAND_NOT_FOUND');
  }
  return { run, calls, media };
}

/**
 * Fake Whisper provider. `utterances` are what was audible in the recording, in rec time. Like a real
 * engine it only "hears" what is in the audio it was given: it reads the windows the prepare stage wrote
 * and reports times on that audio's own timeline. Options: fail (code | {times, code}), hold (Promise).
 */
export function createFakeProvider({ utterances = [], name = 'faster-whisper', origin = 'whisper', model = 'fixture-small', fail = null, hold = null, language = 'en', withConfidence = true } = {}) {
  const state = { calls: 0, concurrent: 0, maxConcurrent: 0 };
  const provider = {
    name, origin, model, heavy: true, params: { model }, state,
    async transcribe({ audio, outDir, signal }) {
      state.calls += 1; state.concurrent += 1; state.maxConcurrent = Math.max(state.maxConcurrent, state.concurrent);
      try {
        if (hold) await Promise.race([hold, new Promise((_, reject) => signal?.addEventListener('abort', () => reject(failWith('CANCELLED')), { once: true }))]);
        if (fail) { const code = typeof fail === 'string' ? fail : fail.times > 0 ? (fail.times -= 1, fail.code) : null; if (code) throw failWith(code); }
        const stagesDir = path.dirname(outDir);
        const prepareDir = (await fsp.readdir(stagesDir)).filter((dir) => dir.startsWith('prepare-'));
        let windows = null;
        for (const dir of prepareDir) {
          const record = JSON.parse(await fsp.readFile(path.join(stagesDir, dir, 'stage.json'), 'utf8').catch(() => 'null'));
          const input = record?.outputs?.input; if (!input) continue;
          const matches = input.stage === 'prepare' ? path.resolve(path.join(stagesDir, dir, input.file)) === path.resolve(audio) : path.basename(path.dirname(audio)).startsWith('audio-');
          if (matches) { windows = record.outputs.windows; break; }
        }
        if (!windows) throw new Error('fake provider could not find windows');
        const recToIn = (rec) => {
          for (const window of windows) {
            const recEnd = window.recStart + (window.inEnd - window.inStart) * window.recPerIn;
            if (rec >= window.recStart - 1e-9 && rec <= recEnd + 1e-9) return window.inStart + (rec - window.recStart) / window.recPerIn;
          }
          return null;
        };
        const segments = [];
        for (const [index, item] of utterances.entries()) {
          const start = recToIn(item.rec[0]); const end = recToIn(item.rec[1]);
          if (start == null || end == null) continue; // not in this audio (e.g. paused / ad cut out per-span)
          const words = item.words ? item.words.map((word) => ({ w: word.w, start: recToIn(word.rec[0]), end: recToIn(word.rec[1]), probability: 0.9 })).filter((word) => word.start != null && word.end != null) : null;
          segments.push({ index, start, end, text: item.text, avgLogprob: withConfidence ? (item.avgLogprob ?? -0.2) : null, noSpeechProb: withConfidence ? (item.noSpeechProb ?? 0.01) : null, words });
        }
        return { engine: { name, model, version: 'fixture' }, language, languageProbability: withConfidence ? 0.97 : null, durationSec: null, segments };
      } finally { state.concurrent -= 1; }
    }
  };
  return provider;
}

/** Fake long-running ffmpeg for the audio capture adapter. */
export function createFakeCaptureProcess({ deviceListing = '', behaviour = 'ok', segments = 2, listCode = null } = {}) {
  const calls = []; const handles = [];
  const run = async (command, args) => {
    calls.push({ command, args: [...args], kind: 'run' });
    if (listCode) throw failWith(listCode);
    if (args.includes('-list_devices')) throw failWith('PROCESS_FAILED', { exitCode: 1, stderr: deviceListing, stdout: '' });
    return { code: 0, stdout: 'ffmpeg version 7.0-fixture', stderr: '' };
  };
  const start = (command, args, { onStderr } = {}) => {
    calls.push({ command, args: [...args], kind: 'start' });
    let exit = null; const waiters = []; let stderr = '';
    const finish = (value) => { if (exit) return; exit = value; for (const fn of waiters.splice(0)) fn(value); };
    const pattern = args.at(-1).replace(/^file:/, '').replace(/%%/g, '%');
    const writeSegments = async () => { for (let index = 0; index < segments; index += 1) { const file = pattern.replace('%03d', String(index).padStart(3, '0')); await fsp.mkdir(path.dirname(file), { recursive: true }); await fsp.writeFile(file, 'fLaC-fixture'); } };
    const handle = {
      pid: 4242, writes: [], killed: false,
      get exited() { return exit; },
      write(text) { handle.writes.push(text); if (text === 'q' && behaviour !== 'ignore-q') writeSegments().then(() => finish({ code: 0, signal: null, error: null })); return true; },
      kill() { handle.killed = true; writeSegments().then(() => finish({ code: null, signal: 'SIGTERM', error: null })); },
      wait() { return exit ? Promise.resolve(exit) : new Promise((resolve) => waiters.push(resolve)); },
      stderrTail: () => stderr,
      crash() { finish({ code: 1, signal: null, error: null }); }
    };
    handles.push(handle);
    queueMicrotask(() => {
      if (behaviour === 'not-found') return finish({ code: null, error: 'COMMAND_NOT_FOUND' });
      if (behaviour === 'device-gone') { stderr = '[dshow @ 0] Could not find audio only device with name [x] among source devices of type audio.\n'; onStderr?.(stderr); return finish({ code: 1, signal: null, error: null }); }
      if (behaviour === 'silent') return; // never confirms
      stderr = "Output #0, segment, to 'x':\nPress [q] to stop, [?] for help\n"; onStderr?.(stderr);
    });
    return handle;
  };
  return { runner: { run, start }, calls, handles };
}

export function manualTimers() {
  const pending = new Set();
  return {
    pending,
    setTimeout(fn) { const entry = { fn }; pending.add(entry); return entry; },
    clearTimeout(entry) { pending.delete(entry); },
    fireAll() { for (const entry of [...pending]) { pending.delete(entry); entry.fn(); } }
  };
}
