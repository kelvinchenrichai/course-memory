// Minimal fake DOM for adapter tests: elements, a tiny selector engine (tag, #id, .class, [attr],
// [attr=value], descendant combinator, comma lists), bubbling events, a clock-driven <video>, location.

export class FakeEvent {
  constructor(type, init = {}) { Object.assign(this, init); this.type = type; this.isTrusted = false; this.defaultPrevented = false; }
  preventDefault() { this.defaultPrevented = true; }
}
export class FakeKeyboardEvent extends FakeEvent {}

function parseCompound(text) {
  if (text === '*') return { tag: null, ids: [], classes: [], attrs: [] };
  const m = text.match(/^([a-zA-Z][\w-]*)?((?:[#.][\w-]+|\[[^\]]+\])*)$/);
  if (!m) throw new Error(`unsupported selector: ${text}`);
  const parts = { tag: m[1]?.toLowerCase() || null, ids: [], classes: [], attrs: [] };
  for (const token of m[2].match(/[#.][\w-]+|\[[^\]]+\]/g) || []) {
    if (token[0] === '#') parts.ids.push(token.slice(1));
    else if (token[0] === '.') parts.classes.push(token.slice(1));
    else { const [, name, value] = token.match(/^\[([\w-]+)(?:=["']?([^"'\]]*)["']?)?\]$/) || []; if (!name) throw new Error(`unsupported attribute selector: ${token}`); parts.attrs.push({ name, value }); }
  }
  return parts;
}
const matchesCompound = (el, c) => (!c.tag || el.tagName === c.tag) && c.ids.every((id) => el.id === id) && c.classes.every((cls) => el.classList.contains(cls)) && c.attrs.every(({ name, value }) => (value === undefined ? el.hasAttribute(name) : el.getAttribute(name) === value));
function matchesComplex(el, compounds) {
  if (!matchesCompound(el, compounds.at(-1))) return false;
  let index = compounds.length - 2; let node = el.parent;
  while (index >= 0 && node) { if (node.tagName && matchesCompound(node, compounds[index])) index -= 1; node = node.parent; }
  return index < 0;
}
const compile = (selector) => selector.split(',').map((part) => part.trim().split(/\s+/).map(parseCompound));

export class FakeElement {
  constructor(document, tagName, spec = {}) {
    this.ownerDocument = document; this.tagName = tagName.toLowerCase(); this.id = spec.id || ''; this.parent = null; this.children = [];
    this._classes = new Set(String(spec.class || '').split(/\s+/).filter(Boolean)); this._attrs = new Map(Object.entries(spec.attrs || {}));
    this._text = spec.text || ''; this.hidden = Boolean(spec.hidden); this.style = { ...(spec.style || {}) }; this._listeners = new Map();
    this._rect = { x: 0, y: 0, width: 0, height: 0, ...(spec.rect || {}) };
    this.classList = { contains: (c) => this._classes.has(c), add: (c) => this._classes.add(c), remove: (c) => this._classes.delete(c), toggle: (c, on) => ((on ?? !this._classes.has(c)) ? this._classes.add(c) : this._classes.delete(c)) };
  }
  // Real-DOM semantics: textContent includes descendants; className / parentElement exist (P7A discovery).
  get textContent() { return this._text + this.children.map((child) => child.textContent).join(''); }
  set textContent(value) { this._text = String(value ?? ''); this.children = []; }
  get className() { return [...this._classes].join(' '); }
  get parentElement() { return this.parent && this.parent.tagName ? this.parent : null; }
  getAttribute(name) { return this._attrs.has(name) ? String(this._attrs.get(name)) : null; }
  setAttribute(name, value) { this._attrs.set(name, String(value)); }
  hasAttribute(name) { return this._attrs.has(name); }
  appendChild(child) { child.parent = this; this.children.push(child); return child; }
  remove() { if (this.parent) { this.parent.children = this.parent.children.filter((c) => c !== this); this.parent = null; } }
  get isConnected() { let node = this; while (node.parent) node = node.parent; return node === this.ownerDocument.documentElement; }
  *descendants() { for (const child of this.children) { yield child; yield* child.descendants(); } }
  querySelectorAll(selector) { const lists = compile(selector); return [...this.descendants()].filter((el) => lists.some((c) => matchesComplex(el, c))); }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  addEventListener(type, fn) { const set = this._listeners.get(type) || new Set(); set.add(fn); this._listeners.set(type, set); }
  removeEventListener(type, fn) { this._listeners.get(type)?.delete(fn); }
  dispatchEvent(event) {
    event.target ??= this;
    let node = this;
    while (node) { for (const fn of [...(node._listeners?.get(event.type) || [])]) fn.call(node, event); node = node.parent; }
    for (const fn of [...(this.ownerDocument._listeners.get(event.type) || [])]) fn(event);
    return !event.defaultPrevented;
  }
  focus() { this.ownerDocument.activeElement = this; }
  getBoundingClientRect() { return { ...this._rect, right: this._rect.x + this._rect.width, bottom: this._rect.y + this._rect.height }; }
  click() { this.ownerDocument.log.push(`click:${this.describe()}`); this.dispatchEvent(new FakeEvent('click', { bubbles: true })); }
  describe() { return `${this.tagName}${this.id ? `#${this.id}` : ''}${[...this._classes].map((c) => `.${c}`).join('')}`; }
}

/** A <video> whose currentTime advances with the injected clock while playing. */
export class FakeVideo extends FakeElement {
  constructor(document, spec = {}) {
    super(document, 'video', spec); const v = spec.video || {};
    this.clock = document.clock; this._time = v.currentTime ?? 0; this._rate = v.playbackRate ?? 1; this._paused = v.paused ?? true; this._since = this.clock.now();
    this.duration = v.duration ?? NaN; this.readyState = v.readyState ?? 4; this.error = v.error ? { code: v.error } : null;
    this.lockRate = Boolean(v.lockRate); this.rejectPlay = Boolean(v.rejectPlay);
    this.src = v.src || ''; // present only so tests can prove adapters never read or forward it
    this.textTracks = (spec.tracks || []).map((t) => ({ kind: t.kind, language: t.language, label: t.label, mode: t.mode || 'disabled' }));
  }
  _sync() { const now = this.clock.now(); if (!this._paused) { this._time += ((now - this._since) / 1000) * this._rate; if (Number.isFinite(this.duration) && this._time >= this.duration) { this._time = this.duration; this._paused = true; } } this._since = now; }
  get currentTime() { this._sync(); return this._time; }
  set currentTime(value) { this._sync(); this._time = value; }
  get paused() { this._sync(); return this._paused; }
  get ended() { this._sync(); return Number.isFinite(this.duration) && this._time >= this.duration; }
  get playbackRate() { return this._rate; }
  set playbackRate(value) { this.ownerDocument.log.push('write:playbackRate'); if (!this.lockRate) { this._sync(); this._rate = value; } }
  setRateFromPlayer(value) { this._sync(); this._rate = value; } // YouTube's own UI changing the speed
  play() { this.ownerDocument.log.push('video.play()'); if (this.rejectPlay) return Promise.reject(new Error('NotAllowedError')); this._sync(); this._paused = false; return Promise.resolve(); }
  pause() { this.ownerDocument.log.push('video.pause()'); this._sync(); this._paused = true; }
}

export class FakeDocument {
  constructor({ clock, log }) {
    this.clock = clock; this.log = log; this._listeners = new Map(); this.title = ''; this.activeElement = null;
    this.documentElement = new FakeElement(this, 'html'); this.cookie = 'SID=fixture-cookie-secret';
  }
  querySelectorAll(selector) { return this.documentElement.querySelectorAll(selector); }
  querySelector(selector) { return this.documentElement.querySelector(selector); }
  addEventListener(type, fn) { const set = this._listeners.get(type) || new Set(); set.add(fn); this._listeners.set(type, set); }
  createElement(spec) { return spec.tag === 'video' ? new FakeVideo(this, spec) : new FakeElement(this, spec.tag, spec); }
}

function build(document, parent, nodes) { for (const spec of nodes || []) { const el = parent.appendChild(document.createElement(spec)); build(document, el, spec.children); if (spec.shadow) { el.shadowRoot = new FakeElement(document, 'shadow-root'); build(document, el.shadowRoot, spec.shadow); } } }

/** Builds { document, window, log } from a fixtures/platform page description. */
export function buildPage(spec, { clock }) {
  const log = []; const document = new FakeDocument({ clock, log }); document.title = spec.title || '';
  build(document, document.documentElement, spec.tree);
  let href = spec.url;
  const location = { get href() { return href; }, set href(value) { href = new URL(value, href).toString(); log.push(`navigate:${href}`); }, get hostname() { return new URL(href).hostname; }, get pathname() { return new URL(href).pathname; }, get search() { return new URL(href).search; } };
  const window = { location, navigator: { onLine: spec.online !== false }, KeyboardEvent: FakeKeyboardEvent, localStorage: { token: 'fixture-local-token' }, document };
  return { document, window, log, replaceTree(nodes) { document.documentElement.children = []; build(document, document.documentElement, nodes); } };
}
