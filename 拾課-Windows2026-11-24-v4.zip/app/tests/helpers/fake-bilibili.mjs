// Emulates Bilibili's own player controls for the adapter tests (self-built fixtures only).
// State changes happen the way the real UI would do them — never through the adapter touching the video.
export function installFakeBilibili(page, behavior = {}) {
  const { document, window, log } = page;
  const b = { buttonsWork: true, rateWorks: true, nextUrl: null, ...behavior };
  const video = () => document.querySelector('.bpx-player-video-wrap video');
  document.addEventListener('click', (event) => {
    const t = event.target; if (!t?.classList) return;
    if (!b.buttonsWork) return;
    const v = video();
    if (t.classList.contains('bpx-player-ctrl-play') && v) { v._sync(); v._paused = !v._paused; log.push('bilibili:native-play-toggle'); }
    else if (t.classList.contains('bpx-player-ctrl-playbackrate-menu-item') && v && b.rateWorks) v.setRateFromPlayer(Number(t.getAttribute('data-value')));
    else if (t.classList.contains('bpx-player-ctrl-subtitle-language-item')) { for (const item of document.querySelectorAll('.bpx-player-ctrl-subtitle-language-item')) item.classList.remove('bpx-state-active'); t.classList.add('bpx-state-active'); }
    else if (t.classList.contains('bpx-player-ctrl-next')) {
      const url = new URL(window.location.href);
      window.location.href = b.nextUrl || `${url.origin}${url.pathname}?p=${(Number(url.searchParams.get('p')) || 1) + 1}`;
    }
  });
}
