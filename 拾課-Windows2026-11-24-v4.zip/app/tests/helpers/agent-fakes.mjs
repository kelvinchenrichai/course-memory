import { FakeClock } from './fake-obs.mjs';

export { FakeClock };
export const EPOCH_MS = Date.parse('2026-11-11T00:00:00.000Z');
export const settle = async (turns = 3) => { for (let i = 0; i < turns; i += 1) await new Promise((resolve) => setImmediate(resolve)); };

function failure(table, name) {
  const value = table[name];
  if (!value) return null;
  if (typeof value === 'number') { table[name] = value - 1; return 'fail'; }
  if (typeof value === 'object' && value.times > 0) { value.times -= 1; return value; }
  return null;
}

/** Simulated platform player. Source time advances only while playing, scaled by playback rate. */
export class FakePlayer {
  constructor({ clock, log, lessons }) {
    Object.assign(this, { clock, log, lessons, current: null, currentTime: 0, rate: 1, paused: true, ended: false, buffering: false, ad: false, error: null, loginRequired: false, domBroken: false, ignoreRate: false, captionsAvailable: true, fail: {}, lastSync: clock.now() });
  }
  sync() {
    const now = this.clock.now();
    if (!this.paused && !this.buffering && !this.ad && !this.ended && this.current) {
      const duration = this.lessons[this.current]?.durationSec ?? Infinity;
      this.currentTime = Math.min(duration, this.currentTime + ((now - this.lastSync) / 1000) * this.rate);
      if (this.currentTime >= duration) { this.ended = true; this.paused = true; }
    }
    this.lastSync = now;
  }
  set(changes) { this.sync(); Object.assign(this, changes); }
  async navigate(lesson) { this.log.push(`player.navigate:${lesson.platformLessonId}`); if (failure(this.fail, 'navigate')) return { ok: false }; this.sync(); Object.assign(this, { current: lesson.platformLessonId, currentTime: 0, paused: true, ended: false }); return { ok: true }; }
  async verifyPage() { this.log.push('player.verifyPage'); if (failure(this.fail, 'verifyPage') || this.domBroken) return { ok: false }; return { ok: true, lessonId: this.current, loginRequired: this.loginRequired }; }
  async setRate(rate) { this.log.push(`player.setRate:${rate}`); if (failure(this.fail, 'setRate')) return { ok: false }; this.sync(); if (!this.ignoreRate) this.rate = rate; return { ok: true }; }
  async enableCaptions() { this.log.push('player.enableCaptions'); if (failure(this.fail, 'enableCaptions')) return { ok: false }; return { ok: true, available: this.captionsAvailable, trackLabel: this.captionsAvailable ? 'Fixture CC' : null }; }
  async play() { this.log.push('player.play'); if (failure(this.fail, 'play')) return { ok: false }; this.sync(); this.paused = false; return { ok: true }; }
  async pause() { this.log.push('player.pause'); this.sync(); this.paused = true; return { ok: true }; }
  getState() {
    this.sync();
    return { lessonId: this.current, currentTime: this.currentTime, duration: this.lessons[this.current]?.durationSec ?? null, rate: this.rate, paused: this.paused, ended: this.ended, buffering: this.buffering, ad: this.ad, error: this.error, loginRequired: this.loginRequired, cookie: 'fixture-cookie-must-not-persist' };
  }
}

/** Simulated capture. The same class serves audio and video; only `mode` differs. */
export class FakeCapture {
  constructor({ clock, log, mode, startLatencyMs = 300 }) { Object.assign(this, { clock, log, mode, startLatencyMs, active: false, fail: {}, listeners: new Map(), count: 0 }); }
  on(name, fn) { const set = this.listeners.get(name) || new Set(); set.add(fn); this.listeners.set(name, set); return () => set.delete(fn); }
  emit(name, value = {}) { for (const fn of [...(this.listeners.get(name) || [])]) fn(value); }
  async start({ lessonId }) {
    this.log.push(`capture.start:${this.mode}`);
    const f = failure(this.fail, 'start'); if (f) { const error = new Error(f.code || 'CAPTURE_FAILED'); error.code = f.code || 'CAPTURE_FAILED'; throw error; }
    this.active = true; this.count += 1; this.lessonId = lessonId;
    // OBS reports STARTED slightly before the runner resumes, so recording time leads playback (preroll).
    return { startedAtMs: this.clock.now() - this.startLatencyMs };
  }
  async stop() {
    this.log.push('capture.stop');
    const f = failure(this.fail, 'stop'); if (f) { const error = new Error(f.code || 'CAPTURE_FAILED'); error.code = f.code || 'CAPTURE_FAILED'; throw error; }
    const wasActive = this.active; this.active = false;
    const file = `C:\\Fixture\\Recordings\\take-${this.count}.${this.mode === 'audio' ? 'm4a' : 'mkv'}`;
    return wasActive ? { wasActive, outputPath: file, outputFiles: [file], pathSource: 'event', pathMismatch: false } : { wasActive: false, outputPath: null, pathSource: null };
  }
  async status() { return { active: this.active, paused: false }; }
}

export class FakeNetwork {
  constructor({ log }) { Object.assign(this, { log, online: true, listeners: new Set() }); }
  isOnline() { return this.online; }
  on(name, fn) { if (name === 'change') this.listeners.add(fn); return () => this.listeners.delete(fn); }
  set(online) { this.online = online; this.log.push(`network.${online ? 'online' : 'offline'}`); for (const fn of [...this.listeners]) fn(online); }
}

export class FakeDisk { constructor() { this.free = 100 * 1024 ** 3; } freeBytes() { return this.free; } }

export class FakeStore {
  constructor({ log, rights = [] }) { Object.assign(this, { log, jobs: new Map(), sessions: new Map(), checkpoints: [], rights: new Map(rights.map((r) => [r.id, r])), writes: [] }); }
  async loadJob(id) { return this.jobs.has(id) ? structuredClone(this.jobs.get(id)) : null; }
  async saveJob(job) { this.log.push(`store.saveJob:${job.status}`); this.jobs.set(job.id, structuredClone(job)); this.writes.push(JSON.stringify(job)); }
  async saveCheckpoint(jobId, checkpoint) { this.log.push('store.saveCheckpoint'); this.checkpoints.push({ jobId, checkpoint: structuredClone(checkpoint) }); this.writes.push(JSON.stringify(checkpoint)); }
  async saveSession(session) { this.log.push(`store.saveSession:${session.status}`); this.sessions.set(session.id, structuredClone(session)); this.writes.push(JSON.stringify(session)); }
  async readRights(id) { return this.rights.has(id) ? structuredClone(this.rights.get(id)) : null; }
  async listJobs() { return [...this.jobs.values()].map((job) => structuredClone(job)); }
  async listSessionsByJob(jobId) { return [...this.sessions.values()].filter((session) => session.agentJobId === jobId).map((session) => structuredClone(session)); }
  async isLessonCompleted(lessonId) { return [...this.sessions.values()].some((s) => s.lessonId === lessonId && s.status === 'completed'); }
}
