import assert from 'node:assert/strict';

export class FakeClock {
  constructor() { this.time = 0; this.nextId = 1; this.timers = new Map(); }
  now = () => this.time;
  setTimeout = (fn, delay) => { const id = this.nextId++; this.timers.set(id, { at: this.time + delay, fn }); return id; };
  clearTimeout = (id) => this.timers.delete(id);
  advance(ms) { const end = this.time + ms; while (true) { const due = [...this.timers.entries()].filter(([, value]) => value.at <= end).sort((a, b) => a[1].at - b[1].at || a[0] - b[0])[0]; if (!due) break; this.time = due[1].at; this.timers.delete(due[0]); due[1].fn(); } this.time = end; }
  get activeTimers() { return this.timers.size; }
}

export class FakeSocket {
  constructor() { this.protocol = 'obswebsocket.json'; this.listeners = new Map(); this.sent = []; this.closes = []; }
  addEventListener(name, fn) { const list = this.listeners.get(name) || []; list.push(fn); this.listeners.set(name, list); }
  send(text) { this.sent.push(JSON.parse(text)); }
  close(code, reason) { this.closes.push({ code, reason }); }
  dispatch(name, value) { for (const fn of this.listeners.get(name) || []) fn(value); }
  server(message) { this.dispatch('message', { data: JSON.stringify(message) }); }
  serverRaw(data) { this.dispatch('message', { data }); }
  serverBinary(base64) { this.dispatch('message', { data: Buffer.from(base64, 'base64') }); }
  serverClose(value) { this.dispatch('close', value); }
}

export const flush = async () => { await Promise.resolve(); await Promise.resolve(); await Promise.resolve(); };

export function track(promise) {
  const tracked = { state: 'pending', value: undefined };
  promise.then((value) => { tracked.state = 'resolved'; tracked.value = value; }, (error) => { tracked.state = 'rejected'; tracked.value = error; });
  return tracked;
}

const replaceRefs = (value, captures) => {
  if (Array.isArray(value)) return value.map((item) => replaceRefs(item, captures));
  if (value && typeof value === 'object') { if (Object.keys(value).length === 1 && '$ref' in value) return captures[value.$ref]; return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, replaceRefs(item, captures)])); }
  return value;
};

function match(actual, pattern, captures, label = 'value') {
  if (pattern === '$any') return;
  if (pattern === '$string') { assert.equal(typeof actual, 'string', `${label} must be string`); assert.ok(actual.length, `${label} must not be empty`); return; }
  if (pattern && typeof pattern === 'object' && !Array.isArray(pattern) && '$capture' in pattern) { assert.equal(typeof actual, 'string'); assert.ok(actual); captures[pattern.$capture] = actual; return; }
  if (Array.isArray(pattern)) { assert.equal(actual.length, pattern.length); pattern.forEach((item, index) => match(actual[index], item, captures, `${label}[${index}]`)); return; }
  if (pattern && typeof pattern === 'object') {
    assert.ok(actual && typeof actual === 'object', `${label} must be object`);
    for (const [key, expected] of Object.entries(pattern)) {
      if (expected === '$absent') { assert.equal(key in actual, false, `${label}.${key} must be absent`); continue; }
      if (expected === '$optional' && !(key in actual)) continue;
      assert.ok(key in actual, `${label}.${key} is missing`); if (expected !== '$optional') match(actual[key], expected, captures, `${label}.${key}`);
    }
    const allowed = new Set(Object.keys(pattern)); for (const key of Object.keys(actual)) assert.ok(allowed.has(key), `${label}.${key} is unexpected`); return;
  }
  assert.deepEqual(actual, pattern, label);
}

const partial = (actual, expected) => { for (const [key, value] of Object.entries(expected || {})) assert.deepEqual(actual?.[key], value, key); };

export async function runObsFixture(fixture, createClient) {
  const cases = fixture.cases || [{ name: fixture.id, steps: fixture.steps, finalState: fixture.expectFinal?.state }];
  for (const scenario of cases) {
    const clock = new FakeClock(); const socket = new FakeSocket(); const logs = []; const emitted = []; const captures = {}; const promises = {}; let sentCursor = 0; let emittedCursor = 0;
    const logger = Object.fromEntries(['warn', 'info', 'error'].map((level) => [level, (entry) => logs.push({ level, ...entry })]));
    const client = createClient({ url: fixture.options.url, socketFactory: () => socket, clock, getPassword: () => fixture.options.password?.fixtureOnly || null, logger, timeouts: fixture.options.timeouts });
    for (const name of ['recordState', 'recordFileChanged', 'obsExiting', 'disconnected', 'error']) client.on(name, (value) => emitted.push({ event: name, value }));
    for (const step of scenario.steps) {
      if (step.call) { promises[step.call.as] = track(client[step.call.method]()); await flush(); }
      else if (step.server) { socket.server(replaceRefs(step.server, captures)); await flush(); }
      else if (step.serverRaw != null) { socket.serverRaw(step.serverRaw); await flush(); }
      else if (step.serverBinary != null) { socket.serverBinary(step.serverBinary); await flush(); }
      else if (step.serverClose) { socket.serverClose(step.serverClose); await flush(); }
      else if (step.client) { assert.equal(socket.sent.length - sentCursor, 1, `${fixture.id}: expected one client message`); match(socket.sent[sentCursor++], step.client, captures); }
      else if (step.expectNoClientMessage) { assert.equal(socket.sent.length, sentCursor); }
      else if (step.expectClientClose) { assert.ok(socket.closes.some((item) => item.code === step.expectClientClose.code)); }
      else if (step.advance != null) { clock.advance(step.advance); await flush(); }
      else if (step.expectPending) assert.equal(promises[step.expectPending].state, 'pending');
      else if (step.expectResult) { const result = promises[step.expectResult.of]; if (step.expectResult.resolves) { assert.equal(result.state, 'resolved', `${fixture.id}:${step.expectResult.of}`); partial(result.value, step.expectResult.resolves); } else { assert.equal(result.state, 'rejected', `${fixture.id}:${step.expectResult.of}`); partial(result.value, step.expectResult.rejects); } }
      else if (step.expectEmitted) { const found = emitted.slice(emittedCursor).find((item) => item.event === step.expectEmitted.event); assert.ok(found, `${fixture.id}: missing ${step.expectEmitted.event}`); partial(found.value, step.expectEmitted.value); emittedCursor = emitted.indexOf(found) + 1; }
      else if (step.expectNotEmitted) { assert.equal(emitted.slice(emittedCursor).some((item) => item.event === step.expectNotEmitted.event), false); emittedCursor = emitted.length; }
      else if (step.expectLog) assert.ok(logs.some((item) => item.level === step.expectLog.level && item.event === step.expectLog.event), `${fixture.id}: missing log`);
      else if (step.burst) {
        const start = socket.sent.length; const tracked = [];
        for (let index = 0; index < step.burst.count; index += 1) tracked.push(track(client[step.burst.method]()));
        await flush(); const messages = socket.sent.slice(start); const ids = messages.map((message) => message.d.requestId); if (step.burst.expectUniqueRequestIds) assert.equal(new Set(ids).size, ids.length);
        for (const message of messages) socket.server({ op: 7, d: { requestType: message.d.requestType, requestId: message.d.requestId, requestStatus: { result: true, code: 100 }, responseData: { outputActive: false, outputPaused: false, outputTimecode: '00:00:00.000', outputDuration: 0, outputBytes: 0 } } });
        await flush(); assert.ok(tracked.every((item) => item.state === 'resolved')); sentCursor = socket.sent.length;
      }
    }
    assert.equal(client.pendingRequests, fixture.expectFinal.pendingRequests ?? 0, `${fixture.id}: pending`);
    assert.equal(clock.activeTimers, fixture.expectFinal.activeTimers ?? 0, `${fixture.id}: timers`);
    assert.equal(client.state, scenario.finalState || fixture.expectFinal.state, `${fixture.id}: state`);
    if ('recording' in fixture.expectFinal) assert.equal(client.recording, fixture.expectFinal.recording, `${fixture.id}: recording`);
    const serializedLogs = JSON.stringify(logs); for (const secret of fixture.expectFinal.logMustNotContain || []) assert.equal(serializedLogs.includes(secret), false, `${fixture.id}: leaked secret`);
  }
}
