import { createCompanionHub, handleCompanionRequest } from '../../src/services/companion.mjs';

export const EXT_ORIGIN = 'chrome-extension://abcdefghijklmnopabcdefghijklmnop';
export const OTHER_EXT_ORIGIN = 'chrome-extension://ponmlkjihgfedcbaponmlkjihgfedcba';
export const PORT = 4317;
export const settle = async (turns = 3) => { for (let i = 0; i < turns; i += 1) await new Promise((r) => setImmediate(r)); };

/** Deterministic but unique random bytes for ids, tokens and pairing codes. */
export function seededRandom(seed = 1) {
  let n = seed;
  return (size) => { const out = Buffer.alloc(size); for (let i = 0; i < size; i += 1) { n = (n * 1103515245 + 12345) % 2147483648; out[i] = n & 0xff; } return out; };
}

export function makeHub(clock, { seed = 1, options = {}, persistence = null } = {}) {
  const logs = [];
  const logger = Object.fromEntries(['info', 'warn', 'error'].map((level) => [level, (entry) => logs.push({ level, ...entry })]));
  const hub = createCompanionHub({ clock, random: seededRandom(seed), logger, options, persistence });
  return { hub, logs };
}

/** Calls the HTTP handler directly with a realistic request shape. */
export async function call(hub, { method = 'GET', path, origin = EXT_ORIGIN, token, body, host = `127.0.0.1:${PORT}`, signal } = {}) {
  const url = new URL(path, `http://127.0.0.1:${PORT}`);
  const headers = { host, ...(origin ? { origin } : {}), ...(token ? { 'x-companion-token': token } : {}), ...(body !== undefined ? { 'content-type': 'application/json' } : {}) };
  return handleCompanionRequest(hub, { method, pathname: url.pathname, query: url.searchParams, headers, body, signal }, { port: PORT });
}

export async function pairHub(hub) {
  const { body: { code } } = await call(hub, { method: 'POST', path: '/api/companion/pairing-code', origin: null });
  const response = await call(hub, { method: 'POST', path: '/api/companion/pair', body: { code } });
  return response.body.token;
}

/**
 * fetch() for the extension client that routes into the handler. The browser adds Origin itself.
 * kill() simulates the extension/service worker dying: in-flight requests abort, new ones fail.
 */
export function createFakeTransport(hub, { origin = EXT_ORIGIN } = {}) {
  let alive = true; const controllers = new Set(); const requests = [];
  async function fetch(url, init = {}) {
    if (!alive) throw new TypeError('Failed to fetch');
    const parsed = new URL(url); const controller = new AbortController(); controllers.add(controller);
    const headers = { host: parsed.host, origin, ...Object.fromEntries(Object.entries(init.headers || {}).map(([k, v]) => [k.toLowerCase(), v])) };
    requests.push({ method: init.method || 'GET', path: parsed.pathname, headers: { ...headers } });
    try {
      const result = await handleCompanionRequest(hub, { method: init.method || 'GET', pathname: parsed.pathname, query: parsed.searchParams, headers, body: init.body ? JSON.parse(init.body) : undefined, signal: controller.signal }, { port: PORT });
      if (!alive) throw new TypeError('Failed to fetch');
      return { status: result.status, json: async () => result.body };
    } finally { controllers.delete(controller); }
  }
  return { fetch, requests, kill() { alive = false; for (const c of controllers) c.abort(); }, revive() { alive = true; }, get alive() { return alive; } };
}

export function memoryStorage() { const map = new Map(); return { map, get: async (k) => map.get(k), set: async (k, v) => { map.set(k, v); }, remove: async (k) => { map.delete(k); } }; }
