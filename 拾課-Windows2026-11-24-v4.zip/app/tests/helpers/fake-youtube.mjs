// Emulates the parts of YouTube's own UI the adapter relies on: keyboard shortcuts and player buttons.
// Behaviour switches come from fixtures/platform/youtube/*.json ("youtube" block).

export function installFakeYouTube(page, behavior = {}) {
  const { document, window, log } = page;
  const b = { shortcutsWork: true, buttonsWork: true, captionsAvailable: true, playlist: [], ...behavior };
  const player = () => document.querySelector('#movie_player') || document.querySelector('#movie_player_v2');
  const video = () => player()?.querySelector('video');
  const currentId = () => new URL(window.location.href).searchParams.get('v');

  function goTo(id) {
    const url = new URL(window.location.href); url.searchParams.set('v', id); window.location.href = url.toString();
    for (const item of document.querySelectorAll('ytd-playlist-panel-video-renderer')) item.getAttribute('data-video-id') === id ? item.setAttribute('selected', '') : item._attrs.delete('selected');
    const v = video(); if (v) { v.currentTime = 0; }
  }
  function next() {
    const index = b.playlist.indexOf(currentId());
    if (!new URL(window.location.href).searchParams.get('list') || index < 0) { log.push('youtube:recommendation-would-play'); return; }
    if (index + 1 < b.playlist.length) goTo(b.playlist[index + 1]);
  }
  const togglePlay = () => { const v = video(); if (!v) return; v.paused ? v.play() : v.pause(); };
  const toggleCaptions = () => { if (!b.captionsAvailable) return; const button = document.querySelector('.ytp-subtitles-button'); button?.setAttribute('aria-pressed', button.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); };
  const step = (delta) => { const v = video(); if (v) v.setRateFromPlayer(Math.min(2, Math.max(0.25, Math.round((v.playbackRate + delta) * 4) / 4))); };

  document.addEventListener('keydown', (event) => {
    log.push(`key:${event.shiftKey ? 'Shift+' : ''}${event.key}`);
    if (!b.shortcutsWork) return;
    if (event.key === 'k') togglePlay();
    else if (event.key === 'c') toggleCaptions();
    else if (event.key === '>' && event.shiftKey) step(0.25);
    else if (event.key === '<' && event.shiftKey) step(-0.25);
    else if (event.key === 'N' && event.shiftKey) next();
  });
  document.addEventListener('click', (event) => {
    const target = event.target; if (!target?.classList) return;
    if (target.classList.contains('ytp-ad-skip-button')) { log.push('youtube:SKIP_AD_CLICKED'); return; }
    if (!b.buttonsWork) return;
    if (target.classList.contains('ytp-play-button')) togglePlay();
    else if (target.classList.contains('ytp-subtitles-button')) toggleCaptions();
    else if (target.classList.contains('ytp-next-button')) next();
  });
  return { goTo, next };
}
