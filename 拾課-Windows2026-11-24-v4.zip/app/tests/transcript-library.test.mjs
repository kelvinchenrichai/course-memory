import test from 'node:test';
import assert from 'node:assert/strict';
import { handleTranscriptLibraryRequest, renameCourse, setCourseTrashed, transcriptSummary } from '../src/library/transcripts.mjs';
import { createLibraryShell, handleLibraryShellRequest } from '../src/library/shell.mjs';
import { normalizeImportName, receiveMediaImport } from '../src/library/media-import.mjs';
import { Readable } from 'node:stream';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const sample = () => ({ id: 'course_1234', title: '舊名稱', status: 'ready', language: 'zh', createdAt: '2026-01-01T00:00:00.000Z', segments: [{ id: 's1', start: 0, end: 12, text: '測試逐字稿' }], chapters: [{}] });

test('summary never exposes media paths or transcript text', () => {
  const result = transcriptSummary({ ...sample(), video: 'C:\\private\\video.mkv', sourceMedia: 'C:\\private\\source.mkv' });
  assert.equal(result.characterCount, 5); assert.equal(result.duration, 12);
  assert.equal(result.mediaKind, 'video'); assert.equal(result.mediaExtension, 'mkv'); assert.equal(result.hasTranscript, true);
  assert.equal('video' in result, false); assert.equal('sourceMedia' in result, false); assert.equal('segments' in result, false);
});

test('rename validates and normalizes titles', () => {
  const course = sample(); renameCourse(course, '  新的   名稱  ', '2026-02-01T00:00:00.000Z');
  assert.equal(course.title, '新的 名稱'); assert.throws(() => renameCourse(course, '   '), /1～120/);
});

test('trash is recoverable and preserves prior archive state', () => {
  const course = sample(); setCourseTrashed(course, true, '2026-02-01T00:00:00.000Z');
  assert.equal(course.trashed, true); assert.equal(course.archived, true);
  setCourseTrashed(course, false, '2026-02-02T00:00:00.000Z');
  assert.equal(course.trashed, undefined); assert.equal(course.archived, undefined);
});

test('API requires confirmation and persists safe changes', async () => {
  const course = sample(); let saves = 0;
  const ctx = { port: 4317, courses: () => [course], saveCourse: async () => { saves += 1; } };
  const headers = { host: '127.0.0.1:4317', origin: 'http://127.0.0.1:4317', 'sec-fetch-site': 'same-origin', 'content-type': 'application/json' };
  const denied = await handleTranscriptLibraryRequest(ctx, { method: 'POST', pathname: '/api/transcripts/course_1234/trash', headers, body: {} });
  assert.equal(denied.status, 400); assert.equal(saves, 0);
  const done = await handleTranscriptLibraryRequest(ctx, { method: 'POST', pathname: '/api/transcripts/course_1234/trash', headers, body: { confirm: true } });
  assert.equal(done.status, 200); assert.equal(done.body.trashed, true); assert.equal(saves, 1);
});

test('transcript text endpoint is local-only and returns copy-ready text without media paths', async () => {
  const course = sample(); course.segments.push({ id: 's2', start: 12, end: 15, text: '第二段' });
  const ctx = { port: 4317, courses: () => [course] };
  const headers = { host: '127.0.0.1:4317', origin: 'http://127.0.0.1:4317', 'sec-fetch-site': 'same-origin' };
  const result = await handleTranscriptLibraryRequest(ctx, { method: 'GET', pathname: '/api/transcripts/course_1234/text', headers });
  assert.equal(result.status, 200); assert.equal(result.body.text, '測試逐字稿 第二段'); assert.equal(result.body.segmentCount, 2); assert.equal(JSON.stringify(result.body).includes('C:\\'), false);
  const denied = await handleTranscriptLibraryRequest(ctx, { method: 'GET', pathname: '/api/transcripts/course_1234/text', headers: { host: 'evil.example' } });
  assert.equal(denied.status, 403);
});

test('media import accepts an authorized local stream, rejects paths and unsupported files', async (t) => {
  const folder = await fsp.mkdtemp(path.join(os.tmpdir(), 'cm-import-')); t.after(() => fsp.rm(folder, { recursive: true, force: true }));
  assert.equal(normalizeImportName(encodeURIComponent('手機錄影.mp4')), '手機錄影.mp4');
  assert.throws(() => normalizeImportName('../secret.mp4'), /檔名不合法/); assert.throws(() => normalizeImportName('note.txt'), /只支援/);
  const request = Readable.from([Buffer.from('fake-media')]); request.headers = { 'x-rights-ack': 'true', 'x-file-name': encodeURIComponent('Reels.mov'), 'content-length': '10' };
  const result = await receiveMediaImport({ request, importsFolder: folder, maxBytes: 100 });
  assert.equal(result.name, 'Reels.mov'); assert.equal(await fsp.readFile(path.join(folder, result.name), 'utf8'), 'fake-media');
  const denied = Readable.from([Buffer.from('x')]); denied.headers = { 'x-file-name': 'x.mp4' };
  await assert.rejects(receiveMediaImport({ request: denied, importsFolder: folder }), (error) => error.code === 'RIGHTS_REQUIRED');
});

test('open-folder endpoint opens only the configured Windows recordings folder', () => {
  const calls = [];
  const shell = createLibraryShell({ recordingsFolder: 'C:\\CourseMemory\\recordings', platform: 'win32', spawnProcess(command, args, options) { calls.push({ command, args, options }); return { unref() { calls.push('unref'); } }; } });
  const headers = { host: '127.0.0.1:4317', origin: 'http://127.0.0.1:4317', 'sec-fetch-site': 'same-origin', 'content-type': 'application/json' };
  const result = handleLibraryShellRequest({ port: 4317, shell }, { method: 'POST', pathname: '/api/library/open-recordings', headers });
  assert.equal(result.status, 200); assert.deepEqual(calls[0].args, ['C:\\CourseMemory\\recordings']); assert.equal(calls[0].options.shell, false);
  const rejected = handleLibraryShellRequest({ port: 4317, shell }, { method: 'POST', pathname: '/api/library/open-recordings', headers: { host: 'evil.example' } });
  assert.equal(rejected.status, 403); assert.equal(calls.length, 2, 'rejected request did not launch another process');
});

test('content library wires a resilient viewer action and the folder shortcut', async () => {
  const { readFile } = await import('node:fs/promises');
  const [html, app, core] = await Promise.all([readFile(new URL('../web/index.html', import.meta.url), 'utf8'), readFile(new URL('../web/transcript-library-app.js', import.meta.url), 'utf8'), readFile(new URL('../web/app.js', import.meta.url), 'utf8')]);
  assert.match(html, /id="transcriptLibraryOpenFolder"/);
  assert.match(html, /id="transcriptLibraryImport"/); assert.match(app, /data-copy/); assert.match(app, /\/api\/imports\/file/);
  assert.match(app, /await controller\.refresh/); assert.match(app, /controller\.openCourse/); assert.match(app, /\/api\/library\/open-recordings/);
  assert.match(core, /if \(focusNav\) focusNav\.onclick/, 'an optional sidebar shortcut must not abort the viewer bootstrap');
});
