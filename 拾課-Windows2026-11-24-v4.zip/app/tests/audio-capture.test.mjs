import test from 'node:test';
import assert from 'node:assert/strict';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createAudioCapture } from '../src/agent/capture-audio.mjs';
import { createAgentRunner, STOP_CODES } from '../src/agent/runner.mjs';
import { dshowInputArg, listAudioDevices, parseDshowDevices, resolveAudioDevice, saveAudioDeviceSelection } from '../src/services/audio-devices.mjs';
import { createFakeCaptureProcess, manualTimers } from './helpers/fake-process.mjs';
import { EPOCH_MS, FakeClock, FakeDisk, FakeNetwork, FakePlayer, FakeStore, settle } from './helpers/agent-fakes.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const listing = (name) => fsp.readFile(path.join(root, 'fixtures', 'pipeline', 'dshow', `${name}.txt`), 'utf8');
const tmp = async () => { const base = path.join(process.cwd(), 'tmp-tests'); await fsp.mkdir(base, { recursive: true }); return fsp.mkdtemp(path.join(base, 'cms-p4a-audio-')); };
const MIC = 'Microphone Array (Fixture Audio)';

test('dshow listings (current and legacy ffmpeg) parse to audio devices only, with a loopback name hint', async () => {
  const modern = parseDshowDevices(await listing('modern'));
  assert.deepEqual(modern.map((d) => d.name), [MIC, 'Stereo Mix (Fixture Audio)', 'Line In: Rear "Panel"']);
  assert.equal(modern[1].hint, 'possible-system-audio'); assert.equal(modern[0].hint, undefined);
  assert.match(modern[0].alternativeName, /^@device_cm_/);
  const legacy = parseDshowDevices(await listing('legacy'));
  assert.deepEqual(legacy.map((d) => [d.name, d.hint ?? null]), [['麥克風 (Fixture 音訊)', null], ['CABLE Output (Fixture Virtual Cable)', 'possible-system-audio']]);
  assert.deepEqual(parseDshowDevices(await listing('none')), []);
});

test('device listing: Windows only, ffmpeg missing is explicit, the list never invents a device', async () => {
  await assert.rejects(listAudioDevices({ run: async () => ({}), platform: 'linux' }), (e) => e.code === 'AUDIO_DEVICE_LISTING_UNSUPPORTED');
  await assert.rejects(listAudioDevices({ run: async () => { throw Object.assign(new Error(), { code: 'COMMAND_NOT_FOUND' }); }, platform: 'win32' }), (e) => e.code === 'FFMPEG_UNAVAILABLE');
  const fake = createFakeCaptureProcess({ deviceListing: await listing('none') });
  assert.deepEqual((await listAudioDevices({ run: fake.runner.run, platform: 'win32' })).devices, []);
  assert.deepEqual(fake.calls[0].args, ['-hide_banner', '-list_devices', 'true', '-f', 'dshow', '-i', 'dummy']);
});

test('only a listed device resolves; colon names use the alternative name; selection is saved to config.json', async () => {
  const devices = parseDshowDevices(await listing('modern'));
  assert.throws(() => resolveAudioDevice({}, devices), (e) => e.code === 'AUDIO_DEVICE_UNAVAILABLE');
  assert.throws(() => resolveAudioDevice({ deviceName: 'Some Other Mic' }, devices), (e) => e.code === 'AUDIO_DEVICE_UNAVAILABLE');
  assert.equal(resolveAudioDevice({ deviceName: MIC }, devices).name, MIC);
  assert.equal(dshowInputArg(devices[0]), `audio=${MIC}`);
  assert.match(dshowInputArg(devices[2]), /^audio=@device_cm_/);
  assert.throws(() => dshowInputArg({ name: 'A: B', alternativeName: null }), (e) => e.code === 'AUDIO_DEVICE_NAME_UNSUPPORTED');
  const dir = await tmp(); const configFile = path.join(dir, 'config.json');
  await fsp.writeFile(configFile, JSON.stringify({ port: 4317, obsPassword: '' }));
  const saved = await saveAudioDeviceSelection({ configFile, name: MIC, devices });
  const config = JSON.parse(await fsp.readFile(configFile, 'utf8'));
  assert.equal(config.port, 4317); assert.equal(config.audioCapture.deviceName, MIC); assert.equal(config.audioCapture.backend, 'ffmpeg');
  assert.equal(JSON.stringify(saved).includes(MIC), true); assert.match(saved.deviceRef, /^[0-9a-f]{10}$/);
  await assert.rejects(saveAudioDeviceSelection({ configFile, name: 'Not Listed', devices }), (e) => e.code === 'AUDIO_DEVICE_UNAVAILABLE');
  await assert.rejects(saveAudioDeviceSelection({ configFile: path.join(dir, 'other.json'), name: MIC, devices }), (e) => e.code === 'CONFIG_PATH_INVALID');
});

async function captureEnv({ behaviour = 'ok', deviceName = MIC, listingName = 'modern', listCode = null, free = 100 * 1024 ** 3, segmentSeconds = 900 } = {}) {
  const dir = await tmp(); const outputDir = path.join(dir, 'audio 100%');
  const fake = createFakeCaptureProcess({ deviceListing: await listing(listingName), behaviour, listCode });
  const timers = manualTimers(); const logs = [];
  const capture = createAudioCapture({ processRunner: fake.runner, audioConfig: { deviceName, segmentSeconds }, outputDir, disk: { freeBytes: async () => free }, platform: 'win32', timers, clock: { now: () => EPOCH_MS }, logger: { info: (v) => logs.push(v), warn: (v) => logs.push(v) } });
  return { dir, outputDir, fake, capture, timers, logs };
}

test('audio capture start/stop/status: segmented ffmpeg run of the chosen device, partial-safe stop', async () => {
  const env = await captureEnv();
  assert.equal(env.capture.kind, 'ffmpeg-audio'); assert.equal(env.capture.mode, 'audio');
  const started = await env.capture.start({ sessionId: 'rec_aaaaaaaaaaaa' });
  assert.equal(started.startedAtMs, EPOCH_MS);
  const args = env.fake.calls.find((c) => c.kind === 'start').args;
  assert.deepEqual(args.slice(0, 9), ['-hide_banner', '-nostats', '-loglevel', 'info', '-f', 'dshow', '-i', `audio=${MIC}`, '-vn']);
  assert.deepEqual(args.slice(args.indexOf('-f', 6), args.indexOf('-f', 6) + 8), ['-f', 'segment', '-segment_time', '900', '-reset_timestamps', '1', '-segment_format', 'flac']);
  assert.ok(args.at(-1).startsWith('file:') && args.at(-1).includes('audio 100%%') && args.at(-1).endsWith('%03d.flac'), args.at(-1));
  assert.equal((await env.capture.status()).active, true);
  await assert.rejects(env.capture.start({}), (e) => e.code === 'AUDIO_CAPTURE_BUSY');
  const stopped = await env.capture.stop();
  assert.deepEqual(env.fake.handles[0].writes, ['q']); assert.equal(env.fake.handles[0].killed, false);
  assert.equal(stopped.wasActive, true); assert.equal(stopped.outputFiles.length, 2);
  assert.ok(stopped.outputFiles.every((f) => /audio-rec_aaaaaaaaaaaa-\d{8}T\d{6}-00[01]\.flac$/.test(f))); assert.equal(stopped.outputPath, stopped.outputFiles.at(-1));
  assert.equal((await env.capture.status()).active, false);
  assert.equal(JSON.stringify(env.logs).includes('Microphone'), false, 'device name never logged');
  assert.ok(env.logs.some((l) => l.event === 'audio_capture_started' && /^[0-9a-f]{10}$/.test(l.deviceRef)));
});

test('audio capture refuses to start without ffmpeg, without the device, on low disk, or unconfirmed', async (t) => {
  const cases = [
    [{ listCode: 'COMMAND_NOT_FOUND' }, 'FFMPEG_UNAVAILABLE'],
    [{ behaviour: 'not-found' }, 'FFMPEG_UNAVAILABLE'],
    [{ deviceName: '' }, 'AUDIO_DEVICE_UNAVAILABLE'],
    [{ deviceName: 'Unplugged USB Mic' }, 'AUDIO_DEVICE_UNAVAILABLE'],
    [{ listingName: 'none' }, 'AUDIO_DEVICE_UNAVAILABLE'],
    [{ behaviour: 'device-gone' }, 'AUDIO_DEVICE_UNAVAILABLE'],
    [{ free: 10 * 1024 ** 2 }, 'DISK_LOW']
  ];
  for (const [options, code] of cases) {
    await t.test(`${JSON.stringify(options)} → ${code}`, async () => {
      const env = await captureEnv(options);
      await assert.rejects(env.capture.start({}), (e) => e.code === code, `${JSON.stringify(options)} → ${code}`);
      assert.equal((await env.capture.status()).active, false);
    });
  }
  await t.test('no chosen device reports unavailable', async () => {
    assert.equal((await captureEnv({ deviceName: '' })).capture.kind, 'unavailable');
  });
  await t.test('unconfirmed ffmpeg is killed', async () => {
    const silent = await captureEnv({ behaviour: 'silent' });
    const pending = silent.capture.start({});
    // start() performs real async folder/device checks before arming the injected timer. Under a busy full-suite
    // run, a fixed number of microtasks can finish too early; wait for the observable contract instead.
    const deadline = Date.now() + 1000;
    while (silent.timers.pending.size === 0 && Date.now() < deadline) await new Promise((resolve) => setTimeout(resolve, 5));
    assert.ok(silent.timers.pending.size > 0, 'start confirmation timer was armed'); silent.timers.fireAll();
    await assert.rejects(pending, (e) => e.code === 'AUDIO_CAPTURE_FAILED'); assert.equal(silent.fake.handles[0].killed, true);
  });
});

test('ffmpeg exiting mid-recording is reported; a stop that hangs is killed and keeps the partial files', async () => {
  const env = await captureEnv(); const events = [];
  env.capture.on('stoppedExternally', (v) => events.push(v));
  await env.capture.start({ sessionId: 'rec_bbbbbbbbbbbb' }); env.fake.handles[0].crash(); await settle();
  assert.deepEqual(events, [{ reason: 'ffmpeg_exited' }]); assert.equal((await env.capture.status()).active, false);
  const hang = await captureEnv({ behaviour: 'ignore-q' });
  await hang.capture.start({ sessionId: 'rec_cccccccccccc' });
  const stopping = hang.capture.stop(); await settle(); hang.timers.fireAll(); await settle(5);
  const result = await stopping;
  assert.equal(hang.fake.handles[0].killed, true); assert.equal(result.wasActive, true); assert.equal(result.outputFiles.length, 2);
});

// --- integration with the P3A Runner ------------------------------------------------------------

const RIGHTS = { id: 'rts_aaaaaaaaaaaa', schemaVersion: 1, basis: 'personal-study', recordPermissionAcknowledged: true, privateTransformAllowed: true, allowDerivative: false, evidence: [], history: [] };
const DRAFT = { items: [{ courseId: 'crs_aaaaaaaaaaaa', rightsId: RIGHTS.id, lessons: [{ platformLessonId: 'A1', title: 'Fixture lesson A1', durationSec: 4 }] }], captureMode: 'audio', rate: 1.5, captions: { enabled: false, languages: ['en'] }, markComplete: false, cloudBackup: { enabled: false } };

async function runnerWith(capture, { offlineAtMs = null } = {}) {
  const log = []; const clock = new FakeClock();
  const player = new FakePlayer({ clock, log, lessons: { A1: { durationSec: 4 } } }); const store = new FakeStore({ log, rights: [RIGHTS] });
  const network = new FakeNetwork({ log });
  const runner = createAgentRunner({ player, capture, store, clock, network, disk: new FakeDisk(), options: { epochMs: EPOCH_MS } });
  const job = await runner.createDraft(DRAFT); const { planHash } = await runner.requestConfirmation(job.id);
  await runner.confirm(job.id, { planHash, acknowledgements: { recordPermission: true, privateProcessing: true } });
  let done = false; const running = runner.start(job.id); running.catch(() => {}).finally(() => { done = true; });
  for (let t = 0; t < 20_000 && !done; t += 500) { if (offlineAtMs != null && t === offlineAtMs) network.set(false); clock.advance(500); await settle(6); await new Promise((r) => setTimeout(r, 3)); }
  return { job: await store.loadJob(job.id), sessions: [...store.sessions.values()] };
}

test('Runner: a missing audio device blocks the job with AUDIO_DEVICE_UNAVAILABLE (not an OBS code)', async () => {
  const env = await captureEnv({ deviceName: 'Unplugged USB Mic' });
  const { job, sessions } = await runnerWith(env.capture);
  assert.equal(job.status, 'blocked'); assert.equal(job.blocker.code, STOP_CODES.AUDIO_DEVICE_UNAVAILABLE);
  assert.notEqual(job.blocker.obsMayStillBeRecording, true);
  assert.equal(sessions.length, 1); assert.equal(sessions[0].captureMode, 'audio');
});

test('Runner: network loss stops audio capture normally and saves a partial session with the segments', async () => {
  const env = await captureEnv();
  const { job, sessions } = await runnerWith(env.capture, { offlineAtMs: 1500 });
  assert.equal(job.status, 'blocked'); assert.equal(job.blocker.code, STOP_CODES.NETWORK_OFFLINE);
  assert.deepEqual(env.fake.handles[0].writes, ['q'], 'ffmpeg asked to finish, not killed');
  assert.equal(sessions[0].status, 'partial'); assert.equal(sessions[0].obsOutputFiles.length, 2); assert.ok(sessions[0].timeMap.spans.length >= 1);
});

test('Runner: a full audio lesson completes and records the segment files', async () => {
  const env = await captureEnv();
  const { job, sessions } = await runnerWith(env.capture);
  assert.equal(job.status, 'completed'); assert.equal(sessions[0].status, 'completed'); assert.equal(sessions[0].captureMode, 'audio');
  assert.equal(sessions[0].obsOutputFiles.length, 2); assert.ok(sessions[0].obsOutputFiles.every((f) => f.endsWith('.flac')));
});
