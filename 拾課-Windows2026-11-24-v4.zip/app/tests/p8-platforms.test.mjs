import test from 'node:test';
import assert from 'node:assert/strict';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createAgentService } from '../src/agent/service.mjs';
import { createJsonAgentStore } from '../src/agent/json-store.mjs';
import { createConsole, handleConsoleRequest } from '../src/agent/console-api.mjs';
import { companionView } from '../src/agent/console.mjs';
import { createCompanionPlayer } from '../src/agent/player-companion.mjs';
import { sanitizeCommandResult } from '../src/services/companion.mjs';
import { createBilibiliAdapter } from '../extension/adapters/bilibili.mjs';
import { createYouTubeAdapter } from '../extension/adapters/youtube.mjs';
import { createGenericHtml5Adapter } from '../extension/adapters/generic-html5.mjs';
import { detectPageBlocker } from '../extension/adapters/page-blockers.mjs';
import { sanitizeResult } from '../extension/adapters/common.mjs';
import { dispatchCommand } from '../extension/dispatch.mjs';
import { renderCompanionWizard, renderTestResult, wizardSteps } from '../web/companion-wizard-view.js';
import { renderJobCard } from '../web/agent-console-view.js';
import { buildPage } from './helpers/fake-dom.mjs';
import { installFakeYouTube } from './helpers/fake-youtube.mjs';
import { installFakeBilibili } from './helpers/fake-bilibili.mjs';
import { createIoTracker, pollUntil } from './helpers/quiesce.mjs';
import { EPOCH_MS, FakeCapture, FakeClock, FakeDisk, FakeNetwork } from './helpers/agent-fakes.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const readJson = async (...parts) => JSON.parse(await fsp.readFile(path.join(root, ...parts), 'utf8'));
const fixture = (platform, name) => readJson('fixtures', 'platform', platform, `${name}.json`);
const BILI_SELECTORS = () => readJson('extension', 'adapters', 'bilibili-selectors.json');
const YT_SELECTORS = () => readJson('extension', 'adapters', 'youtube-selectors.json');
const ACKS = { recordPermission: true, privateProcessing: true };
const forbidden = (log) => log.filter((entry) => /write:playbackRate|youtube:SKIP_AD|youtube:recommendation/.test(entry));

/** Drives an adapter promise forward on the fake clock (adapters verify with waitFor). */
async function drive(clock, promise) { let done = false; promise.finally(() => { done = true; }); for (let i = 0; i < 400 && !done; i += 1) { await new Promise((r) => setImmediate(r)); if (!done) clock.advance(100); } return promise; }
const setDuration = (nodes, seconds) => { for (const node of nodes || []) { if (node.video) node.video.duration = seconds; setDuration(node.children, seconds); } };

async function pageFor(platform, name, clock, behavior = {}) {
  const spec = await fixture(platform, name);
  const page = buildPage(spec, { clock });
  if (platform === 'bilibili') { installFakeBilibili(page, behavior); return { page, adapter: createBilibiliAdapter({ document: page.document, window: page.window, selectors: await BILI_SELECTORS(), clock }) }; }
  if (platform === 'youtube') { installFakeYouTube(page, behavior); return { page, adapter: createYouTubeAdapter({ document: page.document, window: page.window, selectors: await YT_SELECTORS(), clock }) }; }
  return { page, adapter: createGenericHtml5Adapter({ document: page.document, window: page.window, clock }) };
}

// ---------------------------------------------------------------------------------------------------
test('Bilibili: native speed menu, subtitles and play button; never writes the video or reads media URLs', async () => {
  const clock = new FakeClock();
  const { page, adapter } = await pageFor('bilibili', 'multipart', clock);
  const detect = adapter.detect();
  assert.deepEqual([detect.ok, detect.adapterId, detect.platform, detect.isPlaylist], [true, 'bilibili', 'bilibili', true]);
  assert.deepEqual(await drive(clock, adapter.setRate(1.5)), { ok: true, rate: 1.5 });
  assert.equal((await drive(clock, adapter.setRate(1.75))).reason, 'RATE_UNAVAILABLE', 'Bilibili has no 1.75× item');
  const captions = await drive(clock, adapter.enableCaptions({ languages: ['zh'] }));
  assert.equal(captions.ok, true); assert.match(captions.trackLabel, /中文/);
  assert.equal((await drive(clock, adapter.play())).ok, true); assert.equal(adapter.getState().paused, false);
  assert.equal((await drive(clock, adapter.pause())).ok, true); assert.equal(adapter.getState().paused, true);
  assert.ok(!page.log.includes('video.play()') && !page.log.includes('video.pause()'), 'only the native play button');
  assert.deepEqual(forbidden(page.log), []);
  const state = adapter.getState();
  assert.equal(state.captions.on, true); assert.equal(state.rate, 1.5); assert.equal(state.platform, 'bilibili');
  assert.ok(!JSON.stringify(state).includes('fixture-media-token') && !JSON.stringify(state).includes('upos'));
  const none = await pageFor('bilibili', 'no-subtitles', clock);
  assert.deepEqual(await drive(clock, none.adapter.enableCaptions({ languages: ['zh'] })), { ok: true, available: false });
});

test('Bilibili: lesson identity is BV + 分P; native「下一個」changes the lesson and is reported, not trusted', async () => {
  const clock = new FakeClock();
  const { page, adapter } = await pageFor('bilibili', 'multipart', clock);
  const verified = await drive(clock, adapter.verifyPage({ url: 'https://www.bilibili.com/video/BV1Fx4y1z7Ab/?p=1', platformLessonId: 'web-p1' }));
  assert.equal(verified.lessonId, 'web-p1', 'tracking parameters (spm_id_from, vd_source) do not matter');
  assert.equal((await drive(clock, adapter.verifyPage({ url: 'https://www.bilibili.com/video/BV1Fx4y1z7Ab/?p=2', platformLessonId: 'web-p2' }))).lessonId, 'URL_CHANGED');
  await drive(clock, adapter.verifyPage({ url: 'https://www.bilibili.com/video/BV1Fx4y1z7Ab/?p=1', platformLessonId: 'web-p1' }));
  const next = await drive(clock, adapter.nextLesson());
  assert.equal(next.ok, true); assert.match(page.window.location.href, /p=2/);
  assert.equal(adapter.getState().lessonId, 'URL_CHANGED', 'the Runner must verify the new page against its plan');
});

test('blockers: Bilibili / Skool / 知識衛星 / HTML5 — login, CAPTCHA, payment, DOM change, player not found, autoplay', async () => {
  const clock = new FakeClock();
  const expectations = [
    ['bilibili', 'captcha', 'CAPTCHA'], ['bilibili', 'login-required', 'LOGIN_REQUIRED'], ['bilibili', 'payment-prompt', 'PAYMENT_PROMPT'],
    ['skool', 'login-wall', 'LOGIN_REQUIRED'], ['sat-knowledge', 'payment', 'PAYMENT_PROMPT'], ['generic-html5', 'captcha', 'CAPTCHA']
  ];
  for (const [platform, name, code] of expectations) {
    const { page, adapter } = await pageFor(platform, name, clock);
    const result = await drive(clock, adapter.verifyPage({ url: page.window.location.href }));
    assert.equal(result.blocker, code, `${platform}/${name}`);
    assert.equal(adapter.getState().blocker, code, `${platform}/${name} state`);
    assert.deepEqual(page.log.filter((l) => /click:|video\.play|navigate:/.test(l)), [], `${platform}/${name}: nothing clicked or played`);
  }
  const changed = await pageFor('bilibili', 'selectors-changed', clock);
  assert.equal(changed.adapter.detect().reason, 'DOM_CHANGED'); assert.equal((await drive(clock, changed.adapter.play())).stop, 'DOM_CHANGED');
  const iframe = await pageFor('skool', 'iframe-player', clock);
  assert.equal(iframe.adapter.detect().reason, 'PLAYER_NOT_FOUND', 'embedded players are left to the user');
  const blocked = await pageFor('generic-html5', 'autoplay-blocked', clock);
  assert.deepEqual(await blocked.adapter.play(), { ok: false, reason: 'PLAY_REJECTED', stop: 'PLAYBACK_BLOCKED' });
  // An upsell banner next to a playable video is not a paywall.
  const skool = await pageFor('skool', 'lesson', clock);
  assert.equal(detectPageBlocker(skool.page.document, { hasPlayer: true }), null); assert.equal(skool.adapter.getState().platform, 'skool');
  const sat = await pageFor('sat-knowledge', 'chapter', clock);
  assert.equal(sat.adapter.getState().platform, 'satKnowledge'); assert.equal(sat.adapter.getState().captions.available, true);
});

// ---------------------------------------------------------------------------------------------------
/**
 * Runner + real adapters through the Companion command path (content-script allowlist → hub allowlist).
 * `navigate` loads the fixture for the requested URL (or a redirect, to simulate a wrong next video).
 */
async function harness({ pages, redirects = {}, rate = 1.5, captions = true, mode = 'audio' } = {}) {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'cms-p8-'));
  const clock = new FakeClock(); const io = createIoTracker(); const store = io.track(createJsonAgentStore(path.join(dir, 'agent')));
  const log = []; const captures = {}; const network = new FakeNetwork({ log });
  const browser = { page: null, adapter: null, disconnected: false, commands: [], pageLogs: [] };
  async function open(url) {
    const target = redirects[url] || url;
    const entry = pages.find((item) => target.startsWith(item.prefix)); if (!entry) throw new Error(`no fixture for ${target}`);
    const spec = await fixture(entry.platform, entry.name); spec.url = target; setDuration(spec.tree, 4);
    const page = buildPage(spec, { clock }); browser.pageLogs.push(page.log);
    if (entry.platform === 'bilibili') { installFakeBilibili(page, entry.behavior); browser.adapter = createBilibiliAdapter({ document: page.document, window: page.window, selectors: await BILI_SELECTORS(), clock }); }
    else if (entry.platform === 'youtube') { installFakeYouTube(page, entry.behavior); browser.adapter = createYouTubeAdapter({ document: page.document, window: page.window, selectors: await YT_SELECTORS(), clock }); }
    else browser.adapter = createGenericHtml5Adapter({ document: page.document, window: page.window, clock });
    browser.page = page;
  }
  const listeners = new Set();
  const hub = {
    browserOnline: true,
    on: (name, fn) => { if (name !== 'disconnected') return () => {}; listeners.add(fn); return () => listeners.delete(fn); },
    async sendCommand({ type, args }) {
      browser.commands.push(type);
      if (browser.disconnected) throw Object.assign(new Error('lost'), { code: 'COMPANION_DISCONNECTED' });
      if (type === 'navigate') { await open(args.url); return { ok: true }; } // the extension background does this via chrome.tabs.update
      const raw = await dispatchCommand(browser.adapter, type, args, {});
      return sanitizeCommandResult(JSON.parse(JSON.stringify(sanitizeResult(raw))));
    }
  };
  const player = createCompanionPlayer({ hub });
  const hubStatus = { paired: true, connected: true, browserOnline: true, extensionVersion: '0.5.0', tabs: [{ tabId: 1, origin: 'https://www.bilibili.com', bound: true, permissionGranted: true }], latestState: null };
  const make = () => createAgentService({ hub: { status: () => hubStatus, on: () => () => {} }, store, captureFactory: (m) => (captures[m] ||= new FakeCapture({ clock, log, mode: m })), disk: new FakeDisk(), clock, runnerOptions: { epochMs: EPOCH_MS }, player, network });
  const service = make();
  const ctx = { port: 4317, dataDir: dir, service, store, freeBytes: async () => 50 * 1024 ** 3, now: () => EPOCH_MS + clock.now() };
  ctx.console = createConsole(ctx);
  const env = { dir, clock, io, store, log, captures, network, browser, hubStatus, make, service, ctx, disconnect: () => { browser.disconnected = true; for (const fn of listeners) fn(); } };
  env.plan = async (urls) => {
    const plan = await ctx.console.plan({ captureMode: mode, rate, captions: { enabled: captions, languages: ['zh'] }, courses: [{ title: '自建課程', rightsBasis: 'personal-study', lessons: urls.map((url, i) => ({ url, title: `第 ${i + 1} 部`, minutes: 1 })) }] });
    await ctx.console.confirm(plan.job.id, { planHash: plan.planHash, acknowledgements: ACKS });
    return plan.job.id;
  };
  env.job = async (id) => env.ctx.service.getJob(id);
  env.until = (cond, maxMs = 120_000) => pollUntil(cond, { clock, quiesce: io.quiesce, maxSteps: Math.ceil(maxMs / 500) });
  env.status = async (id) => (await env.job(id)).status;
  env.allLogs = () => browser.pageLogs.flat();
  return env;
}
const BILI = [{ prefix: 'https://www.bilibili.com/', platform: 'bilibili', name: 'multipart' }];
const BILI_URLS = ['https://www.bilibili.com/video/BV1Fx4y1z7Ab/?p=1', 'https://www.bilibili.com/video/BV1Fx4y1z7Ab/?p=2'];

test('Runner × Bilibili: two 分P lessons, native speed + subtitles, each page verified, completes', async () => {
  const env = await harness({ pages: BILI });
  const id = await env.plan(BILI_URLS);
  await env.ctx.console.act(id, 'start');
  assert.ok(await env.until(async () => (await env.status(id)) === 'completed'), JSON.stringify((await env.job(id)).blocker));
  assert.equal(env.browser.commands.filter((c) => c === 'navigate').length, 2);
  assert.equal(env.browser.commands.filter((c) => c === 'verifyPage').length, 2, 'every lesson page is verified');
  assert.ok(!env.allLogs().includes('video.play()'), 'Bilibili playback only via its own button');
  assert.deepEqual(forbidden(env.allLogs()), []);
  assert.ok(!env.browser.commands.includes('nextLesson'), 'the Runner opens planned URLs itself; it never trusts an autoplayed next video');
});

test('Runner × Bilibili: a wrong next video stops with UNEXPECTED_LESSON (no recording continues)', async () => {
  const env = await harness({ pages: BILI, redirects: { [BILI_URLS[1]]: 'https://www.bilibili.com/video/BV9Zz9z9z9Zz/' } });
  const id = await env.plan(BILI_URLS);
  await env.ctx.console.act(id, 'start');
  assert.ok(await env.until(async () => (await env.status(id)) === 'blocked'));
  const job = await env.job(id);
  assert.equal(job.blocker.code, 'UNEXPECTED_LESSON'); assert.deepEqual(job.checkpoint.completedLessonIds.length, 1);
  const view = await env.ctx.console.get(id);
  assert.equal(view.blocker.title, '頁面跳到計畫外的影片'); assert.match(view.blocker.next, /繼續/);
});

test('Runner × YouTube: rate and CC via shortcuts, two playlist lessons; a wrong next video → UNEXPECTED_LESSON', async () => {
  const urls = ['https://www.youtube.com/watch?v=fixVidA0001&list=PLfixture', 'https://www.youtube.com/watch?v=fixVidA0002&list=PLfixture'];
  const pages = [{ prefix: 'https://www.youtube.com/', platform: 'youtube', name: 'playlist-watch', behavior: { playlist: ['fixVidA0001', 'fixVidA0002'] } }];
  const ok = await harness({ pages });
  const id = await ok.plan(urls); await ok.ctx.console.act(id, 'start');
  assert.ok(await ok.until(async () => (await ok.status(id)) === 'completed'), JSON.stringify((await ok.job(id)).blocker));
  assert.ok(ok.allLogs().some((l) => l === 'key:Shift+>'), 'speed set with YouTube shortcuts'); assert.deepEqual(forbidden(ok.allLogs()), []);
  const wrong = await harness({ pages, redirects: { [urls[1]]: 'https://www.youtube.com/watch?v=fixVidZ9999&list=PLfixture' } });
  const id2 = await wrong.plan(urls); await wrong.ctx.console.act(id2, 'start');
  assert.ok(await wrong.until(async () => (await wrong.status(id2)) === 'blocked'));
  assert.equal((await wrong.job(id2)).blocker.code, 'UNEXPECTED_LESSON');
});

test('Runner × Skool / 知識衛星 / HTML5: autoplay when a player is found; login, payment, CAPTCHA and autoplay blocks stop safely', async () => {
  const skool = await harness({ pages: [{ prefix: 'https://www.skool.com/', platform: 'skool', name: 'lesson' }] });
  const id = await skool.plan(['https://www.skool.com/fixture-group/classroom/c0ffee12?md=lesson01']); await skool.ctx.console.act(id, 'start');
  assert.ok(await skool.until(async () => (await skool.status(id)) === 'completed'), JSON.stringify((await skool.job(id)).blocker));
  const sat = await harness({ pages: [{ prefix: 'https://sat.cool/', platform: 'sat-knowledge', name: 'chapter' }] });
  const id2 = await sat.plan(['https://sat.cool/courses/fixture-course/chapters/1']); await sat.ctx.console.act(id2, 'start');
  assert.ok(await sat.until(async () => (await sat.status(id2)) === 'completed'));
  for (const [platform, name, url, code] of [
    ['skool', 'login-wall', 'https://www.skool.com/fixture-group/classroom/c0ffee12?md=lesson01', 'LOGIN_REQUIRED'],
    ['skool', 'iframe-player', 'https://www.skool.com/fixture-group/classroom/c0ffee12?md=lesson03', 'PLAYER_NOT_FOUND'],
    ['sat-knowledge', 'payment', 'https://sat.cool/courses/fixture-course/chapters/9', 'PAYMENT_PROMPT'],
    ['generic-html5', 'captcha', 'https://learn.fixture.example/lesson/1', 'CAPTCHA'],
    ['generic-html5', 'autoplay-blocked', 'https://learn.fixture.example/lesson/2', 'PLAYBACK_BLOCKED'],
    ['bilibili', 'selectors-changed', 'https://www.bilibili.com/video/BV1Fx4y1z7Ab/?p=1', 'DOM_CHANGED']
  ]) {
    const env = await harness({ pages: [{ prefix: new URL(url).origin, platform, name }] });
    const jobId = await env.plan([url]); await env.ctx.console.act(jobId, 'start');
    assert.ok(await env.until(async () => (await env.status(jobId)) === 'blocked'), `${name} should block`);
    const job = await env.job(jobId);
    assert.equal(job.blocker.code, code, name);
    const view = await env.ctx.console.get(jobId);
    assert.match(view.blocker.title, /[一-鿿]/, `${name}: 繁中 reason`); assert.match(view.blocker.next, /[一-鿿]/);
    assert.equal(env.log.filter((l) => l.startsWith('capture.start')).length, code === 'PLAYBACK_BLOCKED' ? 1 : 0, `${name}: recording only starts once the page is verified`);
  }
});

test('hang-up safety: extension disconnect and network loss stop the run; nothing resumes until the user presses 繼續', async () => {
  const env = await harness({ pages: BILI });
  const id = await env.plan(BILI_URLS); await env.ctx.console.act(id, 'start');
  assert.ok(await env.until(async () => (await env.job(id)).status === 'running' && env.log.some((l) => l.startsWith('capture.start'))));
  env.network.set(false);
  assert.ok(await env.until(async () => (await env.status(id)) === 'blocked'));
  assert.equal((await env.job(id)).blocker.code, 'NETWORK_OFFLINE');
  env.network.set(true);
  const starts = env.log.filter((l) => l.startsWith('capture.start')).length;
  assert.equal(await env.until(async () => (await env.status(id)) !== 'blocked', 30_000), false, 'network recovery never resumes by itself');
  assert.equal(env.log.filter((l) => l.startsWith('capture.start')).length, starts);
  await env.ctx.console.act(id, 'resume');
  assert.ok(await env.until(async () => (await env.status(id)) === 'completed'), JSON.stringify((await env.job(id)).blocker));

  const lost = await harness({ pages: BILI });
  const id2 = await lost.plan(BILI_URLS); await lost.ctx.console.act(id2, 'start');
  assert.ok(await lost.until(async () => (await lost.job(id2)).status === 'running' && lost.log.some((l) => l.startsWith('capture.start'))));
  lost.disconnect();
  assert.ok(await lost.until(async () => (await lost.status(id2)) === 'blocked'));
  assert.equal((await lost.job(id2)).blocker.code, 'COMPANION_DISCONNECTED');
  lost.browser.disconnected = false;
  assert.equal(await lost.until(async () => (await lost.status(id2)) !== 'blocked', 30_000), false, 'reconnecting never resumes by itself');
});

test('restart: an interrupted run comes back blocked (SERVER_RESTARTED) and waits for the user', async () => {
  const env = await harness({ pages: BILI });
  const id = await env.plan(BILI_URLS); await env.ctx.console.act(id, 'start');
  assert.ok(await env.until(async () => (await env.job(id)).status === 'running'));
  const restarted = env.make();
  assert.deepEqual(await restarted.recover(), [id]);
  const ctx = { ...env.ctx, service: restarted }; ctx.console = createConsole(ctx); env.ctx = ctx;
  const blocked = await ctx.console.get(id);
  assert.equal(blocked.blocker.code, 'SERVER_RESTARTED'); assert.equal(blocked.actions.resume, true);
  assert.equal(await env.until(async () => (await env.status(id)) !== 'blocked', 30_000), false, 'never resumes after a restart by itself');
});

// ---------------------------------------------------------------------------------------------------
test('setup wizard API:「測試連線」sends only detect + getState and never plays, records or navigates', async () => {
  const env = await harness({ pages: BILI });
  const sent = [];
  const page = await pageFor('bilibili', 'multipart', env.clock);
  env.ctx.companionCommand = async ({ type, args }) => { sent.push(type); return sanitizeCommandResult(sanitizeResult(await dispatchCommand(page.adapter, type, args, {}))); };
  const call = (method, pathname) => handleConsoleRequest(env.ctx, { method, pathname, headers: { host: '127.0.0.1:4317', 'content-type': 'application/json' }, body: {} });
  const wizard = await call('GET', '/api/agent-console/companion');
  assert.equal(wizard.status, 200); assert.equal(wizard.body.platform.label, 'Bilibili'); assert.equal(wizard.body.extensionOk, true);
  const result = await call('POST', '/api/agent-console/companion/test');
  assert.equal(result.status, 200); assert.equal(result.body.ok, true); assert.equal(result.body.readOnly, true);
  assert.deepEqual(sent, ['detect', 'getState']);
  assert.equal(result.body.adapter, 'bilibili'); assert.equal(result.body.player.found, true); assert.equal(result.body.capabilities.nextLesson, true);
  assert.ok(result.body.platform.automatic.length && result.body.platform.needsUser.length);
  assert.deepEqual(page.page.log.filter((l) => /click:|video\.|navigate:|key:/.test(l)), [], 'read-only');
  const text = JSON.stringify(result.body);
  for (const bad of ['http', 'fixture-media-token', 'cookie', 'token', env.dir]) assert.ok(!text.includes(bad), bad);
  // Blocked page → reported, still read-only
  const captcha = await pageFor('bilibili', 'captcha', env.clock);
  env.ctx.companionCommand = async ({ type, args }) => sanitizeCommandResult(sanitizeResult(await dispatchCommand(captcha.adapter, type, args, {})));
  const blocked = await call('POST', '/api/agent-console/companion/test');
  assert.equal(blocked.body.ok, false); assert.equal(blocked.body.blocker.code, 'CAPTCHA'); assert.match(blocked.body.blocker.next, /[一-鿿]/);
  // Not paired / no tab / extension too old
  env.hubStatus.paired = false;
  assert.equal((await call('POST', '/api/agent-console/companion/test')).body.error.code, 'COMPANION_NOT_PAIRED');
  env.hubStatus.paired = true; env.hubStatus.tabs = [];
  assert.equal((await call('POST', '/api/agent-console/companion/test')).body.error.code, 'COMPANION_TAB_UNBOUND');
  env.hubStatus.extensionVersion = '0.4.0';
  assert.equal(companionView(env.hubStatus).extensionOk, false);
  assert.equal((await handleConsoleRequest(env.ctx, { method: 'POST', pathname: '/api/agent-console/companion/test', headers: { host: '127.0.0.1:4317', 'content-type': 'application/json', 'sec-fetch-site': 'cross-site' }, body: {} })).status, 403);
});

test('UI: wizard steps, test result, automation lists, current video / CC / recording / next; escaped; 390px rules', async () => {
  const fresh = wizardSteps({ paired: false, connected: false, tabSelected: false, minExtensionVersion: '0.5.0' });
  assert.deepEqual(fresh.map((s) => s.done), [false, false, false, false, null]); assert.match(fresh[0].todo, /chrome:\/\/extensions/);
  const old = wizardSteps({ paired: true, connected: true, extensionVersion: '0.4.0', extensionOk: false, minExtensionVersion: '0.5.0' });
  assert.equal(old[0].done, false); assert.match(old[0].todo, /0\.5\.0/);
  const ready = renderCompanionWizard({ paired: true, connected: true, tabSelected: true, sitePermission: true, site: 'www.bilibili.com', platform: { label: 'Bilibili' }, extensionVersion: '0.5.0', extensionOk: true, minExtensionVersion: '0.5.0' }, { pairingCode: null });
  assert.match(ready, /瀏覽器已準備好/); assert.match(ready, /data-wizard-test/); assert.match(ready, /不會自動登入、略過廣告、解除 DRM/);
  const notPaired = renderCompanionWizard({ paired: false, connected: false, tabSelected: false, minExtensionVersion: '0.5.0' }, { pairingCode: '<b>123</b>' });
  assert.match(notPaired, /data-wizard-pair/); assert.ok(!notPaired.includes('<b>123</b>'));
  const result = renderTestResult({ ok: true, testedAt: new Date(EPOCH_MS).toISOString(), platform: { label: 'Bilibili', automatic: ['<img src=x>倍速'], needsUser: ['登入'] }, player: { found: true, title: '<script>x</script>', currentTime: 5, duration: 60, rate: 1.5, paused: false, captions: { available: true, on: true }, isPlaylist: true }, capabilities: { play: true, setRate: true, captions: true, nextLesson: true, blockerDetection: true }, blocker: null });
  assert.ok(!result.includes('<script>') && !result.includes('<img src=x>')); assert.match(result, /只讀取，沒有播放或錄影/); assert.match(result, /Agent 自動處理/); assert.match(result, /需要你操作/);
  const card = renderJobCard({ id: 'job_000000000001', status: 'running', statusText: '執行中', createdAt: new Date(EPOCH_MS).toISOString(), modeText: '錄影', rate: 1.5, captions: ['zh'], courses: [{ title: '自建課程' }], progress: { done: 0, total: 2, skipped: 0 },
    current: { index: 1, lessonTitle: '第 1 部', courseTitle: '自建課程', sourceTime: 10, duration: 60, recordingSeconds: 7, playerRate: 1.5, captionsOn: true, captionsAvailable: true, platform: 'Bilibili', recording: 'recording' },
    next: { index: 2, title: '第 2 部' }, automation: { platform: 'Bilibili', automatic: ['倍速'], needsUser: ['登入'] }, checkpoint: null, blocker: null, actions: { pause: true } });
  for (const label of ['字幕 CC', '已開啟', '錄製狀態', '● 錄製中', '下一部', '第 2 部', 'Agent 自動處理', '需要你操作', 'Bilibili']) assert.ok(card.includes(label), label);
  const css = await fsp.readFile(path.join(root, 'web', 'agent-console.css'), 'utf8');
  assert.match(css, /@media\(max-width:760px\)\{\.auto-cols\{grid-template-columns:1fr\}/);
  const app = await fsp.readFile(path.join(root, 'web', 'agent-console-app.js'), 'utf8');
  assert.match(app, /\/api\/agent-console\/companion\/test/); assert.ok(!/\/start'|act\(/.test(app.split('renderWizard')[1].split('async function refresh')[0]), 'the wizard never starts a job');
});

test('extension: Bilibili adapter is wired, read-only rules hold, no new permissions', async () => {
  const manifest = await readJson('extension', 'manifest.json');
  assert.deepEqual(manifest.permissions, ['storage', 'scripting', 'activeTab', 'alarms']);
  assert.equal(manifest.version, '0.5.0');
  for (const file of ['adapters/bilibili.mjs', 'adapters/bilibili-selectors.json', 'adapters/page-blockers.mjs']) assert.ok(manifest.web_accessible_resources[0].resources.includes(file), file);
  const content = await fsp.readFile(path.join(root, 'extension', 'content.mjs'), 'utf8'); assert.match(content, /createBilibiliAdapter/);
  for (const file of ['bilibili.mjs', 'page-blockers.mjs']) {
    const source = (await fsp.readFile(path.join(root, 'extension', 'adapters', file), 'utf8')).replace(/^\s*(\/\/|\*|\/\*\*).*$/gm, '');
    for (const bad of [/\.play\(\)/, /playbackRate\s*=[^=]/, /fetch\(/, /cookie/i, /localStorage|sessionStorage/, /\.src\b|currentSrc/, /type=["']?password/i, /\.value\b/, /location\.href\s*=/]) assert.ok(!bad.test(source), `${file}: ${bad}`);
  }
});
