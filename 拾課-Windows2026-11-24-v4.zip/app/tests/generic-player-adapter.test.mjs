import test from 'node:test';
import assert from 'node:assert/strict';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createGenericHtml5Adapter } from '../extension/adapters/generic-html5.mjs';
import { dispatchCommand } from '../extension/dispatch.mjs';
import { FakeClock } from './helpers/fake-obs.mjs';
import { buildPage } from './helpers/fake-dom.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fixture = async (name) => JSON.parse(await fsp.readFile(path.join(root, 'fixtures', 'platform', 'generic-html5', `${name}.json`), 'utf8'));
async function setup(name) {
  const clock = new FakeClock(); const spec = await fixture(name); const page = buildPage(spec, { clock });
  return { clock, spec, page, adapter: createGenericHtml5Adapter({ document: page.document, window: page.window, clock }) };
}
/** Settles a promise that may wait on the fake clock (verification timeouts). */
async function drive(clock, promise) { let done = false; promise.finally(() => { done = true; }); for (let i = 0; i < 200 && !done; i += 1) { await new Promise((r) => setImmediate(r)); if (!done) clock.advance(100); } return promise; }
const NOISE = ['fixture-cookie-secret', 'fixture-local-token', 'secret-stream', 'fixture-media-token', '<video', 'outerHTML', 'innerHTML'];
const assertClean = (value) => { const text = JSON.stringify(value); for (const n of NOISE) assert.equal(text.includes(n), false, `leaked ${n}: ${text}`); };

test('single <video>: detect, state fields and capability flags', async () => {
  const { adapter } = await setup('single-video');
  assert.deepEqual(adapter.detect(), { ok: true, adapterId: 'generic-html5', platform: 'generic', capabilities: adapter.capabilities });
  const state = adapter.getState();
  for (const key of ['adapterId', 'currentTime', 'duration', 'rate', 'paused', 'ended', 'buffering', 'online', 'ad', 'title', 'captions', 'capabilities']) assert.ok(key in state, key);
  assert.equal(state.duration, 60); assert.equal(state.ad, false); assert.equal(state.capabilities.nextLesson, false);
  assert.deepEqual(state.captions, { available: true, on: false, languages: ['en'] });
  assertClean(state);
});

test('Skool/Mux: finds the one video through nested open shadow roots without reading media URLs', () => {
  const clock = new FakeClock();
  const page = buildPage({ url: 'https://www.skool.com/group/classroom/x?md=lesson', title: 'Skool lesson', tree: [{ tag: 'body', text: 'Join this group to see other content', children: [{ tag: 'mux-player', shadow: [{ tag: 'mux-video', shadow: [{ tag: 'video', video: { duration: 174, paused: true, src: 'secret-stream' }, tracks: [{ kind: 'subtitles', language: 'en', label: 'English' }] }] }] }] }] }, { clock });
  const adapter = createGenericHtml5Adapter({ document: page.document, window: page.window, clock });
  assert.deepEqual(adapter.detect(), { ok: true, adapterId: 'generic-html5', platform: 'skool', capabilities: adapter.capabilities });
  assert.equal(adapter.getState().duration, 174); assert.equal(adapter.getState().blocker, undefined); assertClean(adapter.getState());
});

test('Skool/Mux placeholder: uses the custom element media API before its inner video exists', () => {
  const clock = new FakeClock(); const page = buildPage({ url: 'https://www.skool.com/group/classroom/x?md=lesson', title: 'Skool lesson', tree: [{ tag: 'body', children: [{ tag: 'mux-player' }] }] }, { clock });
  const mux = page.document.querySelector('mux-player'); Object.assign(mux, { currentTime: 0, duration: 174, playbackRate: 1, paused: true, ended: false, readyState: 4, error: null, textTracks: [] });
  mux.play = async () => { mux.paused = false; }; mux.pause = () => { mux.paused = true; };
  const adapter = createGenericHtml5Adapter({ document: page.document, window: page.window, clock });
  assert.equal(adapter.detect().ok, true); assert.deepEqual(adapter.getState().duration, 174); assert.deepEqual(adapter.getState().platform, 'skool');
});

test('Skool poster is activated once, then the created player is paused and rewound for unattended capture', async () => {
  const clock = new FakeClock();
  const page = buildPage({ url: 'https://www.skool.com/group/classroom/x?md=lesson', title: 'Skool lesson', tree: [{ tag: 'body', text: 'Join this group to see other content', children: [{ tag: 'img', rect: { width: 750, height: 420 } }] }] }, { clock });
  page.document.querySelector('img').addEventListener('click', () => page.replaceTree([{ tag: 'body', children: [{ tag: 'video', video: { duration: 285, currentTime: 17, paused: false }, tracks: [{ kind: 'captions', language: 'en', label: 'English' }] }] }]));
  const adapter = createGenericHtml5Adapter({ document: page.document, window: page.window, clock });
  assert.deepEqual(adapter.detect(), { ok: false, reason: 'PLAYER_NOT_FOUND' });
  const result = await drive(clock, adapter.verifyPage({ platformLessonId: 'L4', url: page.window.location.href }));
  assert.deepEqual(result, { ok: true, lessonId: 'L4', loginRequired: false });
  assert.equal(page.log.filter((entry) => entry.startsWith('click:img')).length, 1);
  assert.equal(adapter.getState().paused, true);
  assert.equal(adapter.getState().currentTime, 0);
  assert.equal(page.document.querySelector('video').style.position, 'fixed');
  assert.equal(page.document.querySelector('video').style.zIndex, '2147483647');
});

test('Skool poster preparation never clicks when multiple large images are ambiguous', async () => {
  const clock = new FakeClock();
  const page = buildPage({ url: 'https://www.skool.com/group/classroom/x?md=lesson', title: 'Skool lesson', tree: [{ tag: 'body', children: [{ tag: 'img', rect: { width: 750, height: 420 } }, { tag: 'img', rect: { width: 740, height: 410 } }] }] }, { clock });
  const adapter = createGenericHtml5Adapter({ document: page.document, window: page.window, clock });
  assert.deepEqual(await adapter.verifyPage({ platformLessonId: 'L4', url: page.window.location.href }), { ok: false, reason: 'PLAYER_NOT_FOUND' });
  assert.deepEqual(page.log, []);
});

test('play and pause use HTMLMediaElement and are verified', async () => {
  const { adapter, page, clock } = await setup('single-video');
  assert.deepEqual(await adapter.play(), { ok: true });
  clock.advance(2000); assert.ok(Math.abs(adapter.getState().currentTime - 2) < 1e-9);
  assert.deepEqual(await adapter.pause(), { ok: true });
  assert.deepEqual(page.log.filter((l) => l.startsWith('video.')), ['video.play()', 'video.pause()']);
});

test('setRate succeeds and is read back', async () => {
  const { adapter } = await setup('single-video');
  assert.deepEqual(await adapter.setRate(1.5), { ok: true, rate: 1.5 });
  assert.equal(adapter.getState().rate, 1.5);
});

test('setRate fails verification twice → stop DOM_CHANGED, exactly two attempts', async () => {
  const { adapter, page, clock } = await setup('rate-locked');
  const result = await drive(clock, adapter.setRate(2));
  assert.deepEqual(result, { ok: false, reason: 'RATE_NOT_APPLIED', stop: 'DOM_CHANGED' });
  assert.equal(page.log.filter((l) => l === 'write:playbackRate').length, 2);
});

test('captions: matching track is shown; no tracks → available:false', async () => {
  const ok = await setup('single-video');
  assert.deepEqual(await ok.adapter.enableCaptions({ languages: ['en'] }), { ok: true, available: true, trackLabel: 'English' });
  assert.equal(ok.adapter.getState().captions.on, true);
  const none = await setup('no-captions');
  assert.deepEqual(await none.adapter.enableCaptions({ languages: ['en'] }), { ok: true, available: false });
});

test('no player → PLAYER_NOT_FOUND everywhere, nothing is touched', async () => {
  const { adapter, page } = await setup('no-video');
  assert.deepEqual(adapter.detect(), { ok: false, reason: 'PLAYER_NOT_FOUND' });
  assert.equal(adapter.getState().blocker, 'PLAYER_NOT_FOUND');
  assert.deepEqual(await adapter.play(), { ok: false, reason: 'PLAYER_NOT_FOUND' });
  assert.deepEqual(await adapter.verifyPage({ platformLessonId: 'L1', url: 'https://course.example.invalid/lesson/1' }), { ok: false, reason: 'PLAYER_NOT_FOUND' });
  assert.deepEqual(page.log, []);
});

test('multiple players → AMBIGUOUS_PLAYER, never guesses', async () => {
  const { adapter, page } = await setup('multiple-videos');
  assert.deepEqual(adapter.detect(), { ok: false, reason: 'AMBIGUOUS_PLAYER' });
  assert.deepEqual(await adapter.play(), { ok: false, reason: 'AMBIGUOUS_PLAYER' });
  assert.deepEqual(await adapter.setRate(2), { ok: false, reason: 'AMBIGUOUS_PLAYER' });
  assert.equal(adapter.getState().blocker, 'AMBIGUOUS_PLAYER');
  assert.deepEqual(page.log, []);
});

test('verifyPage binds the lesson to the URL; SPA navigation is re-detected', async () => {
  const { adapter, page } = await setup('single-video');
  assert.deepEqual(await adapter.verifyPage({ platformLessonId: 'L1', url: 'https://course.example.invalid/lesson/1#t=3' }), { ok: true, lessonId: 'L1', loginRequired: false });
  assert.equal(adapter.getState().lessonId, 'L1');
  const next = await fixture('spa-next');
  page.window.location.href = next.url; page.replaceTree(next.tree); page.document.title = next.title;
  const state = adapter.getState();
  assert.equal(state.lessonId, 'URL_CHANGED', 'runner sees a different lesson');
  assert.equal(state.duration, 90, 'the new <video> element was picked up');
  assert.deepEqual(await adapter.verifyPage({ platformLessonId: 'L2', url: next.url }), { ok: true, lessonId: 'L2', loginRequired: false });
  assert.equal(adapter.getState().lessonId, 'L2');
});

test('verifyPage on another URL reports a different lesson instead of guessing', async () => {
  const { adapter } = await setup('single-video');
  assert.deepEqual(await adapter.verifyPage({ platformLessonId: 'L9', url: 'https://course.example.invalid/lesson/9' }), { ok: true, lessonId: 'URL_CHANGED', loginRequired: false });
});

test('navigation and next lesson are not performed in-page by the generic adapter', async () => {
  const { adapter, page } = await setup('single-video');
  assert.deepEqual(await adapter.navigate({ url: 'https://course.example.invalid/lesson/2' }), { ok: false, reason: 'NAVIGATE_VIA_BACKGROUND' });
  assert.deepEqual(await adapter.nextLesson(), { ok: false, reason: 'UNSUPPORTED' });
  assert.equal(page.window.location.href, 'https://course.example.invalid/lesson/1');
});

test('dispatchCommand output is allowlisted (no cookie, token, media URL or DOM)', async () => {
  const { adapter } = await setup('single-video');
  const hostile = { ...adapter, getState: () => ({ ...adapter.getState(), cookie: 'fixture-cookie-secret', authorization: 'Bearer x', html: '<video src="secret-stream">', src: 'secret-stream' }) };
  const result = await dispatchCommand(hostile, 'getState');
  assertClean(result); assert.equal('cookie' in result.state, false); assert.equal('html' in result.state, false);
  assert.deepEqual(await dispatchCommand(adapter, 'eval', {}), { ok: false, reason: 'UNSUPPORTED' });
});
