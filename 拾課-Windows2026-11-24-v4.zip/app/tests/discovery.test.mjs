import test from 'node:test';
import assert from 'node:assert/strict';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createAgentService } from '../src/agent/service.mjs';
import { createJsonAgentStore } from '../src/agent/json-store.mjs';
import { createConsole } from '../src/agent/console-api.mjs';
import { parseLessonUrl } from '../src/agent/console.mjs';
import { COMMAND_TYPES, sanitizeCommandResult } from '../src/services/companion.mjs';
import { createDiscoveryService, handleDiscoveryRequest } from '../src/discovery/service.mjs';
import { cleanLessonUrl, cleanPageUrl, siteOf } from '../src/discovery/urls.mjs';
import { PLATFORMS, platformForHost, listPlatforms } from '../src/discovery/platforms.mjs';
import { discoverPage, detectDiscoveryPlatform, parseDuration } from '../extension/adapters/discovery.mjs';
import { sanitizeResult } from '../extension/adapters/common.mjs';
import { dispatchCommand } from '../extension/dispatch.mjs';
import { createGenericHtml5Adapter } from '../extension/adapters/generic-html5.mjs';
import { allSelection, rangeSelection, renderBlocker, renderEstimate, renderLocal, renderScan } from '../web/discovery-view.js';
import { buildPage } from './helpers/fake-dom.mjs';
import { createIoTracker, pollUntil } from './helpers/quiesce.mjs';
import { EPOCH_MS, FakeCapture, FakeClock, FakeDisk, FakeNetwork, FakePlayer, settle } from './helpers/agent-fakes.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fixture = async (name) => JSON.parse(await fsp.readFile(path.join(root, 'fixtures', 'discovery', `${name}.json`), 'utf8'));
const local = { host: '127.0.0.1:4317', 'content-type': 'application/json' };
const ACKS = { recordPermission: true, privateProcessing: true };
const LEAKS = ['fixture-secret-token', 'fixture-media-token', 'fixture-cookie', 'fixture-local-token', 'SID=', 'password', 'cookie', 'authorization', 'token=', '/home/', '/Users/', 'C:\\'];

/**
 * Full stack: fake page → content-script dispatch (extension allowlist) → Companion hub allowlist →
 * discovery service → P5 console → real Agent service/Runner with fake player/capture.
 */
async function setup({ page: pageName = 'youtube-playlist', companion = {}, playerLessons = {} } = {}) {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'cms-p7a-'));
  const clock = new FakeClock(); const log = []; const io = createIoTracker(); const store = io.track(createJsonAgentStore(path.join(dir, 'agent')));
  const player = new FakePlayer({ clock, log, lessons: playerLessons }); const network = new FakeNetwork({ log }); const captures = {};
  const hubStatus = { paired: true, connected: true, browserOnline: true, tabs: [{ tabId: 7, origin: 'https://www.youtube.com', bound: true, permissionGranted: true }], latestState: null, ...companion };
  const service = createAgentService({ hub: { status: () => hubStatus, on: () => () => {} }, store, captureFactory: (mode) => (captures[mode] ||= new FakeCapture({ clock, log, mode })), disk: new FakeDisk(), clock, runnerOptions: { epochMs: EPOCH_MS }, player, network });
  const ctx = { port: 4317, dataDir: dir, service, store, freeBytes: async () => 50 * 1024 ** 3, now: () => EPOCH_MS + clock.now() };
  ctx.console = createConsole(ctx);
  const env = { dir, clock, log, store, service, ctx, captures, hubStatus, commands: [], page: buildPage(await fixture(pageName), { clock }) };
  env.load = async (name) => { const spec = await fixture(name); env.page.replaceTree(spec.tree); };
  env.adapter = createGenericHtml5Adapter({ document: env.page.document, window: env.page.window, clock });
  const sendCommand = async (command) => {
    env.commands.push(command.type);
    const raw = await dispatchCommand(env.adapter, command.type, command.args, { discover: () => discoverPage({ document: env.page.document, window: env.page.window }) });
    return sanitizeCommandResult(JSON.parse(JSON.stringify(sanitizeResult(raw)))); // extension allowlist, then hub allowlist
  };
  env.discovery = createDiscoveryService({ sendCommand, companionStatus: () => hubStatus, console: ctx.console, listJobs: () => store.listJobs(), freeBytes: async () => 50 * 1024 ** 3, now: () => EPOCH_MS + clock.now(),
    listLocalVideos: async () => [{ name: '/home/someone/secret/週一課程.mp4', sizeBytes: 3 * 1024 ** 2, modifiedAt: '2026-11-01T00:00:00.000Z', inLibrary: false }, { name: 'C:\\Users\\someone\\Videos\\已整理.mkv', sizeBytes: 9 * 1024 ** 2, modifiedAt: null, inLibrary: true }],
    scanLocal: async () => { env.log.push('legacy.scan'); } });
  env.http = (method, pathname, { body, headers = local } = {}) => handleDiscoveryRequest({ port: 4317, discovery: env.discovery }, { method, pathname, headers, body });
  // State-based waiting (no real-time sleeps): fake time moves only after store I/O has settled.
  env.run = async (maxMs = 120_000) => { await pollUntil(async () => !(await store.listJobs()).some((item) => ['preparing', 'running', 'stopping', 'queued'].includes(item.status)), { clock, quiesce: io.quiesce, maxSteps: Math.ceil(maxMs / 500) }); await io.quiesce(); };
  return env;
}
const titles = (scan) => scan.items.map((item) => item.title);
const noPlayback = (env) => {
  assert.deepEqual(env.page.log.filter((entry) => /video\.(play|pause)|click:|navigate:|key:|write:playbackRate/.test(entry)), [], 'discovery touched the player or navigated');
  assert.deepEqual(env.log.filter((entry) => /capture\.|player\./.test(entry)), [], 'discovery started capture or player commands');
  assert.ok(env.commands.every((type) => type === 'discover'), `unexpected companion commands: ${env.commands}`);
};

test('registry: every platform reports capabilities and what is automatic vs needs the user', () => {
  for (const platform of listPlatforms()) {
    assert.deepEqual(Object.keys(platform.capabilities).sort(), ['autoNext', 'captions', 'discover', 'navigate', 'rate']);
    assert.ok(platform.automatic.length && platform.needsUser.length, platform.id);
    assert.ok(['auto', 'semi', 'local'].includes(platform.discovery));
  }
  assert.equal(PLATFORMS.youtube.discovery, 'auto'); assert.equal(PLATFORMS.bilibili.discovery, 'semi'); assert.equal(PLATFORMS.local.capabilities.navigate, false);
  assert.equal(platformForHost('www.youtube.com'), 'youtube'); assert.equal(platformForHost('m.bilibili.com'), 'bilibili'); assert.equal(platformForHost('www.skool.com'), 'skool');
  assert.equal(platformForHost('sat.cool'), 'satKnowledge'); assert.equal(platformForHost('evilsat.cool.example'), 'generic'); assert.equal(platformForHost('learn.example.com'), 'generic');
  for (const host of ['www.youtube.com', 'www.bilibili.com', 'www.skool.com', 'hi.sat.cool', 'x.example']) assert.equal(detectDiscoveryPlatform(host), platformForHost(host), host);
  assert.equal(parseDuration('1:02:03'), 3723); assert.equal(parseDuration('約 8 分鐘'), 480); assert.equal(parseDuration('2.3 分享連結'), null);
});

test('YouTube playlist: titles, order, durations; duplicates/private skipped; members-only locked; range selection', async () => {
  const env = await setup();
  const scan = await env.discovery.scan();
  assert.equal(scan.platform.id, 'youtube'); assert.equal(scan.platform.discovery, 'auto'); assert.equal(scan.courseTitle, '自建測試課程：從零開始');
  assert.deepEqual(scan.items.map((item) => item.id), ['fixVid00001', 'fixVid00002', 'fixVid00003', 'fixVid00005']);
  assert.deepEqual(scan.items.map((item) => item.durationSec), [725, 510, 3723, 900]);
  assert.deepEqual(scan.items.map((item) => item.index), [1, 2, 3, 4]);
  assert.equal(scan.items[3].locked, true); assert.equal(scan.counts.rejected.duplicate, 1); assert.equal(scan.counts.rejected.unavailable, 1);
  assert.equal(scan.partial, true, '8 declared, 6 rendered → ask the user to scroll and re-read');
  assert.deepEqual([...allSelection(scan.items)], ['fixVid00001', 'fixVid00002', 'fixVid00003'], 'locked items are never auto-selected');
  assert.deepEqual([...rangeSelection(scan.items, 2, 4)], ['fixVid00002', 'fixVid00003']);
  assert.equal(rangeSelection(scan.items, 3, 2), null);
  const preview = await env.discovery.preview({ scanId: scan.scanId, selected: ['fixVid00001', 'fixVid00002', 'fixVid00003'], captureMode: 'video', rate: 1.5 });
  assert.equal(preview.estimate.sourceSeconds, 725 + 510 + 3723); assert.equal(preview.estimate.recordSeconds, Math.round((725 + 510 + 3723) / 1.5));
  assert.ok(preview.estimate.bytes > 0); assert.equal(preview.estimate.spaceOk, true); assert.deepEqual(preview.duplicates, []);
  await assert.rejects(env.discovery.preview({ scanId: scan.scanId, selected: ['fixVid00005'] }), { code: 'LOCKED_ITEM' });
  await assert.rejects(env.discovery.preview({ scanId: scan.scanId, selected: ['notInList0'] }), { code: 'UNKNOWN_ITEM' });
  noPlayback(env);
});

test('dynamic loading: re-reading the same page adds only new items, never duplicates', async () => {
  const env = await setup();
  const first = await env.discovery.scan();
  await env.load('youtube-playlist-more');
  const second = await env.discovery.scan({ scanId: first.scanId });
  assert.equal(second.scanId, first.scanId); assert.equal(second.added, 2); assert.equal(second.items.length, 6);
  assert.deepEqual(second.items.map((item) => item.id), ['fixVid00001', 'fixVid00002', 'fixVid00003', 'fixVid00005', 'fixVid00006', 'fixVid00007']);
  assert.equal(new Set(second.items.map((item) => item.id)).size, second.items.length); assert.equal(second.partial, false);
  const third = await env.discovery.scan({ scanId: first.scanId });
  assert.equal(third.added, 0); assert.equal(third.items.length, 6);
  // A different site is a new list, not merged into this one.
  await env.load('sat-course'); env.page.window.location.href = 'https://sat.cool/courses/fixture-course/chapters/1';
  const other = await env.discovery.scan({ scanId: first.scanId });
  assert.notEqual(other.scanId, first.scanId); assert.equal(other.platform.id, 'satKnowledge');
});

test('a partial course outline cannot create a plan until the user scrolls and re-reads it', async () => {
  const env = await setup();
  const first = await env.discovery.scan();
  assert.equal(first.partial, true);
  await assert.rejects(
    env.discovery.plan({ scanId: first.scanId, selected: [first.items[0].id], acknowledgements: ACKS }),
    (error) => error.code === 'DISCOVERY_PARTIAL' && /捲到最底/.test(error.message)
  );
  await env.load('youtube-playlist-more');
  const complete = await env.discovery.scan({ scanId: first.scanId });
  assert.equal(complete.partial, false);
  const plan = await env.discovery.plan({ scanId: complete.scanId, selected: [complete.items[0].id], acknowledgements: ACKS });
  assert.equal(plan.job.status, 'queued');
});

test('Bilibili fixture: 分P + 合集 links, tracking parameters removed, semi-automatic', async () => {
  const env = await setup({ page: 'bilibili-multipart' });
  const scan = await env.discovery.scan();
  assert.equal(scan.platform.id, 'bilibili'); assert.equal(scan.platform.discovery, 'semi'); assert.equal(scan.courseTitle, '自建分P課程');
  assert.deepEqual(titles(scan), ['P1 開場', 'P2 工具安裝', 'P3 第一個專案', 'P4 Q&A', '合集：番外篇']);
  assert.deepEqual(scan.items.map((item) => item.durationSec), [310, 702, 1503, 599, 180]);
  assert.equal(scan.platform.capabilities.captions, true); assert.ok(scan.platform.automatic.some((text) => /原生/.test(text)));
  const plan = await env.discovery.plan({ scanId: scan.scanId, selected: scan.items.map((item) => item.id), acknowledgements: ACKS });
  const job = await env.service.getJob(plan.job.id);
  const urls = job.plan.lessons.map((lesson) => lesson.url);
  assert.deepEqual(urls.slice(0, 2), ['https://www.bilibili.com/video/BV1Fx4y1z7Ab/?p=1', 'https://www.bilibili.com/video/BV1Fx4y1z7Ab/?p=2']);
  assert.ok(urls.every((url) => !/spm_id_from|vd_source|#/.test(url)), urls.join());
  noPlayback(env);
});

test('Skool / 知識衛星 generic fixtures: only the visible outline, locked units flagged, token links refused', async () => {
  const env = await setup({ page: 'skool-classroom' });
  const scan = await env.discovery.scan();
  assert.equal(scan.platform.id, 'skool'); assert.equal(scan.courseTitle, 'Fixture 社群課程');
  assert.deepEqual(titles(scan), ['1.1 歡迎', '1.2 設定帳號', '2.1 進階技巧', '2.2 付費加值']);
  assert.deepEqual(scan.items.map((item) => item.locked), [false, false, false, true]);
  assert.equal(scan.counts.rejected.sensitive, 1, 'the ?token= link is not stored'); assert.equal(scan.counts.rejected.duplicate, 1, 'fbclid / #comments variants collapse');
  assert.ok(!JSON.stringify(scan).includes('fixture-secret-token'));
  const sat = await setup({ page: 'sat-course' });
  const satScan = await sat.discovery.scan();
  assert.equal(satScan.platform.label, '知識衛星（SAT. Knowledge）');
  assert.deepEqual(titles(satScan), ['1-1 為什么要學財務', '1-2 看懂報表', '2-1 現金流']);
  assert.deepEqual(satScan.items.map((item) => item.durationSec), [750, 480, 1265]);
  assert.ok(!titles(satScan).some((title) => /條款|隱私/.test(title)), 'footer links are not lessons');
  noPlayback(env); noPlayback(sat);
});

test('login wall, CAPTCHA, paywall and unrecognised pages explain the reason in 繁中 and are never bypassed', async () => {
  for (const [name, code, words] of [['login-wall', 'LOGIN_REQUIRED', /登入/], ['captcha', 'CAPTCHA', /驗證/], ['paywall', 'PAYWALL', /付費/], ['unrecognized', 'UNRECOGNIZED_PAGE', /課程清單/]]) {
    const env = await setup({ page: name });
    const scan = await env.discovery.scan();
    assert.equal(scan.blocker.code, code, name); assert.match(scan.blocker.title, words, name); assert.match(scan.blocker.next, /[一-鿿]/);
    assert.equal(scan.scanId, null, 'nothing is kept'); assert.deepEqual(scan.items, []);
    assert.match(renderBlocker(scan.blocker), new RegExp(`data-blocker="${code}"`));
    noPlayback(env);
  }
  const env = await setup({ page: 'captcha' });
  assert.equal((await env.discovery.scan()).blocker.code, 'CAPTCHA', 'items behind a CAPTCHA are not read');
});

test('URL hygiene: fragments and tracking removed; token / signature / auth links refused; cross-site and media refused', async () => {
  const page = 'https://learn.example.com/course/1';
  assert.equal(cleanLessonUrl('https://learn.example.com/course/1/lesson/2?utm_source=x&fbclid=1&ref=nav#t=30', { pageUrl: page }).url, 'https://learn.example.com/course/1/lesson/2');
  assert.equal(cleanLessonUrl('https://learn.example.com/l?id=7&utm_medium=mail', { pageUrl: page }).url, 'https://learn.example.com/l?id=7');
  for (const bad of ['https://learn.example.com/l?token=abc', 'https://learn.example.com/l?access_token=abc', 'https://learn.example.com/l?signature=abc', 'https://learn.example.com/l?X-Amz-Signature=abc', 'https://learn.example.com/l?auth=1', 'https://learn.example.com/l?Policy=x&Key-Pair-Id=y', 'https://learn.example.com/l?s=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.abc', 'https://user:pw@learn.example.com/l']) {
    assert.throws(() => cleanLessonUrl(bad, { pageUrl: page }), { code: 'SENSITIVE_URL' }, bad);
  }
  assert.throws(() => cleanLessonUrl('https://evil.example.net/course/1', { pageUrl: page }), { code: 'CROSS_SITE' });
  assert.throws(() => cleanLessonUrl('https://learn.example.com/video/master.m3u8', { pageUrl: page }), { code: 'MEDIA_URL' });
  assert.equal(cleanLessonUrl('https://sub.learn.example.com/x', { pageUrl: page }).host, 'sub.learn.example.com');
  assert.equal(siteOf('www.example.com.tw'), 'example.com.tw'); assert.equal(siteOf('a.b.example.co.uk'), 'example.co.uk');
  assert.throws(() => cleanPageUrl('https://learn.example.com/c?session=1'), { code: 'SENSITIVE_URL' });
  // A page whose own address carries a token is refused as a whole; nothing is stored.
  const env = await setup({ page: 'sat-course' });
  env.page.window.location.href = 'https://sat.cool/courses/fixture-course/chapters/1?token=fixture-secret-token';
  await assert.rejects(env.discovery.scan(), { code: 'SENSITIVE_URL' });
  // Hostile payload straight to the hub allowlist: extra fields never get through.
  const hostile = sanitizeCommandResult({ ok: true, discovery: { platform: 'evil', pageUrl: 'https://x.example/', cookie: 'SID=1', html: '<script>', items: [{ title: 'a', url: 'https://x.example/a', cookie: 'c', headers: { authorization: 'Bearer z' } }] } });
  assert.equal(hostile.discovery.platform, 'generic'); assert.deepEqual(Object.keys(hostile.discovery.items[0]).sort(), ['durationSec', 'key', 'locked', 'order', 'title', 'unavailable', 'url']);
  assert.ok(!JSON.stringify(hostile).includes('SID=') && !JSON.stringify(hostile).includes('Bearer'));
});

test('cross-site requests, wrong host, foreign origin and non-JSON writes are refused', async () => {
  const env = await setup();
  for (const headers of [{ host: 'evil.example', 'content-type': 'application/json' }, { ...local, origin: 'https://evil.example' }, { ...local, 'sec-fetch-site': 'cross-site' }]) {
    assert.equal((await env.http('POST', '/api/course-discovery/scan', { headers, body: {} })).status, 403, JSON.stringify(headers));
  }
  assert.equal((await env.http('POST', '/api/course-discovery/plan', { headers: { host: '127.0.0.1:4317' }, body: {} })).status, 415);
  assert.equal(env.commands.length, 0, 'refused requests never reach the browser');
  assert.equal(await handleDiscoveryRequest({ port: 4317, discovery: env.discovery }, { method: 'GET', pathname: '/api/course-discovery/../agent', headers: local }), null);
});

test('no plan without both acknowledgements; nothing is created or recorded', async () => {
  const env = await setup();
  const scan = await env.discovery.scan();
  for (const acknowledgements of [undefined, {}, { recordPermission: true }, { recordPermission: true, privateProcessing: 'yes' }]) {
    const response = await env.http('POST', '/api/course-discovery/plan', { body: { scanId: scan.scanId, selected: ['fixVid00001'], acknowledgements } });
    assert.equal(response.status, 403); assert.equal(response.body.error, 'RIGHTS_REQUIRED'); assert.match(response.body.message, /授權/);
  }
  assert.deepEqual(await env.store.listJobs(), []); assert.equal(await env.store.readRights?.('rts_000000000000') ?? null, null);
  noPlayback(env);
});

test('companion not paired / tab not selected / extension too old → clear 繁中 reasons, no command sent', async () => {
  for (const [companion, code] of [[{ paired: false }, 'COMPANION_NOT_PAIRED'], [{ connected: false }, 'COMPANION_DISCONNECTED'], [{ tabs: [] }, 'COMPANION_TAB_UNBOUND']]) {
    const env = await setup({ companion });
    const response = await env.http('POST', '/api/course-discovery/scan', { body: {} });
    assert.equal(response.status, 409); assert.equal(response.body.error, code); assert.match(response.body.message, /[一-鿿]/);
    assert.equal(env.commands.length, 0);
  }
  const old = createDiscoveryService({ sendCommand: async () => ({ ok: false, reason: 'UNSUPPORTED' }), console: {} });
  await assert.rejects(old.scan(), (e) => e.code === 'DISCOVERY_FAILED' && /0\.4\.0/.test(e.message));
});

test('the generated plan goes straight to the existing Runner and completes (after「開始」only)', async () => {
  const ids = ['fixVid00001', 'fixVid00002', 'fixVid00003'];
  const env = await setup({ playerLessons: Object.fromEntries(ids.map((id) => [id, { durationSec: 4 }])) });
  const first = await env.discovery.scan();
  await env.load('youtube-playlist-more');
  const scan = await env.discovery.scan({ scanId: first.scanId });
  const response = await env.http('POST', '/api/course-discovery/plan', { body: { scanId: scan.scanId, selected: [...rangeSelection(scan.items, 1, 3)], captureMode: 'audio', rate: 2, title: '自建播放清單', acknowledgements: ACKS } });
  assert.equal(response.status, 201, JSON.stringify(response.body));
  assert.equal(response.body.job.status, 'queued', 'confirmed, waiting for the user to press 開始');
  noPlayback(env);
  const job = await env.service.getJob(response.body.job.id);
  assert.deepEqual(job.plan.lessons.map((lesson) => lesson.platformLessonId), ids);
  assert.deepEqual(job.plan.lessons.map((lesson) => lesson.url), ids.map((id) => `https://www.youtube.com/watch?v=${id}&list=PLfixtureCourse01`));
  assert.ok(job.plan.lessons.every((lesson) => parseLessonUrl(lesson.url).platformLessonId === lesson.platformLessonId));
  assert.equal(job.plan.captureMode, 'audio'); assert.equal(job.plan.rate, 2);
  // Duplicate detection now sees these lessons in an existing task.
  const again = await env.discovery.scan({ scanId: scan.scanId });
  assert.deepEqual(again.items.filter((item) => item.alreadyPlanned).map((item) => item.id), ids);
  const preview = await env.discovery.preview({ scanId: scan.scanId, selected: ['fixVid00001'] });
  assert.equal(preview.duplicates.length, 1); assert.match(renderEstimate(preview, { captureMode: 'video' }), /重複項目：1 部/);
  await env.ctx.console.act(job.id, 'start'); await env.run();
  assert.equal((await env.service.getJob(job.id)).status, 'completed');
  assert.deepEqual(env.log.filter((entry) => entry.startsWith('player.navigate:')).map((entry) => entry.split(':')[1]), ids);
});

test('API responses carry no cookies, tokens, passwords, page URLs or local paths', async () => {
  const env = await setup({ page: 'skool-classroom', playerLessons: {} });
  const scan = await env.http('POST', '/api/course-discovery/scan', { body: {} });
  const preview = await env.http('POST', '/api/course-discovery/preview', { body: { scanId: scan.body.scanId, selected: [scan.body.items[0].id] } });
  const plan = await env.http('POST', '/api/course-discovery/plan', { body: { scanId: scan.body.scanId, selected: [scan.body.items[0].id], acknowledgements: ACKS } });
  const localList = await env.http('GET', '/api/course-discovery/local');
  const platforms = await env.http('GET', '/api/course-discovery/platforms');
  const again = await env.http('GET', `/api/course-discovery/scans/${scan.body.scanId}`);
  for (const response of [scan, preview, plan, localList, platforms, again]) {
    assert.ok(response.status < 300, JSON.stringify(response.body));
    const text = JSON.stringify(response.body);
    for (const bad of [...LEAKS, env.dir, os.homedir()]) assert.ok(!text.includes(bad), `leaks ${bad}`);
    assert.ok(!/https?:\/\//.test(text), `no URLs in ${text.slice(0, 120)}`);
    assert.equal(response.headers['cache-control'], 'no-store');
  }
  assert.deepEqual(localList.body.files.map((file) => file.name), ['週一課程.mp4', '已整理.mkv']);
  assert.equal((await env.http('POST', '/api/course-discovery/local/scan', { body: {} })).status, 202); assert.ok(env.log.includes('legacy.scan'));
  assert.equal((await env.http('POST', '/api/course-discovery/local', { body: {} })).status, 405, 'no browser-supplied local path');
});

test('UI: escaped titles, checkboxes, range controls, estimates, local list; 390px layout rules', async () => {
  const env = await setup();
  const scan = await env.discovery.scan();
  const html = renderScan(scan, allSelection(scan.items));
  assert.ok(!html.includes('<img src=x'), 'hostile title is escaped'); assert.match(html, /&lt;img src=x onerror=alert\(1\)&gt;/);
  assert.match(html, /data-select="fixVid00005" disabled/); assert.match(html, /鎖住／需付費/);
  assert.equal((html.match(/data-select="[^"]+" checked/g) || []).length, 3);
  for (const label of ['全選', '全不選', '套用範圍', '已選 3／4 部', '自動讀取', '倍速', '字幕 CC', '自動下一部', '清單可能還沒全部載入', '頁面上重複的項目 1 個']) assert.ok(html.includes(label), label);
  const preview = await env.discovery.preview({ scanId: scan.scanId, selected: ['fixVid00001', 'fixVid00002'], captureMode: 'audio', rate: 1 });
  const estimate = renderEstimate(preview, { captureMode: 'audio' });
  for (const label of ['預估播放／錄製時間', '預估錄音空間', '剩餘', '2 部']) assert.ok(estimate.includes(label), label);
  const localHtml = renderLocal(await env.discovery.local());
  assert.match(localHtml, /錄影資料夾/); assert.ok(!localHtml.includes('/home/'));
  const index = await fsp.readFile(path.join(root, 'web', 'index.html'), 'utf8');
  for (const needle of ['id="discoveryImport"', '從目前頁面讀取', 'id="dAckRecord"', 'id="dAckPrivate"', 'id="discoveryCreate" class="primary-button" type="button" disabled', 'href="discovery.css"', 'src="discovery-app.js"', '不會播放、錄音或錄影']) assert.ok(index.includes(needle), needle);
  const css = await fsp.readFile(path.join(root, 'web', 'discovery.css'), 'utf8');
  assert.match(css, /@media\(max-width:760px\)\{[^}]*\.discovery-options\{grid-template-columns:1fr 1fr\}/);
  assert.match(css, /\.discovery-estimate\{grid-template-columns:1fr\}/);
  const app = await fsp.readFile(path.join(root, 'web', 'discovery-app.js'), 'utf8');
  assert.match(app, /disabled = busy \|\| !scan\?\.scanId \|\| !selection\.size \|\| !acks/);
  assert.ok(!/\.play\(|captureMode: 'video', start/.test(app));
});

test('extension: discover command is read-only, needs no new permissions, and is allowlisted end to end', async () => {
  const manifest = JSON.parse(await fsp.readFile(path.join(root, 'extension', 'manifest.json'), 'utf8'));
  assert.deepEqual(manifest.permissions, ['storage', 'scripting', 'activeTab', 'alarms']);
  for (const forbidden of ['cookies', 'webRequest', 'webRequestBlocking', 'downloads', 'history', 'tabs', 'declarativeNetRequest']) assert.ok(!manifest.permissions.includes(forbidden), forbidden);
  assert.ok(manifest.web_accessible_resources[0].resources.includes('adapters/discovery.mjs'));
  assert.ok(COMMAND_TYPES.includes('discover'));
  const source = await fsp.readFile(path.join(root, 'extension', 'adapters', 'discovery.mjs'), 'utf8');
  for (const forbidden of [/\.play\(/, /\.click\(/, /fetch\(/, /cookie/i, /localStorage|sessionStorage/, /XMLHttpRequest/, /location\.href\s*=/, /innerHTML|outerHTML/, /\.src\b/]) assert.ok(!forbidden.test(source.replace(/^\/\/.*$/gm, '')), String(forbidden));
  const env = await setup();
  const out = await dispatchCommand(env.adapter, 'discover', {}, { discover: () => discoverPage({ document: env.page.document, window: env.page.window }) });
  assert.equal(out.ok, true); assert.ok(!JSON.stringify(sanitizeResult(out)).includes('fixture-media-token'), 'media src never read');
  assert.deepEqual(await dispatchCommand(env.adapter, 'discover', {}, {}), { ok: false, reason: 'UNSUPPORTED' });
  noPlayback(env);
});
