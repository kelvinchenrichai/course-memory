import test from 'node:test';
import assert from 'node:assert/strict';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import Ajv2020 from 'ajv/dist/2020.js';
import addFormats from 'ajv-formats';
import { createPipelineRunner } from '../src/pipeline/runner.mjs';
import { createIntake, jobInputFromSession } from '../src/pipeline/intake.mjs';
import { recToSrc } from '../src/domain/timemap.mjs';
import { createFakeMedia, createFakeProvider } from './helpers/fake-process.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const readJson = async (file) => JSON.parse(await fsp.readFile(file, 'utf8'));
const tmp = async (label) => { const base = path.join(process.cwd(), 'tmp-tests'); await fsp.mkdir(base, { recursive: true }); return fsp.mkdtemp(path.join(base, `cms-p4a-${label}-`)); };
const close = (actual, expected, label) => { if (expected == null) assert.equal(actual, expected, label); else assert.ok(Math.abs(actual - expected) <= 1e-3, `${label}: ${actual} != ${expected}`); };

let validators;
async function schemas() {
  if (validators) return validators;
  const ajv = new Ajv2020({ allErrors: true, strict: false }); addFormats(ajv);
  for (const name of (await fsp.readdir(path.join(root, 'schemas'))).filter((n) => n.endsWith('.json'))) ajv.addSchema(await readJson(path.join(root, 'schemas', name)));
  const get = (name) => ajv.getSchema(`https://schemas.course-memory.local/v1/${name}.schema.json`);
  validators = { track: get('transcript-track'), job: get('pipeline-job'), text: (v) => ajv.errorsText(v.errors) };
  return validators;
}

/** Builds a sandbox with recordings/ and imports/ folders, fake media files and a runner. */
async function setup({ files = [], kind = 'video', utterances = [], providerOptions = {}, fail = {}, runnerOptions = {} } = {}) {
  const base = await tmp('run'); const folder = path.join(base, kind === 'import' ? 'imports' : 'recordings');
  await fsp.mkdir(path.join(base, 'recordings'), { recursive: true }); await fsp.mkdir(path.join(base, 'imports'), { recursive: true });
  const media = new Map(); const paths = [];
  for (const file of files) {
    const full = path.join(folder, file.name); await fsp.writeFile(full, `fixture media ${file.name} ${file.durationSec}`);
    media.set(path.resolve(full), file); paths.push(full);
  }
  const fake = createFakeMedia({ media, fail });
  const provider = createFakeProvider({ utterances, ...providerOptions });
  const logs = []; const logger = { info: (v) => logs.push(v), warn: (v) => logs.push(v), error: (v) => logs.push(v) };
  const make = (extra = {}) => createPipelineRunner({ dataDir: path.join(base, 'data'), workRoot: path.join(base, 'work'), allowedRoots: [path.join(base, 'recordings'), path.join(base, 'imports')], run: fake.run, provider, logger, ...runnerOptions, ...extra });
  return { base, paths, fake, provider, logs, runner: make(), make };
}

async function scenarioFixtures() {
  const dir = path.join(root, 'fixtures', 'pipeline', 'scenarios');
  return Promise.all((await fsp.readdir(dir)).filter((n) => n.endsWith('.json')).sort().map((n) => readJson(path.join(dir, n))));
}

test('P4A scenarios: audio / video / import share one pipeline and land on correct rec/src time', async () => {
  const { track: validateTrack, job: validateJob, text } = await schemas();
  for (const fixture of await scenarioFixtures()) {
    const env = await setup({ files: fixture.files, kind: fixture.source, utterances: fixture.utterances });
    const { job: queued } = await env.runner.enqueue({ source: { kind: fixture.source }, files: env.paths, timeMap: fixture.timeMap ?? undefined });
    await env.runner.idle();
    const job = await env.runner.get(queued.id);
    const tag = fixture.name;
    assert.equal(job.status, 'completed', `${tag}: ${JSON.stringify(job.error)}`);
    assert.equal(validateJob(job), true, `${tag} job schema: ${text(validateJob)}`);
    const assetDir = path.join(env.base, 'work', job.result.assetDir);
    const track = await readJson(path.join(assetDir, 'transcript.json'));
    assert.equal(validateTrack(track), true, `${tag} track schema: ${text(validateTrack)}`);
    assert.equal(track.revision, 1); assert.equal(track.timeBase.strategy, fixture.expect.strategy, tag);
    if (fixture.expect.timeMapSource) assert.equal(track.timeBase.timeMapSource, fixture.expect.timeMapSource, tag);
    assert.equal(track.engine.tempoNormalized, fixture.expect.strategy === 'per-span', tag);
    assert.equal(track.segments.length, fixture.expect.segments.length, `${tag} segments ${JSON.stringify(track.segments.map((s) => s.text))}`);
    fixture.expect.segments.forEach((expected, index) => {
      const actual = track.segments[index];
      assert.equal(actual.id, `s${String(index + 1).padStart(4, '0')}`);
      assert.equal(actual.text, expected.text, tag); assert.equal(actual.pass, expected.pass, `${tag} pass`);
      close(actual.rec[0], expected.rec[0], `${tag} rec0`); close(actual.rec[1], expected.rec[1], `${tag} rec1`);
      close(actual.src[0], expected.src[0], `${tag} src0`); close(actual.src[1], expected.src[1], `${tag} src1`);
      // Independent check: every mapped segment agrees with the TimeMap itself.
      if (fixture.timeMap?.spans) close(recToSrc(actual.rec[0], fixture.timeMap.spans), actual.src[0], `${tag} recToSrc`);
    });
    const prepare = job.stages.find((s) => s.name === 'prepare').outputs;
    if (fixture.expect.atempo) assert.deepEqual(prepare.pieces.map((p) => p.atempo), fixture.expect.atempo, tag);
    const trackStats = job.stages.find((s) => s.name === 'track').outputs.stats;
    for (const [kind, count] of Object.entries(fixture.expect.excluded || {})) assert.equal(trackStats.excluded[kind], count, `${tag} excluded ${kind}`);
    if (fixture.expect.splitByWords) assert.equal(trackStats.splitByWords, fixture.expect.splitByWords, tag);
    const subs = job.stages.find((s) => s.name === 'subtitles').outputs;
    assert.equal(subs.recCues, fixture.expect.recCues, `${tag} rec cues`); assert.equal(subs.srcCues, fixture.expect.srcCues, `${tag} src cues`);
    assert.equal(subs.srcOverlaps, fixture.expect.srcOverlaps ?? 0, `${tag} overlaps`);
    for (const name of ['transcript.rec.srt', 'transcript.src.srt']) assert.ok((await fsp.readFile(path.join(assetDir, name), 'utf8')).startsWith('﻿'), `${tag} ${name} BOM`);
    // Raw Whisper output is kept separately and its hash is recorded on the track.
    const raw = await readJson(path.join(assetDir, track.raw.file));
    assert.ok(Array.isArray(raw.segments)); assert.equal(raw.segments.length <= fixture.utterances.length, true);
    // Every child process got an argument array, with media paths behind the file: protocol.
    for (const call of env.fake.calls) for (const arg of call.args) if (env.paths.some((p) => arg.includes(path.basename(p)))) assert.ok(arg.startsWith('file:'), `${tag} unprefixed path arg ${arg}`);
    if (fixture.expect.concatInputs) { const extract = env.fake.calls.find((c) => c.command === 'ffmpeg' && !c.args.includes('-ss')); assert.ok(extract.args.includes(`[0:a:0][1:a:0]concat=n=${fixture.expect.concatInputs}:v=0:a=1[aout]`), tag); }
    if (fixture.expect.strategy === 'direct') assert.equal(env.fake.calls.filter((c) => c.args.includes('-ss')).length, 0, `${tag} direct must not cut pieces`);
    else assert.equal(env.fake.calls.filter((c) => c.args.includes('-ss')).length, fixture.expect.atempo.length, `${tag} one cut per play span`);
    assert.equal(JSON.stringify(env.logs).includes(env.base), false, `${tag} logs must not contain paths`);
  }
});

test('non-1x recordings are never tempo-corrected with a single global speed', async () => {
  const fixture = (await scenarioFixtures()).find((f) => f.name === 's04-rate-change-with-pause');
  const env = await setup({ files: fixture.files, utterances: fixture.utterances });
  await env.runner.enqueue({ source: { kind: 'video' }, files: env.paths, timeMap: fixture.timeMap }); await env.runner.idle();
  const cuts = env.fake.calls.filter((c) => c.args.includes('-ss'));
  assert.deepEqual(cuts.map((c) => [c.args[c.args.indexOf('-ss') + 1], c.args[c.args.indexOf('-t') + 1], c.args[c.args.indexOf('-af') + 1]]), [['0.000', '20.000', 'atempo=0.666667'], ['25.000', '20.000', 'atempo=0.5']]);
  const extract = env.fake.calls.find((c) => c.command === 'ffmpeg' && !c.args.includes('-ss'));
  assert.equal(extract.args.some((a) => a.includes('atempo')), false, 'the whole-file extraction never changes tempo');
});

test('stageKey dedupe: the same media, params and version are not processed again', async () => {
  const fixture = (await scenarioFixtures()).find((f) => f.name === 's08-import-identity');
  const env = await setup({ files: fixture.files, kind: 'import', utterances: fixture.utterances });
  const first = await env.runner.enqueue({ source: { kind: 'import' }, files: env.paths }); await env.runner.idle();
  const callsAfterFirst = env.fake.calls.length;
  const second = await env.runner.enqueue({ source: { kind: 'import' }, files: env.paths }); await env.runner.idle();
  assert.notEqual(second.job.id, first.job.id);
  const job = await env.runner.get(second.job.id);
  assert.equal(job.status, 'completed'); assert.ok(job.stages.every((s) => s.reused === true), 'every stage reused');
  assert.equal(env.fake.calls.length, callsAfterFirst, 'no ffprobe/ffmpeg call the second time');
  assert.equal(env.provider.state.calls, 1, 'Whisper ran once');
  assert.deepEqual(job.stages.map((s) => s.stageKey), (await env.runner.get(first.job.id)).stages.map((s) => s.stageKey));
  // A different parameter (language) produces new keys from transcribe onward only.
  const third = await env.runner.enqueue({ source: { kind: 'import' }, files: env.paths, options: { language: 'en' } }); await env.runner.idle();
  const t = await env.runner.get(third.job.id);
  assert.deepEqual(t.stages.map((s) => Boolean(s.reused)), [true, true, true, false, false, false]);
  assert.equal(env.provider.state.calls, 2);
  // The first raw output was not overwritten by the second run.
  const dirs = (await fsp.readdir(path.join(env.base, 'work', 'assets', job.asset.id, 'stages'))).filter((d) => d.startsWith('transcribe-'));
  assert.equal(dirs.length, 2);
});

test('the same media cannot run twice at once; an active job is returned instead', async () => {
  let release; const hold = new Promise((resolve) => { release = resolve; });
  const env = await setup({ files: [{ name: 'a.mkv', durationSec: 10, audio: true, video: true }], utterances: [{ rec: [1, 2], text: 'x' }], providerOptions: { hold } });
  const a = await env.runner.enqueue({ source: { kind: 'video' }, files: env.paths, timeMap: { source: 'none' } });
  const b = await env.runner.enqueue({ source: { kind: 'video' }, files: env.paths, timeMap: { source: 'none' } });
  assert.equal(b.deduplicated, true); assert.equal(b.job.id, a.job.id);
  release(); await env.runner.idle();
  assert.equal((await env.runner.list()).length, 1);
});

test('GPU Whisper stage is single-concurrency across different media', async () => {
  let release; const hold = new Promise((resolve) => { release = resolve; });
  const env = await setup({ files: [{ name: 'a.mkv', durationSec: 10, audio: true, video: true }, { name: 'b.mkv', durationSec: 12, audio: true, video: true }], utterances: [{ rec: [1, 2], text: 'x' }], providerOptions: { hold } });
  await env.runner.enqueue({ source: { kind: 'video' }, files: [env.paths[0]], timeMap: { source: 'none' } });
  await env.runner.enqueue({ source: { kind: 'video' }, files: [env.paths[1]], timeMap: { source: 'none' } });
  // Probe/audio/prepare perform real async file work before the held Whisper call. Wait for the observable
  // entry condition instead of assuming a fixed number of event-loop turns is enough on a busy Windows disk.
  const deadline = Date.now() + 2000;
  while ((env.provider.state.calls < 1 || env.runner.activeCount < 2) && Date.now() < deadline) await new Promise((resolve) => setTimeout(resolve, 5));
  assert.equal(env.runner.activeCount, 2, 'both jobs are running'); assert.equal(env.provider.state.calls, 1, 'only one is inside Whisper');
  release(); await env.runner.idle();
  assert.equal(env.provider.state.maxConcurrent, 1); assert.equal(env.provider.state.calls, 2);
});

test('a mid-run failure keeps completed stages; retry resumes at the failed stage', async () => {
  const env = await setup({ files: [{ name: 'a.mkv', durationSec: 10, audio: true, video: true }], utterances: [{ rec: [1, 2], text: 'x' }], providerOptions: { fail: { times: 1, code: 'WHISPER_FAILED' } } });
  const { job } = await env.runner.enqueue({ source: { kind: 'video' }, files: env.paths, timeMap: { source: 'none' } }); await env.runner.idle();
  let failed = await env.runner.get(job.id);
  assert.equal(failed.status, 'failed'); assert.deepEqual(failed.error, { stage: 'transcribe', code: 'WHISPER_FAILED', message: 'WHISPER_FAILED' });
  assert.deepEqual(failed.stages.map((s) => s.status), ['completed', 'completed', 'completed', 'failed', 'queued', 'queued']);
  const before = env.fake.calls.length;
  await env.runner.retry(job.id); await env.runner.idle();
  const done = await env.runner.get(job.id);
  assert.equal(done.status, 'completed'); assert.equal(env.fake.calls.length, before, 'ffprobe/ffmpeg not repeated');
  assert.equal(done.stages.find((s) => s.name === 'transcribe').attempts, 2); assert.equal(done.stages.find((s) => s.name === 'audio').attempts, 1);
  failed = null;
});

test('after a restart an interrupted job resumes from its unfinished stage', async () => {
  const hold = new Promise(() => {}); // the "crashed" process never finishes Whisper
  const env = await setup({ files: [{ name: 'a.mkv', durationSec: 10, audio: true, video: true }], utterances: [{ rec: [1, 2], text: 'resumed' }], providerOptions: { hold } });
  const { job } = await env.runner.enqueue({ source: { kind: 'video' }, files: env.paths, timeMap: { source: 'none' } });
  for (let i = 0; i < 200 && env.provider.state.calls < 1; i += 1) await new Promise((r) => setTimeout(r, 2));
  const onDisk = await readJson(path.join(env.base, 'data', 'jobs', `${job.id}.json`));
  assert.equal(onDisk.status, 'running'); assert.equal(onDisk.currentStage, 'transcribe');
  // "Restart": a new runner over the same data, with a working provider and a fresh call log.
  const media = env.fake.media; const fake2 = createFakeMedia({ media }); const provider2 = createFakeProvider({ utterances: [{ rec: [1, 2], text: 'resumed' }] });
  const restarted = createPipelineRunner({ dataDir: path.join(env.base, 'data'), workRoot: path.join(env.base, 'work'), allowedRoots: [path.join(env.base, 'recordings')], run: fake2.run, provider: provider2 });
  assert.deepEqual(await restarted.recover(), [job.id]); await restarted.idle();
  const done = await restarted.get(job.id);
  assert.equal(done.status, 'completed'); assert.equal(fake2.calls.length, 0, 'probe / audio / prepare were not redone');
  assert.equal(provider2.state.calls, 1); assert.ok(done.events.some((e) => e.event === 'job_recovered'));
  assert.equal(done.stages.find((s) => s.name === 'transcribe').interrupted, true);
});

test('cancel stops a running job and keeps finished stages', async () => {
  const hold = new Promise(() => {});
  const env = await setup({ files: [{ name: 'a.mkv', durationSec: 10, audio: true, video: true }], providerOptions: { hold } });
  const { job } = await env.runner.enqueue({ source: { kind: 'video' }, files: env.paths, timeMap: { source: 'none' } });
  for (let i = 0; i < 200 && env.provider.state.calls < 1; i += 1) await new Promise((r) => setTimeout(r, 2));
  const cancelled = await env.runner.cancel(job.id);
  assert.equal(cancelled.status, 'cancelled');
  assert.deepEqual(cancelled.stages.map((s) => s.status), ['completed', 'completed', 'completed', 'cancelled', 'queued', 'queued']);
});

test('media problems fail safely with explicit codes', async () => {
  const cases = [
    { name: 'no audio track', files: [{ name: 'mute.mp4', durationSec: 5, audio: false, video: true }], code: 'NO_AUDIO_TRACK', stage: 'probe' },
    { name: 'audio source that contains video', kind: 'audio', files: [{ name: 'fake-audio.mkv', durationSec: 5, audio: true, video: true }], code: 'NOT_AUDIO_ONLY', stage: 'probe' },
    { name: 'ffprobe missing', files: [{ name: 'a.mkv', durationSec: 5, audio: true, video: true }], fail: { ffprobe: 'COMMAND_NOT_FOUND' }, code: 'FFPROBE_UNAVAILABLE', stage: 'probe' },
    { name: 'ffmpeg missing', files: [{ name: 'a.mkv', durationSec: 5, audio: true, video: true }], fail: { extract: 'COMMAND_NOT_FOUND' }, code: 'FFMPEG_UNAVAILABLE', stage: 'audio' },
    { name: 'ffmpeg fails', files: [{ name: 'a.mkv', durationSec: 5, audio: true, video: true }], fail: { extract: 'PROCESS_FAILED' }, code: 'FFMPEG_FAILED', stage: 'audio' },
    { name: 'whisper unavailable', files: [{ name: 'a.mkv', durationSec: 5, audio: true, video: true }], providerOptions: { fail: 'FASTER_WHISPER_UNAVAILABLE' }, code: 'FASTER_WHISPER_UNAVAILABLE', stage: 'transcribe' }
  ];
  for (const item of cases) {
    const env = await setup({ files: item.files, kind: item.kind || 'video', fail: item.fail || {}, providerOptions: item.providerOptions || {} });
    const { job } = await env.runner.enqueue({ source: { kind: item.kind || 'video' }, files: env.paths, timeMap: { source: 'none' } }); await env.runner.idle();
    const result = await env.runner.get(job.id);
    assert.equal(result.status, 'failed', item.name); assert.equal(result.error.code, item.code, item.name); assert.equal(result.error.stage, item.stage, item.name);
    const originals = await Promise.all(env.paths.map((p) => fsp.readFile(p, 'utf8')));
    originals.forEach((text, i) => assert.ok(text.startsWith('fixture media'), `${item.name}: original ${i} untouched`));
  }
});

test('inputs must stay inside the configured folders', async () => {
  const env = await setup({ files: [{ name: 'a.mkv', durationSec: 5, audio: true, video: true }] });
  const outside = path.join(env.base, 'secret.mkv'); await fsp.writeFile(outside, 'x');
  const attempts = [outside, path.join(env.base, 'recordings', '..', 'secret.mkv'), path.join(env.base, 'recordings', 'missing.mkv')];
  for (const file of attempts) await assert.rejects(env.runner.enqueue({ source: { kind: 'video' }, files: [file] }), (e) => e.code === 'PATH_NOT_ALLOWED', file);
  const link = path.join(env.base, 'recordings', 'link.mkv');
  let linked = true; try { await fsp.symlink(outside, link); } catch { linked = false; }
  if (linked) await assert.rejects(env.runner.enqueue({ source: { kind: 'video' }, files: [link] }), (e) => e.code === 'PATH_NOT_ALLOWED');
  await assert.rejects(env.runner.enqueue({ source: { kind: 'video' }, files: env.paths, timeMap: { source: 'identity' } }), (e) => e.code === 'INVALID_TIMEMAP', 'only owned imports may assume src = rec');
  await assert.rejects(env.runner.enqueue({ source: { kind: 'video' }, files: env.paths, timeMap: { source: 'recording', spans: [{ recStart: 0, recEnd: 10, srcStart: 0, srcEnd: 99, rate: 1, kind: 'play' }] } }), (e) => e.code === 'INVALID_TIMEMAP');
  await assert.rejects(env.runner.enqueue({ source: { kind: 'stream' }, files: env.paths }), (e) => e.code === 'INVALID_SOURCE');
  await assert.rejects(env.runner.enqueue({ source: { kind: 'video' }, files: env.paths, options: { language: 'fr' } }), (e) => e.code === 'INVALID_OPTIONS');
});

test('intake: recording sessions, imports and watcher entries all become pipeline jobs', async () => {
  const fixture = (await scenarioFixtures()).find((f) => f.name === 's13-audio-segmented-1x');
  const env = await setup({ files: fixture.files, kind: 'audio', utterances: fixture.utterances });
  const session = { id: 'rec_aaaaaaaaaaaa', status: 'completed', captureMode: 'audio', obsOutputPath: env.paths[1], obsOutputFiles: env.paths, timeMap: { quality: 'ok', spans: fixture.timeMap.spans } };
  assert.deepEqual(jobInputFromSession(session).files, env.paths);
  assert.throws(() => jobInputFromSession({ ...session, status: 'recording' }), (e) => e.code === 'SESSION_NOT_READY');
  const sessions = [session];
  const intake = createIntake({ pipeline: env.runner, findSessions: async () => sessions });
  // The watcher reports each segment file separately; both resolve to the one session job.
  const first = await intake.fromWatchEntry({ kind: 'audio-capture', file: env.paths[0] });
  const second = await intake.fromWatchEntry({ kind: 'audio-capture', file: env.paths[1] });
  assert.equal(second.job.id, first.job.id); assert.equal(first.job.source.recordingSessionId, session.id);
  sessions[0] = { ...session, id: 'rec_bbbbbbbbbbbb', status: 'recording' };
  await env.runner.idle();
  const other = path.join(env.base, 'recordings', 'growing.flac'); await fsp.writeFile(other, 'x');
  sessions.push({ id: 'rec_cccccccccccc', status: 'recording', captureMode: 'audio', obsOutputFiles: [other] });
  assert.deepEqual(await intake.fromWatchEntry({ kind: 'audio-capture', file: other }), { deferred: true, reason: 'SESSION_NOT_READY' });
  const done = await env.runner.get(first.job.id);
  assert.equal(done.status, 'completed'); assert.equal(done.source.kind, 'audio');
});
