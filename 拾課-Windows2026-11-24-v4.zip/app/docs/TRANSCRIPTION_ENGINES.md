# 轉錄引擎：faster-whisper 與 whisper.cpp 備援

## 為什麼需要備援

2026-11 的實際環境：Windows「智慧型應用程式控制」（Smart App Control，強制模式）擋下了未簽章的 `ctranslate2.dll`（`WinError 4551`），faster-whisper 因此完全無法載入。

本程式**不會**、也**不建議**關閉 Smart App Control、Defender 或任何 Windows 安全功能。

FFmpeg 8 起內建 whisper.cpp（`whisper` 音訊濾鏡），gyan.dev 的 full build 也包含它。ffmpeg 本身已經被 Windows 允許執行，所以備援不需要安裝任何新的 .exe 或 DLL，只需要一個 ggml 模型檔。模型檔是純資料，不會被執行。

## 設定（設定頁 →「轉錄（Whisper）」）

| `transcriber` | 行為 |
|---|---|
| `auto`（預設） | 先用 faster-whisper。只有在它**無法在這台電腦執行**時，才改用 whisper.cpp。 |
| `faster-whisper` | 只用 faster-whisper。 |
| `whisper.cpp` | 只用 whisper.cpp。 |

「無法在這台電腦執行」指的是以下幾種情況：

- 未安裝；
- DLL 被應用程式控制擋下；
- DLL 載入失敗；
- 找不到 Python。

`whisperCppBackend` 的選項：

- `auto`：有 whisper-cli 就用它，否則用 ffmpeg 內建的濾鏡。
- `ffmpeg`
- `cli`

模型檔的尋找順序：

1. `whisperCppModel`（若有設定且檔案存在）；
2. `models/whisper/ggml-<whisperModel>.bin`，例如 `ggml-small.bin`。

## 切換規則（不會反覆切換）

- 只有「引擎無法在這台電腦執行」才會切換，而且每次轉錄最多切換一次：
  - **會切換的錯誤**：`ENGINE_BLOCKED`、`ENGINE_LOAD_FAILED`、`FASTER_WHISPER_UNAVAILABLE`、找不到執行檔。
  - **不會切換的錯誤**：引擎能載入但轉錄失敗（`WHISPER_FAILED`）、逾時、輸出無法解析。這些都直接回報失敗。
- 切換後會記住「faster-whisper 被擋」，之後的工作直接用 whisper.cpp，不再先跑一次注定失敗的啟動。
- 設定頁的檢查若發現 faster-whisper 又能載入了，會清除這個記憶。
- whisper.cpp 失敗時就回報失敗，不會再切回 faster-whisper。
- 備援引擎也無法執行時，回報明確的原因與安裝指引，絕不假裝成功：
  - `WHISPER_CPP_MODEL_MISSING`
  - `WHISPER_CPP_FILTER_MISSING`
  - `WHISPER_FALLBACK_UNAVAILABLE`

## 輸出統一

- 兩個引擎都輸出同一份 raw 格式，再由同一個 `buildTranscriptTrack` 產生 TranscriptTrack，所以 segment id（`s0001`…）、rec／src 時間與字幕都走同一條路。
- ffmpeg 濾鏡的 JSON 是一行一個 `{start, end, text[, language]}`，時間單位為毫秒。
  - 濾鏡不會跳脫文字裡的引號，所以無法直接解析的行，改用嚴格的格式比對；兩種都不符就回報 `WHISPER_OUTPUT_INVALID`。
  - `[BLANK_AUDIO]`、`[MUSIC]` 這類標記不算語音。
  - 整段沒有語音時是空逐字稿，之後由知識整理判定為 `KNOWLEDGE_TRANSCRIPT_EMPTY`，不算引擎故障。
- 語言：要求的語言（zh／en）原樣傳給引擎。
  - 「自動」時，只有引擎實際回報的語言才會記錄。ffmpeg 9.0.2 的濾鏡不回報語言，所以 `detectedLanguage` 為 null，絕不猜測。
- whisper.cpp 不提供 avgLogprob、noSpeechProb 與逐字時間，這些欄位維持 null。
- 實際使用的引擎記錄在以下位置，處理中心與課程都看得到：
  - 轉錄階段的 `outputs.engine`；
  - TranscriptTrack 的 `engine { name, model, backend, fallbackFrom, fallbackReason }`。

## 重試與重複處理

- 按「重試」時，未完成的階段改用目前的設定重新計算 stageKey，原本的值留在 `previousStageKey`；已完成的探測、音訊擷取直接沿用，不重新複製或擷取影片。
- 同一媒體同時只會有一個工作（`mediaKey` 鎖），而且轉錄的重工作只有一個名額，所以兩個引擎不會同時處理同一媒體。
- 發布課程以工作 id 與媒體為準：重試或重新同步會更新同一筆課程，不會多出第二筆。

## 隱私

- 錯誤訊息、處理中心與設定頁只顯示代碼、繁中說明與模型檔名，不顯示完整路徑、Windows 使用者名稱或金鑰。
- 模型路徑只會作為參數傳給 ffmpeg，不會寫進紀錄。

## 取得模型

- **來源**：whisper.cpp 官方模型庫，Hugging Face 上的 `ggerganov/whisper.cpp`。
- **建議檔案**：`ggml-small.bin`，487,601,967 bytes，SHA256 `1be3a9b2063867b937e64e2ec7483364a79917e157fa98c5d94b5c1fffea987b`。
- **放置位置**：`models\whisper\`（已列入 .gitignore）。
