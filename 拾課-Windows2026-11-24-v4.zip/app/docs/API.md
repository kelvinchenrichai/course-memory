# Local API

The server listens on `127.0.0.1:4317` only.

- `GET /api/status` — environment and feature availability.
- `GET /api/courses` — local course index.
- `GET /api/search?q=` — transcript search.
- `GET|POST /api/queue` — learning queue.
- `POST /api/queue/:id/complete` — complete a queue item.
- `GET /api/agent/state` — compact state for agents.
- `POST /api/ingest/url` — rights-gated URL ingest job.
- `GET /api/clips/suggestions?courseId=` — candidate segments.
- `POST /api/clips/export` — render a clip job.
- `POST /api/cloud/backup` — compatibility alias that queues the allow-listed private backup service; caller-supplied destinations and modes are ignored.
- `GET /api/jobs` — background-job states.

Mutation endpoints accept JSON. External publication is intentionally not implemented in v0.2.

## Agent（P3B）

只接受本機 UI 或沒有 Origin 的請求；Host 必須是 localhost；POST 必須是 JSON。

- `POST /api/agent/jobs`：建立草稿。
- `POST /api/agent/jobs/:id/confirmation`：取得確認摘要與 `planHash`。
- `POST /api/agent/jobs/:id/confirm` `{ planHash, acknowledgements: { recordPermission, privateProcessing } }`：使用者確認。
- `POST /api/agent/jobs/:id/start`：開始，回 202，工作在背景執行。
- `POST /api/agent/jobs/:id/pause`：暫停，進入 blocked（`USER_PAUSED`）。
- `POST /api/agent/jobs/:id/cancel`：取消。
- `POST /api/agent/jobs/:id/resume`：使用者手動繼續，回 202。
- `GET /api/agent/jobs/:id`：查詢工作狀態。
- `GET /api/agent/companion`：查詢 Companion 狀態，回應中不含 token。

## Companion（P3B）

採 HTTP long polling。擴充功能的請求必須帶 `Origin: chrome-extension://<id>`；配對後還需要 `x-companion-token` header，且 token 只對配對時的 origin 有效。

- 本機 UI 使用：
  - `POST /api/companion/pairing-code`：產生 6 位數配對碼，2 分鐘內有效、只能用一次。
  - `GET /api/companion/status`
  - `DELETE /api/companion/pairing`
- 擴充功能使用：
  - `POST /api/companion/pair`：回傳 token，只在這一次回應中出現。
  - `POST /api/companion/heartbeat`：回報 `{ online, extensionVersion }`。
  - `POST /api/companion/tabs`
  - `POST /api/companion/state`
  - `GET /api/companion/commands?waitMs=`：每個命令只交付一次，附 `commandId`、`instanceId`、`ttlMs`。
  - `POST /api/companion/commands/:commandId/result`：200 為接受；409 為重複或逾時後才到；410 為舊的伺服器 instance；404 為未知命令。
  - `POST /api/companion/unpair`

## 設定、環境、處理中心、學習時段（P4C）

所有路由都只接受：Host 為 localhost；Origin 為空或本機 UI；瀏覽器若送出 `Sec-Fetch-Site`，必須是 `same-origin` 或 `none`；POST／PUT 必須是 `application/json`。

- `GET /api/settings`：可編輯的設定值與選項。金鑰與 OBS 密碼只會回 `{ configured: true|false }`。
- `PUT /api/settings` `{ values: { … }, secrets: { openaiApiKey: { set } | { clear: true }, … } }`：
  - 只接受白名單鍵（學習模式、轉錄、AI 提供者與模型、`openaiBaseUrl`（限 https）、`ollamaUrl`／`obsUrl`（限本機））。
  - 資料夾、執行檔路徑與指令一律不能從瀏覽器修改。
  - 寫入 git-ignore 的 `config.json`；回應會附 `changed` 與 `restartRequired`。
- `GET /api/environment[?refresh=1]`：後端實測 OBS（是否安裝、WebSocket 是否連得上）、ffmpeg、Whisper、AI、雲端備份與兩種學習模式能否使用。回應不含路徑、密碼、金鑰或裝置名稱。
  - `whisper`：`{ mode, active, ready, model, version, backend, fallbackInUse, code, reason, advice, fasterWhisper, whisperCpp }`。
    - `mode` 是設定的 `auto`／`faster-whisper`／`whisper.cpp`；`active` 是實際會使用的引擎（都不能用時為 null）。
    - `fasterWhisper { ready, code, reason, advice, version, model, winerror? }`：用 `scripts/transcribe.py --check` 實際載入（包含 ctranslate2.dll）並呼叫一次原生函式。`code` 為 `ENGINE_BLOCKED`（Windows 應用程式控制擋下）、`ENGINE_LOAD_FAILED`、`FASTER_WHISPER_UNAVAILABLE`、`PYTHON_NOT_FOUND` 或 `ENGINE_CHECK_TIMEOUT`。
    - `whisperCpp { ready, code, reason, advice, backend: 'ffmpeg'|'cli'|null, filter, cli, modelPresent, model }`：`code` 為 `WHISPER_CPP_MODEL_MISSING`、`WHISPER_CPP_FILTER_MISSING`、`WHISPER_CPP_UNAVAILABLE` 或 `FFMPEG_UNAVAILABLE`。
    - `reason`／`advice` 為繁中說明；只有模型檔名，沒有路徑。
- `POST /api/courses/:id/archive`、`POST /api/courses/:id/unarchive` `{ confirm: true }`：封存／取消封存課程紀錄。
  - 只加上 `archived`／`archivedAt`：不刪除 course.json、逐字稿、錄影或雲端備份；封存的課程不再出現在處理中心，課程清單預設隱藏。
  - 需要本機同源請求（`checkLocalRequest`）；沒有 `confirm: true` 回 400；處理中的課程回 409 `COURSE_BUSY`。
- `GET /api/processing`：聚合 Agent 工作、P4A 管線、知識整理、目前學習時段與舊版背景工作。
  - 每項分五個階段：錄製／音訊擷取 → 音訊處理 → 轉錄 → 字幕 → 知識整理。
  - 每個階段的狀態是 `waiting`、`running`、`done`、`needs-user` 或 `skipped`，並附錯誤原因與建議。
- `POST /api/processing/:jobId/retry`：重試失敗或已取消的管線工作；已完成的階段不會重做。
- `GET /api/learning`：目前的學習時段（不含檔案路徑）。
- `POST /api/learning/start` `{ mode: "video"|"audio", recordPermissionAcknowledged: true, manualTimer? }`：
  - 錄影模式由 OBS WebSocket 開始錄影，OBS 確認後才算開始。
  - `manualTimer` 只計時、不控制 OBS。
  - 錄音模式錄下在設定中選定的裝置。
- `POST /api/learning/stop`：停止錄影或錄音。錄音檔會自動送進 P4A 管線。

## 雲端備份（P4D）

這些端點沿用 P4C 的檢查：只接受 localhost、同源請求，POST／PUT 必須是 JSON。回應裡沒有本機路徑、雲端帳號或完整遠端路徑。

- `GET /api/backup`：查詢備份狀態，內容包括：
  - 目的地標籤（例如「Google Drive · CourseMemory」）
  - 連線狀態
  - 清理策略、空間警戒值、剩餘空間
  - 各狀態的檔案數量、可安全清理的容量
  - 每堂課的進度
- `POST /api/backup/check`：重新檢查 rclone 是否可用，以及遠端能不能連上。
- `GET /api/backup/remotes`：列出已設定的 rclone 遠端，只回傳 `{ name, type }`。
- `POST /api/backup/run` `{ courseId? }`：開始一輪備份，回 202。
- `POST /api/backup/retry` `{ courseId? }`：把失敗的檔案重新排隊，再開始備份，回 202。
- `POST /api/backup/cleanup` `{ courseId?, confirm: true }`：刪除已在雲端驗證過的本機原檔。清理策略為 `never` 時回 409。
- `PUT /api/backup/settings` `{ destination?, cleanupPolicy?, autoUpload?, warnFreeGb? }`：修改備份設定。
  - `destination` 必須是已存在的 rclone 雲端遠端，格式為 `遠端名稱:資料夾`。
  - 不接受本機路徑，也不接受 `local`／`alias` 類型的遠端。

本階段只做私人備份：沒有分享、公開連結，或修改雲端權限的端點。

## Agent 學習主控台（P5）

這些端點是現有 Agent service 的最小橋接層。每個操作都對應到 Runner 原本的 draft、confirmation、confirm、start、pause、resume、cancel、getJob。

- **安全檢查**：沿用 P4C 的守門。Host 必須是 localhost，Origin 必須同源，`Sec-Fetch-Site` 必須是 same-origin 或 none，POST 必須是 JSON。
- **回應內容**：不含網址、cookie、token、密碼或本機路徑。

端點：

- `GET /api/agent-console`：回傳 Companion 準備狀態，以及最近 30 個任務的即時檢視。即時檢視包含：
  - 目前課程與章節
  - 原影片時間、錄製時間、倍速
  - 完成進度與 checkpoint
  - 停止原因的繁中說明
  - 目前可以執行的操作
- `POST /api/agent-console/plans`：建立 draft 並取得確認摘要，回 201。主體格式：

  ```
  { courses: [{ title, rightsBasis, lessons: [{ url, title?, minutes? }], from, to }],
    captureMode, rate, captions: { enabled }, transcriptLanguage, translationLanguage }
  ```

  - 只接受課程頁網址。影片檔網址、CDN 串流網址、含帳密的網址、含 token 或簽章參數的網址一律拒絕。
  - YouTube 網址會換成 `watch?v=<id>` 格式。
  - 回應包含影片數、預估時間、預估空間、錄製模式，以及每個平台「Agent 會自動做的事」和「需要你操作的事」。
- `POST /api/agent-console/jobs/:id/confirm` `{ planHash, acknowledgements: { recordPermission, privateProcessing } }`：
  - 兩項確認都勾選時，才會建立「私人學習」授權紀錄，再呼叫 Runner confirm。
  - 缺任何一項回 403 `RIGHTS_REQUIRED`。
- `POST /api/agent-console/jobs/:id/start | pause | resume | cancel`：
  - `pause` 是安全停止，任務會變成 blocked，停止原因為 `USER_PAUSED`。
  - `resume` 只能由使用者明確呼叫。
- `GET /api/agent-console/jobs/:id`：取得單一任務的即時檢視。

## P6 雙語逐字稿與翻譯（`/api/translations`）

所有路由都套用 P4C 本機防護：Host 必須是 localhost，Origin 只能是本機介面，`sec-fetch-site` 必須是 same-origin／none，POST 必須是 JSON。回應一律 `cache-control: no-store`，不含金鑰、本機完整路徑或原始請求內容。

- `GET /api/translations/:courseId?target=zh-Hant|en|none`
  - 回傳 `{ courseId, targetLanguage, preference, state, code, failedBatch, progress, provider, sourceLanguage, method, segments }`。
  - `state`：`none`、`running`、`needs-retry`、`completed`。
  - `segments` 只來自「完整」的結果：`[{ segmentId, translatedText }]`。新的嘗試失敗時，上一份完整結果仍保留。
  - `target=none` 只回傳這堂課的偏好（Agent 任務偏好優先，否則用設定的「預設翻譯語言」）。
- `POST /api/translations/:courseId` `{ "targetLanguage": "zh-Hant" | "en" | "none" }`
  - 回傳 202 `{ started, targetLanguage }`。會從已接受的批次續跑；`none` 不呼叫模型。
  - 錯誤碼：`INVALID_TARGET`（400）、`INVALID_COURSE`（400）、`COURSE_NOT_FOUND`（404）、`COURSE_NOT_READY`（409）。
- `GET /api/translations/search?q=`
  - 同時搜尋原文與已完成的繁中／英文翻譯。
  - 回傳 `[{ courseId, title, segmentId, start, clock, excerpt, lang: "original" | "translation", language }]`，最多 50 筆。
  - `start` 一律是錄影時間，翻譯命中也會跳回同一段。

翻譯失敗碼（`code`）：`TRANSLATION_PROVIDER_DISABLED`、`TRANSLATION_KEY_MISSING`、`TRANSLATION_AUTH_FAILED`、`TRANSLATION_RATE_LIMITED`、`TRANSLATION_MODEL_NOT_FOUND`、`TRANSLATION_UNAVAILABLE`、`TRANSLATION_TIMEOUT`、`TRANSLATION_NOT_JSON`、`TRANSLATION_MISSING_ID`、`TRANSLATION_UNKNOWN_ID`、`TRANSLATION_DUPLICATE_ID`、`TRANSLATION_ORDER_MISMATCH`、`TRANSLATION_BAD_TEXT`、`TRANSLATION_INTERRUPTED`。

輸出格式見 `schemas/translation-result.schema.json`（`cms.translation/1`），存放在 `data/translations/<courseId>/`。

## P7A 匯入課程清單（`/api/course-discovery`）

所有路由都套用 P4C 本機防護：Host 必須是 localhost，Origin 只能是本機介面，`sec-fetch-site` 必須是 same-origin／none，POST 必須是 JSON（64 KB 上限）。回應一律 `cache-control: no-store`，不含網址、cookie、權杖、密碼或本機路徑。

- `GET /api/course-discovery/platforms`：平台能力表。每個平台包含 `id`、`label`、`discovery`（`auto`／`semi`／`local`）、`capabilities { discover, navigate, rate, captions, autoNext }`、`automatic[]`、`needsUser[]`。
- `POST /api/course-discovery/scan` `{ scanId? }`
  - 透過已配對、已選定分頁的擴充功能送出唯讀的 `discover` 指令，讀取頁面上看得到的清單。不會播放、錄製或切換頁面。
  - 帶 `scanId` 表示同一頁重新讀取：只加入新項目，不會重複。
  - 回傳 `{ scanId, platform, courseTitle, pageHost, items: [{ id, index, title, durationSec|null, host, locked, alreadyPlanned }], counts { total, locked, alreadyPlanned, unknownDuration, rejected { sensitive, crossSite, invalid, media, unavailable, duplicate } }, partial, added, blocker }`。
  - 遇到登入、驗證、付費牆或無法辨識的頁面時，回傳 `blocker { code: LOGIN_REQUIRED | CAPTCHA | PAYWALL | UNRECOGNIZED_PAGE, title, next }`，`scanId` 為 null，什麼都不保存。
  - 錯誤碼：`COMPANION_NOT_PAIRED`、`COMPANION_DISCONNECTED`、`COMPANION_TAB_UNBOUND`、`COMPANION_TIMEOUT`、`DISCOVERY_FAILED`（皆為 409）；`SENSITIVE_URL`（400，頁面網址本身含有權杖或簽章參數）。
- `GET /api/course-discovery/scans/:scanId`：取回同一份清單（只存在記憶體，2 小時後過期）。
- `POST /api/course-discovery/preview` `{ scanId, selected[], captureMode, rate }`：回傳 `{ selected, estimate, duplicates[] }`，`estimate` 與 P5 確認畫面使用相同算法。
- `POST /api/course-discovery/plan` `{ scanId, selected[], captureMode, rate, captions, transcriptLanguage, translationLanguage, rightsBasis, title, acknowledgements { recordPermission, privateProcessing } }`
  - 兩項確認缺一就回 403 `RIGHTS_REQUIRED`，不建立任何東西。
  - 確認後呼叫 P5 console 的 `plan` 與 `confirm`，回傳 201 `{ job, summary }`。任務停在 `queued`，使用者在任務列表按「開始」才會播放與錄製。
  - 錯誤碼：`LOCKED_ITEM`、`UNKNOWN_ITEM`、`NOTHING_SELECTED`、`TOO_MANY`（上限 200）、`SCAN_NOT_FOUND`（404）。
- `GET /api/course-discovery/local`：列出錄影資料夾裡的影片檔，只有檔名、大小、時間，以及是否已在課程庫。
- `POST /api/course-discovery/local/scan`：交給既有的錄影資料夾掃描流程。瀏覽器不能指定任何本機路徑。

Companion 新增指令 `discover`（擴充功能 0.4.0）。結果在頁面內與伺服器端各經過一次欄位白名單；沒有新增任何瀏覽器權限。

## P7B 錄製完成後的增量雲端備份

`GET /api/backup`（P4D 既有路由）新增以下欄位：

- `recording[]`：仍在錄影的工作階段 `{ id, title, phase: "waiting-recording", phaseLabel }`。只是提示，沒有任何上傳。
- `courses[]` 每一項新增 `phase`、`phaseLabel`、`reason`、`code`、`provisional`：
  - `phase` 可能是：`waiting-recording` 等待錄影結束、`media-uploading` 媒體上傳中、`media-backed-up` 媒體已備份、`artifacts-uploading` 成果追加中、`complete` 完整備份、`needs-attention` 需要處理。
  - `provisional: true` 表示錄影已進入管線，但還沒發布成課程；課程代碼與日後發布時相同（`makeId("pipeline:" + assetId)`）。
  - `code` 例如 `KNOWLEDGE_TRANSCRIPT_EMPTY`、`PIPELINE_FAILED`、`MEDIA_CHANGED_AFTER_RECORDING`、`MEDIA_STILL_WRITING`。
- 單一檔案的 `status` 新增 `waiting`：檔案仍在寫入，或剛寫完還在安靜期內，穩定後才會上傳。
- `reclaimableBytes` 只計算「完整備份」的課程。

上傳順序與時機：

1. 錄影進入管線後（watcher 看到檔案穩定、錄製工作階段已結束），先上傳媒體。
2. 管線階段完成後追加：`track` 完成時上傳逐字稿（去除本機路徑的副本），`subtitles` 完成時上傳字幕。
3. 課程發布後上傳摘要與知識包，最後上傳 manifest。
4. 每個檔案上傳完後，會再檢查一次本機的大小與修改時間，接著比對雲端的大小與 MD5；任一不符就不算已備份。

本機清理（`cleanupPolicy`）只會處理 `complete` 的課程；在清理前一刻還會重新確認雲端的大小與 MD5。

本機驗收：`npm run e2e`（假的 ffmpeg 與 Whisper、本機資料夾充當 Google Drive、自寫句子），結束代碼 0 代表全部通過。

## P8 Companion 設定精靈與多平台連續學習

- `GET /api/agent-console/companion`：設定精靈的狀態。
  - 欄位：`paired`、`connected`、`tabSelected`、`site`、`sitePermission`、`browserOnline`、`extensionVersion`、`extensionOk`、`minExtensionVersion`、`platform { id, label, discovery }`、`playerBlocker`。
- `POST /api/agent-console/companion/test`：「測試連線」。
  - 只送出 Companion 的 `detect` 與 `getState` 兩個唯讀指令，不播放、不暫停、不切換影片、不錄影。
  - 成功時回傳：`{ ok, readOnly: true, testedAt, companion, adapter, platform { id, label, automatic[], needsUser[] }, player { found, title, currentTime, duration, rate, paused, captions, isPlaylist }, capabilities, blocker }`。
  - 無法測試時回傳 `{ ok: false, error: { code, title, next } }`，`code` 為 `COMPANION_NOT_PAIRED`、`COMPANION_DISCONNECTED`、`COMPANION_TAB_UNBOUND`、`COMPANION_TIMEOUT` 或 `COMPANION_UNAVAILABLE`。
- 任務的 `liveView` 新增：
  - `current.captionsOn`、`current.captionsAvailable`、`current.platform`；
  - `current.recording`：`recording`、`starting`、`maybe`（OBS 可能仍在錄）或 `idle`；
  - `next { index, title }`：下一部；
  - `automation { platform, automatic[], needsUser[] }`：哪些由 Agent 自動處理、哪些需要使用者操作。
- 新增停止碼 `PLAYBACK_BLOCKED`：瀏覽器擋下自動播放。請使用者在頁面上按一次播放，再按「繼續」。

既有規則不變：每次開啟下一部後都會核對課程代碼，不符就停在 `UNEXPECTED_LESSON`。遇到斷網、擴充功能中斷或程式重新啟動都會停下，一律要等使用者按「繼續」，不會自動恢復。

## P9 直播工作台（`/api/live`）

所有路由都使用和 P4C 相同的防護：Host 必須是本機、Origin 必須同源、`POST` 必須是 JSON。沒有任何路由會發布、分享、回傳本機路徑、cookie 或 token。

- `GET /api/live`：總覽。
  - 回傳 `{ now, disk { freeBytes, warnBytes, stopBytes }, cloud { state }, sources[], plans[], sessions[] }`。
  - session 欄位：`id`、`planId`、`status`、`segmentation`、`title`、`obs { state, startedByUs, mayStillBeRecording, websocketVersion }`、`recordedSeconds`、`segments[] { index, state, fileName, upload, verification, processing }`、`counts`、`preflight`、`blocker`、`stopReason`、`warnings[]`、`signals[]`、`candidates[]`、`actions { stop, cancel, resume, finish, marker }`。
  - 分段只有檔名（`fileName`），不會有完整路徑。
- `POST /api/live/sources`：建立直播來源。
  - 欄位：`name`、`pageUrl`、`contentType`（esports／trading／generic）、`purpose`（private-study／creator-candidate）、`defaultCaptureMode`、`acknowledgements { recordPermission, privateProcessing, derivativePermission }`。
  - 創作候選另需 `rightsBasis` 與 `evidence`。
  - 會拒絕：帶登入、簽章或 token 參數的網址，含帳密的網址，以及串流檔網址。
  - 其他欄位（例如 cookie、password）一律忽略，不會儲存。
- `POST /api/live/plans`：建立排程。
  - 欄位：`sourceId`、`title`、`timeZone`（IANA）、`startLocal`／`endLocal`（`YYYY-MM-DDTHH:mm`）、`prepareMinutes`（1–60）、`captureMode`、`segmentMinutes`（2–60，預設 10）、`backupAfterClose`、`enable`。
  - 錯誤碼：重疊回傳 `409 PLAN_OVERLAP`；DST 跳過的時間回傳 `LOCAL_TIME_NONEXISTENT`。
- `POST /api/live/plans/:id`：修改還沒開始的排程。
- `POST /api/live/plans/:id/enable|disable|cancel`：啟用、停用或取消排程。
- `POST /api/live/sessions/:id/<動作>`：
  - `stop`：立即安全停止。
  - `cancel`：開始錄影前取消。
  - `resume`：從暫停中恢復。只能在排程時間內，且 OBS 沒有在錄影；會重新做開播前檢查。
  - `finish { confirm: true, stopObs? }`：結束這場。`stopObs: true` 代表使用者明確確認 OBS 正在錄的就是這場。
  - `marker { note? }`：建立手動 `SignalEvent`。
  - `retry-backup`：只在 `BACKUP_FAILED` 或 `BACKUP_NOT_CONFIGURED` 時可用，重新排入備份並回到 processing。
  - `acknowledge`：只在 `SEGMENT_PATH_AMBIGUOUS` 或 `SEGMENT_PATH_UNKNOWN` 時可用。使用者確認已自行檢查錄影資料夾後，這場轉成 completed 並保留警告；那些檔案不會被上傳或刪除。
  - `repair-segment { segmentId, candidateId, confirm: true }`（確認時先計算候選檔的大小與 MD5 並記在分段上；備份上傳前必須完全一致，否則該項目 `blocked SOURCE_CHANGED`、不產生完成清單）：只在 `SEGMENT_PATH_DUPLICATE`、`SEGMENT_PATH_AMBIGUOUS` 或 `SEGMENT_PATH_UNKNOWN` 時可用，而且該分段必須有 `pathIssue`。
    - `candidateId` 是 `segments[].repairCandidates[].id`（12 位十六進位不透明 id），不接受路徑；沒有 `confirm: true` 回傳 400；分段不屬於這場或候選不存在回傳 409。
    - 成功後分段 `revision` 加 1、`owner` 為 `user-confirmed`，以新的 key（例如 `segment-003-r1.mkv`）重新備份；舊 key 在備份層標 `superseded` 並保留。
- session 新增 `backup { state, total, verified, failed, unresolved, interrupted }`：
  - `state` 的值為 `disabled`、`waiting`、`uploading`、`verified`、`failed` 或 `needs-repair`（有分段共用同一檔案）；另有 `duplicate` 計數；
  - 只有所有分段都 `verified`（或這場不備份）時，session 才會是 `completed`。
- 分段新增 `pathIssue`：`ambiguous`、`unknown` 或 `duplicate`，表示這段沒有確定的檔案，不會上傳。另有 `revision`（修復次數）、`backupKey`、`confirmed { bytes, md5 }`、`lastRepair { at, newKey, supersedes }` 與 `repairCandidates [{ id, fileName, bytes, modifiedAt, newKey, replacesKey }]`（`newKey` 是確認後的新備份名稱，例如 `segment-003-r1.mkv`；`replacesKey` 是會保留並標為已取代的舊名稱）。
- 設定 `transcriber`：`auto`（預設）／`faster-whisper`／`whisper.cpp`；`whisperCppBackend`：`auto`／`ffmpeg`／`cli`。
- 處理中心的課程項目新增 `engine { name, model, backend?, fallbackFrom?, fallbackReason? }`，轉錄階段的 `note` 寫出實際使用的引擎與模型。
- `POST /api/processing/:jobId/retry`：未完成的階段會改用目前的轉錄設定重新計算 stageKey（原本的記在 `previousStageKey`）；已完成的探測、音訊擷取階段直接沿用，不重新擷取。
- 備份 item 新增狀態 `superseded`（修復後被取代的舊 key，保留不清理、不計入完成）與阻擋代碼 `SOURCE_DUPLICATE`、`SEGMENT_PATH_DUPLICATE`、`MANIFEST_STALE`。
- 分段新增兩個欄位：
  - `owner`：`obs-confirmed`、`user-confirmed` 或 `inferred`。
  - `needsOwnerConfirmation`：為 true 時，這段要等使用者確認才會上傳。
  - 推測的檔案（`inferred`）一律不會被自動清理。
- `POST /api/live/sessions/:id/confirm-segment { segmentId }`：只能確認這場直播中、所有權為 `inferred` 的分段。
  - 不接受任何路徑；不符合條件時回傳 409。
  - 錯誤碼：`SEGMENT_FILE_MISSING`、`SEGMENT_FILE_CHANGED`、`SEGMENT_FILE_CLAIMED`。
- `POST /api/live/settings { dedicatedRecordFolder: boolean }`：宣告 OBS 目前的錄影資料夾只給 OBS 使用。
  - 資料夾由程式向 OBS 讀取，不由瀏覽器傳入；回應不含路徑。
  - `GET /api/live` 的 `settings.dedicatedRecordFolder` 會顯示目前狀態。
- 雲端備份：`POST /api/backup/run|retry { courseId }` 只處理該項目（課程、轉錄管線中的錄影或直播），不會整批掃描；找不到時回傳 `COURSE_NOT_FOUND`。
- `POST /api/library/open-recordings`：只在 Windows 本機開啟設定好的錄影資料夾；瀏覽器不能指定路徑，回應也不包含路徑。
- 錯誤一律回傳 `{ error: <代碼>, message: <繁中說明> }`。
