# AI Agent 操作指南

本文件供 Codex、Claude 或其他能操作 Windows UI 的 Agent 使用。目標是協助私人學習，不是繞過登入、付費牆、DRM、CAPTCHA 或平台限制。

## 不可違反的規則

1. 只處理使用者明確指定且已確認有權錄製／轉錄的內容。
2. 只使用網站與播放器原生 UI；不擷取 Cookie、Token、串流網址，不下載或破解媒體。
3. 遇到登入失效、CAPTCHA、付費牆、DOM 改變、磁碟不足、網路或 OBS 斷線，安全停止並通知使用者。
4. 不自動公開、分享、上傳到社群或建立公開連結。雲端只做使用者已設定的私人備份。
5. 未確認雲端大小／雜湊一致前，不刪本機媒體。

## 啟動前檢查

- 執行 `Start-Learning.ps1`，確認 `http://127.0.0.1:4317` 可用。
- 設定頁必須顯示 OBS、ffmpeg、Whisper 可用；OBS 預覽不是黑屏，桌面音訊有波形。
- Companion 擴充功能已配對、已允許網域並綁定正確分頁。
- 使用者已登入課程平台；Agent 不代填帳密或處理驗證碼。
- 確認模式（錄影／錄音）、字幕、語言、倍速、課程範圍、剩餘空間及備份策略。

## 單支影片的標準順序

1. 開啟指定課程頁，確認標題正確，暫停影片並回到 0:00。
2. 點播放器本身的全螢幕按鈕（不是瀏覽器 F11）。
3. 用播放器原生選單開啟指定字幕。
4. 用播放器原生選單設定使用者指定倍速。
5. 再次確認影片仍在 0:00 且暫停。
6. 呼叫本機工具開始錄影，必須等到 OBS 回報 `confirmed: true`。
7. 才按播放。
8. 播放期間不要切換視窗或顯示私人通知；只監控結束、錯誤與停止要求。
9. 結束後先暫停，再停止錄影；等 OBS 確認停止並保存檔案。
10. 確認工作已排入處理中心後，才前往下一支，並重新執行 1–9。

## 本機 API 範例

API 只可連本機，請帶同源標頭：

```powershell
$h = @{
  Host = '127.0.0.1:4317'
  Origin = 'http://127.0.0.1:4317'
  'Sec-Fetch-Site' = 'same-origin'
}

# 查詢狀態
Invoke-RestMethod -Uri 'http://127.0.0.1:4317/api/learning' -Headers $h

# 使用者已確認授權後，開始 OBS 錄影
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:4317/api/learning/start' `
  -Headers $h -ContentType 'application/json' `
  -Body '{"mode":"video","recordPermissionAcknowledged":true}'

# 安全停止並排入處理
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:4317/api/learning/stop' `
  -Headers $h -ContentType 'application/json' -Body '{}'
```

不要把 Host 改成外部位址，不要在 prompt、日誌或回覆中輸出金鑰、OBS 密碼、Cookie、本機完整使用者路徑。

## 建議交給 Agent 的指令模板

> 請只處理我已取得私人錄製與轉錄授權的課程。先檢查拾課、OBS、桌面音訊、Whisper 與 Companion。使用者未指定倍速時用 1 倍；明確指定 1.25／1.5／1.75／2 倍時照指定值設定並驗證。優先交給拾課 Agent Runner 自動開始、監看 ended、安全停止並處理下一支。遇到登入、CAPTCHA、付費牆、黑屏、無聲音、磁碟不足、網路／OBS 斷線或頁面結構改變時立即停止並通知我。不要繞過平台限制，不要公開分享，不要刪除尚未驗證備份的本機檔案。

## 驗收一堂課

- 錄影有畫面與系統音訊，開頭沒有遺漏。
- 原始檔、逐字稿、字幕、摘要／知識包都屬於同一堂課。
- 字幕時間可點回影片；逐字稿不是空白。
- 處理中心沒有未解決錯誤。
- 若啟用備份：遠端大小與雜湊驗證通過，且沒有上傳 `config.json`、`.env`、Cookies、瀏覽器資料或金鑰。

詳細端點見 `docs/API.md`；擴充功能行為見 `extension/README.md`。
