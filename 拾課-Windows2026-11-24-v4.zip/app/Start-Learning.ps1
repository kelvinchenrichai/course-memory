$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $Root
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host 'Node.js was not found. Please run Setup.ps1 first.' -ForegroundColor Red
  Read-Host 'Press Enter to exit'
  exit 1
}
$Health = $null
try { $Health = Invoke-RestMethod 'http://127.0.0.1:4317/api/status' -TimeoutSec 1 } catch {}
if (-not $Health) {
  Start-Process -FilePath (Get-Command node).Source -ArgumentList 'server.mjs' -WorkingDirectory $Root -WindowStyle Hidden
  Start-Sleep -Seconds 2
}
Start-Process powershell.exe -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $Root 'scripts\marker-hotkeys.ps1') -WorkingDirectory $Root -WindowStyle Hidden
Start-Process 'http://127.0.0.1:4317'
