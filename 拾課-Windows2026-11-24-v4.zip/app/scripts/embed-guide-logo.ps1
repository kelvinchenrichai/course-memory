$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Guide = Join-Path $Root 'distribution\windows\1_先看我_使用教學.html'
$Logo = Join-Path $Root 'assets\ck-trading-logo.png'
if (-not (Test-Path -LiteralPath $Logo)) { throw 'Missing assets\ck-trading-logo.png' }
$html = [System.IO.File]::ReadAllText($Guide)
if ($html -match 'data:image/png;base64,') { Write-Output $Guide; exit 0 }
$dataUri = 'data:image/png;base64,' + [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($Logo))
$html = $html.Replace('app/assets/ck-trading-logo.png', $dataUri)
[System.IO.File]::WriteAllText($Guide, $html, [System.Text.UTF8Encoding]::new($false))
Write-Output $Guide
