param([string]$OutputDirectory = (Join-Path (Split-Path -Parent $PSScriptRoot) 'assets'))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

function New-BrandPng([int]$Size) {
  $bitmap = [System.Drawing.Bitmap]::new($Size, $Size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
  $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
  $graphics.Clear([System.Drawing.Color]::Transparent)
  $margin = [Math]::Max(1, [int]($Size * 0.055)); $radius = [Math]::Max(3, [int]($Size * 0.25))
  $rect = [System.Drawing.RectangleF]::new($margin, $margin, $Size - 2 * $margin, $Size - 2 * $margin); $diameter = 2 * $radius
  $path = [System.Drawing.Drawing2D.GraphicsPath]::new()
  $path.AddArc($rect.Left, $rect.Top, $diameter, $diameter, 180, 90); $path.AddArc($rect.Right - $diameter, $rect.Top, $diameter, $diameter, 270, 90)
  $path.AddArc($rect.Right - $diameter, $rect.Bottom - $diameter, $diameter, $diameter, 0, 90); $path.AddArc($rect.Left, $rect.Bottom - $diameter, $diameter, $diameter, 90, 90); $path.CloseFigure()
  $brush = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#F5D178')); $graphics.FillPath($brush, $path)
  $font = [System.Drawing.Font]::new('Microsoft JhengHei', [single]($Size * 0.50), [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
  $textBrush = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#214D3D'))
  $format = [System.Drawing.StringFormat]::new(); $format.Alignment = [System.Drawing.StringAlignment]::Center; $format.LineAlignment = [System.Drawing.StringAlignment]::Center
  $graphics.DrawString('拾', $font, $textBrush, $rect, $format)
  # B 方案：右下角的播放記號，保留「拾」在小尺寸下的辨識度。
  $playSize = [Math]::Max(5, [int]($Size * 0.27)); $playX = [int]($Size * 0.62); $playY = [int]($Size * 0.62)
  $playBrush = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#214D3D'))
  $graphics.FillEllipse($playBrush, $playX, $playY, $playSize, $playSize)
  $triangle = [System.Drawing.Drawing2D.GraphicsPath]::new(); $triangle.AddPolygon([System.Drawing.Point[]]@(
    [System.Drawing.Point]::new([int]($playX + $playSize * .39), [int]($playY + $playSize * .27)),
    [System.Drawing.Point]::new([int]($playX + $playSize * .39), [int]($playY + $playSize * .73)),
    [System.Drawing.Point]::new([int]($playX + $playSize * .72), [int]($playY + $playSize * .50))
  ))
  $triangleBrush = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#F5D178')); $graphics.FillPath($triangleBrush, $triangle)
  $stream = [System.IO.MemoryStream]::new(); $bitmap.Save($stream, [System.Drawing.Imaging.ImageFormat]::Png); $bytes = $stream.ToArray()
  $stream.Dispose(); $triangleBrush.Dispose(); $triangle.Dispose(); $playBrush.Dispose(); $format.Dispose(); $textBrush.Dispose(); $font.Dispose(); $brush.Dispose(); $path.Dispose(); $graphics.Dispose(); $bitmap.Dispose(); Write-Output -NoEnumerate $bytes
}

$sizes = @(256, 128, 64, 48, 32, 16)
$images = foreach ($size in $sizes) { [pscustomobject]@{ Size = $size; Bytes = (New-BrandPng $size) } }
[System.IO.File]::WriteAllBytes((Join-Path $OutputDirectory 'course-memory-256.png'), $images[0].Bytes)
$webAssets = Join-Path (Split-Path -Parent $PSScriptRoot) 'web\assets'; New-Item -ItemType Directory -Path $webAssets -Force | Out-Null
[System.IO.File]::WriteAllBytes((Join-Path $webAssets 'course-memory-256.png'), $images[0].Bytes)
$iconPath = Join-Path $OutputDirectory 'course-memory-b.ico'; $stream = [System.IO.File]::Open($iconPath, [System.IO.FileMode]::Create); $writer = [System.IO.BinaryWriter]::new($stream)
$writer.Write([uint16]0); $writer.Write([uint16]1); $writer.Write([uint16]$images.Count); $offset = 6 + 16 * $images.Count
foreach ($image in $images) { $dimension = if ($image.Size -eq 256) { 0 } else { $image.Size }; $writer.Write([byte]$dimension); $writer.Write([byte]$dimension); $writer.Write([byte]0); $writer.Write([byte]0); $writer.Write([uint16]1); $writer.Write([uint16]32); $writer.Write([uint32]$image.Bytes.Length); $writer.Write([uint32]$offset); $offset += $image.Bytes.Length }
foreach ($image in $images) { $writer.Write($image.Bytes) }
$writer.Dispose(); $stream.Dispose(); Copy-Item -LiteralPath $iconPath -Destination (Join-Path $OutputDirectory 'course-memory.ico') -Force; Write-Output $iconPath
