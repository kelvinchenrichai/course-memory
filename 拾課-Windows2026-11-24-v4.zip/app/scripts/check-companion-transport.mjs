// Companion transport check: pairs a simulated extension with the real hub, polls WITHOUT an Origin header on GET
// (as Chrome may do), sends getState, and confirms a token-less GET is still refused. Usage: node scripts/check-companion-transport.mjs
import http from 'node:http';
const app = process.argv[2] || new URL('..', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1');
const { createCompanionHub, handleCompanionRequest } = await import('file://' + app + '/src/services/companion.mjs');
const { createCompanionClient } = await import('file://' + app + '/extension/companion.mjs');
const hub = createCompanionHub();
const srv = http.createServer(async (req, res) => { const url = new URL(req.url, 'http://127.0.0.1'); let t=''; for await (const c of req) t+=c;
  const ac = new AbortController(); res.on('close', () => { if (!res.writableEnded) ac.abort(); });
  const r = await handleCompanionRequest(hub, { method: req.method, pathname: url.pathname, query: url.searchParams, headers: req.headers, body: t ? JSON.parse(t) : undefined, signal: ac.signal }, { port: 4399 });
  res.writeHead(r.status, r.headers); res.end(r.body == null ? undefined : JSON.stringify(r.body)); }).listen(4399);
const O='chrome-extension://abcdefghijklmnopabcdefghijklmnop', mem={};
// Simulate Chrome: Origin only on non-GET requests.
const c = createCompanionClient({ fetch:(u,o)=>fetch(u,{...o,headers:(o.method||'GET')==='GET'?o.headers:{...o.headers,origin:O}}), storage:{get:async k=>mem[k],set:async(k,v)=>{mem[k]=v},remove:async k=>{delete mem[k]}}, clock:{now:Date.now,setTimeout,clearTimeout}, serverUrl:'http://127.0.0.1:4399', pollWaitMs:2000, executeCommand:async()=>({ok:true,state:{paused:true}}) });
await c.pair(hub.createPairingCode().code); await c.start(); hub.reportTabs([{tabId:7,bound:true,origin:'https://www.skool.com'}]);
const r = await hub.sendCommand({type:'getState'}).then(x=>'ok '+x.ok, e=>'ERR '+e.code);
// a GET without token must still be refused
const bad = await fetch('http://127.0.0.1:4399/api/companion/commands').then(r=>r.status);
console.log('getState', r, '| GET without token ->', bad); c.stop(); hub.dispose(); srv.close(); process.exit(0);
