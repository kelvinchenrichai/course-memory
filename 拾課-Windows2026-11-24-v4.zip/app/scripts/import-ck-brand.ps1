param([Parameter(Mandatory = $true)][string]$Source)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$Root = Split-Path -Parent $PSScriptRoot; $Assets = Join-Path $Root 'assets'; $WebAssets = Join-Path $Root 'web\assets'
New-Item -ItemType Directory -Path $Assets, $WebAssets -Force | Out-Null
$sourceImage = [System.Drawing.Bitmap]::FromFile($Source)
$left = $sourceImage.Width; $top = $sourceImage.Height; $right = -1; $bottom = -1
for ($y = 0; $y -lt $sourceImage.Height; $y += 1) { for ($x = 0; $x -lt $sourceImage.Width; $x += 1) { if ($sourceImage.GetPixel($x, $y).A -gt 8) { if ($x -lt $left) { $left = $x }; if ($x -gt $right) { $right = $x }; if ($y -lt $top) { $top = $y }; if ($y -gt $bottom) { $bottom = $y } } } }
if ($right -lt $left -or $bottom -lt $top) { throw 'Logo has no visible pixels.' }
$pad = 12; $left = [Math]::Max(0, $left - $pad); $top = [Math]::Max(0, $top - $pad); $right = [Math]::Min($sourceImage.Width - 1, $right + $pad); $bottom = [Math]::Min($sourceImage.Height - 1, $bottom + $pad)
$crop = [System.Drawing.Bitmap]::new($right - $left + 1, $bottom - $top + 1, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$g = [System.Drawing.Graphics]::FromImage($crop); $g.DrawImage($sourceImage, [System.Drawing.Rectangle]::new(0, 0, $crop.Width, $crop.Height), [System.Drawing.Rectangle]::new($left, $top, $crop.Width, $crop.Height), [System.Drawing.GraphicsUnit]::Pixel); $g.Dispose(); $sourceImage.Dispose()
$logoPath = Join-Path $Assets 'ck-trading-logo.png'; $crop.Save($logoPath, [System.Drawing.Imaging.ImageFormat]::Png); Copy-Item -LiteralPath $logoPath -Destination (Join-Path $WebAssets 'ck-trading-logo.png') -Force

function New-IconPng([int]$Size) {
  $canvas = [System.Drawing.Bitmap]::new($Size, $Size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb); $graphics = [System.Drawing.Graphics]::FromImage($canvas)
  $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality; $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic; $graphics.Clear([System.Drawing.Color]::White)
  $margin = [Math]::Max(1, [int]($Size * .08)); $scale = [Math]::Min(($Size - 2 * $margin) / $crop.Width, ($Size - 2 * $margin) / $crop.Height)
  $w = [int]($crop.Width * $scale); $h = [int]($crop.Height * $scale); $graphics.DrawImage($crop, [int](($Size - $w) / 2), [int](($Size - $h) / 2), $w, $h)
  $stream = [System.IO.MemoryStream]::new(); $canvas.Save($stream, [System.Drawing.Imaging.ImageFormat]::Png); $bytes = $stream.ToArray(); $stream.Dispose(); $graphics.Dispose(); $canvas.Dispose(); Write-Output -NoEnumerate $bytes
}
$sizes = @(256, 128, 64, 48, 32, 16); $images = foreach ($size in $sizes) { [pscustomobject]@{ Size = $size; Bytes = (New-IconPng $size) } }
$iconPath = Join-Path $Assets 'ck-trading-watermark.ico'; $stream = [System.IO.File]::Open($iconPath, [System.IO.FileMode]::Create); $writer = [System.IO.BinaryWriter]::new($stream)
$writer.Write([uint16]0); $writer.Write([uint16]1); $writer.Write([uint16]$images.Count); $offset = 6 + 16 * $images.Count
foreach ($image in $images) { $dimension = if ($image.Size -eq 256) { 0 } else { $image.Size }; $writer.Write([byte]$dimension); $writer.Write([byte]$dimension); $writer.Write([byte]0); $writer.Write([byte]0); $writer.Write([uint16]1); $writer.Write([uint16]32); $writer.Write([uint32]$image.Bytes.Length); $writer.Write([uint32]$offset); $offset += $image.Bytes.Length }
foreach ($image in $images) { $writer.Write($image.Bytes) }; $writer.Dispose(); $stream.Dispose(); $crop.Dispose()
Write-Output $iconPath
