import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { commandExists, runCommand } from '../src/utils/process.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const defaults = JSON.parse(await fsp.readFile(path.join(root, 'config.example.json'), 'utf8'));
let local = {};
try { local = JSON.parse(await fsp.readFile(path.join(root, 'config.json'), 'utf8')); } catch {}
const config = { ...defaults, ...local };
const python = path.isAbsolute(config.pythonCommand) ? config.pythonCommand : path.join(root, config.pythonCommand);
const obsPath = path.join(process.env.ProgramFiles || 'C:\\Program Files', 'obs-studio', 'bin', '64bit', 'obs64.exe');

const configuredCommandExists = async (command) => {
  if (typeof command !== 'string' || !command) return false;
  if (path.isAbsolute(command)) return fs.existsSync(command);
  if (command.includes('/') || command.includes('\\')) return fs.existsSync(path.resolve(root, command));
  return commandExists(command);
};

const importable = async (module) => {
  if (!fs.existsSync(python)) return false;
  try { await runCommand(python, ['-c', `import ${module}`]); return true; } catch { return false; }
};

const checks = [
  ['Node.js', true, process.version],
  ['OBS Studio', fs.existsSync(obsPath) || await commandExists('obs64'), '螢幕與系統音訊錄製'],
  ['ffmpeg', await configuredCommandExists(config.ffmpegCommand || 'ffmpeg'), '音訊擷取與短片輸出'],
  ['Python venv', fs.existsSync(python), python],
  ['faster-whisper', await importable('faster_whisper'), '本機逐字稿'],
  ['yt-dlp', await importable('yt_dlp'), '授權網址匯入'],
  ['Ollama', await commandExists('ollama'), '本機摘要與翻譯'],
  ['rclone', await commandExists('rclone'), '個人雲端備份']
];

console.log('\nCourse Memory Studio 環境健檢\n');
for (const [name, ready, detail] of checks) console.log(`${ready ? '✓' : '○'} ${name.padEnd(16)} ${detail}`);
const coreReady = checks.filter(([name]) => ['ffmpeg', 'Python venv', 'faster-whisper'].includes(name)).every(([, ready]) => ready);
console.log(coreReady ? '\n核心轉錄環境已就緒。' : '\n核心轉錄環境尚未完成，請執行 Setup.ps1。');

// P9 直播工作台: OBS 安全分段設定指引（本程式不會修改 OBS 設定）。
console.log(`
直播工作台（無人值守錄影）需要：
  1. OBS 30.2 以上（obs-websocket 5.5 以上，才支援安全分段 SplitRecordFile）。
  2. OBS →「工具」→「WebSocket 伺服器設定」→ 勾選「啟用 WebSocket 伺服器」，密碼填到本程式「設定 → OBS 連線」。
  3. OBS →「設定」→「輸出」→ 輸出模式選「進階」→「錄影」分頁：
     ・錄影格式選 MKV（斷電或當機時已錄的部分仍可讀取）
     ・錄影路徑設成本程式的錄影資料夾，分段才能自動備份
     ・勾選「自動分割檔案」，選「僅手動分割」（由本程式每 N 分鐘分段）或依時間分割
  4. 未開啟分割時，直播仍會以單一檔案錄下，並標示「segmentation-unavailable」，整場結束後才備份。
  5. 錄影期間請讓電腦保持開機且不睡眠、網路與 OBS 保持開啟；本程式不會喚醒電腦或修改 Windows 電源設定。`);
