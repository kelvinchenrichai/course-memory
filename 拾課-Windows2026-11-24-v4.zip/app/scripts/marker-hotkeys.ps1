Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class Keys {
  [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vKey);
}
'@
$Created = $false
$Mutex = [Threading.Mutex]::new($true, 'Local\CourseMemoryMarkerHotkeys', [ref]$Created)
if (-not $Created) { exit 0 }
$Endpoint = 'http://127.0.0.1:4317/api/markers'
$WasDown = $false
while ($true) {
  $Down = (([Keys]::GetAsyncKeyState(0x11) -band 0x8000) -ne 0) -and (([Keys]::GetAsyncKeyState(0x12) -band 0x8000) -ne 0) -and (([Keys]::GetAsyncKeyState(0x4D) -band 0x8000) -ne 0)
  if ($Down -and -not $WasDown) {
    try { Invoke-RestMethod -Method Post -Uri $Endpoint -ContentType 'application/json; charset=utf-8' -Body '{}' | Out-Null } catch {}
  }
  $WasDown = $Down
  Start-Sleep -Milliseconds 80
}
