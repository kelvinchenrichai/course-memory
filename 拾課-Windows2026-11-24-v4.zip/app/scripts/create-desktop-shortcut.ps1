param([string]$Name = '拾課 - 課程學習')
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot; $Icon = Join-Path $Root 'assets\course-memory-b.ico'; $Launcher = Join-Path $Root 'Start-Learning.ps1'
if (-not (Test-Path -LiteralPath $Icon)) { & (Join-Path $PSScriptRoot 'build-brand-icon.ps1') | Out-Null }
$ShortcutPath = Join-Path ([Environment]::GetFolderPath('Desktop')) "$Name.lnk"
$Shell = New-Object -ComObject WScript.Shell; $Shortcut = $Shell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = 'powershell.exe'; $Shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$Launcher`""; $Shortcut.WorkingDirectory = $Root
$Shortcut.IconLocation = "$Icon,0"; $Shortcut.Description = '啟動拾課 Course Memory'; $Shortcut.Save(); Write-Output $ShortcutPath
