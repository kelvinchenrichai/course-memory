#!/usr/bin/env node
/**
 * P7B 本機端到端驗收：錄影檔 → 轉錄 → 字幕 → 知識整理 → 雲端備份。
 *
 * Runs the real watcher, intake, pipeline runner, publish step and backup service in a throw-away folder.
 * Only the external tools are replaced: ffmpeg/ffprobe and Whisper are the test fakes
 * (tests/helpers/fake-process.mjs), the AI is not used (rule-based knowledge fallback) and "Google Drive"
 * is a local folder through the same Drive-folder adapter the app uses. No network, no real course content:
 * every spoken line below was written for this script.
 *
 * Usage: node scripts/e2e-acceptance.mjs [--keep] [--json]
 * Exit code 0 = every check passed.
 */
import crypto from 'node:crypto';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createPipelineRunner } from '../src/pipeline/runner.mjs';
import { createFileWatcher, createWatchLedger } from '../src/pipeline/watcher.mjs';
import { createIntake } from '../src/pipeline/intake.mjs';
import { buildPipelineCourse, publishErrorCode, shouldAttemptPublish, trackKeyOf } from '../src/pipeline/publish.mjs';
import { createBackupService } from '../src/backup/service.mjs';
import { createDriveFolderAdapter, DRIVE_FOLDER_REMOTE } from '../src/backup/drive-folder.mjs';
import { RcloneError } from '../src/backup/rclone.mjs';
import { createFakeMedia, createFakeProvider } from '../tests/helpers/fake-process.mjs';

const SPOKEN = [
  { rec: [1, 4], text: '歡迎來到驗收用的示範課程，今天只用自己寫的句子。' },
  { rec: [5, 9], text: '第一個重點：錄影結束後，媒體會先備份到私人雲端。' },
  { rec: [10, 14], text: '第二個重點：逐字稿與字幕完成後，會再追加備份。' },
  { rec: [15, 19], text: '最後，知識整理完成並驗證後，才允許清理本機原始檔。' }
];
const SECRET = 'fixture-secret-should-never-upload';
const md5 = async (file) => crypto.createHash('md5').update(await fsp.readFile(file)).digest('hex');

async function walk(dir) {
  const out = [];
  for (const entry of await fsp.readdir(dir, { withFileTypes: true }).catch(() => [])) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...await walk(full)); else out.push(full);
  }
  return out;
}

export async function runAcceptance({ keep = false, log = () => {} } = {}) {
  const base = await fsp.mkdtemp(path.join(os.tmpdir(), 'cms-p7b-e2e-'));
  const dirs = { recordings: path.join(base, 'recordings'), data: path.join(base, 'data'), library: path.join(base, 'library'), cloud: path.join(base, 'cloud') };
  for (const dir of Object.values(dirs)) await fsp.mkdir(dir, { recursive: true });
  const workRoot = path.join(dirs.data, 'pipeline', 'work');
  // Things that must never reach the cloud.
  await fsp.writeFile(path.join(base, 'config.json'), JSON.stringify({ openaiApiKey: SECRET, obsPassword: SECRET }));
  await fsp.writeFile(path.join(dirs.recordings, 'cookies.sqlite'), SECRET);

  const checks = [];
  const check = (name, ok, detail = '') => { checks.push({ name, ok: Boolean(ok), ...(detail ? { detail } : {}) }); log(`${ok ? '✓' : '✗'} ${name}${detail ? `（${detail}）` : ''}`); };

  // --- fake tools (only the external programs are fake) ---------------------------------------------
  const media = new Map();
  const fake = createFakeMedia({ media });
  let release; const hold = new Promise((resolve) => { release = resolve; });
  const providers = { speech: createFakeProvider({ utterances: SPOKEN, language: 'zh', hold }), silence: createFakeProvider({ utterances: [], language: 'zh' }) };
  let currentProvider = providers.speech;
  const provider = { ...providers.speech, transcribe: (input) => currentProvider.transcribe(input) };
  const pipeline = createPipelineRunner({ dataDir: dirs.data, workRoot, allowedRoots: [dirs.recordings], run: fake.run, provider });

  // --- recording sessions + watcher + intake (same modules the app uses) ---------------------------
  const sessions = [];
  const watcher = createFileWatcher({ roots: [{ id: 'recordings', dir: dirs.recordings, kind: 'recording' }], ledger: createWatchLedger(path.join(dirs.data, 'pipeline', 'watch-ledger.json')), maxDepth: 1, stableChecks: 2 });
  const intake = createIntake({ pipeline, findSessions: async () => sessions });
  const handOver = async () => { const result = await watcher.scan(); for (const entry of result.ready) await intake.fromWatchEntry(entry); return result; };

  // --- "cloud" = local folder through the Drive-folder adapter; can be switched offline ------------
  const drive = createDriveFolderAdapter({ root: dirs.cloud });
  const net = { offline: false, uploads: [] };
  const rclone = {
    version: () => drive.version(), listRemotes: () => drive.listRemotes(),
    probe: (dest) => (net.offline ? { state: 'offline', code: 'NETWORK_OFFLINE' } : drive.probe(dest)),
    upload: async (args) => { if (net.offline) throw new RcloneError('NETWORK_OFFLINE', 'offline'); net.uploads.push(args.remotePath); return drive.upload(args); },
    stat: (remotePath) => { if (net.offline) throw new RcloneError('NETWORK_OFFLINE', 'offline'); return drive.stat(remotePath); }
  };

  // --- published library (what server.mjs keeps in memory) -----------------------------------------
  const courses = []; const publishErrors = new Map();
  const publish = async () => {
    for (const job of (await pipeline.list()).filter((item) => item.status === 'completed' && item.result?.transcript)) {
      if (courses.some((course) => course.pipelineJobId === job.id) || !shouldAttemptPublish(job, publishErrors.get(job.id))) continue;
      try {
        const track = JSON.parse(await fsp.readFile(path.join(workRoot, job.result.assetDir, job.result.transcript), 'utf8'));
        const course = await buildPipelineCourse({ job, track, workRoot, chapterMinutes: 1 });
        courses.unshift(course); publishErrors.delete(job.id);
        await fsp.mkdir(path.join(dirs.library, course.id), { recursive: true });
        await fsp.writeFile(path.join(dirs.library, course.id, 'course.json'), JSON.stringify(course));
      } catch (error) { publishErrors.set(job.id, { code: publishErrorCode(error), trackKey: trackKeyOf(job) }); }
    }
  };

  const config = { cloudDestination: `${DRIVE_FOLDER_REMOTE}:CourseMemory`, backup: { autoUpload: true, cleanupPolicy: 'manual', maxAttempts: 3 } };
  const makeBackup = () => createBackupService({
    config, dataDir: dirs.data, rclone, roots: [dirs.recordings], workRoot, libraryFolder: dirs.library,
    listCourses: async () => courses, listPipelineJobs: () => pipeline.list(),
    listPublishErrors: async () => [...publishErrors.entries()].map(([jobId, value]) => ({ jobId, code: value.code })),
    listActiveRecordings: async () => sessions.filter((item) => ['starting', 'recording', 'stopping'].includes(item.status)).map((item) => ({ id: item.id, title: '驗收錄影' })),
    isMediaWriting: async (file) => sessions.some((item) => item.status === 'recording' && path.resolve(item.obsOutputPath) === path.resolve(file)),
    isMediaBusy: async () => false, quietMs: 0, backoffMs: [0, 0]
  });
  let backup = makeBackup();
  const entryOf = (status, courseId) => status.courses.find((course) => course.courseId === courseId);
  const cloudKeys = async (courseId) => (await walk(path.join(dirs.cloud, 'CourseMemory', 'courses', courseId))).map((file) => path.relative(path.join(dirs.cloud, 'CourseMemory', 'courses', courseId), file).split(path.sep).join('/')).sort();

  try {
    // 1. OBS is still writing lesson A: nothing is handed over, nothing is uploaded.
    const fileA = path.join(dirs.recordings, '示範課 第1堂.mkv');
    sessions.push({ id: 'rec_e2e000000001', status: 'recording', captureMode: 'video', obsOutputPath: fileA });
    await fsp.writeFile(fileA, Buffer.alloc(64 * 1024, 1)); media.set(path.resolve(fileA), { durationSec: 20, audio: true, video: true });
    await handOver(); await fsp.appendFile(fileA, Buffer.alloc(32 * 1024, 2)); await handOver();
    let status = await backup.run();
    check('錄影中：只顯示「等待錄影結束」，沒有上傳任何檔案', status.recording.some((item) => item.phase === 'waiting-recording') && net.uploads.length === 0 && (await pipeline.list()).length === 0);

    // 2. Recording stops, the file is closed and stable → pipeline job → media backed up right away.
    sessions[0].status = 'completed';
    await handOver(); await handOver();
    const [jobA] = await pipeline.list();
    check('錄影結束且檔案穩定後才進入管線', Boolean(jobA) && jobA.asset.files[0].bytes === 96 * 1024);
    status = await backup.run();
    const courseIdA = status.courses[0]?.courseId;
    const phaseAfterMedia = entryOf(status, courseIdA)?.phase;
    const keysAfterMedia = await cloudKeys(courseIdA);
    check('不等知識整理：媒體先備份並驗證', phaseAfterMedia === 'media-backed-up' && keysAfterMedia.join() === 'media/original-001.mkv', `${phaseAfterMedia}；${keysAfterMedia.join('、')}`);
    const remoteMedia = path.join(dirs.cloud, 'CourseMemory', 'courses', courseIdA, 'media', 'original-001.mkv');
    const originalMd5 = await md5(fileA);
    check('雲端媒體與本機原檔大小、MD5 一致', (await md5(remoteMedia)) === originalMd5 && (await fsp.stat(remoteMedia)).size === (await fsp.stat(fileA)).size);
    check('轉錄仍在進行中（媒體備份沒有等它）', (await pipeline.list())[0].status !== 'completed');

    // 3. Transcription + subtitles finish → appended.
    release(); await pipeline.idle();
    status = await backup.run();
    const keysAfterTranscript = await cloudKeys(courseIdA);
    check('逐字稿與字幕完成後追加備份', ['transcript/transcript.json', 'subtitles/transcript.rec.srt'].every((key) => keysAfterTranscript.includes(key)) && !keysAfterTranscript.includes('manifest.json'), keysAfterTranscript.join('、'));
    check('尚未完成知識整理前不算完整備份、不可清理', entryOf(status, courseIdA).phase !== 'complete' && status.reclaimableBytes === 0);

    // 4. Knowledge → summary + knowledge pack + manifest (last) → 完整備份.
    await publish();
    check('知識整理產生章節與重點（每項都有引用）', courses[0]?.knowledge?.chapters?.length > 0 && courses[0].id === courseIdA);
    status = await backup.run();
    const keysComplete = await cloudKeys(courseIdA);
    check('摘要、知識包與 manifest 追加完成 →「完整備份」', entryOf(status, courseIdA).phase === 'complete' && ['summary/course.json', 'knowledge/knowledge-pack.json', 'manifest.json'].every((key) => keysComplete.includes(key)), keysComplete.join('、'));
    check('manifest 最後上傳', net.uploads.filter((item) => item.includes(courseIdA)).at(-1)?.endsWith('/manifest.json'));

    // 5. Repeated runs and a restart upload nothing again.
    const before = net.uploads.length;
    await backup.run(); await backup.run();
    backup = makeBackup(); await backup.run();
    check('重複執行與重新啟動後不會重複上傳（冪等）', net.uploads.length === before, `${net.uploads.length - before} 次多餘上傳`);

    // 6. Same file name, different recording, while offline; and it has no speech at all.
    currentProvider = providers.silence;
    const dayTwo = path.join(dirs.recordings, '第二天'); await fsp.mkdir(dayTwo);
    const fileB = path.join(dayTwo, '示範課 第1堂.mkv');
    await fsp.writeFile(fileB, Buffer.alloc(48 * 1024, 7)); media.set(path.resolve(fileB), { durationSec: 12, audio: true, video: true });
    sessions.push({ id: 'rec_e2e000000002', status: 'completed', captureMode: 'video', obsOutputPath: fileB });
    await handOver(); await handOver(); await pipeline.idle();
    net.offline = true;
    const uploadsBeforeOffline = net.uploads.length;
    status = await backup.run();
    check('斷網時不嘗試上傳、不消耗重試次數', net.uploads.length === uploadsBeforeOffline && status.connection.state === 'offline');
    net.offline = false;
    await publish();
    status = await backup.run();
    const courseIdB = status.courses.find((course) => course.courseId !== courseIdA)?.courseId;
    check('同名錄影檔放在不同課程資料夾，不互相覆蓋', courseIdB && courseIdB !== courseIdA && (await md5(path.join(dirs.cloud, 'CourseMemory', 'courses', courseIdB, 'media', 'original-001.mkv'))) === await md5(fileB) && (await md5(remoteMedia)) === originalMd5);
    const entryB = entryOf(status, courseIdB);
    const jobB = (await pipeline.list()).find((job) => path.resolve(job.asset.files[0].path) === path.resolve(fileB));
    check('空逐字稿顯示 KNOWLEDGE_TRANSCRIPT_EMPTY，而不是一直處理中', Boolean(jobB) && publishErrors.get(jobB.id)?.code === 'KNOWLEDGE_TRANSCRIPT_EMPTY' && entryB?.phase === 'needs-attention' && entryB?.code === 'KNOWLEDGE_TRANSCRIPT_EMPTY');
    check('空逐字稿的錄影：媒體仍已備份', entryB?.items.find((item) => item.kind === 'media')?.status === 'verified');
    await publish();
    check('空逐字稿不會每次重新整理（不重試迴圈）', publishErrors.size === 1 && courses.length === 1);

    // 7. Cleanup: only the completely backed-up recording; the remote copy is re-verified first.
    const cleaned = await backup.cleanup({ reason: 'manual' });
    const aGone = await fsp.access(fileA).then(() => false, () => true);
    const bKept = await fsp.access(fileB).then(() => true, () => false);
    check('清理只移除「完整備份」的原始媒體，空逐字稿那支保留', aGone && bKept && cleaned.removed.length === 1 && cleaned.removed[0].courseId === courseIdA);
    check('清理後雲端仍有完全相同的媒體', (await md5(remoteMedia)) === originalMd5);
    const transcriptAssetDir = jobA.result?.assetDir || (await pipeline.list())[0]?.result?.assetDir;
    check('清理不動逐字稿、字幕、課程庫或設定檔', Boolean(transcriptAssetDir) && await fsp.access(path.join(workRoot, transcriptAssetDir, 'transcript.json')).then(() => true, () => false) && await fsp.access(path.join(base, 'config.json')).then(() => true, () => false));

    // 8. Nothing private in the cloud.
    const cloudFiles = await walk(dirs.cloud);
    const contents = (await Promise.all(cloudFiles.filter((file) => /\.(json|srt|vtt)$/.test(file)).map((file) => fsp.readFile(file, 'utf8')))).join('\n');
    check('雲端沒有 config、金鑰、cookies、暫存檔或本機路徑', !cloudFiles.some((file) => /config\.json|cookies|\.part$|\.tmp$/i.test(path.basename(file))) && !contents.includes(SECRET) && !contents.includes(base) && !contents.includes(os.homedir()));
    check('雲端只有 courses/<課程代碼>/ 底下的私人備份', cloudFiles.every((file) => path.relative(dirs.cloud, file).split(path.sep).slice(0, 2).join('/') === 'CourseMemory/courses'));
  } finally {
    if (!keep) await fsp.rm(base, { recursive: true, force: true }).catch(() => {});
  }
  return { ok: checks.every((item) => item.ok), checks, folder: keep ? base : null };
}

if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  const json = process.argv.includes('--json');
  const result = await runAcceptance({ keep: process.argv.includes('--keep'), log: json ? () => {} : (line) => console.log(line) });
  if (json) console.log(JSON.stringify(result, null, 2));
  else console.log(result.ok ? `\n全部通過（${result.checks.length} 項）。` : `\n有 ${result.checks.filter((item) => !item.ok).length} 項未通過。`);
  process.exitCode = result.ok ? 0 : 1;
}
void fileURLToPath;
