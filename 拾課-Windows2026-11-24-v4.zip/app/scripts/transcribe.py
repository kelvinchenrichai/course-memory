"""faster-whisper → JSON (contract `cms.whisper-raw/1`, see docs/AI_PIPELINE_SPEC.md §2.2 and src/pipeline/transcript.mjs).

Usage: transcribe.py INPUT OUTPUT [--model small] [--language auto|en|zh] [--device auto|cpu|cuda]
                     [--compute-type int8] [--beam-size 5] [--word-timestamps|--no-word-timestamps] [--vad|--no-vad]

Output keeps everything faster-whisper reports: detected language and its probability, each segment's id,
start/end, text, avg_logprob, no_speech_prob and (optionally) word timestamps. Nothing is translated or
converted (no Traditional/Simplified conversion here). The output is written to a temp file and renamed.
Transcript text is never printed. Exit codes: 0 ok, 2 bad arguments, 3 faster-whisper not installed,
4 transcription failed, 5 a native library (e.g. ctranslate2.dll) was blocked by a Windows application-control
policy such as Smart App Control (WinError 4551), 6 a native library could not be loaded for another reason.

`transcribe.py --check` only loads faster-whisper and runs one ctranslate2 call, then prints one JSON line
{"ok", "code", "version", "winerror"} — no paths. Used by the settings page to test the engine for real.
"""
import argparse
import json
import os
import shutil
import sys
import tempfile

SCHEMA = "cms.whisper-raw/1"
# WinError codes meaning "Windows refused to load this file" (application control / group policy / AV).
POLICY_BLOCKED_WINERRORS = {4551, 4556, 1260, 225}


def classify_load_error(error):
    """(exit code, short code, winerror) for an exception raised while importing faster-whisper."""
    if isinstance(error, ImportError) and not isinstance(getattr(error, "__cause__", None), OSError):
        return 3, "FASTER_WHISPER_UNAVAILABLE", None
    os_error = error if isinstance(error, OSError) else getattr(error, "__cause__", None)
    winerror = getattr(os_error, "winerror", None)
    if winerror in POLICY_BLOCKED_WINERRORS:
        return 5, "ENGINE_BLOCKED", winerror
    return 6, "ENGINE_LOAD_FAILED", winerror


def load_engine():
    import faster_whisper  # noqa: F401 - imports ctranslate2 and its native DLLs
    ctranslate2 = sys.modules.get("ctranslate2")  # loaded by faster_whisper itself
    if ctranslate2 is not None:
        ctranslate2.get_supported_compute_types("cpu")  # one real native call
    return faster_whisper


def check():
    try:
        module = load_engine()
    except BaseException as error:  # noqa: BLE001 - only the classification is reported
        exit_code, code, winerror = classify_load_error(error)
        sys.stdout.write(json.dumps({"ok": False, "code": code, "winerror": winerror, "error": type(error).__name__}) + "\n")
        return exit_code
    sys.stdout.write(json.dumps({"ok": True, "code": None, "version": getattr(module, "__version__", None)}) + "\n")
    return 0


def rounded(value, digits=3):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if number != number or number in (float("inf"), float("-inf")):
        return None
    return round(number, digits)


def parse_args(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--model", default="small")
    parser.add_argument("--language", default="auto")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--compute-type", default="int8")
    parser.add_argument("--beam-size", type=int, default=5)
    parser.add_argument("--word-timestamps", dest="word_timestamps", action="store_true", default=True)
    parser.add_argument("--no-word-timestamps", dest="word_timestamps", action="store_false")
    parser.add_argument("--vad", dest="vad", action="store_true", default=True)
    parser.add_argument("--no-vad", dest="vad", action="store_false")
    args = parser.parse_args(argv)
    if args.language not in ("auto", "en", "zh"):
        parser.error("language must be auto, en or zh")
    return args


def write_atomic(path, payload):
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix=".whisper-", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
        try:
            os.replace(temporary, path)
        except PermissionError:
            # Some Windows controlled/synchronised folders allow file creation but reject atomic rename.
            # Copying the fully-written temporary file is a safe fallback here: the Node stage validates
            # the complete JSON before publishing it, and a failed copy never becomes a successful stage.
            with open(temporary, "rb") as source, open(path, "wb") as target:
                shutil.copyfileobj(source, target)
                target.flush()
                os.fsync(target.fileno())
            os.unlink(temporary)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv == ["--check"]:
        return check()
    args = parse_args(argv)
    try:
        faster_whisper = load_engine()
        from faster_whisper import WhisperModel
    except BaseException as error:  # noqa: BLE001
        exit_code, code, winerror = classify_load_error(error)
        sys.stderr.write("%s%s\n" % (code, " (WinError %s)" % winerror if winerror else ""))
        return exit_code
    try:
        model = WhisperModel(args.model, device=args.device, compute_type=args.compute_type)
        segments, info = model.transcribe(
            args.input,
            language=None if args.language == "auto" else args.language,
            vad_filter=args.vad,
            beam_size=args.beam_size,
            word_timestamps=args.word_timestamps,
        )
        items = []
        for index, segment in enumerate(segments):
            words = None
            if args.word_timestamps:
                words = [
                    {"w": word.word, "start": rounded(word.start), "end": rounded(word.end), "probability": rounded(getattr(word, "probability", None), 4)}
                    for word in (getattr(segment, "words", None) or [])
                    if rounded(word.start) is not None and rounded(word.end) is not None
                ]
            items.append({
                "id": getattr(segment, "id", index),
                "start": rounded(segment.start),
                "end": rounded(segment.end),
                "text": segment.text,
                "avgLogprob": rounded(getattr(segment, "avg_logprob", None), 4),
                "noSpeechProb": rounded(getattr(segment, "no_speech_prob", None), 4),
                "compressionRatio": rounded(getattr(segment, "compression_ratio", None), 4),
                "words": words,
            })
        payload = {
            "schema": SCHEMA,
            "engine": {"name": "faster-whisper", "version": getattr(faster_whisper, "__version__", None), "model": args.model},
            "language": getattr(info, "language", None),
            "languageProbability": rounded(getattr(info, "language_probability", None), 4),
            "duration": rounded(getattr(info, "duration", None)),
            "segments": items,
        }
        write_atomic(args.output, payload)
    except Exception as error:  # noqa: BLE001 - report the type only, never transcript content or paths
        sys.stderr.write("TRANSCRIBE_FAILED: %s\n" % type(error).__name__)
        return 4
    return 0


if __name__ == "__main__":
    sys.exit(main())
