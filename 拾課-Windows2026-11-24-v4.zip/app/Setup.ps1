param(
  [switch]$InstallChrome,
  [switch]$InstallObs,
  [switch]$NonInteractive
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $Root
Write-Host '拾課 Course Memory · CK_Trading' -ForegroundColor Green
Write-Host 'This will install the missing free components. Please approve any installer prompts.'
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw 'winget was not found. Update App Installer from Microsoft Store first.' }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { winget install --id OpenJS.NodeJS.LTS --exact --accept-package-agreements --accept-source-agreements }
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { winget install --id Gyan.FFmpeg --exact --accept-package-agreements --accept-source-agreements }
if (-not (Get-Command rclone -ErrorAction SilentlyContinue)) { winget install --id Rclone.Rclone --exact --accept-package-agreements --accept-source-agreements }
if (-not (Get-Command python -ErrorAction SilentlyContinue) -or (python --version 2>&1) -notmatch 'Python 3') { winget install --id Python.Python.3.12 --exact --accept-package-agreements --accept-source-agreements }
$ChromePaths = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "$env:LocalAppData\Google\Chrome\Application\chrome.exe")
$HasChrome = $ChromePaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
$WantChrome = $InstallChrome.IsPresent
if (-not $HasChrome -and -not $NonInteractive -and -not $WantChrome) { $WantChrome = (Read-Host 'Install Google Chrome? Enter Y to install, or press Enter to use Edge') -match '^[Yy]' }
if (-not $HasChrome -and $WantChrome) { winget install --id Google.Chrome --exact --accept-package-agreements --accept-source-agreements }
$WantObs = $InstallObs.IsPresent
if (-not $NonInteractive -and -not $WantObs) { $WantObs = (Read-Host 'Install OBS Studio? Enter Y to install, or press Enter to skip') -match '^[Yy]' }
if ($WantObs) { winget install --id OBSProject.OBSStudio --exact --accept-package-agreements --accept-source-agreements }
$Python = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $Python -or $Python -like '*WindowsApps*') {
  $Python = Get-ChildItem "$env:LocalAppData\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1 -ExpandProperty FullName
}
if (-not $Python) { throw 'Python was installed but is not visible yet. Close this window and run Setup.ps1 again.' }
& $Python -m venv .venv
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt

# Prepare the data-only whisper.cpp fallback model. This keeps transcription usable on Windows PCs where
# Smart App Control refuses faster-whisper's native ctranslate2.dll. Never weaken Windows security settings.
$ModelDir = Join-Path $Root 'models\whisper'
$ModelFile = Join-Path $ModelDir 'ggml-small.bin'
$ModelDownload = "$ModelFile.download"
$ModelSha256 = '1be3a9b2063867b937e64e2ec7483364a79917e157fa98c5d94b5c1fffea987b'
$ModelUrl = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin'
if (Test-Path -LiteralPath $ModelFile) {
  $ActualModelSha256 = (Get-FileHash -LiteralPath $ModelFile -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($ActualModelSha256 -ne $ModelSha256) { throw "Existing whisper.cpp model failed SHA256 verification. Keep it for inspection and replace it manually: $ModelFile" }
} else {
  if (-not (Get-Command curl.exe -ErrorAction SilentlyContinue)) { throw 'Windows curl.exe was not found; cannot download the verified whisper.cpp model.' }
  New-Item -ItemType Directory -Force -Path $ModelDir | Out-Null
  Write-Host 'Downloading the verified whisper.cpp small model (about 488 MB)...' -ForegroundColor Cyan
  & curl.exe --fail --location --retry 3 --output $ModelDownload $ModelUrl
  if ($LASTEXITCODE -ne 0) { throw "Model download failed. Run Setup.ps1 again; the partial file is kept at $ModelDownload" }
  $ActualModelSha256 = (Get-FileHash -LiteralPath $ModelDownload -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($ActualModelSha256 -ne $ModelSha256) { throw "Downloaded whisper.cpp model failed SHA256 verification. The file was kept for inspection: $ModelDownload" }
  Move-Item -LiteralPath $ModelDownload -Destination $ModelFile
}
if (-not (Test-Path config.json)) { Copy-Item config.example.json config.json }
& (Join-Path $Root 'scripts\create-desktop-shortcut.ps1') | Out-Null
Write-Host 'Setup complete. Follow OBS-Settings guide, then run Start-Learning.ps1.' -ForegroundColor Green
if (-not $NonInteractive) { Read-Host 'Press Enter to exit' }
