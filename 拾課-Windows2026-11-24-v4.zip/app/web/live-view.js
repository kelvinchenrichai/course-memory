// Pure render helpers for the 直播工作台 page (P9). No DOM access; unit-tested in Node.
// Everything shown comes from /api/live, which carries file names only (no paths, accounts or tokens).
import { esc } from './p4c-view.js';
import { formatBytes } from './backup-view.js';

export const SESSION_TEXT = Object.freeze({
  scheduled: '等待中', preparing: '準備中（檢查 OBS 與環境）', recording: 'OBS 錄影中', stopping: '正在安全停止', processing: '錄影完成，備份等待中',
  completed: '已完成', blocked: '暫停：需要你處理', failed: '未能完成', cancelled: '已取消'
});
const TONE = { scheduled: 'waiting', preparing: 'running', recording: 'running', stopping: 'running', processing: 'running', completed: 'done', blocked: 'needs-user', failed: 'needs-user', cancelled: 'waiting' };
/** What confirming a repair candidate will do — shown before the user confirms. */
export function repairNote(candidate) {
  const size = Number.isFinite(candidate.bytes) ? `${(candidate.bytes / 1048576).toFixed(1)} MB` : '大小未知';
  return `${size}・確認後以新的備份名稱 ${candidate.newKey || '（新版本）'} 上傳並驗證大小與 MD5${candidate.replacesKey ? `；雲端舊的 ${candidate.replacesKey} 保留並標示為已取代，不刪除` : ''}；本機檔案都保留。`;
}

/** What the cloud backup of an ended session looks like (session.backup.state from /api/live). */
export const BACKUP_TEXT = Object.freeze({
  disabled: '未啟用備份：分段只保存在本機', waiting: '錄影完成，備份等待中', uploading: '錄影完成，正在上傳與驗證',
  verified: '全部分段已備份並驗證', failed: '備份失敗：本機檔案都保留，請重試',
  'needs-repair': '有分段指向同一個檔案，已停止備份：本機與雲端檔案都保留，修復前不會完成'
});
export function completionText(session) {
  if (session.status !== 'completed') return SESSION_TEXT[session.status] || session.status;
  if (session.backup?.state === 'disabled') return '已完成（未啟用備份，只存本機）';
  if (session.backup?.unresolved) return '已完成（有分段需你手動確認，未備份）';
  if (session.backup?.state === 'needs-repair') return '需要修復';
  return '已完成（全部分段已備份並驗證）';
}
export const PLAN_TEXT = Object.freeze({ draft: '草稿', enabled: '已排程', disabled: '已停用', cancelled: '已取消', done: '已結束' });
const SEGMENT_TEXT = { recording: '錄影中', closed: '已封存', interrupted: '中斷（保留在本機）' };
const UPLOAD_TEXT = { 'not-queued': '尚未排入', waiting: '等待上傳', queued: '排隊中', uploading: '上傳中', uploaded: '已上傳並驗證', failed: '上傳失敗', disabled: '不備份' };
export const PURPOSE_TEXT = Object.freeze({ 'private-study': '私人學習', 'creator-candidate': '創作候選' });
const CONTENT_TEXT = { esports: '電競', trading: '交易', generic: '一般' };

/** Blocker / warning code → what happened and the next step (Traditional Chinese). */
export const NEXT_STEP = Object.freeze({
  SERVER_RESTARTED: ['程式曾重新啟動，錄影狀態不明。', '請先看 OBS：若仍在錄影，可按「結束這場」並勾選停止 OBS；若已停止，可按「恢復錄影」或「結束這場」。'],
  OBS_DISCONNECTED: ['與 OBS 的連線中斷。', 'OBS 可能仍在錄影。請開啟 OBS 確認，再選擇恢復或結束。'],
  OBS_STOPPED_EXTERNALLY: ['OBS 的錄影被手動停止了。', '已完成的分段都保留了；若要繼續請按「恢復錄影」。'],
  OBS_UNAVAILABLE: ['連不到 OBS。', '請開啟 OBS，確認「工具 → WebSocket 伺服器設定」已啟用，再按「恢復錄影」。'],
  OBS_START_UNCONFIRMED: ['OBS 沒有回報「已開始錄影」。', '請看 OBS 是否真的在錄；本程式不會把它當成錄影中。'],
  OBS_STOP_UNCONFIRMED: ['OBS 沒有回報「已停止錄影」。', '請到 OBS 手動按「停止錄影」，再按「結束這場」。'],
  OBS_ALREADY_RECORDING: ['OBS 已經在錄別的東西。', '本程式不會接手或停止不是它開始的錄影。請先在 OBS 停止，再按「恢復錄影」。'],
  OBS_PROTOCOL_ERROR: ['OBS WebSocket 回應異常。', '請更新 OBS 到 30 版以上後再試。'],
  CAPTURE_SOURCE_MISSING: ['OBS 目前的場景沒有任何啟用的來源。', '請在 OBS 加入「視窗擷取」或「顯示器擷取」，讓直播畫面出現在預覽中。'],
  AUDIO_PROFILE_UNCONFIRMED: ['尚未確認 OBS 的「只錄聲音」設定。', '請改用影片模式，或先在設定頁完成 OBS 音訊設定。'],
  RIGHTS_MISSING: ['找不到這場直播的錄製授權確認。', '請重新建立直播來源並確認授權。'],
  DERIVATIVE_RIGHTS_REQUIRED: ['「創作候選」需要公開二創授權與證據。', '請補上授權依據與證據，或改為「私人學習」。'],
  DISK_LOW: ['硬碟空間不足，已安全停止。', '已完成的分段都保留了。請清出空間（或在雲端備份頁清理已驗證的檔案）後再恢復。'],
  CAPTCHA: ['直播頁出現人機驗證。', '本程式不會代填驗證。已安全停止並保留分段；請自己完成驗證後再恢復。'],
  LOGIN_REQUIRED: ['直播頁要求重新登入。', '本程式不會代你登入。已安全停止並保留分段；請自己登入後再恢復。'],
  DOM_CHANGED: ['直播頁的版面改變，偵測不到播放器。', '已安全停止並保留分段。請確認頁面仍在播放直播，再恢復。'],
  PLAYER_NOT_FOUND: ['找不到直播播放器。', '已安全停止並保留分段。請確認頁面仍在播放直播，再恢復。'],
  PAYMENT_PROMPT: ['直播頁出現付費或訂閱提示。', '本程式不會自動購買或訂閱。已安全停止並保留分段。'],
  ANOTHER_SESSION_ACTIVE: ['同一時間已有另一場在錄。', '目前一次只能錄一場；請取消其中一場。'],
  PREFLIGHT_FAILED: ['開播前檢查沒有通過。', '請依檢查項目修正後按「恢復錄影」。'],
  SCHEDULE_MISSED: ['程式沒有在排程時間執行。', '排程已錯過，沒有錄到任何內容。'],
  SEGMENTATION_UNAVAILABLE: ['OBS 無法自動分割檔案，改為單一檔案錄影。', '整場結束後才會備份。若要每段備份，請在 OBS「設定 → 輸出 → 錄影」開啟「自動分割檔案」。'],
  SPLIT_UNSUPPORTED_VERSION: ['OBS WebSocket 版本太舊（需要 5.5 以上），無法分段。', '請更新 OBS 到 30.2 以上；這次會以單一檔案錄影。'],
  CLOUD_UNAVAILABLE: ['雲端目前無法連線。', '錄影照常進行，分段會留在本機，網路恢復後再上傳。'],
  CLOUD_OFFLINE: ['網路中斷。', '錄影照常進行，備份會等網路恢復。'],
  BACKUP_NOT_CONFIGURED: ['這場要備份，但雲端備份尚未設定或沒有開啟自動上傳。', '分段都保留在本機。到「雲端備份」頁設定目的地並開啟自動上傳後，會自動繼續。'],
  BACKUP_FAILED_SEGMENTS: ['有分段上傳失敗。', '本機檔案都保留著；請到「雲端備份」頁按「重試」。'],
  BACKUP_DISABLED: ['這個排程不備份。', '分段只保留在本機。'],
  DISK_MAY_RUN_OUT: ['剩餘空間可能不夠錄完整場。', '建議先清出空間；空間真的不足時會先嘗試安全清理，仍不足就安全停止。'],
  DISK_LOW_WARNING: ['硬碟空間偏低。', '錄影繼續；若低於安全值會安全停止。'],
  DISK_UNKNOWN: ['無法讀取剩餘空間。', '請自行確認硬碟空間足夠。'],
  RECORD_FOLDER_NOT_BACKED_UP: ['OBS 的錄影資料夾不在本程式的錄影資料夾內。', '分段仍會保留，但無法自動備份或清理；建議把 OBS 錄影路徑改成本程式設定的資料夾。'],
  RECORD_FOLDER_UNKNOWN: ['讀不到 OBS 錄影資料夾。', '請確認 OBS 已開啟。'],
  PAGE_NOT_MONITORED: ['沒有連上瀏覽器 Companion，無法偵測直播頁是否要求登入。', '錄影會照常進行，但請自己留意直播頁。'],
  SEGMENT_PATH_UNKNOWN: ['有一段錄影找不到檔名，沒有上傳。', '檔案仍在 OBS 錄影資料夾中，請手動確認後按「我已確認」。'],
  SEGMENT_PATH_DUPLICATE: ['兩個分段指向同一個錄影檔，無法確定哪一段是對的。', '已停止這場的備份，也不會標示完成；本機與雲端檔案全部保留。請在下方為受影響的分段選出真正的檔案，確認後才會重新備份。'],
  STOP_PATH_IGNORED: ['OBS 停止錄影時回報的檔名與目前分段不同，已忽略。', 'OBS 停止時常回報整場的第一個檔案；分段檔名以換檔通知為準。'],
  STOP_PATH_MISMATCH: ['OBS 停止錄影時的兩個回報檔名不一致。', '這一段改由錄影資料夾比對；無法唯一判斷時會請你確認。'],
  SEGMENT_REPAIRED: ['已依你的確認修復分段檔案。', '修復後的分段會以新的備份名稱上傳，先前的雲端副本保留不動。'],
  SEGMENT_OWNER_UNCONFIRMED: ['有一段錄影的檔案是從錄影資料夾推測的（OBS 沒有回報檔名），尚未確認是本場直播。', '確認前不會上傳或清理。請到 OBS 錄影資料夾核對檔名，確定是本場直播再按「我確認這是本場直播檔案」；不是的話按「我已確認」略過。'],
  SEGMENT_PATH_AMBIGUOUS: ['開始錄影時錄影資料夾同時出現多個新檔案，無法確定哪一個是這場直播。', '這些檔案都不會上傳、也不會被清理。請自己到 OBS 錄影資料夾確認，再按「我已確認」。'],
  BACKUP_FAILED: ['有分段備份失敗（雲端大小或內容不一致、或多次上傳失敗）。', '本機檔案都保留著。檢查雲端與網路後按「重試備份」。'],
  SEGMENTS_INTERRUPTED_LOCAL: ['有中斷的分段只保留在本機，沒有備份。', '請到 OBS 錄影資料夾確認該檔案。']
});
export const explain = (code) => NEXT_STEP[code] || [code ? `狀態代碼 ${code}` : '', ''];
const CHECK_TEXT = { obs: 'OBS 連線', websocket: 'WebSocket 版本', 'obs-idle': 'OBS 未在錄其他內容', 'capture-source': '擷取來源', 'record-folder': '錄影資料夾', disk: '硬碟空間', rights: '錄製授權', cloud: '雲端備份', page: '直播頁狀態' };

export function formatDuration(seconds) {
  const s = Math.max(0, Math.round(Number(seconds) || 0)); const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60);
  return h ? `${h} 小時 ${m} 分` : `${m} 分 ${s % 60} 秒`;
}
const time = (iso, timeZone) => { try { return new Intl.DateTimeFormat('zh-TW', { timeZone, month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(iso)); } catch { return ''; } };

export function renderLiveSummary(data) {
  if (!data) return '<p class="muted">讀取中…</p>';
  const active = (data.sessions || []).find((item) => ['preparing', 'recording', 'stopping'].includes(item.status));
  const next = (data.plans || []).find((plan) => plan.status === 'enabled' && Date.parse(plan.endAt) > Date.parse(data.now));
  const free = data.disk?.freeBytes; const low = Number.isFinite(free) && free < data.disk.warnBytes;
  const cloud = { connected: '已連線', offline: '離線', 'not-set': '未設定', 'auth-required': '需要重新授權' }[data.cloud?.state] || '無法確認';
  return `<div class="lw-tiles">
    <div class="lw-tile"><small>現在</small><b>${esc(active ? SESSION_TEXT[active.status] : next ? '等待下一場' : '沒有排程')}</b></div>
    <div class="lw-tile"><small>下一場</small><b>${next ? esc(`${time(next.startAt, next.timeZone)} ${next.title}`) : '—'}</b></div>
    <div class="lw-tile ${low ? 'bad' : ''}"><small>剩餘空間</small><b>${Number.isFinite(free) ? esc(formatBytes(free)) : '無法讀取'}</b></div>
    <div class="lw-tile"><small>雲端備份</small><b>${esc(cloud)}</b></div>
  </div>
  <label class="lw-check lw-dedicated"><input type="checkbox" data-live-dedicated ${data.settings?.dedicatedRecordFolder ? 'checked' : ''}> OBS 目前的錄影資料夾只給 OBS 使用（沒有其他程式寫入影片）。勾選後，從資料夾推測的檔案可以備份，但仍不會被自動清理。</label>
  <p class="lw-reminder">⚠ 無人值守錄影期間，請讓電腦保持開機且不要進入睡眠、網路連線、OBS 與本程式都保持開啟。本程式不會喚醒電腦，也不會修改 Windows 電源設定。</p>`;
}

function renderChecks(preflight) {
  if (!preflight?.checks?.length) return '';
  return `<ul class="lw-checks">${preflight.checks.map((item) => `<li class="${item.ok ? (item.warning ? 'warn' : 'good') : 'bad'}"><b>${esc(CHECK_TEXT[item.id] || item.id)}</b><span>${item.ok ? (item.warning ? esc(explain(item.code)[0]) : '通過') : esc(explain(item.code)[0] || '未通過')}</span></li>`).join('')}</ul>`;
}

export function renderSessionCard(session) {
  const status = completionText(session);
  const [what, next] = session.blocker ? explain(session.blocker.code) : ['', ''];
  const segs = session.segments || [];
  const warnings = (session.warnings || []).filter((code) => code !== session.blocker?.code);
  const buttons = [
    session.actions?.stop ? `<button class="primary-button" type="button" data-live-stop="${esc(session.id)}">立即安全停止</button>` : '',
    session.actions?.resume ? `<button class="secondary-button" type="button" data-live-resume="${esc(session.id)}">恢復錄影</button>` : '',
    session.actions?.finish ? `<button class="quiet-button" type="button" data-live-finish="${esc(session.id)}" data-obs-maybe="${session.obs?.mayStillBeRecording ? '1' : '0'}">結束這場</button>` : '',
    session.actions?.cancel ? `<button class="quiet-button" type="button" data-live-cancel="${esc(session.id)}">取消</button>` : '',
    session.actions?.retryBackup ? `<button class="secondary-button" type="button" data-live-retry-backup="${esc(session.id)}">重試備份</button>` : '',
    session.actions?.acknowledge ? `<button class="quiet-button" type="button" data-live-acknowledge="${esc(session.id)}">我已確認</button>` : '',
    session.actions?.marker ? `<button class="mini-button" type="button" data-live-marker="${esc(session.id)}">⭐ 標記此刻</button>` : ''
  ].join('');
  return `<article class="lw-session process-item ${TONE[session.status] || ''}">
    <div class="lw-session-head"><div><h3>${esc(session.title)}</h3><small>${esc(status)}${session.blocker?.code === 'SEGMENT_PATH_DUPLICATE' || session.actions?.repair ? ` · 場次 <code>${esc(session.id)}</code>` : ''}${session.segmentation === 'segmentation-unavailable' ? ' · <span class="lw-flag">未分段（單一檔案）</span>' : ''}</small></div><span class="lw-status ${TONE[session.status] || ''}">${esc(status)}</span></div>
    ${session.obs?.mayStillBeRecording && session.status === 'blocked' ? '<p class="lw-alert"><b>OBS 可能仍在錄影</b>　請先打開 OBS 確認，本程式不會自動接手或停止。</p>' : ''}
    ${session.blocker ? `<p class="lw-blocker"><b>${esc(what)}</b><br>${esc(next)}</p>` : ''}
    ${session.backup && session.status !== 'recording' ? `<p class="lw-backup ${esc(session.backup.state)}">${esc(BACKUP_TEXT[session.backup.state] || '')}${session.backup.state === 'disabled' ? '' : `（${esc(session.backup.verified)}／${esc(session.backup.total)} 段已驗證${session.backup.failed ? `，${esc(session.backup.failed)} 段失敗` : ''}）`}</p>` : ''}
    <dl class="lw-stats"><div><dt>已錄時間</dt><dd>${esc(formatDuration(session.recordedSeconds))}</dd></div><div><dt>完成分段</dt><dd>${esc(session.counts?.closed ?? 0)}</dd></div><div><dt>已備份分段</dt><dd>${esc(session.counts?.backedUp ?? 0)}</dd></div><div><dt>中斷分段</dt><dd>${esc(session.counts?.interrupted ?? 0)}</dd></div></dl>
    ${renderChecks(session.status === 'preparing' || session.status === 'blocked' ? session.preflight : null)}
    ${warnings.length ? `<ul class="lw-warnings">${warnings.map((code) => `<li>${esc(explain(code)[0])} ${esc(explain(code)[1])}</li>`).join('')}</ul>` : ''}
    ${segs.length ? `<details class="lw-segments"><summary>分段（${segs.length}）</summary><ol>${segs.map((seg) => `<li><span>#${esc(seg.index)} ${esc(seg.fileName || '（檔名待確認）')}</span><span>${esc(SEGMENT_TEXT[seg.state] || seg.state)} · ${esc(seg.pathIssue === 'duplicate' ? '與其他分段同一檔案，需修復' : seg.pathIssue === 'ambiguous' ? '檔案無法確定，不上傳' : seg.pathIssue === 'unknown' ? '找不到檔案，不上傳' : seg.needsOwnerConfirmation ? '推測的檔案，待你確認後才備份' : UPLOAD_TEXT[seg.upload] || seg.upload)}${seg.owner === 'inferred' && !seg.needsOwnerConfirmation ? esc('（推測的檔案：可備份，不會自動清理）') : ''}</span>${(seg.repairCandidates || []).length && session.actions?.repair ? `<span class="lw-repair">${seg.repairCandidates.map((c) => `<span class="lw-repair-option"><button class="mini-button" type="button" data-live-repair="${esc(seg.id)}" data-candidate="${esc(c.id)}" data-session="${esc(session.id)}" data-index="${esc(seg.index)}" data-file="${esc(c.fileName)}" data-new-key="${esc(c.newKey || '')}" data-replaces="${esc(c.replacesKey || '')}" data-bytes="${esc(c.bytes ?? '')}">這是第 ${esc(seg.index)} 段：${esc(c.fileName)}</button><small>${esc(repairNote(c))}</small></span>`).join('')}</span>` : ''}${seg.lastRepair && !seg.pathIssue ? `<small class="lw-repair-done">${esc(`已修復：以 ${seg.lastRepair.newKey || seg.backupKey} 備份${seg.lastRepair.supersedes ? `；雲端舊的 ${seg.lastRepair.supersedes} 保留並標示為已取代` : ''}${seg.confirmed ? `（確認的大小 ${seg.confirmed.bytes.toLocaleString('en-US')} bytes，MD5 ${seg.confirmed.md5.slice(0, 8)}…）` : ''}`)}</small>` : ''}${seg.needsOwnerConfirmation ? `<button class="mini-button" type="button" data-live-confirm-segment="${esc(seg.id)}" data-session="${esc(session.id)}" data-file="${esc(seg.fileName || '')}">我確認這是本場直播檔案</button>` : ''}</li>`).join('')}</ol></details>` : ''}
    ${(session.signals || []).length ? `<p class="muted">已標記 ${esc(session.signals.length)} 個時刻</p>` : ''}
    <div class="form-row lw-actions">${buttons}</div>
  </article>`;
}

export function renderLiveSessions(data) {
  const sessions = (data?.sessions || []).filter((item) => !['cancelled'].includes(item.status) || Date.parse(data.now) - Date.parse(item.actualStopAt || item.actualStartAt || data.now) < 86_400_000);
  if (!sessions.length) return '<p class="empty-state">目前沒有進行中或最近的直播錄影。</p>';
  return sessions.map(renderSessionCard).join('');
}

export function renderLivePlans(data) {
  const plans = (data?.plans || []).filter((plan) => ['enabled', 'disabled', 'draft'].includes(plan.status) && !plan.sessionId);
  if (!plans.length) return '<p class="empty-state">還沒有排程。建立一個直播來源後，就能排程今晚的直播。</p>';
  const sources = new Map((data.sources || []).map((item) => [item.id, item]));
  return plans.map((plan) => {
    const source = sources.get(plan.sourceId);
    return `<article class="lw-plan process-item ${plan.status === 'enabled' ? 'running' : 'waiting'}">
      <div><h3>${esc(plan.title)}</h3><small>${esc(time(plan.startAt, plan.timeZone))} – ${esc(time(plan.endAt, plan.timeZone))}（${esc(plan.timeZone)}）· 提前 ${esc(plan.prepareMinutes)} 分準備 · 每 ${esc(plan.segmentMinutes)} 分一段 · ${plan.captureMode === 'audio' ? '只錄聲音' : '錄影'}${source ? ` · ${esc(PURPOSE_TEXT[source.purpose] || '')} · ${esc(CONTENT_TEXT[source.contentType] || '')}` : ''}</small></div>
      <div class="form-row lw-actions"><span class="lw-status">${esc(PLAN_TEXT[plan.status] || plan.status)}</span>${plan.status === 'enabled' ? `<button class="quiet-button" type="button" data-plan-disable="${esc(plan.id)}">停用</button>` : `<button class="secondary-button" type="button" data-plan-enable="${esc(plan.id)}">啟用</button>`}<button class="quiet-button" type="button" data-plan-cancel="${esc(plan.id)}">取消排程</button></div>
    </article>`;
  }).join('');
}

export function renderSourceOptions(data) {
  const sources = data?.sources || [];
  return `<option value="">新增直播來源…</option>${sources.map((item) => `<option value="${esc(item.id)}">${esc(item.name)}（${esc(PURPOSE_TEXT[item.purpose] || '')}）</option>`).join('')}`;
}
