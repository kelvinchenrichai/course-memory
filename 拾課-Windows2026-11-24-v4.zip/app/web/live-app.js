import { renderLivePlans, renderLiveSessions, renderLiveSummary, renderSourceOptions } from './live-view.js';

// P9 wiring for the 直播工作台 page. All state comes from /api/live (file names only; no paths or accounts).
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const api = async (url, options = {}) => {
  const response = await fetch(url, { ...options, headers: { ...(options.body ? { 'content-type': 'application/json' } : {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.message || data.error || '操作失敗'), { code: data.error });
  return data;
};
const toast = (message) => { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(el._timer); el._timer = setTimeout(() => el.classList.remove('show'), 3200); };
let data = null;
const visible = () => !$('#liveView').classList.contains('hidden');
const form = $('#livePlanForm');

function render() {
  $('#liveSummary').innerHTML = renderLiveSummary(data);
  $('#liveSessions').innerHTML = renderLiveSessions(data);
  $('#livePlans').innerHTML = renderLivePlans(data);
  const select = $('#liveSource'); const chosen = select.value;
  select.innerHTML = renderSourceOptions(data); if ([...select.options].some((option) => option.value === chosen)) select.value = chosen;
  toggleSourceFields();
  $$('[data-live-stop]').forEach((b) => b.onclick = () => { if (confirm('立即停止 OBS 錄影？已完成的分段都會保留。')) act(b.dataset.liveStop, 'stop', {}, '已安全停止'); });
  $$('[data-live-resume]').forEach((b) => b.onclick = () => { if (confirm('恢復錄影前，請先確認 OBS 沒有在錄其他內容。確定恢復？')) act(b.dataset.liveResume, 'resume', {}, '已重新檢查並恢復'); });
  $$('[data-live-finish]').forEach((b) => b.onclick = () => {
    const maybe = b.dataset.obsMaybe === '1';
    if (!confirm('結束這場直播錄影？已完成的分段都會保留。')) return;
    const stopObs = maybe && confirm('OBS 可能仍在錄影。要由本程式送出「停止錄影」嗎？\n只有在你確認 OBS 正在錄的就是這場直播時才按「確定」；否則按「取消」，請自己在 OBS 處理。');
    act(b.dataset.liveFinish, 'finish', { confirm: true, stopObs }, '已結束');
  });
  $$('[data-live-retry-backup]').forEach((b) => b.onclick = () => act(b.dataset.liveRetryBackup, 'retry-backup', {}, '已重新排入備份'));
  $$('[data-live-acknowledge]').forEach((b) => b.onclick = () => { if (confirm('確認你已自己到 OBS 錄影資料夾檢查過這些檔案？它們不會被上傳或刪除。')) act(b.dataset.liveAcknowledge, 'acknowledge', {}, '已記錄'); });
  $$('[data-live-confirm-segment]').forEach((b) => b.onclick = () => { if (confirm(`請先到 OBS 錄影資料夾核對：「${b.dataset.file}」確定是這場直播的錄影嗎？確認後才會備份，且日後可依清理策略清理。`)) act(b.dataset.session, 'confirm-segment', { segmentId: b.dataset.liveConfirmSegment }, '已確認這個分段'); });
  const dedicated = $('[data-live-dedicated]');
  if (dedicated) dedicated.onchange = async () => {
    if (dedicated.checked && !confirm('確定 OBS 目前的錄影資料夾只給 OBS 使用嗎？若有其他程式也寫入影片，可能把別人的檔案當成直播備份。')) { dedicated.checked = false; return; }
    try { await api('/api/live/settings', { method: 'POST', body: JSON.stringify({ dedicatedRecordFolder: dedicated.checked }) }); toast(dedicated.checked ? '已記下 OBS 專用錄影資料夾' : '已取消'); } catch (error) { toast(error.message); dedicated.checked = !dedicated.checked; }
    refresh();
  };
  $$('[data-live-repair]').forEach((b) => b.onclick = () => {
    const lines = [`場次 ${b.dataset.session}`, `確認「${b.dataset.file}」就是第 ${b.dataset.index} 段的錄影檔？`, '',
      `・會先計算這個檔案的大小與 MD5，再以新的備份名稱 ${b.dataset.newKey || '（新版本）'} 上傳；雲端大小與 MD5 一致才算完成。`,
      ...(b.dataset.replaces ? [`・雲端舊的 ${b.dataset.replaces} 保留並標示為「已取代」，不會刪除。`] : []),
      '・只修復這一場；本機錄影、其他場次與錯誤的課程紀錄都不會被刪除。', '・新的完成清單（manifest）要等所有分段都上傳並驗證成功後才會寫入。'];
    if (confirm(lines.join('\n'))) act(b.dataset.session, 'repair-segment', { segmentId: b.dataset.liveRepair, candidateId: b.dataset.candidate, confirm: true }, '已確認，開始重新備份這一段');
  });
  $$('[data-live-cancel]').forEach((b) => b.onclick = () => { if (confirm('取消這場？')) act(b.dataset.liveCancel, 'cancel', {}, '已取消'); });
  $$('[data-live-marker]').forEach((b) => b.onclick = () => { const note = prompt('標記說明（選填）', '') ?? null; if (note !== null) act(b.dataset.liveMarker, 'marker', { note }, '已標記'); });
  $$('[data-plan-enable]').forEach((b) => b.onclick = () => planAction(b.dataset.planEnable, 'enable', '已啟用'));
  $$('[data-plan-disable]').forEach((b) => b.onclick = () => planAction(b.dataset.planDisable, 'disable', '已停用'));
  $$('[data-plan-cancel]').forEach((b) => b.onclick = () => { if (confirm('取消這個排程？')) planAction(b.dataset.planCancel, 'cancel', '已取消排程'); });
  const needs = (data?.sessions || []).some((item) => item.status === 'blocked');
  $('#liveBadge').classList.toggle('hidden', !needs);
}
async function refresh() { try { data = await api('/api/live'); render(); } catch {} }
async function act(id, action, body, message) { try { await api(`/api/live/sessions/${id}/${action}`, { method: 'POST', body: JSON.stringify(body) }); toast(message); } catch (error) { toast(error.message); } refresh(); }
async function planAction(id, action, message) { try { await api(`/api/live/plans/${id}/${action}`, { method: 'POST', body: '{}' }); toast(message); } catch (error) { toast(error.message); } refresh(); }

function toggleSourceFields() {
  $('#liveNewSource').classList.toggle('hidden', Boolean($('#liveSource').value));
  $('#liveDerivative').classList.toggle('hidden', form.elements.purpose.value !== 'creator-candidate');
}
$('#liveSource').addEventListener('change', toggleSourceFields);
form.elements.purpose.addEventListener('change', toggleSourceFields);
try { form.elements.timeZone.value = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Taipei'; } catch { form.elements.timeZone.value = 'Asia/Taipei'; }

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const f = form.elements; let sourceId = f.sourceId.value;
  try {
    if (!sourceId) {
      const creator = f.purpose.value === 'creator-candidate';
      const source = await api('/api/live/sources', { method: 'POST', body: JSON.stringify({
        name: f.name.value, pageUrl: f.pageUrl.value, contentType: f.contentType.value, purpose: f.purpose.value, defaultCaptureMode: f.defaultCaptureMode.value,
        ...(creator ? { rightsBasis: f.rightsBasis.value, evidence: f.evidence.value ? [f.evidence.value] : [] } : {}),
        acknowledgements: { recordPermission: f.ackRecord.checked, privateProcessing: f.ackRecord.checked, derivativePermission: creator && f.ackDerivative.checked }
      }) });
      sourceId = source.id;
    }
    await api('/api/live/plans', { method: 'POST', body: JSON.stringify({
      sourceId, title: f.title.value || undefined, timeZone: f.timeZone.value, startLocal: f.startLocal.value, endLocal: f.endLocal.value,
      ...(f.captureMode.value ? { captureMode: f.captureMode.value } : {}), segmentMinutes: Number(f.segmentMinutes.value), prepareMinutes: Number(f.prepareMinutes.value), backupAfterClose: f.backupAfterClose.checked
    }) });
    toast('已建立排程'); form.reset(); try { f.timeZone.value = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Taipei'; } catch {}
    await refresh(); if (sourceId) $('#liveSource').value = sourceId; toggleSourceFields();
  } catch (error) { toast(error.message); await refresh(); }
});
$('#liveRefresh').addEventListener('click', refresh);
document.querySelector('.nav-item[data-view="liveView"]')?.addEventListener('click', refresh);
setInterval(() => { if (visible() || !data) refresh(); }, 5000);
refresh();
