const esc = (value = '') => String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
const clock = (value = 0) => { const n = Math.max(0, Math.floor(Number(value) || 0)); const h = Math.floor(n / 3600), m = Math.floor(n % 3600 / 60), s = n % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`; };

export function renderTranscriptLibrary(items) {
  if (!items.length) return '<div class="tl-empty">沒有符合條件的內容。</div>';
  return items.map((item) => {
    const media = item.mediaKind === 'audio' ? '錄音' : item.mediaKind === 'video' ? '錄影' : '文字';
    const readiness = [item.hasTranscript ? '逐字稿' : null, item.hasKnowledge ? '已整理' : null].filter(Boolean).join('・') || '等待處理';
    return `<article class="tl-item ${item.trashed ? 'is-trashed' : ''}"><div class="tl-main"><div class="tl-title"><span class="tl-media ${esc(item.mediaKind)}">${esc(media)}</span><h3>${esc(item.title)}</h3>${item.trashed ? '<span>垃圾桶</span>' : item.archived ? '<span>已封存</span>' : ''}</div><p>${readiness} · ${item.segmentCount} 段 · ${item.chapterCount} 章 · ${clock(item.duration)}${item.characterCount ? ` · ${item.characterCount.toLocaleString('zh-TW')} 字` : ''}${item.language ? ` · ${esc(item.language)}` : ''}</p><small>${item.createdAt ? new Date(item.createdAt).toLocaleString('zh-TW') : '日期不明'}${item.mediaExtension ? ` · ${esc(item.mediaExtension.toUpperCase())}` : ''}</small></div><div class="tl-actions">${item.demo ? `<button data-open="${esc(item.id)}">查看 Demo</button>` : item.trashed ? `<button data-restore="${esc(item.id)}">還原</button>` : `<button data-open="${esc(item.id)}">播放／查看</button>${item.hasTranscript ? `<button data-copy="${esc(item.id)}">複製逐字稿</button>` : ''}<button data-rename="${esc(item.id)}" data-title="${esc(item.title)}">更名</button><button class="danger" data-trash="${esc(item.id)}" data-title="${esc(item.title)}">移到垃圾桶</button>`}</div></article>`;
  }).join('');
}

