import { allSelection, rangeSelection, renderError, renderEstimate, renderLocal, renderScan } from './discovery-view.js';

// P7A「匯入課程清單」wiring inside「Agent 學習」. Reading a page never plays, records or navigates;
// a plan is created only after both acknowledgements, and then waits for「開始」in the task list below.
const root = document.querySelector('#discoveryImport');
if (root) {
  const $ = (s) => root.querySelector(s);
  const $$ = (s) => [...root.querySelectorAll(s)];
  const api = async (url, options = {}) => {
    const response = await fetch(url, { ...options, headers: options.body ? { 'content-type': 'application/json' } : {} });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw Object.assign(new Error(data.message || data.error || '操作失敗'), { code: data.error });
    return data;
  };
  const toast = (message) => { const el = document.querySelector('#toast'); if (!el) return; el.textContent = message; el.classList.add('show'); clearTimeout(el._timer); el._timer = setTimeout(() => el.classList.remove('show'), 3200); };
  let scan = null; let selection = new Set(); let preview = null; let busy = false; let previewTimer = null;
  const opts = () => ({ captureMode: $('[data-d-opt="captureMode"]').value, rate: Number($('[data-d-opt="rate"]').value), captions: $('[data-d-opt="captions"]').checked, translationLanguage: $('[data-d-opt="translationLanguage"]').value });

  function updateButtons() {
    const acks = $('#dAckRecord').checked && $('#dAckPrivate').checked;
    $('#discoveryCreate').disabled = busy || !scan?.scanId || !selection.size || !acks;
    $('#discoveryRescan').disabled = busy || !scan?.scanId;
    $('#discoveryRead').disabled = busy;
    const count = $('.sel-count'); if (count && scan) count.textContent = `已選 ${selection.size}／${scan.items.length} 部`;
  }

  function renderList() {
    $('#discoveryResult').innerHTML = renderScan(scan, selection);
    $('#discoveryPlanBox').classList.toggle('hidden', !scan?.scanId);
    $$('[data-select]').forEach((box) => box.onchange = () => { box.checked ? selection.add(box.dataset.select) : selection.delete(box.dataset.select); schedulePreview(); });
    const all = $('[data-select-all]'); if (all) all.onclick = () => { selection = allSelection(scan.items); renderList(); schedulePreview(); };
    const none = $('[data-select-none]'); if (none) none.onclick = () => { selection = new Set(); renderList(); schedulePreview(); };
    const range = $('[data-select-range]'); if (range) range.onclick = () => {
      const next = rangeSelection(scan.items, $('[data-range-from]').value, $('[data-range-to]').value);
      if (!next) return toast('範圍不正確：請輸入「第 N 部到第 M 部」，N 不可大於 M');
      selection = next; renderList(); schedulePreview();
    };
    updateButtons();
  }

  function schedulePreview() {
    updateButtons(); clearTimeout(previewTimer);
    if (!scan?.scanId || !selection.size) { preview = null; $('#discoveryEstimate').innerHTML = renderEstimate(null, opts()); return; }
    previewTimer = setTimeout(async () => {
      try { preview = await api('/api/course-discovery/preview', { method: 'POST', body: JSON.stringify({ scanId: scan.scanId, selected: [...selection], ...opts() }) }); }
      catch (error) { preview = null; toast(error.message); }
      $('#discoveryEstimate').innerHTML = renderEstimate(preview, opts());
    }, 150);
  }

  async function read(rescan) {
    busy = true; updateButtons(); $('#discoveryStatus').textContent = '正在讀取頁面上看得到的清單…（不會播放或錄製）';
    try {
      const next = await api('/api/course-discovery/scan', { method: 'POST', body: JSON.stringify(rescan && scan?.scanId ? { scanId: scan.scanId } : {}) });
      const sameList = rescan && scan?.scanId && next.scanId === scan.scanId;
      if (!sameList) selection = next.scanId ? allSelection(next.items) : new Set();
      else for (const item of next.items) if (!scan.items.some((old) => old.id === item.id) && !item.locked) selection.add(item.id);
      scan = next; $('#discoveryStatus').textContent = next.blocker ? '' : sameList ? `已更新清單，新增 ${next.added} 部，重複的不會再加入。` : '讀取完成。請確認清單與範圍。';
      renderList(); schedulePreview();
    } catch (error) { scan = null; selection = new Set(); $('#discoveryResult').innerHTML = renderError(error.message); $('#discoveryPlanBox').classList.add('hidden'); $('#discoveryStatus').textContent = ''; }
    finally { busy = false; updateButtons(); }
  }

  async function create() {
    const acknowledgements = { recordPermission: $('#dAckRecord').checked, privateProcessing: $('#dAckPrivate').checked };
    if (!acknowledgements.recordPermission || !acknowledgements.privateProcessing) return toast('請先勾選兩項授權確認');
    busy = true; updateButtons();
    try {
      const result = await api('/api/course-discovery/plan', { method: 'POST', body: JSON.stringify({ scanId: scan.scanId, selected: [...selection], ...opts(), title: $('#discoveryTitle').value, acknowledgements }) });
      toast(`已建立 Agent 學習計畫（${result.summary?.lessons?.length || selection.size} 部）。準備好瀏覽器後，在下方任務按「開始」。`);
      $('#dAckRecord').checked = false; $('#dAckPrivate').checked = false;
      document.querySelector('.nav-item[data-view="agentConsoleView"]')?.dispatchEvent(new Event('click'));
    } catch (error) { toast(error.message); }
    finally { busy = false; updateButtons(); }
  }

  async function loadLocal() {
    try { $('#discoveryLocal').innerHTML = renderLocal(await api('/api/course-discovery/local')); } catch (error) { $('#discoveryLocal').innerHTML = renderError(error.message); }
  }

  $('#discoveryRead').onclick = () => read(false);
  $('#discoveryRescan').onclick = () => read(true);
  $('#discoveryCreate').onclick = create;
  $$('[data-d-opt]').forEach((input) => input.onchange = schedulePreview);
  ['#dAckRecord', '#dAckPrivate'].forEach((id) => $(id).onchange = updateButtons);
  $('#discoveryLocalToggle').addEventListener('toggle', (event) => { if (event.target.open) loadLocal(); });
  $('#discoveryLocalScan').onclick = async () => { try { await api('/api/course-discovery/local/scan', { method: 'POST', body: '{}' }); toast('已交給既有匯入流程：檔案穩定後會自動轉成逐字稿'); setTimeout(loadLocal, 800); } catch (error) { toast(error.message); } };
  updateButtons();
}
