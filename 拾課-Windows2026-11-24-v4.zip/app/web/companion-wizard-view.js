// P8 Companion 設定精靈 — pure render helpers (no DOM access). Every page/remote string is escaped.
import { esc } from './p4c-view.js';

const time = (s) => { if (!Number.isFinite(s)) return '—'; const n = Math.floor(s); const h = Math.floor(n / 3600), m = Math.floor((n % 3600) / 60), x = n % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}`; };
const CAP = [['play', '播放／暫停'], ['setRate', '倍速'], ['captions', '字幕 CC'], ['nextLesson', '平台的「下一部」'], ['blockerDetection', '偵測登入／驗證／付款畫面']];

/** The five wizard steps derived from companionView(). */
export function wizardSteps(companion = {}) {
  const installed = Boolean(companion.paired || companion.connected);
  const tooOld = companion.extensionOk === false;
  return [
    { key: 'install', done: installed && !tooOld, title: '安裝瀏覽器擴充功能', doneText: companion.extensionVersion ? `已安裝（版本 ${companion.extensionVersion}）` : '已安裝',
      todo: tooOld ? `擴充功能版本 ${companion.extensionVersion} 太舊：請到 chrome://extensions 按「重新載入」（需要 ${companion.minExtensionVersion} 以上）。`
        : '在 Chrome 開啟 chrome://extensions → 開啟「開發人員模式」→「載入未封裝項目」→ 選擇本程式資料夾裡的 extension 資料夾。' },
    { key: 'pair', done: Boolean(companion.paired), title: '配對', doneText: '已配對', todo: '按「產生配對碼」，再把配對碼貼到擴充功能視窗。配對碼兩分鐘內有效。' },
    { key: 'connect', done: Boolean(companion.connected) && companion.browserOnline !== false, title: '連線', doneText: '擴充功能已連線',
      todo: companion.connected && companion.browserOnline === false ? '瀏覽器回報目前離線，請確認網路。' : '開著瀏覽器、確認擴充功能已啟用；通常幾秒內就會連上。' },
    { key: 'tab', done: Boolean(companion.tabSelected) && companion.sitePermission !== false, title: '選擇課程分頁並允許網站',
      doneText: `已選擇 ${companion.site || '分頁'}${companion.platform ? `（${companion.platform.label}）` : ''}`,
      todo: companion.tabSelected && companion.sitePermission === false ? `請在擴充功能允許 ${companion.site || '這個網站'}。` : '打開要看的課程頁，按擴充功能圖示 →「使用這個分頁」，並允許這個網站。只會存取你選的這一個分頁。' },
    { key: 'test', done: null, title: '測試連線', doneText: '', todo: '只讀取播放器狀態：不會播放、暫停、切換影片或錄影。' }
  ];
}

export function renderTestResult(test) {
  if (!test) return '';
  if (test.error) return `<div class="wizard-result bad" role="status"><b>${esc(test.error.title)}</b><p>${esc(test.error.next)}</p><code>${esc(test.error.code)}</code></div>`;
  const p = test.player || {};
  const rows = [
    ['平台', test.platform?.label || '—'], ['播放器', p.found ? '已找到' : '沒有找到可用的播放器'],
    ...(p.found ? [['目前影片', p.title || '—'], ['時間', `${time(p.currentTime)}${p.duration ? ` / ${time(p.duration)}` : ''}`], ['倍速', p.rate ? `${p.rate}×` : '—'], ['狀態', p.paused === false ? '播放中' : '暫停'], ['字幕 CC', p.captions?.available ? (p.captions.on ? '已開啟' : '可開啟') : '這部影片沒有字幕'], ['播放清單', p.isPlaylist ? '是' : '否']] : [])
  ];
  return `<div class="wizard-result ${test.ok ? 'good' : 'warn'}" role="status">
    <b>${test.ok ? '連線正常，Agent 可以操作這個分頁' : test.blocker ? esc(test.blocker.title) : '已連線，但還不能開始'}</b>
    ${test.blocker ? `<p>${esc(test.blocker.next)}</p><code>${esc(test.blocker.code)}</code>` : ''}
    <dl class="wizard-grid">${rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl>
    <ul class="cap-list">${CAP.map(([key, label]) => `<li class="${test.capabilities?.[key] ? 'yes' : 'no'}">${test.capabilities?.[key] ? '✓' : '需你操作'} ${label}</li>`).join('')}</ul>
    ${test.platform ? `<div class="auto-cols"><div><b>Agent 自動處理</b><ul>${test.platform.automatic.map((x) => `<li>✓ ${esc(x)}</li>`).join('')}</ul></div><div><b>需要你操作</b><ul>${test.platform.needsUser.map((x) => `<li>○ ${esc(x)}</li>`).join('')}</ul></div></div>` : ''}
    <small class="hint">測試時間 ${esc(new Date(test.testedAt).toLocaleTimeString('zh-TW'))}・只讀取，沒有播放或錄影</small>
  </div>`;
}

export function renderCompanionWizard(companion, { test = null, pairingCode = null, testing = false } = {}) {
  if (!companion) return '';
  const steps = wizardSteps(companion);
  const ready = steps.slice(0, 4).every((step) => step.done);
  const current = steps.findIndex((step) => step.done === false);
  return `<section class="tool-card companion-wizard ${ready ? 'ready' : ''}" aria-labelledby="wizardHeading">
    <div class="card-heading"><div><p class="tool-number">Companion 設定精靈</p><h2 id="wizardHeading">${ready ? '瀏覽器已準備好' : '讓 Agent 能操作你的課程分頁'}</h2></div><span class="state-chip ${ready ? 'done' : 'needs-user'}">${ready ? '可以開始' : `第 ${current + 1} 步`}</span></div>
    <ol class="wizard-steps">${steps.map((step, i) => `<li class="${step.done === true ? 'ok' : i === current ? 'current' : 'todo'}" data-step="${step.key}">
      <span class="mark">${step.done === true ? '✓' : i + 1}</span><div><b>${esc(step.title)}</b><p>${esc(step.done === true ? step.doneText : step.todo)}</p>
      ${step.key === 'pair' && !step.done ? `<button type="button" class="mini-button" data-wizard-pair>產生配對碼</button>${pairingCode ? ` <code class="pair-code">${esc(pairingCode)}</code>` : ''}` : ''}
      ${step.key === 'test' ? `<button type="button" class="secondary-button" data-wizard-test${testing ? ' disabled' : ''}>${testing ? '測試中…' : '測試連線'}</button>` : ''}</div></li>`).join('')}</ol>
    ${renderTestResult(test)}
    <p class="hint">Agent 不會自動登入、略過廣告、解除 DRM、取得串流網址、讀取 cookies 或下載影片；遇到登入、驗證、付款或看不懂的頁面會安全停下，等你處理後按「繼續」。</p>
  </section>`;
}
