import { formToRequest, renderConfirmation, renderCourseEditor, renderJobs, renderOptions } from './agent-console-view.js';
import { renderCompanionWizard } from './companion-wizard-view.js';

// P5 wiring for「Agent 學習」. Every status comes from /api/agent-console; the page never controls a player.
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const api = async (url, options = {}) => {
  const response = await fetch(url, { ...options, headers: options.body ? { 'content-type': 'application/json' } : {} });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.message || data.error || '操作失敗'), { code: data.error });
  return data;
};
const toast = (message) => { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(el._timer); el._timer = setTimeout(() => el.classList.remove('show'), 3200); };
const blankCourse = () => ({ title: '', rightsBasis: 'personal-study', lessons: [{ url: '' }], from: 1, to: 1 });
let courses = [blankCourse()]; let options = { captureMode: 'video', rate: 1, captions: false, transcriptLanguage: 'auto', translationLanguage: 'none' }; let plan = null; let step = 1;
const visible = () => !$('#agentConsoleView').classList.contains('hidden');

function showStep(next) {
  step = next;
  $$('.console-step').forEach((section) => section.classList.toggle('hidden', Number(section.dataset.step) !== step));
  $$('.stepper li').forEach((item) => { const n = Number(item.dataset.step); item.classList.toggle('active', n === step); item.classList.toggle('done', n < step); });
}

function renderEditor() {
  $('#consoleCourses').innerHTML = renderCourseEditor(courses);
  $$('#consoleCourses [data-field]').forEach((input) => input.oninput = input.onchange = () => {
    const course = courses[Number(input.dataset.course)]; const field = input.dataset.field;
    if (input.dataset.lesson != null) { const lesson = course.lessons[Number(input.dataset.lesson)]; lesson[field === 'lessonTitle' ? 'title' : field] = input.value; }
    else course[field] = field === 'from' || field === 'to' ? Number(input.value) : input.value;
  });
  $$('[data-add-lesson]').forEach((button) => button.onclick = () => { const course = courses[Number(button.dataset.addLesson)]; course.lessons.push({ url: '' }); course.to = course.lessons.length; renderEditor(); });
  $$('[data-remove-lesson]').forEach((button) => button.onclick = () => { const [c, l] = button.dataset.removeLesson.split(':').map(Number); courses[c].lessons.splice(l, 1); courses[c].from = 1; courses[c].to = courses[c].lessons.length; renderEditor(); });
  $$('[data-remove-course]').forEach((button) => button.onclick = () => { courses.splice(Number(button.dataset.removeCourse), 1); renderEditor(); });
}

function renderOptionForm() {
  $('#consoleOptions').innerHTML = renderOptions(options);
  $$('input[name="consoleMode"]').forEach((input) => input.onchange = () => { options.captureMode = input.value; });
  $$('[data-option]').forEach((input) => input.onchange = () => { options[input.dataset.option] = input.type === 'checkbox' ? input.checked : input.value; });
}

async function buildPlan() {
  const body = formToRequest(courses, options);
  if (!body.courses.length) return toast('請至少貼上一個課程頁網址');
  try { plan = await api('/api/agent-console/plans', { method: 'POST', body: JSON.stringify(body) }); $('#consoleConfirm').innerHTML = renderConfirmation(plan); showStep(3); }
  catch (error) { toast(error.message); }
}

async function confirmPlan() {
  if (!plan) return;
  const acknowledgements = { recordPermission: $('#ackRecord')?.checked === true, privateProcessing: $('#ackPrivate')?.checked === true };
  if (!acknowledgements.recordPermission || !acknowledgements.privateProcessing) return toast('請先勾選兩項授權確認');
  try {
    await api(`/api/agent-console/jobs/${plan.job.id}/confirm`, { method: 'POST', body: JSON.stringify({ planHash: plan.planHash, acknowledgements }) });
    toast('已確認。準備好瀏覽器後，在下方任務按「開始」'); plan = null; courses = [blankCourse()]; renderEditor(); showStep(1); refresh();
  } catch (error) { toast(error.message); }
}

// P8 setup wizard state. The test only reads the player (detect + getState): nothing plays or records.
const wizard = { test: null, pairingCode: null, testing: false };
function renderWizard(companion) {
  $('#consoleCompanion').innerHTML = renderCompanionWizard(companion, wizard);
  const pair = $('#consoleCompanion [data-wizard-pair]');
  if (pair) pair.onclick = async () => {
    try { const { code, expiresInMs } = await api('/api/companion/pairing-code', { method: 'POST', body: '{}' }); wizard.pairingCode = code; renderWizard(companion); setTimeout(() => { wizard.pairingCode = null; refresh(); }, expiresInMs); }
    catch (error) { toast(error.message); }
  };
  const test = $('#consoleCompanion [data-wizard-test]');
  if (test) test.onclick = async () => {
    wizard.testing = true; renderWizard(companion);
    try { wizard.test = await api('/api/agent-console/companion/test', { method: 'POST', body: '{}' }); }
    catch (error) { wizard.test = { error: { code: error.code || 'AGENT_ERROR', title: '測試失敗', next: error.message } }; }
    finally { wizard.testing = false; renderWizard(wizard.test?.companion || companion); }
  };
}

async function refresh() {
  try {
    const data = await api('/api/agent-console');
    renderWizard(data.companion);
    $('#consoleJobs').innerHTML = renderJobs(data.jobs);
    $$('#consoleJobs [data-console-action]').forEach((button) => button.onclick = async () => {
      const id = button.closest('[data-job]').dataset.job; const action = button.dataset.consoleAction;
      if (action === 'cancel' && !confirm('確定要取消這個任務嗎？已錄好的部分會保留。')) return;
      button.disabled = true;
      try { await api(`/api/agent-console/jobs/${id}/${action}`, { method: 'POST', body: '{}' }); toast({ start: '已開始', pause: '正在安全停止…', resume: '已繼續', cancel: '已取消' }[action]); }
      catch (error) { toast(error.message); }
      finally { refresh(); }
    });
  } catch {}
}

$('#consoleAddCourse').onclick = () => { courses.push(blankCourse()); renderEditor(); };
$('#consoleNext1').onclick = () => { renderOptionForm(); showStep(2); };
$('#consoleBack2').onclick = () => showStep(1);
$('#consoleNext2').onclick = buildPlan;
$('#consoleBack3').onclick = () => showStep(2);
$('#consoleConfirmButton').onclick = confirmPlan;
document.querySelector('.nav-item[data-view="agentConsoleView"]')?.addEventListener('click', refresh);
renderEditor(); renderOptionForm(); showStep(1); refresh();
setInterval(() => { if (visible()) refresh(); }, 2000);
