import { renderTranscriptLibrary } from './transcript-library-view.js';
const $ = (selector) => document.querySelector(selector); let items = [];
async function api(url, options) { const response = await fetch(url, options); const data = await response.json(); if (!response.ok) throw new Error(data.message || data.error || '操作失敗'); return data; }
function toast(message) { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(el._timer); el._timer = setTimeout(() => el.classList.remove('show'), 2400); }
function filtered() { const query = $('#transcriptLibrarySearch').value.trim().toLocaleLowerCase('zh-TW'); const mode = $('#transcriptLibraryFilter').value; return items.filter((item) => (mode === 'trash' ? item.trashed : mode === 'archived' ? item.archived && !item.trashed : !item.trashed) && (!query || item.title.toLocaleLowerCase('zh-TW').includes(query))); }
async function openItem(id) {
  try {
    const controller = window.courseMemory;
    if (!controller?.refresh || !controller?.openCourse) throw new Error('課程檢視器尚未準備好，請重新整理頁面');
    await controller.refresh({ preserveCourse: false });
    if (!controller.getCourses().some((course) => course.id === id)) throw new Error('找不到這筆課程，請按重新整理後再試');
    controller.openCourse(id);
  } catch (error) { toast(error.message || '無法開啟內容'); }
}
function render() {
  const active = items.filter((item) => !item.trashed).length, trashed = items.filter((item) => item.trashed).length;
  $('#transcriptLibrarySummary').textContent = `${active} 筆內容${trashed ? ` · 垃圾桶 ${trashed} 筆` : ''}`; $('#transcriptLibraryList').innerHTML = renderTranscriptLibrary(filtered());
  document.querySelectorAll('[data-open]').forEach((button) => button.onclick = () => openItem(button.dataset.open));
  document.querySelectorAll('[data-copy]').forEach((button) => button.onclick = async () => { try { const result = await api(`/api/transcripts/${button.dataset.copy}/text`); if (!result.text) throw new Error('這筆內容沒有逐字稿'); await navigator.clipboard.writeText(result.text); toast(`已複製 ${result.segmentCount} 段逐字稿`); } catch (error) { toast(error.message || '無法複製逐字稿'); } });
  document.querySelectorAll('[data-rename]').forEach((button) => button.onclick = async () => { const title = window.prompt('輸入新的名稱', button.dataset.title); if (title == null) return; try { await api(`/api/transcripts/${button.dataset.rename}/rename`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ title }) }); toast('名稱已更新'); await load(); await window.courseMemory?.refresh(); } catch (error) { toast(error.message); } });
  document.querySelectorAll('[data-trash]').forEach((button) => button.onclick = async () => { if (!window.confirm(`把「${button.dataset.title}」移到垃圾桶？\n\n內容會從一般列表隱藏，但原始影音、逐字稿和雲端備份不會刪除，可隨時還原。`)) return; try { await api(`/api/transcripts/${button.dataset.trash}/trash`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ confirm: true }) }); toast('已移到垃圾桶'); await load(); await window.courseMemory?.refresh(); } catch (error) { toast(error.message); } });
  document.querySelectorAll('[data-restore]').forEach((button) => button.onclick = async () => { try { await api(`/api/transcripts/${button.dataset.restore}/restore`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ confirm: true }) }); toast('已還原內容'); await load(); await window.courseMemory?.refresh(); } catch (error) { toast(error.message); } });
}
async function load() { try { items = await api('/api/transcripts'); render(); } catch (error) { toast(error.message); } }
$('#transcriptLibrarySearch').oninput = render; $('#transcriptLibraryFilter').onchange = render; $('#transcriptLibraryRefresh').onclick = load; document.querySelector('[data-view="transcriptLibraryView"]').addEventListener('click', load); load();
$('#transcriptLibraryOpenFolder').onclick = async () => { try { await api('/api/library/open-recordings', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' }); toast('已開啟影片資料夾'); } catch (error) { toast(error.message); } };
$('#transcriptLibraryImport').onclick = () => { if (window.confirm('請只匯入你擁有或已獲授權處理的影片／錄音。確認後選擇檔案。')) $('#transcriptLibraryFile').click(); };
$('#transcriptLibraryFile').onchange = async (event) => {
  const file = event.target.files?.[0]; if (!file) return;
  const button = $('#transcriptLibraryImport'); const old = button.textContent; button.disabled = true; button.textContent = '正在匯入…';
  try {
    const response = await fetch('/api/imports/file', { method: 'POST', headers: { 'content-type': 'application/octet-stream', 'x-file-name': encodeURIComponent(file.name), 'x-rights-ack': 'true' }, body: file });
    const result = await response.json(); if (!response.ok) throw new Error(result.message || result.error || '匯入失敗');
    toast(`已匯入「${result.name}」，正在排入轉錄`); setTimeout(load, 1200);
  } catch (error) { toast(error.message || '匯入失敗'); }
  finally { event.target.value = ''; button.disabled = false; button.textContent = old; }
};

