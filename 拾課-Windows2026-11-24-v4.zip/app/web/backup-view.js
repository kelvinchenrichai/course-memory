// Pure render helpers for the 雲端備份 page (P4D). No DOM access; unit-tested in Node.
import { esc } from './p4c-view.js';

export const BACKUP_STATE = Object.freeze({ queued: '排隊中', uploading: '上傳中', verified: '已備份', failed: '失敗', blocked: '不允許上傳', waiting: '等待寫入完成' });
// P7B: one phase per course/recording, in the order a recording normally goes through them.
export const PHASE_TEXT = Object.freeze({ 'waiting-recording': '等待錄影結束', 'media-uploading': '媒體上傳中', 'media-backed-up': '媒體已備份', 'artifacts-uploading': '成果追加中', complete: '完整備份', 'needs-attention': '需要處理' });
const PHASE_TONE = { 'waiting-recording': 'running', 'media-uploading': 'running', 'media-backed-up': 'done', 'artifacts-uploading': 'running', complete: 'done', 'needs-attention': 'needs-user' };
const CONNECTION = {
  connected: ['已連線', 'good'], offline: ['離線（網路中斷）', 'bad'], 'auth-required': ['需要重新授權 rclone', 'bad'], 'not-configured': ['找不到 rclone 遠端', 'bad'],
  'rclone-missing': ['尚未安裝 rclone', 'bad'], 'not-set': ['尚未設定目的地', 'warn'], unknown: ['檢查中', 'warn'], error: ['無法連線', 'bad']
};
const ERROR_TEXT = {
  NETWORK_OFFLINE: '網路中斷，恢復後會自動重試', NETWORK_TIMEOUT: '連線逾時，稍後會自動重試', AUTH_REQUIRED: 'rclone 授權過期，請在電腦上執行 rclone config reconnect',
  REMOTE_NOT_CONFIGURED: '找不到 rclone 遠端設定', REMOTE_QUOTA: '雲端空間不足', REMOTE_RATE_LIMITED: '雲端暫時限流，稍後重試', RCLONE_UNAVAILABLE: '尚未安裝 rclone',
  VERIFY_MISSING: '上傳後在雲端找不到檔案', VERIFY_SIZE_MISMATCH: '雲端檔案大小不一致（可能只上傳了一部分）', VERIFY_HASH_MISMATCH: '雲端檔案內容不一致', LOCAL_CHANGED: '本機檔案在上傳時變動，已重新排隊',
  FILE_NOT_ALLOWED: '這個檔案不在允許備份的範圍，已略過', UPLOAD_FAILED: '上傳失敗', REMOTE_CHANGED: '雲端檔案有變動，已重新排隊',
  MEDIA_STILL_WRITING: '錄影檔仍在寫入，結束且穩定後才會上傳', MEDIA_CHANGED_AFTER_RECORDING: '錄影檔在錄製結束後被修改，沒有上傳'
};
export const errorText = (code) => ERROR_TEXT[code] || (code ? `錯誤代碼 ${code}` : '');

export function formatBytes(bytes) {
  const value = Number(bytes) || 0;
  if (value >= 1024 ** 3) return `${(value / 1024 ** 3).toFixed(1)} GB`;
  if (value >= 1024 ** 2) return `${(value / 1024 ** 2).toFixed(1)} MB`;
  if (value >= 1024) return `${Math.round(value / 1024)} KB`;
  return `${value} B`;
}

const POLICY_TEXT = { never: '只備份、不清理（最安全）', 'auto-when-low': '空間不足時，自動清理已驗證備份的本機原檔', manual: '由我手動清理已驗證備份的本機原檔' };

export function renderBackupSummary(status) {
  if (!status) return '<div class="empty-list">讀取備份狀態中…</div>';
  const [text, tone] = CONNECTION[status.connection?.state] || CONNECTION.unknown;
  const disk = status.disk || {};
  const tiles = ['queued', 'uploading', 'verified', 'failed'].map((key) => `<div class="backup-tile ${key}"><strong>${Number(status.counts?.[key] || 0)}</strong><span>${BACKUP_STATE[key]}</span></div>`).join('');
  const canClean = status.policy.cleanupPolicy !== 'never' && status.reclaimableBytes > 0;
  return `<div class="backup-status">
    <div class="env-row"><div><b>雲端連線</b><small>${status.destination.configured ? esc(status.destination.label || '已設定') : '尚未選擇目的地'}・私人備份，不建立分享連結</small></div><span class="env-badge ${tone}">${esc(text)}</span></div>
    <div class="env-row"><div><b>本機剩餘空間</b><small>警戒值 ${formatBytes(status.policy.warnFreeBytes)}；低於警戒值時，Agent 不會開始下一堂</small></div><span class="env-badge ${disk.low ? 'bad' : 'good'}">${disk.freeBytes == null ? '無法讀取' : `${formatBytes(disk.freeBytes)}${disk.low ? '・空間不足' : ''}`}</span></div>
    <div class="backup-tiles">${tiles}</div>
    ${status.current ? `<div class="backup-current"><small>正在上傳 ${esc(status.current.key)}</small><div class="bar"><i style="width:${Math.round((status.current.total ? status.current.bytes / status.current.total : 0) * 100)}%"></i></div></div>` : ''}
    <div class="env-row"><div><b>可安全清理</b><small>${esc(POLICY_TEXT[status.policy.cleanupPolicy])}</small></div><span class="env-badge ${status.reclaimableBytes ? 'good' : 'warn'}">${formatBytes(status.reclaimableBytes)}</span></div>
    ${canClean ? '<button id="backupCleanup" class="secondary-button" type="button">清理已驗證備份的本機原檔…</button>' : ''}
  </div>`;
}

export function renderBackupCourses(status) {
  if (!status) return '';
  const recording = (status.recording || []).map((item) => `<article class="process-card"><header><div><b>${esc(item.title)}</b><small>錄影結束、檔案關閉後會立刻開始備份媒體</small></div><span class="state-chip running">${esc(PHASE_TEXT['waiting-recording'])}</span></header></article>`).join('');
  if (!status.courses.length) return recording || '<div class="empty-list">還沒有備份紀錄。開啟自動備份後，錄影結束就會先備份媒體，逐字稿與知識整理完成後再追加。</div>';
  return recording + status.courses.map((course) => {
    const failed = course.items.filter((item) => item.status === 'failed' || item.status === 'blocked');
    return `<article class="process-card ${course.overall === 'failed' ? 'needs-user' : ''}">
      <header><div><b>${esc(course.title || course.courseId)}</b><small>課程代碼 ${esc(course.courseId)}・${formatBytes(course.verifiedBytes)} / ${formatBytes(course.totalBytes)}${course.localMediaCleaned ? '・本機原檔已清理（雲端有備份）' : ''}</small></div><span class="state-chip ${course.phase ? PHASE_TONE[course.phase] : course.overall === 'verified' ? 'done' : course.overall === 'failed' ? 'needs-user' : 'running'}" data-phase="${esc(course.phase || '')}">${esc(course.phase ? PHASE_TEXT[course.phase] : BACKUP_STATE[course.overall])}</span></header>
      ${course.reason ? `<p class="hint${course.phase === 'needs-attention' ? ' warn' : ''}">${esc(course.reason)}</p>` : ''}
      <div class="bar" role="progressbar" aria-valuenow="${Math.round(course.progress * 100)}" aria-valuemin="0" aria-valuemax="100"><i style="width:${Math.round(course.progress * 100)}%"></i></div>
      <ul class="backup-items">${course.items.map((item) => `<li><span>${esc(item.key)}</span><span class="state-chip ${item.status === 'verified' ? 'done' : item.status === 'failed' || item.status === 'blocked' ? 'needs-user' : 'running'}">${esc(BACKUP_STATE[item.status] || item.status)}${item.cleaned ? '・本機已清理' : ''}</span>${item.code ? `<small>${esc(errorText(item.code))}${item.retryAt ? '（稍後自動重試）' : ''}</small>` : ''}</li>`).join('')}</ul>
      <footer>${failed.length ? `<button class="mini-button" type="button" data-backup-retry="${esc(course.courseId)}">重試</button>` : ''}<button class="mini-button" type="button" data-backup-run="${esc(course.courseId)}">立即備份這堂</button></footer>
    </article>`;
  }).join('');
}

export function renderBackupSettings(status, remotes = []) {
  if (!status) return '';
  const current = status.destination.label;
  return `<label>雲端位置<select id="backupRemote">${remotes.length ? remotes.map((remote) => `<option value="${esc(remote.name)}">${esc(remote.name)}（${esc(remote.type)}）</option>`).join('') : '<option value="">尚未設定任何雲端位置</option>'}</select></label>
    <label>雲端資料夾名稱<input id="backupFolder" maxlength="120" placeholder="CourseMemory" value="CourseMemory"></label>
    <p class="hint">${current ? `目前目的地：${esc(current)}。` : ''}${remotes.some((remote) => remote.name === 'google-drive-desktop') ? '已連接 Google Drive 電腦版。' : '尚未連接雲端；可使用 rclone 建立遠端。'}</p>
    <label>清理策略<select id="backupPolicy">${Object.entries(POLICY_TEXT).map(([value, label]) => `<option value="${value}"${value === status.policy.cleanupPolicy ? ' selected' : ''}>${esc(label)}</option>`).join('')}</select></label>
    <label>空間警戒值（GB）<input id="backupWarn" type="number" min="1" max="2000" step="1" value="${Math.round(status.policy.warnFreeBytes / 1024 ** 3)}"></label>
    <label class="check-row"><input id="backupAuto" type="checkbox"${status.policy.autoUpload ? ' checked' : ''}>自動備份：錄影結束先備份媒體，逐字稿、字幕、摘要與知識包完成後再追加</label>
    <p class="hint">只上傳錄影／錄音原檔、逐字稿、字幕、摘要與知識包；config.json、金鑰、OBS 密碼、cookies、瀏覽器資料與暫存檔一律不上傳。</p>`;
}
