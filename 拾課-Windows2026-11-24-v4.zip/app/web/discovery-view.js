// P7A「匯入課程清單」pure render helpers (no DOM access). Every page-supplied string is escaped.
import { esc } from './p4c-view.js';

const CAP_LABELS = [['discover', '探索清單'], ['navigate', '開啟影片'], ['rate', '倍速'], ['captions', '字幕 CC'], ['autoNext', '自動下一部']];
const MODE_TEXT = { auto: '自動讀取', semi: '半自動（只讀你看得到的連結）', local: '本機檔案' };
const REJECT_TEXT = { sensitive: '含權杖／簽章的連結（已拒絕保存）', crossSite: '其他網站的連結', invalid: '無法辨識的連結', media: '影片檔或串流網址', unavailable: '已刪除或私人影片', duplicate: '頁面上重複的項目' };

export function clockText(seconds) {
  if (!Number.isFinite(seconds)) return '—';
  const n = Math.max(0, Math.round(seconds)); const h = Math.floor(n / 3600); const m = Math.floor((n % 3600) / 60); const s = n % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`;
}
export function hoursText(seconds) {
  if (!Number.isFinite(seconds) || seconds <= 0) return '0 分鐘';
  const h = Math.floor(seconds / 3600); const m = Math.round((seconds % 3600) / 60);
  return h ? `${h} 小時 ${m} 分鐘` : `${m} 分鐘`;
}
export function bytesText(bytes) {
  if (!Number.isFinite(bytes)) return '未知';
  return bytes >= 1024 ** 3 ? `${(bytes / 1024 ** 3).toFixed(1)} GB` : `${Math.max(1, Math.round(bytes / 1024 ** 2))} MB`;
}

/** Ids for「第 N 部到第 M 部」(1-based, inclusive). Locked items are never selected automatically. */
export function rangeSelection(items, from, to) {
  const n = Number(from); const m = Number(to);
  if (!Number.isInteger(n) || !Number.isInteger(m) || n < 1 || m < n) return null;
  return new Set(items.filter((item) => item.index >= n && item.index <= m && !item.locked).map((item) => item.id));
}
export const allSelection = (items) => new Set(items.filter((item) => !item.locked).map((item) => item.id));

export function renderBlocker(blocker) {
  if (!blocker) return '';
  return `<div class="discovery-blocker" role="alert" data-blocker="${esc(blocker.code)}"><b>${esc(blocker.title)}</b><p>${esc(blocker.next)}</p></div>`;
}

export function renderError(message) {
  return message ? `<div class="discovery-blocker" role="alert"><b>無法讀取</b><p>${esc(message)}</p></div>` : '';
}

export function renderPlatform(platform) {
  if (!platform) return '';
  const caps = CAP_LABELS.map(([key, label]) => `<li class="${platform.capabilities?.[key] ? 'yes' : 'no'}">${platform.capabilities?.[key] ? '✓' : '需你操作'} ${label}</li>`).join('');
  return `<div class="discovery-platform"><div><b>${esc(platform.label)}</b><span class="mode-badge ${esc(platform.discovery)}">${esc(MODE_TEXT[platform.discovery] || platform.discovery)}</span></div>
    <ul class="cap-list">${caps}</ul>
    <details><summary>哪些步驟會自動完成、哪些需要你</summary><p><b>自動：</b>${platform.automatic.map(esc).join('、')}</p><p><b>需要你：</b>${platform.needsUser.map(esc).join('、')}</p></details></div>`;
}

/** The discovered list with checkboxes. `selection` is a Set of item ids. */
export function renderScan(scan, selection) {
  if (!scan) return '';
  if (scan.blocker) return renderBlocker(scan.blocker);
  const rejected = Object.entries(scan.counts?.rejected || {}).filter(([, n]) => n > 0).map(([key, n]) => `${REJECT_TEXT[key] || key} ${n} 個`);
  const rows = scan.items.map((item) => `<li class="discovery-item${item.locked ? ' locked' : ''}" data-item="${esc(item.id)}">
      <label><input type="checkbox" data-select="${esc(item.id)}"${selection.has(item.id) ? ' checked' : ''}${item.locked ? ' disabled' : ''}><span class="idx">${item.index}</span><span class="t">${esc(item.title)}</span></label>
      <span class="d">${item.durationSec == null ? '時長未知' : clockText(item.durationSec)}</span>
      ${item.locked ? '<em class="badge warn">鎖住／需付費</em>' : ''}${item.alreadyPlanned ? '<em class="badge dup">已在其他任務</em>' : ''}
    </li>`).join('');
  return `${renderPlatform(scan.platform)}
    <div class="discovery-head"><div><p class="eyebrow">讀取結果</p><h3>${esc(scan.courseTitle)}</h3><small>${esc(scan.pageHost)} · 共 ${scan.items.length} 部${scan.added != null ? `（這次新增 ${scan.added} 部）` : ''}</small></div></div>
    ${scan.partial ? '<p class="hint warn">清單可能還沒全部載入：請在瀏覽器捲到清單最底下，再按「重新讀取」。已讀到的不會重複加入。</p>' : ''}
    ${rejected.length ? `<p class="hint">已略過：${rejected.map(esc).join('；')}</p>` : ''}
    <div class="range-row"><button type="button" class="mini-button" data-select-all>全選</button><button type="button" class="mini-button" data-select-none>全不選</button>
      <label>第 <input type="number" min="1" max="${scan.items.length}" value="1" data-range-from> 部</label><label>到第 <input type="number" min="1" max="${scan.items.length}" value="${scan.items.length}" data-range-to> 部</label><button type="button" class="mini-button" data-select-range>套用範圍</button>
      <span class="sel-count" aria-live="polite">已選 ${selection.size}／${scan.items.length} 部</span></div>
    <ol class="discovery-list">${rows}</ol>`;
}

export function renderEstimate(preview, { captureMode }) {
  if (!preview) return '<p class="hint">勾選影片後會顯示預估時間與空間。</p>';
  const e = preview.estimate;
  return `<div class="discovery-estimate"><div><span>預估播放／錄製時間</span><b>${hoursText(e.totalSeconds)}</b><small>影片 ${hoursText(e.sourceSeconds)}，倍速後 ${hoursText(e.recordSeconds)}</small></div>
    <div><span>預估${captureMode === 'audio' ? '錄音' : '錄影'}空間</span><b>${bytesText(e.bytes)}</b><small>${e.freeBytes == null ? '剩餘空間未知' : `剩餘 ${bytesText(e.freeBytes)}${e.spaceOk === false ? '，空間不足！' : ''}`}</small></div>
    <div><span>選擇</span><b>${preview.selected} 部</b><small>${e.unknownDurations ? `${e.unknownDurations} 部時長未知，未計入` : '時長都已知'}</small></div></div>
    ${preview.duplicates.length ? `<p class="hint warn">重複項目：${preview.duplicates.length} 部已在其他 Agent 任務中（${preview.duplicates.slice(0, 5).map((item) => esc(item.title)).join('、')}${preview.duplicates.length > 5 ? '…' : ''}）。仍要建立嗎？可以先取消勾選。</p>` : ''}
    <p class="hint">${esc(e.basis)}</p>`;
}

export function renderLocal(local) {
  if (!local) return '';
  const rows = local.files.map((file) => `<li><span class="t">${esc(file.name)}</span><span class="d">${bytesText(file.sizeBytes)}</span>${file.inLibrary ? '<em class="badge dup">已在課程庫</em>' : '<em class="badge">等待處理</em>'}</li>`).join('');
  return `<p class="hint">網頁無法指定電腦上的路徑。請把影片放進設定中的「錄影資料夾」，再交給既有的匯入流程。</p>
    <ol class="discovery-list local">${rows || '<li class="empty">錄影資料夾中沒有影片檔</li>'}</ol>`;
}
