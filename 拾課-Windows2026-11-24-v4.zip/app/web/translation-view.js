// P6 pure render helpers: 原文／翻譯／雙語 transcript and bilingual search rows. No DOM access.
import { esc } from './p4c-view.js';

export const MODES = Object.freeze([['original', '原文'], ['translation', '翻譯'], ['bilingual', '雙語']]);
export const TARGET_LABEL = Object.freeze({ 'zh-Hant': '繁體中文', en: '英文' });
const clock = (n = 0) => { n = Math.max(0, Math.floor(Number(n) || 0)); const h = Math.floor(n / 3600), m = Math.floor((n % 3600) / 60), s = n % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`; };

const STATE_TEXT = {
  none: '尚未翻譯', running: '翻譯中…', completed: '翻譯完成', 'needs-retry': '需要重試'
};
const CODE_TEXT = {
  TRANSLATION_PROVIDER_DISABLED: '設定中已關閉 AI。請到「設定」選擇 Ollama 或自備金鑰的服務。',
  TRANSLATION_KEY_MISSING: '尚未設定外部服務的金鑰。請到「設定」輸入。',
  TRANSLATION_EXTERNAL_CONSENT_REQUIRED: '尚未允許傳送逐字稿給外部 AI。請到「設定」確認後再重試。',
  TRANSLATION_AUTH_FAILED: '外部服務拒絕金鑰，請確認金鑰正確。',
  TRANSLATION_UNAVAILABLE: '連不上翻譯模型（Ollama 是否已啟動？）。',
  TRANSLATION_TIMEOUT: '翻譯逾時，請重試。',
  TRANSLATION_NOT_JSON: '模型回傳格式不正確，這一批沒有採用。',
  TRANSLATION_MISSING_ID: '模型漏掉了段落，這一批沒有採用。',
  TRANSLATION_UNKNOWN_ID: '模型回傳了不存在的段落，這一批沒有採用。',
  TRANSLATION_DUPLICATE_ID: '模型重複回傳同一段，這一批沒有採用。',
  TRANSLATION_ORDER_MISMATCH: '段落順序被打亂，這一批沒有採用。',
  TRANSLATION_INTERRUPTED: '上次翻譯中途停止，可從已完成的批次繼續。',
  TRANSLATION_RATE_LIMITED: '外部服務暫時限制請求次數，請稍後重試。',
  TRANSLATION_MODEL_NOT_FOUND: '找不到設定的模型，請到「設定」確認模型名稱。',
  TRANSLATION_BAD_TEXT: '有段落翻譯為空，這一批沒有採用。'
};
export const codeText = (code) => CODE_TEXT[code] || (code ? `翻譯失敗（${code}）` : '');

/** Toolbar above the transcript. `view` = GET /api/translations/:id?target=… */
export function renderTranscriptToolbar(mode, target, view) {
  const state = view?.state || 'none';
  const provider = view?.provider;
  const where = provider ? (provider.external ? `使用外部服務 ${provider.name}（${provider.model || ''}）` : provider.name === 'identity' ? '原文已是英文' : `本機 ${provider.name}（${provider.model || ''}）`) : '';
  const busy = state === 'running';
  return `<div class="transcript-toolbar">
    <div class="segmented" role="tablist" aria-label="逐字稿顯示">${MODES.map(([value, label]) => `<button type="button" role="tab" aria-selected="${value === mode}" class="${value === mode ? 'active' : ''}" data-transcript-mode="${value}">${label}</button>`).join('')}</div>
    <label class="target-pick">翻譯成<select data-translation-target>${Object.entries(TARGET_LABEL).map(([value, label]) => `<option value="${value}"${value === target ? ' selected' : ''}>${label}</option>`).join('')}</select></label>
    <span class="translation-state ${esc(state)}">${esc(STATE_TEXT[state] || state)}${view?.progress && busy ? `（${view.progress.done}/${view.progress.total} 批）` : ''}</span>
    ${busy ? '' : `<button type="button" class="mini-button" data-translate-run>${state === 'needs-retry' ? '重試翻譯' : state === 'completed' ? '重新檢查' : '開始翻譯'}</button>`}
    ${where ? `<small class="hint">${esc(where)}</small>` : ''}
    ${state === 'needs-retry' ? `<p class="hint warn">${esc(codeText(view.code))}${view.failedBatch ? `（第 ${view.failedBatch} 批）` : ''}${view.segments?.length ? ' 先前完成的翻譯仍保留顯示。' : ''}</p>` : ''}
  </div>`;
}

/** Segments in the chosen mode. Every row keeps data-seek = the segment's recording start time. */
export function renderTranscript(segments, translatedSegments, mode) {
  if (!segments?.length) return '<p>尚無逐字稿。</p>';
  const map = new Map((translatedSegments || []).map((item) => [item.segmentId, item.translatedText]));
  return segments.map((segment) => {
    const original = `<p class="seg-original" lang="und">${esc(segment.text)}</p>`;
    const translated = map.has(segment.id) ? `<p class="seg-translation">${esc(map.get(segment.id))}</p>` : '<p class="seg-translation missing">（尚未翻譯）</p>';
    const body = mode === 'translation' ? translated : mode === 'bilingual' ? original + translated : original;
    return `<div class="segment" data-segment="${esc(segment.id)}"><button class="time" data-seek="${Number(segment.start) || 0}" title="跳到 ${clock(segment.start)}">${clock(segment.start)}</button><div class="seg-body">${body}</div></div>`;
  }).join('');
}

/** One global search result. `row.lang` = original | translation; knowledge rows come from the older index. */
export function renderSearchRow(row) {
  const badge = row.kind === 'knowledge' ? '知識卡' : row.lang === 'translation' ? `翻譯・${TARGET_LABEL[row.language] || row.language}` : '原文';
  return `<div class="result" data-id="${esc(row.courseId)}" data-at="${Number(row.start) || 0}"><b>${esc(row.clock)}</b><span><strong>${esc(row.title)}</strong> <em class="lang-badge ${row.lang === 'translation' ? 'tr' : ''}">${esc(badge)}</em><br>${esc(row.excerpt)}</span></div>`;
}
