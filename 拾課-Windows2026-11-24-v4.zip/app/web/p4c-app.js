import { buildSettingsPatch, canStart, liveText, renderAudioDevices, renderCounts, renderEnvironment, renderModePanel, renderProcessing, renderSettingsForm } from './p4c-view.js';

// P4C wiring: mode-aware learning card, 處理中心, 設定. Every status shown here comes from the backend.
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const api = async (url, options = {}) => {
  const init = { ...options, headers: { ...(options.body ? { 'content-type': 'application/json' } : {}), ...(options.headers || {}) } };
  const response = await fetch(url, init); const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.message || data.error || '操作失敗'), { code: data.error });
  return data;
};
const toast = (message) => { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(el._timer); el._timer = setTimeout(() => el.classList.remove('show'), 2800); };
const clock = (n = 0) => { n = Math.max(0, Math.floor(n)); const h = Math.floor(n / 3600), m = Math.floor(n % 3600 / 60), s = n % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`; };

let env = null; let settings = null; let devices = null; let processing = null; let filter = 'all'; let mode = 'video'; let session = null; let timer = null; let pendingClears = new Set();

function goto(view) { document.querySelector(`.nav-item[data-view="${view}"]`)?.click(); }

// ---------- learning card ----------
function renderMode() {
  $$('.mode-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.mode === mode));
  const live = session?.active;
  $('.mode-picker')?.classList.toggle('hidden', Boolean(live)); $('#recordAckRow')?.classList.toggle('hidden', Boolean(live));
  $('#modePanel').innerHTML = live ? '' : renderModePanel(env, mode);
  $$('#modePanel [data-goto]').forEach((button) => button.onclick = () => goto(button.dataset.goto));
  $('#manualTimer')?.addEventListener('change', updateStartButton);
  updateStartButton();
}

function updateStartButton() {
  const button = $('#session'); if (!button) return;
  if (session?.active) { button.disabled = false; button.innerHTML = '<span class="record-dot"></span>結束這次學習'; return; }
  button.disabled = !canStart(env, mode, { acknowledged: $('#recordAck')?.checked, manualTimer: $('#manualTimer')?.checked }) || !$('#recordingTitle')?.value.trim();
  button.innerHTML = `<span class="record-dot"></span>${mode === 'audio' ? '開始錄音學習' : $('#manualTimer')?.checked && !env?.modes.video.ready ? '開始計時（不控制 OBS）' : '開始錄影學習'}`;
}

function renderSession(next) {
  session = next;
  const text = liveText(session);
  $('#learningCard').classList.toggle('live', Boolean(session?.active));
  $('#sessionLabel').textContent = text.label; $('#sessionTitle').textContent = text.title; $('#sessionHint').textContent = text.hint;
  clearInterval(timer);
  const tick = () => { $('#sessionTimer').textContent = session?.active && session.startedAt ? clock((Date.now() - session.startedAt) / 1000) : '00:00'; };
  tick(); if (session?.active) timer = setInterval(tick, 1000);
  renderMode();
}

async function toggleSession() {
  const button = $('#session'); button.disabled = true;
  try {
    if (session?.active) { const result = await api('/api/learning/stop', { method: 'POST', body: '{}' }); renderSession(result); toast(result.mode === 'audio' ? (result.queued ? '錄音已保存，已送去轉錄' : '錄音已停止') : result.capture?.kind === 'manual-timer' ? '計時已結束，請記得在 OBS 停止錄影' : 'OBS 已停止錄影，稍後會自動整理'); }
    else {
      const result = await api('/api/learning/start', { method: 'POST', body: JSON.stringify({ mode, title: $('#recordingTitle').value.trim(), recordPermissionAcknowledged: $('#recordAck').checked, manualTimer: $('#manualTimer')?.checked === true }) });
      renderSession(result); toast(mode === 'audio' ? '已開始錄音' : result.capture?.kind === 'manual-timer' ? '已開始計時（本程式沒有控制 OBS）' : 'OBS 已確認開始錄影');
    }
  } catch (error) { toast(error.message); await refreshEnvironment(true); }
  finally { updateStartButton(); window.courseMemory?.refresh?.(); }
}

// ---------- processing centre ----------
async function refreshProcessing() {
  try {
    processing = await api('/api/processing');
    const needs = processing.counts['needs-user'] || 0;
    $('#needsUserBadge').textContent = needs; $('#needsUserBadge').classList.toggle('hidden', !needs);
    if (!$('#processingView').classList.contains('hidden')) renderProcessingView();
  } catch {}
}

function renderProcessingView() {
  $('#processingCounts').innerHTML = `<button class="count-tab${filter === 'all' ? ' active' : ''}" type="button" data-filter="all">全部 <b>${processing?.items.length || 0}</b></button>${renderCounts(processing?.counts)}`;
  $$('#processingCounts [data-filter]').forEach((tab) => { tab.classList.toggle('active', tab.dataset.filter === filter); tab.onclick = () => { filter = tab.dataset.filter; renderProcessingView(); }; });
  $('#processingList').innerHTML = renderProcessing(processing, filter);
  $$('#processingList [data-action]').forEach((button) => button.onclick = async () => {
    button.disabled = true;
    try {
      if (button.dataset.action === 'retry-pipeline') { await api(`/api/processing/${button.dataset.job}/retry`, { method: 'POST', body: '{}' }); toast('已重新排入處理'); }
      else if (button.dataset.action === 'resume-agent') { await api(`/api/agent/jobs/${button.dataset.job}/resume`, { method: 'POST', body: '{}' }); toast('已請 Agent 繼續'); }
      else if (button.dataset.action === 'open-course') { window.courseMemory?.openCourse(button.dataset.course); return; }
      else if (button.dataset.action === 'rename-course') {
        const title = window.prompt('輸入新的影片／課程名稱', button.dataset.title || ''); if (title == null) return;
        await api(`/api/transcripts/${button.dataset.course}/rename`, { method: 'POST', body: JSON.stringify({ title }) }); toast('名稱已更新');
        await window.courseMemory?.refresh?.();
      }
      else if (button.dataset.action === 'archive-course') {
        if (!window.confirm('封存這筆課程紀錄？\n\n只會從處理中心與課程清單隱藏，不會刪除錄影、逐字稿或雲端備份；之後可以取消封存。')) return;
        await api(`/api/courses/${button.dataset.course}/archive`, { method: 'POST', body: JSON.stringify({ confirm: true }) }); toast('已封存（沒有刪除任何檔案）');
      }
    } catch (error) { toast(error.message); }
    finally { button.disabled = false; refreshProcessing(); }
  });
}

// ---------- settings ----------
async function refreshEnvironment(force = false) {
  try { env = await api(`/api/environment${force ? '?refresh=1' : ''}`); } catch { env = null; }
  $('#envList').innerHTML = renderEnvironment(env);
  if (!session?.active) renderMode();
}

function showProviderFields() {
  const provider = $('[data-key="aiProvider"]')?.value;
  $$('.provider-fields').forEach((box) => box.classList.toggle('hidden', box.dataset.provider !== provider));
}

async function loadSettings() {
  settings = await api('/api/settings'); pendingClears = new Set();
  $('#settingsForm').innerHTML = renderSettingsForm(settings);
  showProviderFields(); $('[data-key="aiProvider"]').onchange = showProviderFields;
  $$('#settingsForm [data-clear]').forEach((button) => button.onclick = () => { pendingClears.add(button.dataset.clear); button.closest('.secret-state').textContent = '將在儲存後清除'; });
  if (!session?.active) { mode = settings.values.learningMode; renderMode(); }
}

async function saveSettings(event) {
  event.preventDefault();
  const fields = { learningMode: $('input[name="learningMode"]:checked')?.value };
  $$('#settingsForm [data-key]').forEach((input) => { fields[input.dataset.key] = input.value; });
  const secretInputs = Object.fromEntries($$('#settingsForm [data-secret]').map((input) => [input.dataset.secret, input.value]));
  try {
    const result = await api('/api/settings', { method: 'PUT', body: JSON.stringify(buildSettingsPatch(fields, secretInputs, [...pendingClears])) });
    $$('#settingsForm [data-secret]').forEach((input) => { input.value = ''; });
    toast(result.restartRequired?.length ? '已儲存。部分設定需要重新啟動程式後生效' : result.changed?.length ? '設定已儲存' : '沒有變更');
    await loadSettings(); await refreshEnvironment(true);
  } catch (error) { toast(error.message); }
}

async function listDevices() {
  try { devices = await api('/api/audio/devices'); } catch (error) { devices = { error: error.code || 'ERROR' }; }
  $('#deviceList').innerHTML = renderAudioDevices(devices);
  $('#saveDevice').classList.toggle('hidden', !devices?.devices?.length);
}

async function saveDevice() {
  const index = Number($('input[name="audioDevice"]:checked')?.value);
  const device = devices?.devices?.[index]; if (!device) return toast('請先選一個裝置');
  try { await api('/api/audio/device', { method: 'PUT', body: JSON.stringify({ name: device.name }) }); toast('已選擇音訊裝置'); await listDevices(); await refreshEnvironment(true); }
  catch (error) { toast(error.message); }
}

// ---------- boot ----------
$$('.mode-tab').forEach((tab) => tab.onclick = () => { mode = tab.dataset.mode; renderMode(); });
$('#recordAck').onchange = updateStartButton;
$('#recordingTitle').oninput = updateStartButton;
$('#session').onclick = toggleSession;
$('#settingsCard').onsubmit = saveSettings;
$('#refreshEnv').onclick = () => refreshEnvironment(true);
$('#listDevices').onclick = listDevices;
$('#saveDevice').onclick = saveDevice;
$('#refreshProcessing').onclick = refreshProcessing;
$$('.nav-item[data-view]').forEach((item) => item.addEventListener('click', () => { if (item.dataset.view === 'processingView') { renderProcessingView(); refreshProcessing(); } if (item.dataset.view === 'settingsView') { loadSettings().catch((error) => toast(error.message)); refreshEnvironment(); } }));

window.cmLearning = { render: renderSession };
(async () => {
  try { await loadSettings(); } catch {}
  await refreshEnvironment();
  try { renderSession(await api('/api/learning')); } catch {}
  refreshProcessing();
  setInterval(refreshProcessing, 5000);
  setInterval(() => { if (!session?.active) refreshEnvironment(); }, 30000);
})();
