// Pure render helpers for the P5「Agent 學習」page. No DOM access; unit-tested in Node.
import { esc } from './p4c-view.js';

export const RATES = [1, 1.25, 1.5, 1.75, 2];
const LANG = { auto: '自動偵測', 'zh-Hant': '繁體中文', 'zh-Hans': '簡體中文', en: '英文', none: '不翻譯', zh: '中文', ja: '日文', ko: '韓文' };
const BASIS = { 'personal-study': '個人學習（已購買或可合法觀看）', owned: '我自己的影片', licensed: '已取得授權', cc: 'Creative Commons', 'public-domain': '公有領域', 'platform-permitted': '平台允許錄製' };
const STATE_TONE = { running: 'running', preparing: 'running', stopping: 'running', queued: 'waiting', 'awaiting-confirmation': 'waiting', completed: 'done', blocked: 'needs-user', failed: 'needs-user', cancelled: 'waiting' };

export function clock(seconds) {
  if (seconds == null || !Number.isFinite(Number(seconds))) return '—';
  const n = Math.max(0, Math.floor(Number(seconds))); const h = Math.floor(n / 3600), m = Math.floor((n % 3600) / 60), s = n % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
export const duration = (seconds) => { const m = Math.round((Number(seconds) || 0) / 60); return m >= 60 ? `約 ${Math.floor(m / 60)} 小時 ${m % 60} 分` : `約 ${m} 分鐘`; };
const gb = (bytes) => `${((Number(bytes) || 0) / 1024 ** 3).toFixed(1)} GB`;

/** Companion banner: tells the user exactly what is missing before Agent can watch. */
export function renderCompanion(companion) {
  if (!companion) return '';
  const steps = [
    [companion.paired, '已配對瀏覽器擴充功能', '到「課程佇列」產生配對碼，貼到擴充功能'],
    [companion.connected, '擴充功能已連線', '開啟瀏覽器並確認擴充功能啟用'],
    [companion.tabSelected, `已選擇要使用的分頁${companion.site ? `（${companion.site}）` : ''}`, '在擴充功能視窗選擇課程分頁'],
    [companion.tabSelected && companion.sitePermission !== false, '已允許這個網站', '在擴充功能允許這個網站（選好分頁後確認）']
  ];
  const ready = steps.every(([ok]) => ok);
  return `<div class="console-banner ${ready ? 'good' : 'warn'}"><b>${ready ? '瀏覽器已準備好' : '開始前還需要你操作'}</b><ul>${steps.map(([ok, okText, todo]) => `<li class="${ok ? 'ok' : 'todo'}">${ok ? '✓' : '○'} ${esc(ok ? okText : todo)}</li>`).join('')}</ul></div>`;
}

/** Step 1: course cards. `courses` is the editable form state. */
export function renderCourseEditor(courses) {
  return courses.map((course, c) => `<article class="course-card" data-course="${c}">
    <div class="course-card-head"><label>課程名稱<input data-field="title" data-course="${c}" maxlength="120" value="${esc(course.title || '')}" placeholder="例如：AI 自動化進階課"></label>${courses.length > 1 ? `<button type="button" class="link-button" data-remove-course="${c}">移除課程</button>` : ''}</div>
    <label>授權依據<select data-field="rightsBasis" data-course="${c}">${Object.entries(BASIS).map(([value, label]) => `<option value="${value}"${value === (course.rightsBasis || 'personal-study') ? ' selected' : ''}>${esc(label)}</option>`).join('')}</select></label>
    <ol class="lesson-rows">${course.lessons.map((lesson, l) => `<li><input data-field="url" data-course="${c}" data-lesson="${l}" type="url" inputmode="url" placeholder="課程頁網址（不是影片檔網址）" value="${esc(lesson.url || '')}"><input data-field="lessonTitle" data-course="${c}" data-lesson="${l}" maxlength="120" placeholder="標題（可留空）" value="${esc(lesson.title || '')}"><input data-field="minutes" data-course="${c}" data-lesson="${l}" type="number" min="1" max="1440" placeholder="分鐘" value="${esc(lesson.minutes ?? '')}">${course.lessons.length > 1 ? `<button type="button" class="link-button" data-remove-lesson="${c}:${l}" aria-label="移除這部">✕</button>` : ''}</li>`).join('')}</ol>
    <div class="form-row"><button type="button" class="mini-button" data-add-lesson="${c}">＋ 加入一部影片</button>
      <label class="range">從第<select data-field="from" data-course="${c}">${course.lessons.map((_, i) => `<option${i + 1 === (course.from || 1) ? ' selected' : ''}>${i + 1}</option>`).join('')}</select>部到第<select data-field="to" data-course="${c}">${course.lessons.map((_, i) => `<option${i + 1 === (course.to || course.lessons.length) ? ' selected' : ''}>${i + 1}</option>`).join('')}</select>部</label></div>
  </article>`).join('');
}

/** Step 2: options. */
export function renderOptions(options) {
  const select = (field, values, current) => `<select data-option="${field}">${values.map((value) => `<option value="${value}"${String(value) === String(current) ? ' selected' : ''}>${esc(LANG[value] || `${value}×`)}</option>`).join('')}</select>`;
  return `<div class="mode-choice console-modes">
      <label class="mode-option"><input type="radio" name="consoleMode" value="video"${options.captureMode === 'video' ? ' checked' : ''}><span><b>錄影</b><small>用 OBS 錄下畫面與聲音</small></span></label>
      <label class="mode-option"><input type="radio" name="consoleMode" value="audio"${options.captureMode === 'audio' ? ' checked' : ''}><span><b>純錄音</b><small>只錄聲音，檔案小很多</small></span></label></div>
    <label>播放倍速${select('rate', RATES, options.rate)}<small class="hint">預設 1×，相容性與辨識最穩定。1.5× 約省 33% 錄影時間與空間，2× 約省 50%；拾課會還原音訊速度並用 TimeMap 對應原片時間。</small></label>
    <label class="check-row"><input type="checkbox" data-option="captions"${options.captions ? ' checked' : ''}>開啟平台字幕（CC）<small>平台有字幕時才會開啟；沒有時會記錄下來並繼續</small></label>
    <label>逐字稿語言${select('transcriptLanguage', ['auto', 'zh-Hant', 'zh-Hans', 'en'], options.transcriptLanguage)}</label>
    <label>翻譯語言${select('translationLanguage', ['none', 'zh-Hant', 'en'], options.translationLanguage)}<small class="hint">翻譯是選配：需要已啟用的 Ollama，或你自行設定的 OpenAI／Gemini API；未設定時不影響錄影與轉錄。</small></label>`;
}

/** Step 3: confirmation summary from POST /api/agent-console/plans. */
export function renderConfirmation(plan) {
  if (!plan) return '';
  const s = plan.summary; const e = s.estimate;
  const spaceText = e.freeBytes == null ? '無法讀取剩餘空間' : e.spaceOk ? `剩餘 ${gb(e.freeBytes)}，足夠` : `剩餘 ${gb(e.freeBytes)}，可能不夠`;
  return `<div class="confirm-grid">
      <div class="confirm-tile"><strong>${e.lessons}</strong><span>部影片${e.skipped ? `（${e.skipped} 部已錄過，略過）` : ''}</span></div>
      <div class="confirm-tile"><strong>${e.totalSeconds ? esc(duration(e.totalSeconds)) : '未知'}</strong><span>預估時間${e.unknownDurations ? `（${e.unknownDurations} 部長度未知未計入）` : ''}</span></div>
      <div class="confirm-tile ${e.spaceOk === false ? 'warn' : ''}"><strong>${gb(e.bytes)}</strong><span>預估空間・${esc(spaceText)}</span></div>
      <div class="confirm-tile"><strong>${s.captureMode === 'audio' ? '純錄音' : '錄影'}</strong><span>${s.rate}× 倍速・字幕 ${s.captions.length ? '開' : '關'}・逐字稿 ${esc(LANG[s.transcriptLanguage])}</span></div>
    </div>
    <p class="hint">${esc(e.basis)}</p>
    ${s.courses.map((course) => `<div class="confirm-course"><b>${esc(course.title)}</b><small>第 ${course.from}～${course.to} 部，共 ${course.count} 部・${esc(BASIS[course.rightsBasis] || course.rightsBasis)}</small>
      ${course.platforms.map((p) => `<div class="platform-note"><span>${esc(p.label)}</span><div><small>Agent 會自動：${p.automatic.map(esc).join('、')}</small><small class="needs-you">需要你操作：${p.needsYou.map(esc).join('；')}</small></div></div>`).join('')}</div>`).join('')}
    <ol class="confirm-lessons">${s.lessons.map((lesson) => `<li>${esc(lesson.title)}${lesson.skip ? '<small>（已錄過，略過）</small>' : ''}</li>`).join('')}</ol>
    <label class="check-row"><input type="checkbox" id="ackRecord">我確認有權觀看並錄製上面的內容（不繞過登入、DRM、付費牆或驗證）</label>
    <label class="check-row"><input type="checkbox" id="ackPrivate">我了解錄製內容只供私人學習，不會自動公開或分享</label>`;
}

function liveLine(label, value) { return `<div><span>${esc(label)}</span><b>${esc(value)}</b></div>`; }

/** One running / finished task card from liveView. */
const RECORDING_TEXT = { recording: '● 錄製中', starting: '準備錄製', maybe: 'OBS 可能仍在錄影，請確認', idle: '未錄製' };

export function renderJobCard(job) {
  const tone = STATE_TONE[job.status] || 'waiting'; const c = job.current; const pct = job.progress.total ? Math.round((job.progress.done / job.progress.total) * 100) : 0;
  return `<article class="process-card console-job ${tone}" data-job="${esc(job.id)}">
    <header><div><b>${esc(job.courses.map((course) => course.title).join('、') || 'Agent 學習任務')}</b><small>${esc(job.modeText)}・${job.rate}×${job.captions.length ? '・字幕開' : ''}・${esc(new Date(job.createdAt).toLocaleString('zh-TW'))}</small></div><span class="state-chip ${tone === 'done' ? 'done' : tone}">${esc(job.statusText)}</span></header>
    <div class="bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></div>
    <small class="hint">已完成 ${job.progress.done}／${job.progress.total} 部${job.progress.skipped ? `（略過 ${job.progress.skipped} 部）` : ''}</small>
    ${c ? `<div class="live-grid">${liveLine('目前課程', c.courseTitle || '—')}${liveLine('章節', `第 ${c.index} 部・${c.lessonTitle}`)}${liveLine('原影片時間', `${clock(c.sourceTime)}${c.duration ? ` / ${clock(c.duration)}` : ''}`)}${liveLine('錄製時間', clock(c.recordingSeconds))}${liveLine('倍速', c.playerRate ? `${c.playerRate}×（播放器回報）` : `${job.rate}×（計畫）`)}${liveLine('字幕 CC', c.captionsOn === true ? '已開啟' : c.captionsAvailable === false ? '這部影片沒有字幕' : c.captionsOn === false ? '未開啟' : '—')}${liveLine('錄製狀態', RECORDING_TEXT[c.recording] || '—')}${liveLine('平台', c.platform || '—')}${liveLine('下一部', job.next ? `第 ${job.next.index} 部・${job.next.title}` : '這是最後一部')}${liveLine('Checkpoint', job.checkpoint ? `${new Date(job.checkpoint.savedAt).toLocaleTimeString('zh-TW')}・已完成 ${job.checkpoint.completed} 部` : '尚未建立')}</div>` : ''}
    ${job.automation ? `<details class="automation"><summary>Agent 自動處理／需要你操作（${esc(job.automation.platform)}）</summary><div class="auto-cols"><div><b>Agent 自動處理</b><ul>${job.automation.automatic.map((item) => `<li>✓ ${esc(item)}</li>`).join('')}</ul></div><div><b>需要你操作</b><ul>${job.automation.needsUser.map((item) => `<li>○ ${esc(item)}</li>`).join('')}</ul></div></div></details>` : ''}
    ${job.blocker ? `<div class="blocker-card"><b>${esc(job.blocker.title)}</b><p>${esc(job.blocker.next)}</p>${job.obsMayStillBeRecording ? '<p class="warn">OBS 可能仍在錄影，請先到 OBS 確認。</p>' : ''}<code>${esc(job.blocker.code)}</code></div>` : ''}
    <footer>
      ${job.actions.start ? '<button class="primary-button" type="button" data-console-action="start">開始</button>' : ''}
      ${job.actions.pause ? '<button class="secondary-button" type="button" data-console-action="pause">暫停並安全停止</button>' : ''}
      ${job.actions.resume ? '<button class="primary-button" type="button" data-console-action="resume">我已處理好，繼續</button>' : ''}
      ${job.actions.cancel ? '<button class="quiet-button" type="button" data-console-action="cancel">取消任務</button>' : ''}
    </footer></article>`;
}

export function renderJobs(jobs) {
  return jobs?.length ? jobs.map(renderJobCard).join('') : '<div class="empty-list">還沒有任務。完成上面的三個步驟，就能讓 Agent 幫你看課。</div>';
}

/** Form state → API body. Empty rows are dropped; minutes are optional. */
export function formToRequest(courses, options) {
  return {
    courses: courses.map((course) => {
      const lessons = course.lessons.filter((lesson) => String(lesson.url || '').trim()).map((lesson) => ({ url: lesson.url.trim(), ...(lesson.title?.trim() ? { title: lesson.title.trim() } : {}), ...(Number(lesson.minutes) > 0 ? { minutes: Number(lesson.minutes) } : {}) }));
      const from = Math.min(Math.max(1, Number(course.from) || 1), lessons.length || 1); const to = Math.min(Math.max(from, Number(course.to) || lessons.length), lessons.length || 1);
      return { title: course.title, rightsBasis: course.rightsBasis || 'personal-study', lessons, from, to };
    }).filter((course) => course.lessons.length),
    captureMode: options.captureMode, rate: Number(options.rate), captions: { enabled: options.captions === true, languages: [] },
    transcriptLanguage: options.transcriptLanguage, translationLanguage: options.translationLanguage
  };
}
