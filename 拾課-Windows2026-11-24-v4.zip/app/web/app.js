import { renderTranscriptToolbar, renderTranscript, renderSearchRow, codeText } from './translation-view.js';
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let transcriptMode = 'original', translationTarget = 'zh-Hant', translationView = null, translationTimer = null;
let courses = [], current = null, tab = 'notes', session = null, status = null, timerId = null, learningQueue = [], jobs = [], clips = [];

const clock = (n = 0) => { n = Math.max(0, Math.floor(n)); const h = Math.floor(n / 3600), m = Math.floor(n % 3600 / 60), s = n % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`; };
const escapeHtml = (value = '') => { const el = document.createElement('div'); el.textContent = value; return el.innerHTML; };
const api = async (url, options) => { const response = await fetch(url, options); const data = await response.json(); if (!response.ok) throw new Error(data.error || '操作失敗'); return data; };
const toast = (message) => { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(el._timer); el._timer = setTimeout(() => el.classList.remove('show'), 2400); };
const duration = (course) => course.segments?.at(-1)?.end || 0;
const statusText = (course) => course.status === 'ready' ? '已整理' : course.status === 'error' ? '需要設定' : '處理中';

function showSection(id) {
  ['dashboard', 'transcriptLibraryView', 'queueView', 'agentConsoleView', 'liveView', 'processingView', 'creator', 'backupView', 'settingsView', 'viewer'].forEach((name) => $(`#${name}`).classList.toggle('hidden', name !== id));
  $$('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.view === id));
  document.querySelector('.sidebar').classList.remove('open'); window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showDashboard() {
  current = null; showSection('dashboard'); courseList();
}

function seek(at) {
  const video = $('#video');
  if (current?.demo) return toast(`Demo 時間碼：${clock(at)}`);
  video.currentTime = Number(at) || 0; video.play().catch(() => {});
}

// 封存的課程不刪除，只是預設不顯示；按「顯示已封存」可以看到並取消封存。
let showArchived = false;
function courseList() {
  const archivedCount = courses.filter((course) => course.archived && !course.trashed).length;
  const visible = courses.filter((course) => !course.trashed && (showArchived || !course.archived));
  $('#courses').innerHTML = (visible.map((course) => `<div class="course ${current?.id === course.id ? 'active' : ''}${course.archived ? ' archived' : ''}" data-id="${course.id}"><b>${escapeHtml(course.title)}</b><small><span>${new Date(course.createdAt).toLocaleDateString('zh-TW')}</span><span class="dot ${course.status === 'error' && !course.archived ? 'error' : ''}">${course.archived ? '已封存' : statusText(course)}</span>${course.archived ? `<button class="mini-link" type="button" data-unarchive="${course.id}">取消封存</button>` : ''}</small></div>`).join('') || '<div class="empty-list">還沒有課程</div>')
    + (archivedCount ? `<button class="mini-link archived-toggle" type="button" data-toggle-archived>${showArchived ? '隱藏已封存' : `顯示已封存（${archivedCount}）`}</button>` : '');
  $$('.course[data-id]').forEach((item) => item.onclick = (event) => { if (event.target.closest('[data-unarchive]')) return; openCourse(item.dataset.id); });
  $$('[data-toggle-archived]').forEach((button) => button.onclick = () => { showArchived = !showArchived; courseList(); });
  $$('[data-unarchive]').forEach((button) => button.onclick = async () => {
    try { await api(`/api/courses/${button.dataset.unarchive}/unarchive`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ confirm: true }) }); const item = courses.find((course) => course.id === button.dataset.unarchive); if (item) delete item.archived; courseList(); toast('已取消封存'); }
    catch (error) { toast(error.message); }
  });
}

function renderRecent() {
  const recent = courses.filter((course) => !course.archived).slice(0, 4);
  $('#recentCourses').innerHTML = recent.map((course, index) => `<div class="recent-item" data-id="${course.id}"><span class="course-thumb">${index + 1}</span><div><b>${escapeHtml(course.title)}</b><small>${(course.chapters || []).length} 章 · ${statusText(course)}</small></div><time>${duration(course) ? clock(duration(course)) : '—'}</time></div>`).join('') || '<div class="empty-list">把第一支 OBS 錄影放入監控資料夾，就會出現在這裡。</div>';
  $$('.recent-item').forEach((item) => item.onclick = () => openCourse(item.dataset.id));
}

function renderStats() {
  const realCourses = courses.filter((course) => !course.demo && !course.trashed);
  const source = realCourses;
  const chapters = source.reduce((sum, course) => sum + (course.chapters || []).length, 0);
  const markers = source.reduce((sum, course) => sum + (course.markers || []).length, 0);
  const seconds = source.reduce((sum, course) => sum + duration(course), 0);
  $('#courseCount').textContent = realCourses.length;
  $('#chapterCount').textContent = chapters;
  $('#markerCount').textContent = markers;
  $('#studyTime').textContent = seconds >= 3600 ? `${(seconds / 3600).toFixed(1)}h` : `${Math.round(seconds / 60)}m`;
}

function renderQueue() {
  const pending = learningQueue.filter((item) => item.status !== 'completed');
  $('#queueCount').textContent = `${pending.length} 堂`;
  $('#queueList').innerHTML = learningQueue.length ? learningQueue.map((item) => `<div class="queue-item"><div><b>${escapeHtml(item.title)}</b><small>${escapeHtml(item.platform)}${item.chapter ? ` · ${escapeHtml(item.chapter)}` : ''} · ${item.status === 'completed' ? '已完成' : '等待學習'}</small></div><div class="queue-actions"><a class="mini-button" href="${escapeHtml(item.url)}" target="_blank" rel="noopener">開啟</a>${item.status !== 'completed' ? `<button class="mini-button" data-complete="${item.id}">完成</button>` : ''}</div></div>`).join('') : '<div class="empty-list">先把想學的課程或章節加入佇列。</div>';
  $$('[data-complete]').forEach((button) => button.onclick = async () => { await api(`/api/queue/${button.dataset.complete}/complete`, { method: 'POST' }); toast('已完成，Agent 會接著讀取下一堂'); await refresh(); });
}

function renderStudio() {
  const realCourses = courses.filter((course) => !course.demo && course.status === 'ready');
  for (const selector of ['#clipCourse', '#cloudCourse']) {
    const select = $(selector); const selected = select.value;
    select.innerHTML = '<option value="">請選擇課程</option>' + realCourses.map((course) => `<option value="${course.id}">${escapeHtml(course.title)}</option>`).join('');
    if (realCourses.some((course) => course.id === selected)) select.value = selected;
  }
  $('#jobList').innerHTML = jobs.length ? jobs.slice(0, 8).map((job) => `<div class="job-item"><div><b>${escapeHtml(job.type)}</b><small>${job.error ? escapeHtml(job.error) : new Date(job.createdAt).toLocaleString('zh-TW')}</small></div><span class="job-status ${job.status}">${job.status}</span></div>`).join('') : '<div class="empty-list">目前沒有處理工作</div>';
  $('#clipOutputs').innerHTML = clips.length ? clips.map((clip) => `<div class="output-item"><div><b>${escapeHtml(clip.title)}</b><small>${clip.format} · ${Math.round(clip.duration)} 秒</small></div><a href="/api/clips/${clip.id}/file">下載</a></div>`).join('') : '<div class="empty-list">輸出的短片會出現在這裡</div>';
}

async function loadClipSuggestions() {
  const courseId = $('#clipCourse').value;
  if (!courseId) return $('#clipSuggestions').innerHTML = '<div class="empty-list">選擇課程後，系統會提出候選片段。</div>';
  const suggestions = await api(`/api/clips/suggestions?courseId=${encodeURIComponent(courseId)}`);
  $('#clipSuggestions').innerHTML = suggestions.length ? suggestions.map((item) => `<div class="clip-item"><span class="clip-score">${item.score}</span><div><b>${escapeHtml(item.title)}</b><p>${escapeHtml(item.hook)}</p><small>${clock(item.start)} → ${clock(item.end)} · ${Math.round(item.duration)} 秒</small></div><button class="mini-button" data-export="${item.id}" data-start="${item.start}" data-end="${item.end}" data-title="${escapeHtml(item.title)}">輸出</button></div>`).join('') : '<div class="empty-list">目前沒有合適的片段</div>';
  $$('[data-export]').forEach((button) => button.onclick = async () => { await api('/api/clips/export', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ courseId, start: Number(button.dataset.start), end: Number(button.dataset.end), title: button.dataset.title, format: $('#clipFormat').value }) }); toast('已加入剪輯輸出工作'); await refresh(); });
}

function setStatusLine(selector, ready, readyText, missingText) {
  const el = $(selector); el.className = `status-line ${ready ? 'good' : 'warn'}`; el.querySelector('span').textContent = ready ? readyText : missingText;
}

function renderSystemStatus() {
  if (!status) return;
  const env = status.environment || {};
  setStatusLine('#obsStatus', env.obs, 'OBS 已安裝，可以開始錄影', '尚未偵測到 OBS · 執行 Setup.ps1');
  setStatusLine('#whisperStatus', env.ffmpeg && env.python, `Whisper ${status.whisperModel} 已準備`, '轉錄工具尚未完成安裝');
  const aiName = status.aiProvider === 'ollama' ? `Ollama ${status.ollamaModel}` : status.aiProvider === 'openai' ? 'OpenAI API' : status.aiProvider === 'gemini' ? 'Gemini API' : '內建整理';
  setStatusLine('#aiStatus', env.ai, `${aiName} 可使用`, '將使用內建離線基本整理');
  const coreReady = env.ffmpeg && env.python;
  $('#systemLight').className = `system-light ${coreReady ? 'good' : 'warn'}`;
  $('#systemLight').lastChild.textContent = coreReady ? '轉錄環境就緒' : '還差一次安裝設定';
  $('#processingBadge').classList.toggle('hidden', !status.processing);
  $('#processingBadge').textContent = `正在整理 ${status.processing} 堂課`;
}

function notesPanel(course) {
  const citations = (cite = []) => cite.map((id) => { const segment = (course.segments || []).find((item) => item.id === id); return segment ? `<button class="cite" data-seek="${segment.start}" title="回到引用片段">${escapeHtml(id)} · ${clock(segment.start)}</button>` : ''; }).join('');
  const text = (item) => typeof item === 'string' ? item : item?.text || '';
  return (course.chapters || []).map((chapter, index) => `<article class="chapter"><button data-seek="${chapter.start}"><time>${clock(chapter.start)}</time><b>${String(index + 1).padStart(2, '0')} · ${escapeHtml(chapter.title)}</b></button><div class="chapter-body"><h4>本章重點</h4><ul>${(chapter.summary || []).map((item) => `<li>${escapeHtml(text(item))}${citations(item?.cite)}</li>`).join('')}</ul>${chapter.terms?.length ? `<h4>關鍵名詞</h4>${chapter.terms.map((item) => `<div class="term"><b>${escapeHtml(item.term)}</b>${item.zh ? `（${escapeHtml(item.zh)}）` : ''} — ${escapeHtml(item.explanation || item.definition)}${citations(item.cite)}</div>`).join('')}` : ''}${chapter.actions?.length ? `<h4>可以行動</h4><ul>${chapter.actions.map((item) => `<li>${escapeHtml(text(item))}${citations(item?.cite)}</li>`).join('')}</ul>` : ''}</div></article>`).join('') || `<p>${course.error ? escapeHtml(course.error) : '逐字稿完成後，章節知識會出現在這裡。'}</p>`;
}

function transcriptPanel(course) {
  // P6: 原文／翻譯／雙語. Demo/legacy courses without segment ids only show the original text.
  const view = translationView?.courseId === course.id ? translationView : null;
  const translatable = !course.demo && (course.segments || []).length;
  return (translatable ? renderTranscriptToolbar(transcriptMode, translationTarget, view) : '') + renderTranscript(course.segments || [], view?.segments || [], translatable ? transcriptMode : 'original');
}

const jsonHeaders = { 'content-type': 'application/json' };
async function loadTranslation({ preferPreference = false } = {}) {
  if (!current || current.demo) return;
  const id = current.id;
  try {
    if (preferPreference) { const pref = await api(`/api/translations/${encodeURIComponent(id)}?target=none`); if (['zh-Hant', 'en'].includes(pref.preference)) translationTarget = pref.preference; }
    const view = await api(`/api/translations/${encodeURIComponent(id)}?target=${translationTarget}`);
    if (current?.id !== id) return;
    translationView = view; if (tab === 'transcript') renderPanel();
    clearTimeout(translationTimer); if (view.state === 'running') translationTimer = setTimeout(() => loadTranslation(), 2500);
  } catch { translationView = null; }
}
async function runTranslation() {
  if (!current) return;
  try { await api(`/api/translations/${encodeURIComponent(current.id)}`, { method: 'POST', headers: jsonHeaders, body: JSON.stringify({ targetLanguage: translationTarget }) }); toast('已開始翻譯，完成的批次會先保存'); }
  catch (error) { toast(codeText(error.message)); }
  setTimeout(() => loadTranslation(), 400);
}
function bindTranscriptToolbar() {
  $$('[data-transcript-mode]').forEach((item) => item.onclick = () => { transcriptMode = item.dataset.transcriptMode; renderPanel(); });
  const select = $('[data-translation-target]'); if (select) select.onchange = () => { translationTarget = select.value; translationView = null; renderPanel(); loadTranslation(); };
  const run = $('[data-translate-run]'); if (run) run.onclick = runTranslation;
}

function quizPanel(course) {
  return (course.chapters || []).flatMap((chapter) => chapter.questions || []).map((question, index) => { const object = typeof question === 'object'; const q = object ? question.q : question; return `<div class="quiz"><b>Q${index + 1}</b><div>${escapeHtml(q)}${object && question.options?.length ? `<ol>${question.options.map((option) => `<li>${escapeHtml(option)}</li>`).join('')}</ol>` : ''}${object && question.answer ? `<details><summary>查看答案</summary><p>${escapeHtml(question.answer)}</p></details>` : ''}</div></div>`; }).join('') || '<p>尚無複習題。</p>';
}

function renderPanel() {
  if (!current) return;
  $('#panel').innerHTML = tab === 'notes' ? notesPanel(current) : tab === 'transcript' ? transcriptPanel(current) : quizPanel(current);
  $$('[data-seek]').forEach((item) => item.onclick = () => seek(item.dataset.seek));
  if (tab === 'transcript') bindTranscriptToolbar();
}

function renderMarkers() {
  const markers = current?.markers || [];
  $('#markerTotal').textContent = `${markers.length} 個`;
  $('#markers').innerHTML = markers.map((marker) => `<div class="marker"><button class="time" data-seek="${marker.at}">${clock(marker.at)}</button><span>${escapeHtml(marker.note)}</span></div>`).join('') || '<div class="marker"><span>觀看時按 Ctrl + Alt + M，重要片段會自動留在這裡。</span></div>';
  $$('#markers [data-seek]').forEach((item) => item.onclick = () => seek(item.dataset.seek));
}

function openCourse(id, at) {
  current = courses.find((course) => course.id === id); if (!current) return;
  transcriptMode = 'original'; translationView = null; clearTimeout(translationTimer); loadTranslation({ preferPreference: true });
  showSection('viewer');
  $('#title').textContent = current.title;
  $('#courseDate').textContent = new Date(current.createdAt).toLocaleDateString('zh-TW', { year: 'numeric', month: 'long', day: 'numeric' });
  $('#meta').textContent = `${current.language || '語言偵測中'} · ${(current.segments || []).length} 段逐字稿 · ${(current.chapters || []).length} 個章節 · ${clock(duration(current))}`;
  $('#state').textContent = statusText(current); $('#state').className = `pill ${current.status === 'error' ? 'error' : ''}`;
  const video = $('#video');
  if (current.demo) { video.classList.add('hidden'); $('#noVideo').classList.remove('hidden'); }
  else { video.classList.remove('hidden'); $('#noVideo').classList.add('hidden'); if (!video.src.endsWith(`/api/courses/${current.id}/video`)) video.src = `/api/courses/${current.id}/video`; }
  renderMarkers(); renderPanel(); courseList();
  document.querySelector('.sidebar').classList.remove('open'); window.scrollTo({ top: 0 });
  if (at != null) setTimeout(() => seek(at), 100);
}

function updateSession() {
  // P4C: the learning card is owned by p4c-app.js and shows only backend-confirmed state.
  window.cmLearning?.render(session);
}

async function refresh({ preserveCourse = true } = {}) {
  try {
    const [nextStatus, nextCourses, nextSession, nextQueue, nextJobs, nextClips] = await Promise.all([api('/api/status'), api('/api/courses'), api('/api/session'), api('/api/queue'), api('/api/jobs'), api('/api/clips')]);
    status = nextStatus; courses = nextCourses; session = nextSession; learningQueue = nextQueue; jobs = nextJobs; clips = nextClips;
    $('#folder').textContent = status.recordingsFolder;
    courseList(); renderRecent(); renderStats(); renderSystemStatus(); updateSession(); renderQueue(); renderStudio();
    if (preserveCourse && current) {
      const previous = current; const updated = courses.find((course) => course.id === current.id) || current; current = updated;
      if (previous.status !== updated.status || previous.segments?.length !== updated.segments?.length || previous.markers?.length !== updated.markers?.length) {
        $('#meta').textContent = `${current.language || '語言偵測中'} · ${(current.segments || []).length} 段逐字稿 · ${(current.chapters || []).length} 個章節 · ${clock(duration(current))}`;
        $('#state').textContent = statusText(current); $('#state').className = `pill ${current.status === 'error' ? 'error' : ''}`;
        renderMarkers(); renderPanel();
      }
    }
  } catch (error) { toast(`無法讀取本機服務：${error.message}`); }
}

function openNoteDialog() { $('#noteText').value = ''; $('#noteDialog').showModal(); setTimeout(() => $('#noteText').focus(), 50); }

$('#home').onclick = showDashboard; $('#backHome').onclick = showDashboard; $$('.nav-item[data-view]').forEach((item) => item.onclick = () => { current = null; showSection(item.dataset.view); courseList(); });
// The sidebar search shortcut is optional. Removing it must not abort the app bootstrap before
// window.courseMemory is published for the content library.
const focusNav = $('.nav-item[data-focus]');
if (focusNav) focusNav.onclick = () => { $('#search').focus(); document.querySelector('.sidebar').classList.remove('open'); };
$('#mobileMenu').onclick = () => document.querySelector('.sidebar').classList.toggle('open');
$('#openDemo').onclick = () => { const demo = courses.find((course) => course.demo); demo ? openCourse(demo.id) : toast('目前沒有 Demo'); };
// '#session' is handled by p4c-app.js (mode choice + backend-confirmed start/stop).
$('#scan').onclick = $('#refresh').onclick = async () => { await api('/api/scan', { method: 'POST' }); toast('已重新掃描錄影資料夾'); setTimeout(() => refresh(), 600); };
$('#quickMark').onclick = $('#addNote').onclick = openNoteDialog;
$('#saveNote').onclick = async (event) => { event.preventDefault(); const note = $('#noteText').value.trim(); if (!note) return $('#noteText').focus(); const url = current ? `/api/courses/${current.id}/markers` : '/api/markers'; const at = current && !current.demo ? $('#video').currentTime : 0; await api(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ note, at }) }); $('#noteDialog').close(); toast(current ? '筆記已加入這堂課' : '筆記已保存到目前時間點'); await refresh(); if (current) { current = courses.find((course) => course.id === current.id) || current; renderMarkers(); } };
$('#copyFolder').onclick = async () => { try { await navigator.clipboard.writeText(status.recordingsFolder); toast('錄影資料夾路徑已複製'); } catch { toast(status.recordingsFolder); } };
$('#queueForm').onsubmit = async (event) => { event.preventDefault(); await api('/api/queue', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ title: $('#queueTitle').value, url: $('#queueUrl').value, platform: $('#queuePlatform').value, chapter: $('#queueChapter').value }) }); event.target.reset(); toast('已加入學習佇列'); await refresh(); };
$('#ingestForm').onsubmit = async (event) => { event.preventDefault(); if (!$('#rightsAck').checked) return toast('請先確認素材使用權'); await api('/api/ingest/url', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ url: $('#ingestUrl').value, rights: { basis: $('#rightsBasis').value, owner: $('#rightsOwner').value, note: $('#rightsOwner').value, acknowledged: true, privateTransformAllowed: true } }) }); event.target.reset(); toast('已加入網址匯入工作'); await refresh(); };
$('#clipCourse').onchange = loadClipSuggestions;
$('#cloudForm').onsubmit = async (event) => { event.preventDefault(); if (!$('#cloudCourse').value) return toast('請先選擇課程'); await api('/api/backup/run', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ courseId: $('#cloudCourse').value }) }); toast('已開始安全備份'); };
$$('[data-view-target]').forEach((button) => { button.onclick = () => showView(button.dataset.viewTarget); });
$('#refreshJobs').onclick = () => refresh();
$$('.tabs button').forEach((item) => item.onclick = () => { $$('.tabs button').forEach((other) => other.classList.remove('active')); item.classList.add('active'); tab = item.dataset.tab; renderPanel(); });
document.addEventListener('keydown', (event) => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); $('#search').focus(); } if (event.key === 'Escape') $('#searchResults').innerHTML = ''; });
let searchTimer;
// P6: transcript hits come from the bilingual index (原文 + 翻譯); knowledge-card hits still come from the older index.
async function searchAll(query) {
  const q = encodeURIComponent(query);
  const [legacy, bilingual] = await Promise.all([api(`/api/search?q=${q}`).catch(() => []), api(`/api/translations/search?q=${q}`).catch(() => null)]);
  if (!bilingual) return legacy;
  return [...bilingual, ...legacy.filter((row) => row.kind === 'knowledge')].slice(0, 60);
}
$('#search').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(async () => { const query = $('#search').value.trim(); const rows = query ? await searchAll(query) : []; $('#searchResults').innerHTML = rows.length ? rows.map(renderSearchRow).join('') : query ? '<div class="empty-list">沒有找到相關內容</div>' : ''; $$('.result').forEach((item) => item.onclick = () => { openCourse(item.dataset.id, item.dataset.at); $('#searchResults').innerHTML = ''; $('#search').value = ''; }); }, 180); };

window.courseMemory = { refresh, openCourse, showDashboard, getCourses: () => courses, getSession: () => session };
refresh(); setInterval(() => refresh(), 8000);

// Browser Companion pairing (P3B). The pairing code is shown only here; the token never reaches this page.
async function renderCompanion() {
  try {
    const status = await api('/api/companion/status');
    $('#companionState').textContent = !status.paired ? '未配對' : status.connected ? (status.browserOnline === false ? '瀏覽器離線' : '已連線') : '已配對・未連線';
    const tab = status.tabs?.find((item) => item.bound);
    $('#companionTab').textContent = tab ? `使用中：${tab.origin || '未知網域'}${status.latestState?.lessonId ? `｜${status.latestState.lessonId}` : ''}` : '尚未在擴充功能中選擇要使用的分頁';
  } catch { $('#companionState').textContent = '無法讀取'; }
}
$('#companionPair').onclick = async () => { const { code, expiresInMs } = await api('/api/companion/pairing-code', { method: 'POST' }); $('#companionCode').textContent = code; toast(`配對碼 ${Math.round(expiresInMs / 60000)} 分鐘內有效`); setTimeout(() => { $('#companionCode').textContent = '—'; renderCompanion(); }, expiresInMs); };
$('#companionUnpair').onclick = async () => { await api('/api/companion/pairing', { method: 'DELETE' }); $('#companionCode').textContent = '—'; toast('已解除配對'); renderCompanion(); };
renderCompanion(); setInterval(renderCompanion, 5000);
