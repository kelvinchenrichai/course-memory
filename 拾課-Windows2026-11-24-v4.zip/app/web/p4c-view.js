// Pure render helpers for the P4C settings page, processing centre and learning-mode picker.
// No DOM access here, so the same functions are unit-tested in Node (tests/p4c-ui.test.mjs).

export const esc = (value = '') => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

export const STATE_LABEL = Object.freeze({ waiting: '等待中', running: '處理中', done: '已完成', 'needs-user': '需要你處理', skipped: '不適用' });
const SOURCE_LABEL = { video: '錄影', audio: '錄音', import: '匯入' };

const REASONS = {
  OBS_NOT_INSTALLED: '這台電腦還沒有安裝 OBS。',
  OBS_WEBSOCKET_UNREACHABLE: '已安裝 OBS，但目前連不上（OBS 沒開，或沒有啟用 WebSocket 伺服器）。',
  OBS_AUTH_FAILED: 'OBS WebSocket 密碼不正確，請到「設定」重新輸入。',
  FFMPEG_UNAVAILABLE: '找不到 ffmpeg，請先執行 Setup.ps1。',
  AUDIO_PLATFORM_UNSUPPORTED: '錄音模式目前只支援 Windows。',
  AUDIO_DEVICE_NOT_SELECTED: '還沒選擇要錄哪個音訊裝置。'
};
export const reasonText = (code) => REASONS[code] || '目前無法使用。';

function badge(ok, okText, badText, warn = false) {
  return `<span class="env-badge ${ok ? 'good' : warn ? 'warn' : 'bad'}">${esc(ok ? okText : badText)}</span>`;
}

/** Environment cards for the settings page. `env` comes from GET /api/environment. */
export function renderEnvironment(env) {
  if (!env) return '<div class="empty-list">正在檢查環境…</div>';
  const obsText = env.obs.websocket === 'connected' ? `已連線${env.obs.recording ? '・正在錄影' : ''}` : env.obs.websocket === 'auth-failed' ? '密碼錯誤' : env.obs.installed ? '已安裝・未連線' : '未安裝';
  const ai = env.ai || {};
  const aiName = { ollama: `Ollama ${ai.model || ''}`, openai: `OpenAI ${ai.model || ''}`, gemini: `Gemini ${ai.model || ''}`, none: '不使用 AI' }[ai.provider] || 'AI';
  const aiText = ai.knowledgeMode === 'basic' && ai.translationTarget === 'none' ? '基礎整理（不需要 AI）' : ai.provider === 'none' ? '尚未選擇 AI' : ai.provider === 'ollama' ? (ai.ready ? '可使用' : ai.reachable ? '未下載此模型' : 'Ollama 沒有在執行') : ai.keyConfigured ? '金鑰已設定' : '尚未設定金鑰';
  const rows = [
    ['OBS 錄影', env.obs.ready, obsText, '只有「錄影」模式需要；「錄音」模式不需要 OBS。', env.obs.installed],
    ['ffmpeg', env.ffmpeg.available, env.ffmpeg.available ? `已安裝 ${env.ffmpeg.version || ''}` : '未安裝', '轉錄與錄音都需要。', false],
    ['Whisper 轉錄', env.whisper.ready, transcriberText(env.whisper), transcriberHint(env.whisper), env.whisper.runtime],
    [aiName.trim(), ai.knowledgeMode === 'basic' && ai.translationTarget === 'none' ? true : ai.ready, aiText, ai.external ? '只有明確允許後才會把逐字稿送到外部服務。' : 'AI 不可用時會使用基礎規則式整理，課程仍可使用。', true],
    // P9: guidance only — the program never changes OBS settings.
    ['直播自動分段', env.obs.splitSupported === true, env.obs.splitSupported === true ? `可分段（WebSocket ${env.obs.websocketVersion}）` : env.obs.splitSupported === false ? `OBS 版本太舊（WebSocket ${env.obs.websocketVersion}，需要 5.5 以上）` : '連上 OBS 後才能確認', '直播工作台每段錄完就備份：OBS →「設定」→「輸出」→ 輸出模式「進階」→「錄影」分頁 → 勾選「自動分割檔案」，選「僅手動分割」或任意時間，格式建議 MKV。未開啟時會改成單一檔案錄影。', true],
    ['雲端備份', env.cloud.ready, env.cloud.driveFolder ? (env.cloud.destinationConfigured ? 'Google Drive 電腦版已設定' : '尚未設定目的地') : env.cloud.rclone ? (env.cloud.destinationConfigured ? '已設定' : '尚未設定目的地') : '尚未連接雲端', '選用功能。', true]
  ];
  return rows.map(([name, ok, text, hint, softFail]) => `<div class="env-row"><div><b>${esc(name)}</b><small>${esc(hint)}</small></div>${badge(ok, text, text, softFail)}</div>`).join('') + renderEngineDetails(env.whisper);
}

const BACKEND_TEXT = { ffmpeg: 'ffmpeg 內建', cli: 'whisper-cli' };
/** "whisper.cpp・ggml-small.bin（ffmpeg 內建）" — what transcription will actually use. Names only. */
export function transcriberText(whisper) {
  if (!whisper) return '檢查中';
  if (!whisper.ready) return whisper.reason || (whisper.runtime ? '缺少轉錄套件' : '尚未安裝');
  const model = whisper.model ? `・${whisper.model}` : '';
  const backend = whisper.backend ? `（${BACKEND_TEXT[whisper.backend] || whisper.backend}）` : '';
  return `${whisper.active || whisper.engine}${whisper.version ? ` ${whisper.version}` : ''}${model}${backend}`;
}

function transcriberHint(whisper) {
  if (!whisper) return '把聲音轉成逐字稿。';
  if (whisper.fallbackInUse) return `把聲音轉成逐字稿。faster-whisper 無法在這台電腦執行（${whisper.fasterWhisper?.reason || '無法載入'}），自動模式會改用 whisper.cpp。`;
  if (!whisper.ready && whisper.advice) return `把聲音轉成逐字稿。${whisper.advice}`;
  return '把聲音轉成逐字稿。';
}

/** One line per engine with the reason and advice, so「RuntimeError」is never all the user sees. */
export function renderEngineDetails(whisper) {
  if (!whisper || (!whisper.fasterWhisper && !whisper.whisperCpp)) return '';
  const line = (label, item, okText) => {
    if (!item) return '';
    const text = item.ready ? okText(item) : item.reason || '無法使用';
    return `<div class="env-row engine-detail"><div><b>${esc(label)}</b>${!item.ready && item.advice ? `<small>${esc(item.advice)}</small>` : ''}</div>${badge(item.ready, text, text, true)}</div>`;
  };
  return line('　└ faster-whisper', whisper.fasterWhisper, (item) => `可使用 ${item.version || ''}・${item.model || ''}`.trim())
    + line('　└ whisper.cpp 備援', whisper.whisperCpp, (item) => `可使用・${item.model || ''}（${BACKEND_TEXT[item.backend] || item.backend}）`);
}

/** Home-screen mode picker. `mode` = 'video'|'audio'. */
export function renderModePanel(env, mode) {
  if (!env) return '<p class="mode-note">正在檢查錄影／錄音環境…</p>';
  if (mode === 'audio') {
    const ready = env.modes.audio.ready;
    return ready ? '<p class="mode-note good">錄音裝置已選好。按「開始學習」後，會錄下你在設定中選擇的裝置。</p>'
      : `<div class="mode-guide"><b>${esc(reasonText(env.modes.audio.reason))}</b><p>${env.modes.audio.reason === 'AUDIO_DEVICE_NOT_SELECTED' ? '到「設定 → 音訊裝置」選一個裝置。若要錄電腦播放的聲音，需要啟用「立體聲混音」或安裝虛擬音訊線。' : '請先完成安裝。'}</p><button class="mini-button" data-goto="settingsView" type="button">前往設定</button></div>`;
  }
  if (env.modes.video.ready) return `<p class="mode-note good">OBS 已連線${env.obs.recording ? '（OBS 目前已在錄影，請先在 OBS 停止）' : ''}。按「開始學習」會由 OBS 開始錄影，OBS 確認後才算開始。</p>`;
  const notInstalled = env.modes.video.reason === 'OBS_NOT_INSTALLED';
  return `<div class="mode-guide"><b>${esc(reasonText(env.modes.video.reason))}</b>
    ${notInstalled ? '<ol><li>到 OBS 官方網站 <a href="https://obsproject.com/" target="_blank" rel="noopener">obsproject.com</a> 下載安裝。</li><li>打開 OBS →「工具」→「WebSocket 伺服器設定」→ 勾選「啟用 WebSocket 伺服器」。</li><li>把密碼填到本程式「設定 → OBS 連線」。</li></ol>' : '<ol><li>打開 OBS。</li><li>「工具」→「WebSocket 伺服器設定」→ 勾選「啟用 WebSocket 伺服器」。</li><li>若有設定密碼，到「設定 → OBS 連線」填入。</li></ol>'}
    <p>${env.obs.installed && env.modes.video.reason === 'OBS_WEBSOCKET_UNREACHABLE' ? '直接按「開始錄影學習」會嘗試在背景啟動 OBS；如果仍連不上，再依上方步驟開啟 WebSocket。' : '不想裝 OBS？改選「錄音」模式即可使用。'}</p>
    <label class="check-row"><input id="manualTimer" type="checkbox">我會自己在 OBS 錄影，這裡只計時（本程式不會控制或確認 OBS）</label></div>`;
}

/** Whether "開始學習" may be pressed for the chosen mode. */
export function canStart(env, mode, { acknowledged, manualTimer }) {
  if (!env || !acknowledged) return false;
  if (mode === 'audio') return env.modes.audio.ready;
  return env.modes.video.ready || (env.obs.installed && env.modes.video.reason === 'OBS_WEBSOCKET_UNREACHABLE') || manualTimer === true;
}

/** Text for the live learning card. All facts come from GET /api/learning. */
export function liveText(session) {
  if (!session?.active) return session?.interrupted ? { label: '需要你處理', title: '上次的錄音在程式關閉時中斷', hint: '已錄到的部分會保留；請到處理中心確認後重新開始。' } : { label: '準備開始', title: '今天想學什麼？', hint: '先選擇錄影或錄音，再按開始。' };
  if (session.mode === 'audio' && session.capture?.confirmed) return { label: '錄音中', title: '正在錄下選定的音訊裝置', hint: '可以專心看課；按快捷鍵留下重點。按「結束」後會自動送去轉錄。' };
  if (session.capture?.kind === 'obs' && session.capture.confirmed) return { label: 'OBS 錄影中', title: 'OBS 已確認開始錄影', hint: '可以專心看課；按「結束」會請 OBS 停止錄影。' };
  // Manual timer, legacy timer (no capture info) or anything unconfirmed: never claim a recording.
  return { label: '只計時中', title: '本程式沒有連接 OBS', hint: '請以 OBS 畫面確認是否真的在錄影。結束時先停止 OBS，再按結束。' };
}

function phaseCell(phase) {
  const pct = Math.round((phase.progress || 0) * 100);
  return `<li class="phase ${esc(phase.state)}"><div class="phase-head"><b>${esc(phase.label)}</b><span class="state-chip ${esc(phase.state)}">${esc(STATE_LABEL[phase.state] || phase.state)}</span></div>
    ${phase.state === 'running' ? `<div class="bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></div>` : ''}
    ${phase.note ? `<small>${esc(phase.note)}</small>` : ''}
    ${phase.error ? `<div class="phase-error"><b>${esc(phase.error.message)}</b><small>${esc(phase.error.hint || '')}</small><code>${esc(phase.error.code)}</code></div>` : ''}</li>`;
}

/** Processing centre. `view` comes from GET /api/processing. */
export function renderProcessing(view, filter = 'all') {
  if (!view) return '<div class="empty-list">讀取中…</div>';
  const items = view.items.filter((item) => filter === 'all' || item.overall === filter);
  if (!items.length) return `<div class="empty-list">${filter === 'all' ? '目前沒有處理中的工作。錄好的課程會自動出現在這裡。' : '這個分類沒有工作。'}</div>`;
  return items.map((item) => `<article class="process-card ${esc(item.overall)}" data-id="${esc(item.id)}">
    <header><div><b>${esc(item.title)}</b><small>${esc(SOURCE_LABEL[item.source] || '')}${item.createdAt ? ` · ${esc(new Date(item.createdAt).toLocaleString('zh-TW'))}` : ''}</small></div><span class="state-chip ${esc(item.overall)}">${esc(STATE_LABEL[item.overall])}</span></header>
    <ol class="phases">${item.phases.map(phaseCell).join('')}</ol>
    ${item.actions.length ? `<footer>${item.actions.map((action) => `<button class="mini-button" type="button" data-action="${esc(action.type)}" data-job="${esc(action.jobId || '')}" data-course="${esc(action.courseId || '')}" data-title="${esc(action.currentTitle || '')}">${esc(action.label)}</button>`).join('')}</footer>` : ''}
  </article>`).join('');
}

export function renderCounts(counts = {}) {
  return ['needs-user', 'running', 'waiting', 'done'].map((key) => `<button class="count-tab" type="button" data-filter="${key}">${esc(STATE_LABEL[key])} <b>${Number(counts[key] || 0)}</b></button>`).join('');
}

const optionList = (options, value) => options.map((option) => `<option value="${esc(option.value)}"${option.value === value ? ' selected' : ''}>${esc(option.label)}</option>`).join('');
const secretField = (key, label, state) => `<label>${esc(label)}<input type="password" data-secret="${esc(key)}" autocomplete="off" spellcheck="false" placeholder="${state?.configured ? '已設定（不會顯示）' : '尚未設定'}"><span class="secret-state">${state?.configured ? '已設定' : '未設定'}${state?.configured ? ` <button class="link-button" type="button" data-clear="${esc(key)}">清除</button>` : ''}</span></label>`;

/** Settings form. `settings` comes from GET /api/settings (secrets only as { configured }). */
export function renderSettingsForm(settings) {
  if (!settings) return '<div class="empty-list">讀取設定中…</div>';
  const { values: v, options: o, secrets: s } = settings;
  return `
  <section class="settings-group"><h3>預設學習模式</h3><div class="mode-choice">${o.learningMode.map((option) => `<label class="mode-option"><input type="radio" name="learningMode" value="${esc(option.value)}"${option.value === v.learningMode ? ' checked' : ''}><span>${esc(option.label)}</span></label>`).join('')}</div></section>
  <section class="settings-group"><h3>轉錄（Whisper）</h3>
    <label>轉錄工具<select data-key="transcriber">${optionList(o.transcriber, v.transcriber)}</select></label>
    <label>模型<select data-key="whisperModel">${optionList(o.whisperModel, v.whisperModel)}</select></label>
    <label>語言<select data-key="whisperLanguage">${optionList(o.whisperLanguage, v.whisperLanguage)}</select></label>
    ${o.whisperCppBackend ? `<label>whisper.cpp 執行方式<select data-key="whisperCppBackend">${optionList(o.whisperCppBackend, v.whisperCppBackend)}</select></label>` : ''}
    <p class="hint">「自動」會先用 faster-whisper；只有它無法在這台電腦執行（例如被 Windows 智慧型應用程式控制擋下）時才改用 whisper.cpp，不需要關閉任何安全防護。whisper.cpp 需要模型檔 models\\whisper\\ggml-&lt;模型&gt;.bin。轉錄設定在重新啟動程式後生效。</p></section>
  <section class="settings-group"><h3>翻譯與重點整理</h3>
    <div class="ai-mode-summary"><b>三層模式</b><ol><li>基礎模式：逐字稿、字幕、搜尋與規則式整理，不需要 AI。</li><li>本機 AI：使用 Ollama，逐字稿不離開電腦。</li><li>外部 AI：使用自己的 OpenAI／Gemini 金鑰，送出前必須明確允許。</li></ol></div>
    <label>AI 執行方式<select data-key="aiProvider">${optionList(o.aiProvider, v.aiProvider)}</select></label>
    <label>重點整理<select data-key="knowledgeMode">${optionList(o.knowledgeMode, v.knowledgeMode)}</select></label>
    <label>摘要詳細程度<select data-key="summaryDetail">${optionList(o.summaryDetail, v.summaryDetail)}</select></label>
    <div class="provider-fields" data-provider="ollama"><label>Ollama 模型<input data-key="ollamaModel" value="${esc(v.ollamaModel)}" maxlength="80"></label></div>
    <div class="provider-fields" data-provider="openai"><label>模型<input data-key="openaiModel" value="${esc(v.openaiModel)}" maxlength="80"></label><label>API 位址（https）<input data-key="openaiBaseUrl" value="${esc(v.openaiBaseUrl)}" maxlength="200"></label>${secretField('openaiApiKey', 'OpenAI API 金鑰', s.openaiApiKey)}</div>
    <div class="provider-fields" data-provider="gemini"><label>模型<input data-key="geminiModel" value="${esc(v.geminiModel)}" maxlength="80"></label>${secretField('geminiApiKey', 'Gemini API 金鑰', s.geminiApiKey)}</div>
    <label>翻譯（獨立開關）<select data-key="translationLanguage">${optionList(o.translationLanguage || [{ value: 'none', label: '不翻譯（預設）' }], v.translationLanguage || 'none')}</select></label>
    <label>外部 AI 傳送授權<select data-key="externalTranscriptSharing">${optionList(o.externalTranscriptSharing || [{ value: 'disabled', label: '不允許（預設）' }], v.externalTranscriptSharing || 'disabled')}</select></label>
    <p class="hint translation-privacy"><b>兩個功能互相獨立：</b>可以只做 AI 重點整理、不翻譯，也可以只翻譯。沒有 AI 或模型不可用時，課程仍會完成逐字稿與基礎整理。Ollama 在這台電腦上執行；OpenAI／Gemini 會把逐字稿文字傳送到該外部服務，且程式不會自動改用外部 AI。</p>
    <p class="hint">要使用本機 AI，請先安裝 Ollama 並下載設定中的模型；模型通常很大，因此分享版不會強制附帶或自動下載。</p>
    <p class="hint">金鑰只存在這台電腦的 config.json（不會進 Git），畫面上永遠只顯示「已設定」。</p></section>
  <section class="settings-group"><h3>OBS 連線</h3>
    <label>WebSocket 位址（只能是本機）<input data-key="obsUrl" value="${esc(v.obsUrl)}" maxlength="100"></label>
    ${secretField('obsPassword', 'WebSocket 密碼', s.obsPassword)}
    <p class="hint">OBS →「工具」→「WebSocket 伺服器設定」可以看到密碼。修改後請重新啟動程式。</p></section>`;
}

/** Audio device list. `result` from GET /api/audio/devices, or an error object. */
export function renderAudioDevices(result) {
  if (!result) return '<p class="hint">按「列出裝置」讀取這台電腦的音訊裝置。</p>';
  if (result.error) return `<p class="hint warn">${esc(result.error === 'AUDIO_DEVICE_LISTING_UNSUPPORTED' ? '錄音裝置清單目前只支援 Windows。' : result.error === 'FFMPEG_UNAVAILABLE' ? '找不到 ffmpeg，請先執行 Setup.ps1。' : '無法讀取裝置清單。')}</p>`;
  if (!result.devices?.length) return '<p class="hint warn">ffmpeg 沒有看到任何音訊裝置。</p>';
  return `<div class="device-list">${result.devices.map((device, index) => `<label class="device-option"><input type="radio" name="audioDevice" value="${index}"${device.name === result.selected ? ' checked' : ''}><span>${esc(device.name)}${device.hint === 'possible-system-audio' ? '<small>可能是電腦播放的聲音（依名稱推測）</small>' : ''}</span></label>`).join('')}</div>
    <p class="hint">本程式只錄你選的這個裝置。Windows 不一定能直接錄到電腦播放的聲音，需要「立體聲混音」或虛擬音訊線。</p>`;
}

/** Collects the settings patch from form values. Empty secret inputs are ignored (unchanged). */
export function buildSettingsPatch(fields, secretInputs, clears = []) {
  const values = {};
  for (const [key, value] of Object.entries(fields)) values[key] = key === 'chapterMinutes' ? Number(value) : value;
  const secrets = {};
  for (const [key, value] of Object.entries(secretInputs)) if (typeof value === 'string' && value.trim()) secrets[key] = { set: value.trim() };
  for (const key of clears) secrets[key] = { clear: true };
  return { values, secrets };
}
