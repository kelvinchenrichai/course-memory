import { renderBackupCourses, renderBackupSettings, renderBackupSummary } from './backup-view.js';

// P4D wiring for the 雲端備份 page. All state comes from /api/backup (no paths, no account).
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const api = async (url, options = {}) => {
  const response = await fetch(url, { ...options, headers: { ...(options.body ? { 'content-type': 'application/json' } : {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.message || data.error || '操作失敗'), { code: data.error });
  return data;
};
const toast = (message) => { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(el._timer); el._timer = setTimeout(() => el.classList.remove('show'), 2800); };
let status = null; let remotes = [];
const visible = () => !$('#backupView').classList.contains('hidden');

function render() {
  $('#backupSummary').innerHTML = renderBackupSummary(status);
  $('#backupCourses').innerHTML = renderBackupCourses(status);
  $('#backupCleanup')?.addEventListener('click', cleanup);
  $$('[data-backup-retry]').forEach((button) => button.onclick = () => post('/api/backup/retry', { courseId: button.dataset.backupRetry }, '已重新排入備份'));
  $$('[data-backup-run]').forEach((button) => button.onclick = () => post('/api/backup/run', { courseId: button.dataset.backupRun }, '開始備份這堂課'));
  const badge = $('#backupBadge'); const failed = status?.counts?.failed || 0;
  badge.textContent = failed; badge.classList.toggle('hidden', !failed);
}

async function refresh() { try { status = await api('/api/backup'); render(); } catch {} }
async function post(url, body, message) { try { await api(url, { method: 'POST', body: JSON.stringify(body || {}) }); toast(message); setTimeout(refresh, 800); } catch (error) { toast(error.message); } }

async function cleanup() {
  if (!confirm('只會刪除「已在雲端驗證過大小」的本機錄影／錄音原檔，逐字稿與知識包會保留。確定要清理嗎？')) return;
  try { const result = await api('/api/backup/cleanup', { method: 'POST', body: JSON.stringify({ confirm: true }) }); toast(`已清理 ${result.removedCount} 個檔案`); refresh(); } catch (error) { toast(error.message); }
}

async function openSettings() {
  try { remotes = (await api('/api/backup/remotes')).remotes; } catch { remotes = []; }
  $('#backupSettings').innerHTML = renderBackupSettings(status, remotes);
}

$('#backupSettingsForm').onsubmit = async (event) => {
  event.preventDefault();
  const body = { cleanupPolicy: $('#backupPolicy').value, autoUpload: $('#backupAuto').checked, warnFreeGb: Number($('#backupWarn').value) };
  const remote = $('#backupRemote')?.value; const folder = $('#backupFolder')?.value.trim();
  if (remote && folder) body.destination = `${remote}:${folder}`;
  try { status = await api('/api/backup/settings', { method: 'PUT', body: JSON.stringify(body) }); render(); toast('備份設定已儲存'); } catch (error) { toast(error.message); }
};
$('#backupRun').onclick = () => post('/api/backup/run', {}, '開始備份');
$('#backupCheck').onclick = async () => { try { status = await api('/api/backup/check', { method: 'POST', body: '{}' }); render(); } catch (error) { toast(error.message); } };
document.querySelector('.nav-item[data-view="backupView"]')?.addEventListener('click', async () => { await refresh(); openSettings(); });
refresh(); setInterval(() => { if (visible() || status?.running) refresh(); }, 3000);
